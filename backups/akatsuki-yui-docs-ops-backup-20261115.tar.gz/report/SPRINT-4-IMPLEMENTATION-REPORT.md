# SPRINT 4 IMPLEMENTATION REPORT — SPRINT MANAGEMENT, PRODUCT BACKLOG & KANBAN BOARD

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 4 — Sprint Management, Product Backlog & Kanban Board  
**Status:** Completed & Verified  
**Architecture:** Modular Monolith (Next.js 16 App Router + TypeScript 5.9 + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5)  
**Working Tree Note:** Chưa thực hiện `git commit` hoặc `git push`; toàn bộ thay đổi Sprint 4 đang nằm trên nhánh `feat/sprint3-task-management` để Leader/PO review trước khi commit.

---

## 1. Executive Summary

Sprint 4 đã hoàn thiện đầy đủ end-to-end phân hệ **Sprint Management, Product Backlog, Kanban Board, Sprint Completion và Sprint Progress & Burndown Chart** trên nền Modular Monolith hiện hữu, tuân thủ `report/SPRINT-4-IMPLEMENTATION-PLAN.md` và toàn bộ các quyết định nghiệp vụ `DEC-026`–`DEC-033` đã được xác nhận trong `markdown/DECISION-LOG.md`:

1. **Sprint Core & Lifecycle (`DEC-006`, `DEC-026`, `DEC-027`, `DEC-028`):**
   - Triển khai `SprintStatus` (`PLANNED`, `ACTIVE`, `COMPLETED`, `CANCELLED`), cho phép nhiều `ACTIVE` Sprint đồng thời trong một Project (`DEC-006`).
   - Ràng buộc **chỉ Project `ACTIVE`** mới được Activate Sprint (`CREATED` -> `409 INVALID_STATUS_TRANSITION`, `ARCHIVED` -> `409 PROJECT_ARCHIVED`).
   - Hỗ trợ Activate Sprint trước `startDate` (giữ nguyên `startDate`), cho phép trùng khoảng thời gian giữa các Sprint kèm cảnh báo không chặn `meta.overlappingSprints`.
   - Khóa `startDate` khi Sprint đang `ACTIVE` (chỉ sửa `name`, `goal`, `endDate >= startDate`), bất biến khi `COMPLETED` / `CANCELLED`.
   - Cho phép Cancel (`PLANNED -> CANCELLED`) **chỉ áp dụng cho Sprint `PLANNED`**, tự động trả toàn bộ Task chưa `DONE` về Product Backlog kèm `TaskHistory` (`SPRINT_REMOVED`). Sprint `ACTIVE` không thể Cancel và bắt buộc kết thúc qua Complete Sprint.

2. **Product Backlog & Sprint Planning (`DEC-029`, `DEC-030`):**
   - `Task.sprintId = NULL` biểu diễn Product Backlog mà không nhân bản dữ liệu Task.
   - `createTaskSchema` giữ nguyên quy tắc luôn khởi tạo Task vào Product Backlog (`sprintId = NULL`).
   - Bổ sung tìm kiếm & lọc Backlog theo độ ưu tiên (`priority`), người thực hiện (`assigneeId` / `unassignedOnly`), quá hạn (`overdueOnly`), khoảng deadline (`deadlineFrom` / `deadlineTo` theo múi giờ `Asia/Ho_Chi_Minh`), và chọn nhiều Task để đưa vào Sprint `PLANNED` / `ACTIVE`.
   - Hỗ trợ di chuyển trực tiếp Task giữa hai Sprint `PLANNED`/`ACTIVE` trong cùng Project hoặc trả về Product Backlog; cảnh báo trên UI khi Task đang ở trạng thái `REVIEW`, chặn di chuyển/phân bổ Task đã `DONE` (`409 TASK_ALREADY_COMPLETED`), và ghi nhận `TaskHistory` (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`).

3. **Strict Complete Sprint Workflow (`DEC-007`, `DEC-031`):**
   - Không có `KEEP_IN_SPRINT` ở schema, API, actions và UI.
   - Mọi Task `DONE` giữ nguyên `sprintId`; 100% Task chưa `DONE` phải có disposition rõ ràng (`MOVE_TO_BACKLOG` hoặc `MOVE_TO_SPRINT` sang một Sprint `PLANNED`/`ACTIVE` khác trong cùng Project).
   - Bảo đảm invariant không còn Task chưa `DONE` nào nằm trong Sprint sau khi chuyển `COMPLETED`; dùng row lock + optimistic concurrency (`expectedUpdatedAt`, `expectedStatus`) để trả `409 CONFLICT` / `409 SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION` khi trạng thái bị thay đổi đồng thời.

4. **Kanban Board 4 Cột (`DEC-032`):**
   - 4 cột cố định (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`) với 3 phạm vi (`PROJECT`, `SPRINT`, `BACKLOG`) và bộ lọc Search / Priority / Assignee / Unassigned / Overdue.
   - Desktop hỗ trợ HTML5 Native Drag & Drop (`draggable`, `onDragStart`, `onDragOver`, `onDrop`) kết hợp nút thao tác nhanh; Mobile và bàn phím thao tác 100% qua Action Buttons (không cài `@dnd-kit`).
   - Toàn bộ chuyển trạng thái gọi trực tiếp Sprint 3 Task Workflow Services (`updateTaskStatusAction`, `TaskReviewModal`), tự động rollback card và hiển thị thông báo lỗi khi vi phạm Dependency Gate hoặc quyền hạn.

5. **Sprint Progress & Pure SVG Burndown Chart (`DEC-017`, `DEC-033`):**
   - Tiến độ Sprint tính chặt theo tỷ lệ Task hoàn thành (`DONE Tasks / Total Tasks * 100%`).
   - Burndown Chart vẽ trực tiếp bằng **Pure SVG** (không cài `recharts`), sử dụng `Estimate Hours`, múi giờ `Asia/Ho_Chi_Minh` (`+07:00`), tái dựng scope/remaining hàng ngày từ `Task` + `TaskHistory` (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`, `completedAt`), hiển thị cảnh báo khi thiếu dữ liệu Estimate Hours và liệt kê rõ giới hạn tính toán.

---

## 2. Database & Migration (`20261115072731_sprint4_sprint_management_backlog_kanban`)

- **Schema (`prisma/schema.prisma`):**
  - **Enum mới:** `SprintStatus` (`PLANNED`, `ACTIVE`, `COMPLETED`, `CANCELLED`).
  - **Enum mở rộng:** `TaskHistoryAction` bổ sung `SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`.
  - **Model mới:** `Sprint` với `startDate` / `endDate` kiểu `@db.Date`, `activatedAt`, `completedAt`, `cancelledAt`, `@@unique([projectId, id])`, các index `[projectId, status]`, `[projectId, startDate, endDate]`, `[createdById]`.
  - **Cập nhật quan hệ:** `Task.sprintId` (`@db.Uuid`, `onDelete: SetNull`), index `[projectId, sprintId, status]`, `[sprintId, status]`; quan hệ ngược `User.createdSprints` và `Project.sprints`.
- **PostgreSQL Custom Constraints, Partial Index & Trigger (`prisma/migrations/20261115072731_sprint4_sprint_management_backlog_kanban/migration.sql`):**
  - Partial Index `Task_projectId_backlog_deadline_idx` trên `"Task"("projectId", "deadline") WHERE "sprintId" IS NULL`.
  - Check Constraint `Sprint_date_range_chk`: `"endDate" >= "startDate"`.
  - Check Constraint `Sprint_name_nonempty_chk`: `length(btrim("name")) > 0`.
  - Check Constraint `Sprint_status_timestamps_chk`: đảm bảo `"completedAt" IS NOT NULL` khi `COMPLETED` và `"cancelledAt" IS NOT NULL` khi `CANCELLED`.
  - Trigger `trg_task_sprint_same_project` + hàm `check_task_sprint_same_project()` (`ERRCODE = '23514'`): chặn ở tầng PostgreSQL mọi thao tác gán Task vào Sprint thuộc Project khác.

---

## 3. Modules, Services, Actions & Shared Extensions

### 3.1. Sprint Module (`src/modules/sprints/*`)
- `src/modules/sprints/sprint.schema.ts`: Zod v4 schemas và helpers (`parseSprintCalendarDate`, `formatSprintDateYmd`, `sprintListQuerySchema`, `createSprintSchema`, `updateSprintSchema`, `cancelSprintSchema`, `sprintPlanningAssignSchema`, `moveSprintTaskSchema`, `sprintTaskDispositionItemSchema`, `completeSprintSchema`, `kanbanQuerySchema`).
- `src/modules/sprints/sprint.access.ts`: AuthZ/access helpers (`parseSprintInput`, `parseSprintId`, `assertSprintReadAccess`, `assertSprintManageAccess`, `assertProjectActiveForSprintActivation`, `assertProjectNotArchivedForSprintMutation`), advisory lock `acquireSprintPlanningLock` (`SELECT pg_advisory_xact_lock(hashtext(${lockKey}))::text AS locked`) và `FOR SHARE`/`FOR UPDATE` row locks (`lockProjectRowForSprintMutation`, `lockSprintTasksForUpdate`, `lockSingleTaskForUpdate`).
- `src/modules/sprints/sprint.repository.ts`: `sprintRepository` và tính toán thống kê Sprint (`computeSprintTaskStats` — tổng Task, trạng thái, quá hạn, `progressPercent`, tổng/hoàn thành/còn lại Estimate Hours), overlap query, danh sách Target Sprint, Completion Preview query và Burndown source query.
- `src/modules/sprints/sprint.service.ts`: `listProjectSprintsService`, `getSprintDetailService`, `createSprintService`, `updateSprintService`, `activateSprintService`, `cancelSprintService`.
- `src/modules/sprints/sprint-planning.service.ts`: `listBacklogTasksService`, `assignTasksToSprintService`, `moveSprintTaskService` (serialize bằng advisory lock + `Task` row lock, ghi `TaskHistory`).
- `src/modules/sprints/sprint-completion.service.ts`: `getSprintCompletionPreviewService`, `completeSprintService` (kiểm tra 100% Task chưa `DONE`, chặn mọi `KEEP_IN_SPRINT`, `TaskHistory` atomically trong `$transaction`).
- `src/modules/sprints/kanban.service.ts`: `getKanbanBoardService` (nhóm 4 cột, giới hạn `MAX_KANBAN_CARDS = 250` với cờ `truncated`, tính `permissions` từng card dựa trên quyền và `TaskAssignee`).
- `src/modules/sprints/sprint-analytics.service.ts`: `getSprintProgressAndBurndownService` & `computeSprintBurndownAnalytics` (tính theo `BURNDOWN_TIMEZONE = "Asia/Ho_Chi_Minh"`).
- `src/modules/sprints/sprint-route-helpers.ts`: `extractSearchParams`, `normalizePageSearchParams`, `parseOptionalJsonBody`.
- `src/modules/sprints/sprint.actions.ts`: 7 Server Actions (`createSprintAction`, `updateSprintAction`, `activateSprintAction`, `cancelSprintAction`, `assignTasksToSprintAction`, `moveSprintTaskAction`, `completeSprintAction`) kèm `revalidateSprintPaths`.

### 3.2. Shared Updates to Existing Modules
- `src/types/api.ts`: Bổ sung các error codes Sprint 4 (`SPRINT_NOT_FOUND`, `SPRINT_INVALID_STATUS`, `SPRINT_DATE_INVALID`, `SPRINT_TASK_ALREADY_ASSIGNED`, `SPRINT_NOT_PLANNING_ELIGIBLE`, `SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION`, `SPRINT_INVALID_DISPOSITION_TARGET`, `TASK_ALREADY_COMPLETED`).
- `src/modules/projects/project.service.ts`: Bổ sung `FOR UPDATE` row lock trên `"Project"` trong `archiveProjectService` để serialize cuộc đua Archive Project vs Sprint Mutation.
- `src/modules/tasks/task.schema.ts`: Mở rộng `taskListQuerySchema` thêm `sprintId`, `backlogOnly`, `deadlineFrom`, `deadlineTo` (chuẩn hóa biên ngày `+07:00`).
- `src/modules/tasks/task.repository.ts`: Thêm `sprintId?` & `sprint?` trên `TaskSummaryDTO` (giữ tương thích mock Sprint 3), export `buildTaskProjectWhereInput`, `taskSummarySelect`, `mapTaskSummary`.
- `src/modules/tasks/task.actions.ts`: Cập nhật `revalidateTaskPaths` để revalidate thêm `/projects/[projectId]/backlog`, `/projects/[projectId]/kanban`, `/projects/[projectId]/sprints`.
- `vitest.config.mts`: Cấu hình `fileParallelism: false` để các file PostgreSQL integration tests không xung đột partial unique index `Project_single_active_idx` trên cùng DB thật.

---

## 4. REST API Route Handlers (`/api/v1/*`)

11 Route Handlers mới được triển khai đầy đủ theo chuẩn `{ data, meta? }` / `{ error }`:

- `GET / POST /api/v1/projects/[projectId]/sprints` *(trả `meta.overlappingSprints` nếu có trùng lịch)*
- `GET /api/v1/projects/[projectId]/backlog` *(trả `PaginationMeta`: `page`, `pageSize`, `total`, `totalPages`)*
- `GET /api/v1/projects/[projectId]/kanban`
- `GET / PATCH /api/v1/sprints/[sprintId]` *(không có `DELETE` theo `DEC-026`)*
- `POST /api/v1/sprints/[sprintId]/activate`
- `POST /api/v1/sprints/[sprintId]/cancel` *(hỗ trợ body rỗng hoặc `{ reason }`)*
- `GET /api/v1/sprints/[sprintId]/completion-preview`
- `POST /api/v1/sprints/[sprintId]/complete`
- `PUT /api/v1/sprints/[sprintId]/tasks`
- `POST /api/v1/sprints/[sprintId]/tasks/[taskId]/move`
- `GET /api/v1/sprints/[sprintId]/burndown`

---

## 5. UI Components & Pages Implemented

### 5.1. Shared & Task UI Updates
- `src/components/shared/status-badge.tsx`: Bổ sung `SprintStatusBadge`.
- `src/components/layout/app-shell.tsx`: Cập nhật footer sidebar thành `Sprint 4 · Sprints, Backlog & Kanban`.
- `src/components/tasks/task-history-timeline.tsx`: Bổ sung nhãn tiếng Việt cho `SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`.
- `src/components/tasks/task-detail-panel.tsx` & `src/components/tasks/task-list-client.tsx`: Hiển thị badge liên kết tới Sprint hoặc Product Backlog; thêm liên kết điều hướng nhanh tới Backlog, Sprints, Kanban từ danh sách Task.
- `src/app/(dashboard)/projects/[projectId]/page.tsx` & `src/components/sprints/project-sprint-summary-card.tsx`: Tích hợp Card **Sprint, Product Backlog & Kanban Board** trên trang chi tiết Project.

### 5.2. Sprint, Backlog & Kanban UI Components
- `src/components/sprints/sprint-list-client.tsx`: Danh sách Sprint theo Project kèm bộ lọc trạng thái/từ khóa, thanh tiến độ theo Task và quick links Kanban / Edit / Detail.
- `src/components/sprints/sprint-form.tsx`: Form Tạo / Sửa Sprint (khóa `startDate` khi Sprint `ACTIVE`, cảnh báo overlap sau khi lưu).
- `src/components/sprints/sprint-detail-client.tsx`: Trang điều phối chi tiết Sprint (Activate, Edit, Cancel có modal xác nhận, Complete Modal, Add from Backlog Dialog, Move Task về Backlog / Sprint khác có cảnh báo cho Task `REVIEW`, khóa nút chuyển trên Task `DONE`, Activity Feed).
- `src/components/sprints/assign-backlog-dialog.tsx`: Dialog chọn Task từ Product Backlog đưa vào Sprint đang xem.
- `src/components/sprints/sprint-complete-modal.tsx`: Modal hoàn thành Sprint sử dụng Radix Dialog, tải trực tiếp `completion-preview`, chỉ hỗ trợ `MOVE_TO_BACKLOG` hoặc `MOVE_TO_SPRINT`, hỗ trợ áp dụng nhanh hàng loạt và tự reload preview khi gặp `409 CONFLICT`.
- `src/components/sprints/sprint-burndown-chart.tsx`: Thanh tiến độ theo Task + Biểu đồ Burndown **Pure SVG** với mốc ngày `Asia/Ho_Chi_Minh`, node inspect tương tác, cảnh báo thiếu dữ liệu Estimate Hours và ghi chú giới hạn tính toán.
- `src/components/backlog/backlog-list-client.tsx` & `src/components/backlog/add-to-sprint-dialog.tsx`: Danh sách Product Backlog với bộ lọc tìm kiếm/priority/assignee/overdue/deadline range/sort, chọn nhiều Task để đưa vào Sprint Planning.
- `src/components/kanban/kanban-board-client.tsx` & `src/components/kanban/kanban-task-card.tsx`: Kanban Board 4 cột (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`), chuyển scope `PROJECT | SPRINT | BACKLOG`, bộ lọc, HTML5 Native DnD (desktop) + nút thao tác trực tiếp trên card (desktop/mobile/keyboard), tái sử dụng `TaskReviewModal`, tự rollback optimistic UI khi API/Action báo lỗi.

### 5.3. App Router Pages (`src/app/(dashboard)/projects/[projectId]/`)
- `sprints/page.tsx`: Danh sách Sprints của Project.
- `sprints/new/page.tsx`: Khởi tạo Sprint (`sprint.manage`, Project Leader/Admin, khóa khi `ARCHIVED`).
- `sprints/[sprintId]/page.tsx`: Chi tiết Sprint, Burndown Chart, danh sách Task & thao tác vòng đời Sprint.
- `sprints/[sprintId]/edit/page.tsx`: Chỉnh sửa Sprint (`PLANNED` sửa tất cả; `ACTIVE` khóa `startDate`; `COMPLETED`/`CANCELLED`/`ARCHIVED` khóa sửa).
- `backlog/page.tsx`: Trang Product Backlog & Sprint Planning của Project.
- `kanban/page.tsx`: Trang Kanban Board 4 cột.

---

## 6. Verification Summary & Test Suites

Toàn bộ các bước kiểm tra dưới đây được chạy trực tiếp sau lần chỉnh sửa code cuối cùng và đều đạt kết quả thành công (0 lỗi, 0 warning, 0 test skipped):

| Check / Suite | Command | Result |
|---|---|---|
| Guard Check (`KEEP_IN_SPRINT` in `src` & `prisma`) | `Select-String` trên `src/` và `prisma/` | 0 matches — `KEEP_IN_SPRINT` chỉ tồn tại trong negative assertion của unit test (exit 0) |
| Prisma Schema Validate | `npx prisma validate` | Valid (exit 0) |
| Prisma Migration Status | `npx prisma migrate status` | 4 migrations found, database schema is up to date (exit 0) |
| Prettier Format Check (Sprint 4 files) | `npx prettier --check` *(các file Sprint 4 tạo mới/chỉnh sửa)* | All matched files use Prettier code style (exit 0) |
| ESLint | `npm run lint` (`eslint .`) | Passed — 0 errors, 0 warnings (exit 0) |
| TypeScript Check | `npm run typecheck` (`tsc --noEmit`) | Passed — 0 errors (exit 0) |
| Unit & PostgreSQL Integration Tests | `npm run test` (`vitest run`) | **16 test files passed (16), 104 tests passed (104), 0 skipped** (exit 0) |
| Production Build | `npm run build` (`next build`) | Compiled & built cleanly — **16/16 static pages**, **70 route entries** (`/_not-found` + 69 app/API routes) (exit 0) |

> **Lưu ý về `npm run format:check` toàn repo:** Lệnh `format:check` mặc định quét cả các file Sprint 1/2 cũ không chỉnh sửa trong Sprint 4; toàn bộ file được tạo mới hoặc chỉnh sửa trong Sprint 4 đều đã được kiểm tra pass `npx prettier --check`.

### 6.1. Test Suites Added in Sprint 4 (`3 files, 24 tests`)
- `tests/unit/sprint4-services.test.ts` (**14 tests**): Validation ngày/tên/`KEEP_IN_SPRINT` rejection, Sprint Lifecycle (`CREATED` block activate, `ACTIVE` multiple, `startDate` lock, `COMPLETED`/`CANCELLED` immutable, Cancel chỉ `PLANNED`), Planning (`TASK_ALREADY_COMPLETED`, `REVIEW` allowed, cross-project/done guards), Complete Sprint disposition rules, Kanban scope & filter/truncation, Pure Burndown reconstruction (`Asia/Ho_Chi_Minh`, missing/zero estimates).
- `tests/unit/sprint4-api-routes.test.ts` (**5 tests**): Contract tests `200`/`201`/`400`/`401`/`403`/`404`/`409` cho toàn bộ 11 endpoint Sprint 4, kiểm tra `meta.overlappingSprints`, Backlog pagination `meta`, empty/invalid JSON trên `/cancel`, và xác nhận vắng mặt `DELETE /api/v1/sprints/[sprintId]`.
- `tests/integration/sprint4-db.test.ts` (**5 tests**): Real PostgreSQL CHECK constraints & trigger `trg_task_sprint_same_project`, real Sprint Lifecycle (`PLANNED`/`ACTIVE`/`CANCELLED` + `TaskHistory`), Backlog filters + Planning concurrency race (`pg_advisory_xact_lock`), Complete Sprint transaction rollback khi invalid target & concurrent Complete vs Approve/Planning races & Archive vs Sprint race, Kanban + Dependency Gate qua Workflow + Burndown reconstruction + Live RBAC revocation.

### 6.2. Regression Baseline Verified (Sprint 1–3)
- Sprint 1–3 test suites chạy đầy đủ trong `npm run test`: `auth-validation.test.ts` (8), `authorization-policy.test.ts` (4), `user-service.test.ts` (6), `password.test.ts` (1), `button-slot.test.ts` (2), `api-routes.test.ts` (6), `sprint1-db.test.ts` (3), `sprint2-services.test.ts` (11), `sprint2-api-routes.test.ts` (5), `sprint2-db.test.ts` (3), `sprint3-task-services.test.ts` (21), `sprint3-api-routes.test.ts` (5), `sprint3-db.test.ts` (5).

---

## 7. Out of Scope / Deferred to Later Sprints

- **Sprint 5:** Notification Center UI, Notification delivery & email worker tiêu thụ `emitTaskEventAfterCommit` / Sprint notifications, Task Comments / Discussions, File Uploads & Attachments.
- **Sprint 6:** Member Contribution Report & Advanced Analytics Dashboard (nếu nâng cấp biểu đồ interactive hoặc báo cáo đóng góp thành viên).

---

## 8. Local Verification Guide

```powershell
# 1. Verify Prisma migration state & run all Sprint 1-4 tests
npx prisma migrate status
npm run test

# 2. Verify lint, typecheck & production build
npm run lint
npm run typecheck
npm run build

# 3. Start local server for manual walkthrough
npm run dev
```

*Chưa thực hiện `git commit` hoặc `git push`; toàn bộ mã nguồn và báo cáo Sprint 4 đang sẵn sàng trên working tree để review và commit.*
