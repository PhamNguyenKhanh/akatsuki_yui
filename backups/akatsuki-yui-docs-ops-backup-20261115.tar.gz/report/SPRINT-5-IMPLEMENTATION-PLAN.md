# SPRINT 5 IMPLEMENTATION PLAN — DOCUMENT LIBRARY & NOTIFICATIONS

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 5 — Document Library & Notifications  
**Phase:** Planning Decisions: Confirmed — Ready for Execution Prompt  
**Baseline:** Sprint 1–4 Implementation (`42dd2e5` on `feat/sprint4-sprint-management-backlog-kanban`), `AGENT.md`, `markdown/*` Architecture & Business Specifications, `report/SPRINT-1..4-IMPLEMENTATION-REPORT.md`  
**Author:** Senior Software Architect / Technical Lead  

---

## 1. Executive Summary

### 1.1. Sprint 5 Planning Status

**Planning Decisions: Confirmed — Ready for Execution Prompt**

All 13 Open Questions (`OQ-01` through `OQ-13`) have been reviewed and confirmed by the Product Owner under Option A (`DEC-034` through `DEC-046`). No unresolved Product Decision blocks Sprint 5 execution.

### 1.2. Confirmed Sprint 5 Scope

Sprint 5 delivers two primary business domains and six core functional capabilities:

1. **Document Library** — Google Drive / Google Docs URL metadata management (`https://drive.google.com` and `https://docs.google.com` only), categorization (`SPECIFICATION`, `DESIGN`, `REPORT`, `OTHER`), optional same-project Sprint association, search/filter, and Soft Delete (`deletedAt DateTime?`).
2. **Notification Center** — In-app notification inbox (`/notifications`), header notification bell with unread count badge, read/unread state management (`Mark as Read`, `Mark as Unread`, `Mark All as Read`), and deep-link navigation to target entities.
3. **Notification Event Integration** — Durable transactional integration for all required business rules (`BR-NOTIF-001` through `BR-NOTIF-008`) across Account Management, Project Membership, and Task Workflow/Assignment.
4. **Email Delivery** — Outbound transactional email delivery via the **Resend API** (`resend@6.38.1`), supporting 1 initial attempt + maximum 3 automatic retries (`retryCount = 0..3`) with exponential backoff (`+1m`, `+5m`, `+15m`) and stable provider-level idempotency keys (`notification-delivery:${delivery.id}`).
5. **Deadline Reminder** — Daily scheduled batch processor (`TASK_DEADLINE_REMINDER`) scanning non-`DONE` Tasks whose deadline is approaching within `[now, now + 24h]` or recently overdue within `[now - 24h, now]` in `Asia/Ho_Chi_Minh`, deduplicated per `(taskId, recipientUserId, date)`.
6. **Delivery Monitoring** — Admin-only Delivery History (`/admin/notifications/deliveries`) and controlled Manual Retry governed by dedicated permissions (`notification.delivery.read`, `notification.delivery.retry`).

*Note: Project and Sprint lifecycle notifications (`PROJECT_ACTIVATED`, `PROJECT_ARCHIVED`, `SPRINT_STARTED`, `SPRINT_COMPLETED`) remain out of scope for Sprint 5.*

### 1.3. Key Architectural Decisions

- **Durable Transactional Persistence:** Domain mutations, `ActivityLog`/`AuditLog`, `Notification` (`IN_APP` state), and `NotificationDelivery` (`EMAIL`, `status = PENDING`) are persisted atomically inside the **same** `prisma.$transaction`. If notification persistence fails, the entire transaction rolls back.
- **Post-Commit Non-Blocking Dispatch (`after()`):** External Resend API calls never execute inside database transactions. Immediate email dispatch runs post-commit via Next.js `after()` (`next/server`), ensuring zero added latency or rollback risk if Resend is slow or unreachable.
- **Database-Backed Concurrency & Recovery:** Retryable/pending email deliveries are claimed using PostgreSQL `FOR UPDATE SKIP LOCKED` with worker lease columns (`lockedAt`, `lockToken`). A daily Vercel Cron job (`/api/internal/notifications/process`) and Admin Manual Retry provide complete recovery on Vercel Hobby without external Redis/BullMQ infrastructure.
- **Database-Level Integrity:** Cross-project `Document.sprintId` mismatches are prevented by both Service-layer validation and a PostgreSQL `BEFORE INSERT OR UPDATE` trigger (`check_document_sprint_same_project`), mirroring the Sprint 4 `Task` trigger pattern. Concurrent Project Archiving and Document mutations are serialized via row-level locking on `Project`.

---

## 2. Current Codebase Inspection Summary

### 2.1. Existing Stack & Architecture (Sprints 1–4)

- **Framework & Runtime:** Next.js `16.1.6` App Router, React `19.2.3`, TypeScript `5`, Prisma `6.19.3` on PostgreSQL, Auth.js v5 (`next-auth@5.0.0-beta.30`), Zod `4.3.6`, Tailwind CSS v4, shadcn/ui (Radix), Vitest `4.1.0`.
- **Modular Monolith Structure (`src/modules/*`):**
  - `auth/` — Registration, login, password change, Auth.js callbacks, `loadTrustedAuthContext`.
  - `users/` — Account approval/rejection, suspension, role assignment, permission matrix (`user.service.ts`).
  - `projects/` — Project CRUD, lifecycle (`PREPARING -> ACTIVE -> COMPLETED -> ARCHIVED`), templates, project membership (`project.service.ts`, `project.access.ts`).
  - `tasks/` — Task CRUD, multi-assignee management, review workflow (`SUBMITTED -> APPROVED/REJECTED`), dependencies, history, in-memory event bus (`task-events.ts`).
  - `sprints/` — Sprint CRUD, lifecycle (`PLANNED -> ACTIVE -> COMPLETED`), Product Backlog, Kanban board (`sprint.service.ts`, `sprint.access.ts`).
- **Cross-Cutting Server Utilities (`src/server/*`):**
  - `auth/AuthorizationService.ts` & `auth/permissions.ts` & `auth/project-access.ts` — RBAC + Project-scoped access enforcement (`assertPermission`, `assertProjectReadAccess`, `assertProjectManageAccess`).
  - `audit/audit-log.service.ts` — `recordAuditLog(input, tx)` and `recordActivityLog(input, tx)` supporting Prisma `TransactionClient`.
  - `http/api-response.ts` — Standardized `apiSuccess`, `apiError`, `handleApiError` response envelope.
  - `integrations/email.ts` — Currently a stub (`sendSystemEmail`) logging to console with unused `SMTP_*` comments.

### 2.2. Existing Partial Placeholders & Gaps Identified

1. **Permission Catalog (`src/lib/constants.ts` & `prisma/seed.ts`):**
   - `document.read`, `document.manage`, and `notification.read` already exist in `PERMISSIONS` (`src/lib/constants.ts:44-50`) and are seeded in `prisma/seed.ts`.
   - **Gap:** Delivery monitoring permissions `notification.delivery.read` and `notification.delivery.retry` do not exist yet and must be added and assigned to `ADMIN` only (`DEC-042`).
2. **In-Memory Task Events (`src/modules/tasks/task-events.ts`):**
   - Currently dispatches `TASK_ASSIGNED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, and `TASK_REVIEW_REJECTED` via an in-memory handler array after transaction commit.
   - **Gap:** No database persistence (`Notification` / `NotificationDelivery`) exists, and Account/Project events have no notification hooks yet.
3. **Navigation (`src/components/shared/sidebar.tsx` & `header.tsx`):**
   - Sidebar only lists Dashboard, Projects, and Admin User Management. Header displays user info and logout.
   - **Gap:** Missing global `/documents`, `/notifications`, `/admin/notifications/deliveries`, project-level `Documents` tab, and header `NotificationBell`.
4. **Custom SQL in Existing Migrations (`prisma/migrations/*`):**
   - Sprints 2–4 introduced partial unique indexes (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`), partial index (`Task_projectId_backlog_deadline_idx`), check constraints, and the `check_task_sprint_same_project` trigger.
   - **Gap:** Generating a new Prisma migration via `prisma migrate dev --create-only` will attempt to drop partial indexes not expressible in `schema.prisma`; those `DROP INDEX` statements must be removed before applying the Sprint 5 migration.

---

## 3. Business Requirements & Confirmed Event Matrix

### 3.1. Document Library Business Rules

| Rule ID | Requirement | Sprint 5 Enforcement |
| --- | --- | --- |
| **BR-DOC-001** | System stores only external URL metadata; no binary file upload/storage on server. | Prisma `Document` model stores `title`, `url`, `category`, `description`, `projectId`, `sprintId`, `uploadedById`. |
| **BR-DOC-002** | Only valid Google Drive / Google Docs HTTPS links are accepted (`DEC-035`). | Server-side `URL` parser allowlists exact hostnames `drive.google.com` and `docs.google.com` with `https:` protocol, non-empty path, and no embedded credentials. |
| **BR-DOC-003** | Documents belong to a Project and may optionally link to a Sprint in the **same** Project. | Validated in Service layer AND enforced at PostgreSQL level via trigger `trg_document_sprint_same_project`. |
| **BR-DOC-004** | Documents in `ARCHIVED` Projects are strictly read-only. | `create`, `update`, and `delete` acquire a row lock on `Project` inside `prisma.$transaction` and reject with `409 PROJECT_ARCHIVED_READ_ONLY` if `Project.status === 'ARCHIVED'`. |
| **BR-DOC-005** | Deleting a Document performs a Soft Delete (`DEC-036`). | Sets `deletedAt = new Date()`, records `ActivityLog` & `AuditLog`, leaves Google Drive source untouched, and filters `deletedAt IS NULL` on all standard queries. |

### 3.2. Notification & Email Business Rules (`BR-NOTIF-001` – `BR-NOTIF-008`)

| Rule ID | Notification Type | Trigger Event | Recipients | Channels | Self-Notify Excluded? |
| --- | --- | --- | --- | --- | --- |
| **BR-NOTIF-001** | `ACCOUNT_REGISTERED` | New user registers (`PENDING`) | All `ACTIVE` users holding `ADMIN` role (if none exist, registration still succeeds) | `IN_APP` + `EMAIL` | Yes |
| **BR-NOTIF-002** | `ACCOUNT_APPROVED` | Admin approves `PENDING` account (`PENDING -> ACTIVE`) | The approved User | `IN_APP` + `EMAIL` | Yes |
| **BR-NOTIF-002** | `ACCOUNT_REJECTED` | Admin rejects `PENDING` account (`PENDING -> REJECTED`) | The rejected User (persists `Notification` parent + `NotificationDelivery(EMAIL)` and sends Email; rejected user cannot log in to Notification Center) | `Notification` parent + `EMAIL` delivery | Yes |
| **BR-NOTIF-003** | `PROJECT_MEMBER_ADDED` | User added to Project (`addProjectMemberService` or initial Leader on `createProjectService`) | The added Member (`User.status = ACTIVE`) | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-003** | `PROJECT_MEMBER_REMOVED` | Member removed from Project (`removeProjectMemberService`) | The removed Member (`User.status = ACTIVE`) | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-003** | `PROJECT_LEADER_CHANGED` | Project Leader changed (`changeProjectLeaderService`) | Both previous Leader and new Leader (`User.status = ACTIVE`, deduplicated) | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-004** | `TASK_ASSIGNED` | Task created with assignees or assignees added/replaced | Newly added active Assignees (`User.status = ACTIVE`) | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-005** | `TASK_SUBMITTED_FOR_REVIEW` | Task submitted for review (`IN_PROGRESS -> REVIEW`) | Project `LEADER`(s) in `ProjectMember` (`leftAt IS NULL`, `User.status = ACTIVE`); fallback to `Project.leaderId` | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-006** | `TASK_REVIEW_APPROVED` | Task review approved (`REVIEW -> DONE`) | Active Task Assignees (`removedAt IS NULL`); fallback to `submittedById`, then `createdById` | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-006** | `TASK_REVIEW_REJECTED` | Task review rejected (`REVIEW -> IN_PROGRESS`) | Active Task Assignees (`removedAt IS NULL`); fallback to `submittedById`, then `createdById` | `IN_APP` + `EMAIL` | Yes (`userId !== actorId`) |
| **BR-NOTIF-007** | `TASK_DEADLINE_REMINDER` | Daily Cron batch (`/api/internal/notifications/process`) for Tasks with `status != DONE` and `deadline` in `[now, now + 24h]` (approaching) or `[now - 24h, now]` (recently overdue) | Active Task Assignees (`removedAt IS NULL`, `User.status = ACTIVE`); unassigned tasks excluded | `IN_APP` + `EMAIL` | N/A (System Cron) |
| **BR-NOTIF-008** | *(Delivery Rule)* | Every `EMAIL` delivery failure | Up to 3 automatic retries (`+1m`, `+5m`, `+15m`) + Admin Manual Retry while `retryCount < 3` | `EMAIL` | N/A |

---

## 4. Database Design & Migration Strategy

### 4.1. New Prisma Enums

```prisma
enum DocumentCategory {
  SPECIFICATION
  DESIGN
  REPORT
  OTHER
}

enum NotificationType {
  ACCOUNT_REGISTERED
  ACCOUNT_APPROVED
  ACCOUNT_REJECTED
  TASK_ASSIGNED
  TASK_SUBMITTED_FOR_REVIEW
  TASK_REVIEW_APPROVED
  TASK_REVIEW_REJECTED
  PROJECT_MEMBER_ADDED
  PROJECT_MEMBER_REMOVED
  PROJECT_LEADER_CHANGED
  TASK_DEADLINE_REMINDER
  SYSTEM
}

enum NotificationChannel {
  IN_APP
  EMAIL
}

enum NotificationDeliveryStatus {
  PENDING
  SENT
  FAILED
}
```

### 4.2. New Prisma Models (`Document`, `Notification`, `NotificationDelivery`)

```prisma
model Document {
  id           String           @id @default(uuid()) @db.Uuid
  projectId    String           @db.Uuid
  sprintId     String?          @db.Uuid
  uploadedById String           @db.Uuid
  title        String           @db.VarChar(200)
  url          String           @db.VarChar(1000)
  category     DocumentCategory @default(OTHER)
  description  String?          @db.Text
  createdAt    DateTime         @default(now())
  updatedAt    DateTime         @updatedAt
  deletedAt    DateTime?

  project    Project @relation(fields: [projectId], references: [id], onDelete: Restrict)
  sprint     Sprint? @relation(fields: [sprintId], references: [id], onDelete: SetNull)
  uploadedBy User    @relation("DocumentUploadedBy", fields: [uploadedById], references: [id], onDelete: Restrict)

  @@index([projectId, deletedAt, category, createdAt])
  @@index([sprintId, deletedAt])
  @@index([uploadedById])
}

model Notification {
  id          String           @id @default(uuid()) @db.Uuid
  userId      String           @db.Uuid
  actorId     String?          @db.Uuid
  projectId   String?          @db.Uuid
  type        NotificationType
  title       String           @db.VarChar(255)
  message     String           @db.Text
  targetUrl   String?          @db.VarChar(500)
  entityType  String           @db.VarChar(50)
  entityId    String           @db.Uuid
  metadata    Json?
  dedupKey    String?          @db.VarChar(200)
  isRead      Boolean          @default(false)
  readAt      DateTime?
  createdAt   DateTime         @default(now())

  user       User                   @relation("NotificationRecipient", fields: [userId], references: [id], onDelete: Cascade)
  actor      User?                  @relation("NotificationActor", fields: [actorId], references: [id], onDelete: SetNull)
  project    Project?               @relation(fields: [projectId], references: [id], onDelete: SetNull)
  deliveries NotificationDelivery[]

  @@unique([userId, dedupKey])
  @@index([userId, isRead, createdAt(sort: Desc)])
  @@index([userId, createdAt(sort: Desc)])
  @@index([projectId])
  @@index([type, createdAt])
}

model NotificationDelivery {
  id                String                     @id @default(uuid()) @db.Uuid
  notificationId    String                     @db.Uuid
  channel           NotificationChannel        @default(EMAIL)
  recipientEmail    String                     @db.VarChar(255)
  status            NotificationDeliveryStatus @default(PENDING)
  provider          String                     @default("RESEND") @db.VarChar(50)
  providerMessageId String?                    @db.VarChar(255)
  retryCount        Int                        @default(0)
  lastAttemptAt     DateTime?
  nextRetryAt       DateTime?
  lockedAt          DateTime?
  lockToken         String?                    @db.VarChar(100)
  sentAt            DateTime?
  failedAt          DateTime?
  errorCode         String?                    @db.VarChar(100)
  errorMessage      String?                    @db.Text
  createdAt         DateTime                   @default(now())
  updatedAt         DateTime                   @updatedAt

  notification Notification @relation(fields: [notificationId], references: [id], onDelete: Cascade)

  @@unique([notificationId, channel])
  @@index([status, nextRetryAt])
  @@index([status, lockedAt])
  @@index([recipientEmail, createdAt(sort: Desc)])
  @@index([createdAt(sort: Desc)])
}
```

### 4.3. Schema Design Rules & Invariants

1. **`Document.deletedAt` (Soft Delete — `DEC-036`):**
   - Required field on `Document`. All normal Document queries must include `deletedAt: null`.
   - No Restore UI or Restore API in MVP.
   - Deleting a Document only sets `deletedAt = new Date()` on the DB record; Google Drive source files remain untouched.
2. **Mandatory PostgreSQL Trigger for Document–Sprint Same-Project Integrity:**
   - Both Service validation and a PostgreSQL trigger are **mandatory** in Sprint 5.
   - The migration SQL must add `check_document_sprint_same_project()` and `trg_document_sprint_same_project` on `"Document"` (`BEFORE INSERT OR UPDATE OF "projectId", "sprintId"`), raising `ERRCODE = '23514'` if `NEW."sprintId"` belongs to a different `"projectId"`.
3. **Notification vs NotificationDelivery Channel Separation:**
   - `Notification` represents the in-app notification record (`isRead`, `readAt`).
   - `NotificationDelivery` stores **ONLY `EMAIL` channel rows** (`@@unique([notificationId, channel])`). Do **not** create `IN_APP` rows in `NotificationDelivery`.
   - `Notification.projectId` is stored solely for navigation/display context (`onDelete: SetNull`). Notification read/mark-read authorization checks `notification.userId === currentUser.id`, never current project membership.
4. **Delivery State Machine Interpretation:**
   - `PENDING`: Newly created and not yet attempted (`retryCount = 0`).
   - `SENT`: Delivered to Resend (`sentAt != null`, `nextRetryAt = null`, `lockedAt = null`, `lockToken = null`).
   - `FAILED` (Retryable): `status = FAILED`, `retryCount < 3`, and `nextRetryAt != null`.
   - `FAILED` (Terminal): `status = FAILED`, `retryCount = 3` (or permanent error), and `nextRetryAt = null`.
5. **Preserving Sprint 2–4 Custom SQL Indexes:**
   - When generating the Sprint 5 migration, strip any Prisma-generated `DROP INDEX` statements targeting `Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, or `Task_projectId_backlog_deadline_idx`.

---

## 5. Transactional Notification, Email Delivery & Concurrency Architecture

### 5.1. Transactional Notification Persistence

For every business event in Section 3.2:

1. Domain mutation + `ActivityLog` / `AuditLog` + `Notification` + `NotificationDelivery(channel = EMAIL, status = PENDING)` are written inside the **same** `prisma.$transaction`.
2. If `Notification` or `NotificationDelivery` creation fails inside `tx`, the entire database transaction rolls back so domain state and notification state never diverge.
3. External Resend HTTP requests are **never** invoked inside `prisma.$transaction`.
4. After the transaction commits, the caller schedules immediate asynchronous dispatch via Next.js `after()` (or safe fire-and-forget fallback in non-request test contexts).
5. If Resend fails after transaction commit, the committed domain change and in-app `Notification` remain intact, while `NotificationDelivery` transitions to `FAILED` with scheduled backoff.

### 5.2. Worker Claim, Lease & Concurrency Control (`FOR UPDATE SKIP LOCKED`)

Because `after()` post-commit dispatch, the daily Cron processor, and Admin Manual Retry could overlap, every delivery attempt must first atomically claim a lease on the `NotificationDelivery` row:

1. Inside a short claim transaction, select eligible row(s) using `FOR UPDATE SKIP LOCKED` where:
   - `status = 'PENDING'` OR (`status = 'FAILED'` AND `retryCount < 3` AND `nextRetryAt <= NOW()`), AND
   - `lockedAt IS NULL` OR `lockedAt < NOW() - INTERVAL '5 minutes'` (stale lock recovery).
2. Generate a unique `workerLockToken = randomUUID()`, set `lockedAt = NOW()`, `lockToken = workerLockToken`, `lastAttemptAt = NOW()`, and:
   - If `status = 'PENDING'`, keep `retryCount = 0`.
   - If `status = 'FAILED'` (automatic retry or manual retry), atomically increment `retryCount = retryCount + 1`.
3. Release the claim transaction and invoke Resend outside the DB transaction.
4. On completion (success or failure), update the row with `WHERE id = deliveryId AND lockToken = workerLockToken` and clear `lockedAt = null, lockToken = null`. If the lock token no longer matches, discard the stale worker result.

### 5.3. Retry Counter & Exponential Backoff Semantics (`DEC-040`)

Maximum **1 initial attempt + 3 retries** (`4` total attempts):

| Attempt Stage | `retryCount` During Attempt | Outcome on Transient Failure | Next Retry Schedule (`nextRetryAt`) |
| --- | --- | --- | --- |
| **Initial Attempt** | `0` | `status = FAILED`, `retryCount = 0` | `now + 1 minute` |
| **Retry 1** | `1` | `status = FAILED`, `retryCount = 1` | `now + 5 minutes` |
| **Retry 2** | `2` | `status = FAILED`, `retryCount = 2` | `now + 15 minutes` |
| **Retry 3 (Final)** | `3` | `status = FAILED`, `retryCount = 3` (Terminal) | `null` (No further automatic or manual retries) |

- **Permanent Provider Errors** (e.g., invalid recipient email syntax, `400`/`422` validation error): Immediately mark terminal `FAILED` with `nextRetryAt = null`.
- **Transient Errors** (network timeout, `429` rate limit, `5xx` server error): Schedule `nextRetryAt` according to the table above while `retryCount < 3`.
- **Manual Retry (`DEC-040`, `DEC-042`):** Allowed only when `status = FAILED` and `retryCount < 3` and not currently locked. Increments `retryCount` by 1 during claim and dispatches via the same worker pipeline.

### 5.4. Resend Integration & Idempotency Key (`DEC-045`)

- **SDK Support Verified:** Installed `resend@6.38.1` natively supports `{ idempotencyKey?: string }` as the second parameter to `resend.emails.send(payload, { idempotencyKey })`, which sets the HTTP `Idempotency-Key` header.
- **Stable Key Format:** Always pass `idempotencyKey: "notification-delivery:" + delivery.id`. Do **not** append attempt numbers (`retryCount`), so if an HTTP response drops after Resend accepted the request, subsequent retries within Resend's 24-hour idempotency window will not send duplicate emails.
- **Over-24h Manual Retry Safeguard:** Because all automatic retries complete within ~21 minutes (`+1m`, `+5m`, `+15m`), they are strictly within Resend's 24-hour idempotency window. If an Admin manually retries a failed delivery more than 24 hours after `createdAt`, the service proceeds using the existing `NotificationDelivery` record (never creating a duplicate record) and logs a metadata note in `AuditLog`.
- **SMTP Cleanup:** Remove all unused `SMTP_*` variables and comments from `src/lib/env.ts`, `.env.example`, and `src/server/integrations/email.ts`.

### 5.5. Daily Deadline Reminder Specification (`DEC-039`)

- **Schedule & Timezone:** Runs once daily via `/api/internal/notifications/process` using business timezone `Asia/Ho_Chi_Minh` (`UTC+7`) to compute `dateKey = YYYY-MM-DD`.
- **Eligible Tasks:**
  - `Task.status != 'DONE'`
  - `Task.project.status == 'ACTIVE'`
  - `Task.deadline != null`
  - **Upcoming window:** `now <= deadline <= now + 24 hours`
  - **Recently overdue window:** `now - 24 hours <= deadline < now`
- **Eligible Recipients:** Active Task Assignees (`TaskAssignee.removedAt IS NULL`) whose `User.status == 'ACTIVE'`. Unassigned tasks are skipped.
- **Idempotent Deduplication:**
  - `dedupKey = "deadline-reminder:${task.id}:${recipientUserId}:${dateKey}"`
  - Enforced by `@@unique([userId, dedupKey])` on `Notification`. Re-running the processor on the same day skips already-created reminders without duplicating `Notification` or `NotificationDelivery` rows.

---

## 6. Authorization & Permission Matrix

### 6.1. Permission Catalog Updates (`src/lib/constants.ts` & `prisma/seed.ts`)

Add two new permissions under the `NOTIFICATION` module (`DEC-042`):

| Permission Key | Description | ADMIN | INSTRUCTOR | LEADER | MEMBER |
| --- | --- | :---: | :---: | :---: | :---: |
| `document.read` | Xem danh sách và chi tiết tài liệu dự án | ✅ | ✅ | ✅ | ✅ |
| `document.manage` | Thêm, cập nhật, xóa mềm tài liệu (`DEC-034`) | ✅ | ❌ | ✅ | ❌ *(Configurable)* |
| `notification.read` | Xem và đánh dấu thông báo cá nhân | ✅ | ✅ | ✅ | ✅ |
| `notification.delivery.read` | Xem lịch sử gửi email thông báo toàn hệ thống (`DEC-042`) | ✅ | ❌ | ❌ | ❌ |
| `notification.delivery.retry` | Thử gửi lại email thông báo thất bại (`DEC-042`) | ✅ | ❌ | ❌ | ❌ |

### 6.2. Scoped Access Rules

1. **Document Read (`document.read`):**
   - Requires `assertPermission(ctx, "document.read")` AND `assertProjectReadAccess(ctx, projectId)`.
   - `ADMIN` and `INSTRUCTOR` can view Documents across all Projects. `LEADER` and `MEMBER` can view Documents only in Projects where they have an active `ProjectMember` record (`leftAt IS NULL`) or are Project Leader.
2. **Document Manage (`document.manage` — `DEC-034`):**
   - Requires `assertPermission(ctx, "document.manage")` AND project-scoped check + `Project.status !== 'ARCHIVED'`.
   - `ADMIN`: Manages Documents in any non-archived Project.
   - `LEADER`: Manages Documents in own non-archived Projects (`assertProjectManageAccess`).
   - `MEMBER`: By default does not have `document.manage`. If an Admin grants `document.manage` to `MEMBER` in the Permission Matrix, a `MEMBER` can create, update, and soft-delete Documents **only in non-archived Projects they can access** (`assertProjectReadAccess`). No creator-only restriction applies.
   - `INSTRUCTOR`: Read-only across all Projects.
3. **Personal Notifications (`notification.read`):**
   - Authenticated users (`ACTIVE`) can only list and mark read/unread notifications where `notification.userId === ctx.userId`. Attempting to mutate another user's notification returns `403` / `404`.
4. **Delivery Monitoring (`notification.delivery.read`, `notification.delivery.retry`):**
   - Strictly checked via `assertPermission(ctx, "notification.delivery.read")` and `assertPermission(ctx, "notification.delivery.retry")` (never reusing `account.read` or `account.manage`).
5. **Internal Cron Endpoint (`/api/internal/notifications/process`):**
   - Authenticated via `Authorization: Bearer ${process.env.CRON_SECRET}` using constant-time comparison (`crypto.timingSafeEqual`). Rejects missing/invalid secrets with `401 Unauthorized`.

---

## 7. Service Layer & API Design

### 7.1. Document Module (`src/modules/documents/`)

- **Files:**
  - `src/modules/documents/document.types.ts`
  - `src/modules/documents/document.validation.ts`
  - `src/modules/documents/document.access.ts`
  - `src/modules/documents/document.repository.ts`
  - `src/modules/documents/document.service.ts`
  - `src/modules/documents/document.actions.ts`
- **Google Drive URL Validator (`validateGoogleDriveUrl`):**
  - Trim input; parse with `new URL(input)`.
  - Require `url.protocol === "https:"`.
  - Require `!url.username && !url.password`.
  - Require `url.hostname === "drive.google.com" || url.hostname === "docs.google.com"`.
  - Require `url.pathname.length > 1` (not bare root `/`).
- **Concurrency Serialization Against Project Archive:**
  - Inside `prisma.$transaction`, `lockProjectForDocumentMutation(projectId, tx)` executes `SELECT "id", "status" FROM "Project" WHERE "id" = ${projectId}::uuid FOR SHARE` and throws `409 PROJECT_ARCHIVED_READ_ONLY` if `status === 'ARCHIVED'`.
- **REST Endpoints:**
  - `GET /api/projects/[projectId]/documents` — Filter by `category`, `sprintId`, `search`, `page`, `pageSize` (always `deletedAt: null`).
  - `POST /api/projects/[projectId]/documents` — Create Document.
  - `GET /api/documents/[documentId]` — Document detail (`deletedAt: null`).
  - `PATCH /api/documents/[documentId]` — Update `title`, `url`, `category`, `description`, `sprintId`.
  - `DELETE /api/documents/[documentId]` — Soft delete (`deletedAt = new Date()`).

### 7.2. Notification & Delivery Module (`src/modules/notifications/`)

- **Files:**
  - `src/modules/notifications/notification.types.ts`
  - `src/modules/notifications/notification.validation.ts`
  - `src/modules/notifications/notification.repository.ts`
  - `src/modules/notifications/notification.service.ts`
  - `src/modules/notifications/notification-email.templates.ts`
  - `src/modules/notifications/notification-delivery.service.ts`
  - `src/modules/notifications/notification-deadline.service.ts`
  - `src/modules/notifications/notification.actions.ts`
- **REST Endpoints:**
  - `GET /api/notifications` — Paginated list for current user (`status: all | unread | read`, `type`, `projectId`, `page`, `pageSize`) + `unreadCount`.
  - `GET /api/notifications/unread-count` — Lightweight unread counter for header bell.
  - `PATCH /api/notifications/[notificationId]/read` — Mark single notification as read (`isRead: true`) or unread (`isRead: false`).
  - `POST /api/notifications/mark-all-read` — Mark all unread notifications for current user as read.
  - `GET /api/admin/notifications/deliveries` — Admin Delivery History with filters (`status`, `type`, `recipientEmail`, `page`, `pageSize`).
  - `POST /api/admin/notifications/deliveries/[deliveryId]/retry` — Admin Manual Retry for eligible `FAILED` delivery (`retryCount < 3`).
  - `GET` & `POST /api/internal/notifications/process` — Internal Cron & batch processor (`CRON_SECRET` protected) running:
    1. `runDeadlineReminderBatch()`
    2. `processDueEmailDeliveriesBatch()`

---

## 8. UI / UX Design & Route Map

### 8.1. Document Library Routes (`DEC-046`)

1. **Global Document Library (`/documents` — `src/app/(dashboard)/documents/page.tsx`):**
   - Accessible from the main Sidebar (`Tài liệu`).
   - Lists Documents across all Projects accessible to the current user (`deletedAt: null`), with Project selector/filter, Category filter, Sprint filter, keyword search, and `Thêm tài liệu` modal for Projects where the user has manage rights and `Project.status !== 'ARCHIVED'`.
2. **Project Document Tab (`/projects/[projectId]/documents` — `src/app/(dashboard)/projects/[projectId]/documents/page.tsx`):**
   - Integrated into the Project Detail navigation bar alongside Overview, Sprints, Backlog, and Kanban.
   - Reuses the shared `DocumentLibraryClient` (`src/components/features/documents/document-library-client.tsx`) pre-scoped to `projectId`.
   - Displays read-only banner when `Project.status === 'ARCHIVED'` and hides mutation controls when user lacks `document.manage`.

### 8.2. Notification Center & Header Bell

1. **Header Notification Bell (`src/components/features/notifications/notification-bell.tsx`):**
   - Placed in `src/components/shared/header.tsx`.
   - Shows unread badge count, dropdown preview of recent notifications, quick `Đánh dấu đã đọc` / `Đánh dấu tất cả đã đọc`, and link to `/notifications`.
2. **Notification Center Page (`/notifications` — `src/app/(dashboard)/notifications/page.tsx`):**
   - Filter tabs: `Tất cả`, `Chưa đọc`, `Đã đọc` + filter by Notification Type.
   - Row actions: click to mark read & navigate to `targetUrl`, toggle Read/Unread, and `Đánh dấu tất cả đã đọc`.

### 8.3. Admin Delivery Monitoring (`/admin/notifications/deliveries`)

1. **Admin Delivery Page (`src/app/(dashboard)/admin/notifications/deliveries/page.tsx`):**
   - Visible in Sidebar only when user has `notification.delivery.read`.
   - Displays summary cards (`PENDING`, `SENT`, `FAILED Retryable`, `FAILED Terminal`), filterable delivery table (`recipientEmail`, `NotificationType`, `status`, `retryCount / 3`, `lastAttemptAt`, `nextRetryAt`, `errorMessage`), and `Thử gửi lại` button (enabled when user has `notification.delivery.retry`, `status === 'FAILED'`, and `retryCount < 3`).

---

## 9. Environment & Deployment Configuration

1. **`src/lib/env.ts` & `.env.example` (`DEC-045`):**
   - Remove all `SMTP_*` references.
   - Validate `RESEND_API_KEY` (optional in local/test, used when present), `EMAIL_FROM` (default `"Akatsuki Yui <no-reply@akatsukiyui.local>"`), and `CRON_SECRET` (required in production for `/api/internal/notifications/process`, minimum 16 chars when configured).
2. **`vercel.json`:**
   - Configure daily Vercel Cron job compatible with Vercel Hobby:
     ```json
     {
       "crons": [
         {
           "path": "/api/internal/notifications/process",
           "schedule": "0 1 * * *"
         }
       ]
     }
     ```
     *(01:00 UTC = 08:00 AM `Asia/Ho_Chi_Minh`).*

---

## 10. Phased Implementation Packages (Packages 0 – 8)

Execution strictly follows the 9 sequential packages below:

- **PACKAGE 0 — Repository Audit and Implementation Preparation:**
  - Inspect all documentation, Sprint 1–4 code, migrations, Resend SDK, and test suites; update `report/SPRINT-5-IMPLEMENTATION-PLAN.md`; report findings before modifying application code.
- **PACKAGE 1 — Database and Permissions:**
  - Update `prisma/schema.prisma` (`Document`, `Notification`, `NotificationDelivery` + enums).
  - Create Sprint 5 migration with `check_document_sprint_same_project()` trigger and preserve Sprint 2–4 partial indexes.
  - Add `notification.delivery.read` and `notification.delivery.retry` to `src/lib/constants.ts` and `prisma/seed.ts`.
  - Clean up `SMTP_*` from `src/lib/env.ts` and `.env.example`, and add `CRON_SECRET`.
- **PACKAGE 2 — Document Backend, API, and UI:**
  - Implement `src/modules/documents/*` (URL validation, Project-row lock against archive race, CRUD + Soft Delete, `ActivityLog` & `AuditLog`).
  - Implement Document API routes and Server Actions.
  - Build shared `DocumentLibraryClient`, `/documents`, and `/projects/[projectId]/documents`.
- **PACKAGE 3 — Notification Core, Center UI, and Header Bell:**
  - Implement `src/modules/notifications/*` core repository, service, API routes (`/api/notifications`, `/unread-count`, `/[notificationId]/read`, `/mark-all-read`), Server Actions, `NotificationBell` in Header, and `/notifications` page.
- **PACKAGE 4 — Transactional Business Event Integration:**
  - Integrate durable transactional `Notification` + `NotificationDelivery(EMAIL)` creation and post-commit `after()` dispatch into:
    - `auth.service.ts` (`ACCOUNT_REGISTERED`)
    - `user.service.ts` (`ACCOUNT_APPROVED`, `ACCOUNT_REJECTED`)
    - `project.service.ts` (`PROJECT_MEMBER_ADDED`, `PROJECT_MEMBER_REMOVED`, `PROJECT_LEADER_CHANGED`)
    - `task.service.ts`, `task-assignment.service.ts`, `task-workflow.service.ts` (`TASK_ASSIGNED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, `TASK_REVIEW_REJECTED`)
  - Update affected Sprint 1–4 unit/integration test mocks (`user-service.test.ts`, `sprint2-services.test.ts`, `sprint3-task-services.test.ts`, `sprint3-db.test.ts`) so existing tests stay green.
- **PACKAGE 5 — Resend Email Delivery and Retry Engine:**
  - Refactor `src/server/integrations/email.ts` to use Resend SDK with `idempotencyKey: "notification-delivery:" + delivery.id`.
  - Implement `notification-delivery.service.ts` with `FOR UPDATE SKIP LOCKED` lease claiming (`lockedAt`, `lockToken`), transient vs permanent error classification, and `+1m` / `+5m` / `+15m` backoff up to `retryCount = 3`.
- **PACKAGE 6 — Deadline Reminder and Cron Processor:**
  - Implement `notification-deadline.service.ts` (`Asia/Ho_Chi_Minh` date key, `[now, now+24h]` and `[now-24h, now]` windows, `dedupKey`).
  - Implement `/api/internal/notifications/process` with `CRON_SECRET` verification and `vercel.json`.
- **PACKAGE 7 — Admin Delivery History and Manual Retry UI:**
  - Implement `/api/admin/notifications/deliveries` and `/api/admin/notifications/deliveries/[deliveryId]/retry`.
  - Implement `/admin/notifications/deliveries` page and Sidebar entry gated by `notification.delivery.read`.
- **PACKAGE 8 — Automated Tests, Verification, and Sprint 5 Report:**
  - Write comprehensive unit and real-DB integration tests (`sprint5-documents.test.ts`, `sprint5-notifications.test.ts`, `sprint5-db.test.ts`).
  - Run `npx prisma validate`, `npm run typecheck`, `npm run lint`, `npm test`, `npm run test:integration`, `npm run build`.
  - Produce `report/SPRINT-5-IMPLEMENTATION-REPORT.md` and update `markdown/DECISION-LOG.md`.

---

## 11. Testing & Verification Strategy

1. **Unit Tests (`tests/unit/`):**
   - Google Drive URL validation (valid `drive.google.com`/`docs.google.com` links vs `http://`, lookalike domains, subdomains, credentials, bare root).
   - Document RBAC (`ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER` default vs `MEMBER` granted `document.manage`) and `ARCHIVED` project rejection.
   - Notification self-notification filtering (`actorId` exclusion), recipient resolution (`ACTIVE` status filter), and `ACCOUNT_REJECTED` email-only behavior.
   - Delivery retry state machine (`retryCount = 0 -> 1 -> 2 -> 3`, backoff timestamps, permanent vs transient failure, manual retry cap, Resend idempotency key `notification-delivery:${delivery.id}`).
   - Deadline reminder window calculation (`[now, now+24h]` and `[now-24h, now]`) and `Asia/Ho_Chi_Minh` `dedupKey` generation.
   - Cron secret verification (`401` on missing/wrong token).
2. **Real PostgreSQL Integration Tests (`tests/integration/sprint5-db.test.ts`):**
   - `trg_document_sprint_same_project` trigger blocking cross-project Sprint linkage at DB level.
   - Soft delete filtering (`deletedAt IS NULL`) and `Project.status = ARCHIVED` serialization.
   - Transactional atomicity: simulated notification write failure rolls back domain write; simulated Resend failure after commit preserves domain write and marks `NotificationDelivery` as `FAILED`.
   - `FOR UPDATE SKIP LOCKED` concurrent worker claim preventing double sends.
   - Unique `(userId, dedupKey)` preventing duplicate daily deadline reminders.

---

## 12. Risks & Mitigations

| Risk | Impact | Mitigation |
| --- | --- | --- |
| Prisma `migrate dev --create-only` generates `DROP INDEX` for Sprint 2–4 partial indexes | High (breaks single-active-project and active-member invariants) | Inspect generated `migration.sql` in Package 1 and remove any `DROP INDEX` statements before applying. |
| Resend API failure or timeout during user request | Medium | Never call Resend inside `prisma.$transaction`; dispatch post-commit via `after()` and persist retry state in `NotificationDelivery`. |
| Concurrent duplicate email sends by overlapping `after()`, Cron, or Manual Retry | High | Claim rows via `FOR UPDATE SKIP LOCKED` with `lockedAt` + `lockToken` and pass `idempotencyKey: "notification-delivery:" + delivery.id` to Resend. |
| Existing Sprint 1–4 unit tests failing when notification persistence is added to domain transactions | Medium | Audit and update `txMock` in `user-service.test.ts`, `sprint2-services.test.ts`, and `sprint3-task-services.test.ts` during Package 4. |

---

## 13. Confirmed Decisions (`DEC-034` – `DEC-046`)

| Decision ID | Topic | Confirmed Resolution | Status |
| --- | --- | --- | --- |
| **DEC-034** | Document Management Permission | Use `document.manage` (default: `ADMIN`, `LEADER`). `ADMIN` manages all Projects; `LEADER` manages own Projects; if `ADMIN` grants `document.manage` to `MEMBER` via Permission Matrix, `MEMBER` can manage Documents in accessible non-archived Projects (`assertProjectReadAccess`). No creator-only restriction. | **Confirmed** |
| **DEC-035** | Google Drive URL Validation | Allow only `https://drive.google.com` and `https://docs.google.com` via server-side `URL` parser. Reject `http:`, credentials, bare root paths, lookalike domains, and subdomains. No live HTTP ping. | **Confirmed** |
| **DEC-036** | Document Soft Delete | Keep required `Document.deletedAt DateTime?`. Filter `deletedAt IS NULL` on all standard queries. Record soft delete in `ActivityLog` & `AuditLog`. No Restore UI/API in MVP. Block mutations on `ARCHIVED` Projects with row-level lock serialization. | **Confirmed** |
| **DEC-037** | Project Membership Notifications | Implement `PROJECT_MEMBER_ADDED`, `PROJECT_MEMBER_REMOVED`, and `PROJECT_LEADER_CHANGED` (`IN_APP` + `EMAIL`) for `ACTIVE` recipients, excluding `actorId`. | **Confirmed** |
| **DEC-038** | Account Lifecycle Notifications | Implement `ACCOUNT_REGISTERED` (to all `ACTIVE` Admins; registration succeeds even if none), `ACCOUNT_APPROVED` (`IN_APP` + `EMAIL`), and `ACCOUNT_REJECTED` (persist `Notification` + `NotificationDelivery(EMAIL)` and send Email). No `SUSPEND`/`REACTIVATE` notifications. | **Confirmed** |
| **DEC-039** | Task Deadline Reminder | Daily Cron batch (`TASK_DEADLINE_REMINDER`) for non-`DONE` Tasks in `ACTIVE` Projects with `deadline` in `[now, now + 24h]` or `[now - 24h, now]`. Notify active assignees (`User.status = ACTIVE`) with `dedupKey = deadline-reminder:${taskId}:${recipientUserId}:${YYYY-MM-DD}` (`Asia/Ho_Chi_Minh`). Project/Sprint lifecycle notifications out of scope. | **Confirmed** |
| **DEC-040** | Email Retry Limit & Backoff | Max 1 initial attempt (`retryCount = 0`) + 3 retries (`retryCount = 1, 2, 3`) with backoff `+1m`, `+5m`, `+15m`. After Retry 3 fails, mark terminal `FAILED` (`retryCount = 3`, `nextRetryAt = null`). Manual retry obeys `retryCount < 3`. | **Confirmed** |
| **DEC-041** | Email Notification Preferences | No `NotificationPreference` model or opt-out UI in MVP; all required notifications and Deadline Reminders send Email. | **Confirmed** |
| **DEC-042** | Delivery Monitoring Permissions | Add `notification.delivery.read` and `notification.delivery.retry`, default assigned to `ADMIN` only. Do not reuse `account.read` or `account.manage`. | **Confirmed** |
| **DEC-043** | Notification Retention | Support `Mark as Read`, `Mark as Unread`, and `Mark All as Read`. No user delete/archive or retention cleanup Cron in MVP. | **Confirmed** |
| **DEC-044** | Dispatch & Recovery Architecture | Transactional `Notification` + `NotificationDelivery` persistence -> `after()` post-commit dispatch -> `FOR UPDATE SKIP LOCKED` with `lockedAt` + `lockToken` -> daily Vercel Cron (`/api/internal/notifications/process`) -> Admin Manual Retry. | **Confirmed** |
| **DEC-045** | Resend Only & Idempotency Key | Use Resend SDK exclusively with stable idempotency key `notification-delivery:${delivery.id}`. Remove all unused `SMTP_*` env vars and comments. | **Confirmed** |
| **DEC-046** | Document & Admin Delivery Routes | Implement `/documents` and `/projects/[projectId]/documents` sharing `DocumentLibraryClient` + Document Service Layer, and `/admin/notifications/deliveries` for Admin Delivery Monitoring. | **Confirmed** |

---

## 14. Open Questions & Technical Verification Items

**All 13 Product Owner decisions have been confirmed. No unresolved Product Decision blocks Sprint 5 execution.**

The following implementation-time technical verifications have been audited during Package 0 and will be verified during execution:

1. **Migration SQL Verification:** Confirm custom SQL trigger `check_document_sprint_same_project()` and preservation of existing partial indexes in the Sprint 5 migration file.
2. **Next.js `after()` Execution:** Confirmed `export { after } from 'next/dist/server/after'` in `node_modules/next/server.d.ts` (`next@16.1.6`), with safe fallback when invoked outside a Next.js request scope (e.g., in Vitest unit/integration tests).
3. **Resend SDK Signature & Idempotency:** Confirmed `resend.emails.send(payload, { idempotencyKey })` in `node_modules/resend/dist/index.d.mts` (`resend@6.38.1`) sets the `Idempotency-Key` header.
4. **Concurrency Locking:** Verify `FOR UPDATE SKIP LOCKED` lease claim/release on `NotificationDelivery` and `Project` row locking on Document mutations in real PostgreSQL integration tests.
5. **Existing Sprint 1–4 Regression Suite:** Ensure all existing unit and integration tests pass after refactoring transactional notification persistence into Account, Project, and Task services.

---

## 15. Definition of Done (Sprint 5 Checklist)

- [ ] **1.** `Document`, `Notification`, and `NotificationDelivery` models and enums (`DocumentCategory`, `NotificationType`, `NotificationChannel`, `NotificationDeliveryStatus`) migrated in PostgreSQL.
- [ ] **2.** PostgreSQL trigger `trg_document_sprint_same_project` active and tested; Sprint 2–4 partial indexes preserved.
- [ ] **3.** Permissions `document.read`, `document.manage`, `notification.read`, `notification.delivery.read`, and `notification.delivery.retry` seeded and enforced.
- [ ] **4.** Google Drive URL validation strictly enforces `https://drive.google.com` and `https://docs.google.com` (`DEC-035`).
- [ ] **5.** Document CRUD + Soft Delete (`deletedAt`) working end-to-end with `ActivityLog` and `AuditLog` entries (`DEC-036`).
- [ ] **6.** `ARCHIVED` Projects block all Document mutations (`Create`, `Update`, `Delete`) with row-level lock serialization.
- [ ] **7.** Both `/documents` and `/projects/[projectId]/documents` implemented and sharing `DocumentLibraryClient` (`DEC-046`).
- [ ] **8.** Notification Center (`/notifications`) and Header `NotificationBell` implemented with `Mark as Read`, `Mark as Unread`, and `Mark All as Read` (`DEC-043`).
- [ ] **9.** Account notifications (`ACCOUNT_REGISTERED`, `ACCOUNT_APPROVED`, `ACCOUNT_REJECTED`) persisted transactionally (`DEC-038`).
- [ ] **10.** Project membership notifications (`PROJECT_MEMBER_ADDED`, `PROJECT_MEMBER_REMOVED`, `PROJECT_LEADER_CHANGED`) persisted transactionally (`DEC-037`).
- [ ] **11.** Task workflow & assignment notifications (`TASK_ASSIGNED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, `TASK_REVIEW_REJECTED`) persisted transactionally inside `prisma.$transaction`.
- [ ] **12.** Self-notifications (`recipientId === actorId`) and non-`ACTIVE` recipients excluded across all user-triggered events (except `ACCOUNT_REJECTED` email delivery).
- [ ] **13.** Post-commit email dispatch via Next.js `after()` and Resend SDK (`notification-delivery:${delivery.id}` idempotency key); all `SMTP_*` references removed (`DEC-044`, `DEC-045`).
- [ ] **14.** `FOR UPDATE SKIP LOCKED` worker claim with `lockedAt` and `lockToken` prevents duplicate concurrent email sends.
- [ ] **15.** Automatic retry state machine enforces max 3 retries (`retryCount = 0..3`) with `+1m`, `+5m`, `+15m` backoff and terminal `FAILED` state (`DEC-040`).
- [ ] **16.** Daily Deadline Reminder (`TASK_DEADLINE_REMINDER`) implemented for `[now, now + 24h]` and `[now - 24h, now]` in `Asia/Ho_Chi_Minh` with `dedupKey` idempotency (`DEC-039`).
- [ ] **17.** Cron endpoint `/api/internal/notifications/process` secured by `CRON_SECRET` and configured once daily in `vercel.json`.
- [ ] **18.** Admin Delivery Monitoring UI (`/admin/notifications/deliveries`) and Manual Retry API/UI working and protected by `notification.delivery.read` and `notification.delivery.retry` (`DEC-042`).
- [ ] **19.** Unit tests, real PostgreSQL integration tests, and Sprint 1–4 regression tests pass (`npm test` & `npm run test:integration`).
- [ ] **20.** `npx prisma validate`, `npm run typecheck`, `npm run lint`, and `npm run build` succeed with zero errors; `report/SPRINT-5-IMPLEMENTATION-REPORT.md` and `markdown/DECISION-LOG.md` updated.
