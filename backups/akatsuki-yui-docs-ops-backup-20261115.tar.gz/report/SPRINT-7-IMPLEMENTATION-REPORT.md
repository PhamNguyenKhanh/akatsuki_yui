# SPRINT 7 IMPLEMENTATION REPORT — AKATSUKI YUI

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Branch:** `feat/sprint7-finalization-deployment`  
**Date:** 2026-11-15  
**Scope:** Packages 1–7 (Security Hardening, Resend-to-SMTP Migration, Free-Tier Background Policy, Bug Fixes & App Boundaries, Test Suite & E2E, Deployment Readiness & Documentation Sync)

---

## 1. Executive Summary & Honest Completion Status

Toàn bộ source code, migration SQL, unit/contract/integration/E2E test suites, cấu hình deploy Vercel/Neon/SMTP và bộ tài liệu Markdown cho **Sprint 7 (Packages 1–7)** đã được hoàn thiện và xác minh các cổng kiểm thử không phụ thuộc database/mạng ngoài (`prisma validate`, `typecheck`, `eslint`, `prettier` trên file Sprint 7, **30/30 test files / 178/178 unit & route contract tests**, và `next build` production bundle).

Các hạng mục cần kết nối **PostgreSQL riêng (`TEST_DATABASE_URL`)** hoặc **hạ tầng live (Neon, Vercel, SMTP server thật)** được giữ ở trạng thái **BLOCKED (Chờ hạ tầng/biến môi trường ngoài phiên)**:

- **BLOCKED — Live PostgreSQL Integration (`npm run test:integration`):** Guard cô lập `TEST_DATABASE_URL` (`DEC-066`) hoạt động đúng, từ chối fallback về `.env` (`DATABASE_URL` / `DIRECT_URL`) và dừng fail-fast trên cả 8 integration suites vì chưa được cấp `TEST_DATABASE_URL`.
- **BLOCKED — Live Playwright DB-Backed E2E (`npm run test:e2e`):** Chromium 159 (`v1255`) đã cài đặt, Playwright đã liệt kê đủ `6 tests in 4 files`, và Mock SMTP offline đã sẵn sàng; việc chạy toàn bộ E2E đang chờ `TEST_DATABASE_URL` đã migrate.
- **BLOCKED — Live Cloud Deployment (`PEND-701` – `PEND-704`):** Máy cục bộ hiện không cài `vercel`, `neonctl`, `pg_dump`, `psql` và không có `VERCEL_TOKEN` / Neon / SMTP production credentials (không đọc hoặc chỉnh sửa `.env`).

---

## 2. Package-by-Package Implementation & Commit Map

| Package | Commit SHA | Nội dung chính đã triển khai |
|---|---|---|
| **Package 1** | `4f98841` | Cô lập `TEST_DATABASE_URL` (`tests/lib/test-db-isolation.ts`, `tests/setup-env.ts`, `tests/unit/test-db-isolation.test.ts`), tách `test:unit` / `test:integration` trong `package.json`, bảo vệ `DEC-066`. |
| **Package 2** | `e9cc79b` | Migration `20261115160000_sprint7_security_rate_limit_and_smtp`, `User.tokenVersion` (`DEC-063`), Permission #28 `project.template.manage` (`DEC-064`), PostgreSQL Sliding Window Rate Limiting `RateLimitEvent` (`DEC-065`), HTTP Security Headers / CSP (`next.config.ts`), `64 KB` JSON limit (`413`), open-redirect hardening (`src/lib/safe-redirect.ts`), và chuyển toàn bộ email sang **Nodemailer SMTP (`DEC-070`)** kèm xóa `src/server/integrations/resend.ts`. |
| **Package 3** | `463898b` | Sửa bug Sprint 6 (`BUG-701` dead links, `BUG-702` report project switcher key, `activity.repository.ts`, `estimate-reconstruction.ts`, `dashboard.service.ts`), bổ sung App Router `error.tsx` / `global-error.tsx` / `not-found.tsx` / `loading.tsx`, loại bỏ client polling khỏi `NotificationBell` (zero polling, dùng SSR `initialUnreadCount`), URL `?page=` pagination (`src/lib/search-params.ts`, `UrlPaginationControls`) & `usePropSyncedState`. |
| **Package 4** | `e33a4df` | Trích xuất `prisma/seed-helpers.ts` (`runSafeSeed` — `DEC-067`), viết `tests/unit/sprint7-seed-safety.test.ts`, `tests/unit/sprint7-bugfixes.test.ts`, `tests/integration/sprint7-seed-safety.test.ts`, `tests/integration/sprint7-cross-module.test.ts`, cài `@playwright/test` + Chromium, tạo `playwright.config.ts`, `tests/e2e/helpers/{e2e-db,e2e-ui,mock-smtp}.ts` và 4 E2E specs `01`–`04.spec.ts`. |
| **Package 5** | `b34e6ed` | Tạo `/api/health` & `/api/v1/health` (`src/lib/health.ts` chạy `SELECT 1`, `Cache-Control: no-store`), thêm `validateRuntimeEnvironment` & `isPooledDatabaseUrl` vào `src/lib/env.ts`, đơn giản hóa `prisma/seed.ts` dùng `runSafeSeed`, thêm `"postinstall": "prisma generate"`, đặt `"regions": ["sin1"]` trong `vercel.json`, cập nhật `.env.example` giá trị rỗng (`KEY=`), và viết `tests/unit/sprint7-health-env.test.ts`. |
| **Package 6** | Verified cleanly | Kiểm toán `20261115160000_sprint7_security_rate_limit_and_smtp/migration.sql` (71 dòng additive/idempotent), quét static bundle `.next/static/chunks/*.js` (`STATIC_SECRET_HITS=0`), kiểm toán toàn bộ reference `resend`, và ghi nhận rõ trạng thái `BLOCKED` cho `PEND-701`–`PEND-704`. |
| **Package 7** | `bc3bcaf` | Cập nhật `DECISION-LOG.md` (`DEC-070`), `README.md`, đồng bộ tài liệu `markdown/*`, thêm `05-Quality-and-Delivery/User-and-Admin-Guide.md`, cập nhật `DOCUMENT-INVENTORY.md`, viết báo cáo này và đóng gói backup archive không chứa secret (`backups/akatsuki-yui-docs-ops-backup-20261115.tar.gz`). |

---

## 3. SMTP Migration (`DEC-070`) & Strict Free-Tier Background Policy

### 3.1. Migration từ Resend sang Nodemailer SMTP
- **Loại bỏ hoàn toàn Resend SDK:** Đã xóa `src/server/integrations/resend.ts`; kiểm tra `git grep -n -i "resend"` trên `src/`, `vercel.json`, `.env.example` xác nhận không còn phụ thuộc `resend` hay `RESEND_API_KEY` (chỉ còn tên boolean `confirmUnknownResend` tương ứng hành động "re-send" cho bản ghi `UNKNOWN`).
- **Transport bảo mật (`src/server/integrations/email.ts`):**
  - Hỗ trợ `SMTP_AUTH_MODE="password"` và `"oauth2"`.
  - Bắt buộc TLS (`rejectUnauthorized: true`, `minVersion: "TLSv1.2"`); chỉ bỏ `requireTLS` khi là loopback `127.0.0.1`/`localhost`/`::1` trong non-production hoặc khi test E2E chủ động bật `E2E_ALLOW_PLAINTEXT_LOOPBACK_SMTP=1`.
  - Timeout giới hạn (`4s` connect/greeting, `7s` socket, `3s` DNS) và deterministic RFC 5322 `Message-ID: <notification-delivery-${deliveryId}@${domain}>`.
- **Awaited Bounded Post-Commit Dispatch & Rolling Quota (`src/modules/notifications/notification-delivery.service.ts`):**
  - Thay `after()` bằng awaited bounded post-commit dispatch (`<= 5` emails/request và `<= 10` emails/Cron run, concurrency `<= 2`).
  - Bảo vệ quota trước khi mở socket bằng `pg_advisory_xact_lock(hashtext('smtp:global:quota'))` trên bảng `SmtpQuotaAttempt` (`SMTP_DAILY_SEND_LIMIT` mặc định `50`, `SMTP_PER_MINUTE_LIMIT` mặc định `10`).
  - Trạng thái `UNKNOWN` được gán khi lỗi socket/timeout xảy ra *sau* bước `DATA`: khóa auto-retry để ngăn gửi trùng cho tới khi Admin xác nhận thủ công (`confirmUnknownResend: true`).

### 3.2. Strict Free-Tier Background Request Policy
- **Zero Client Polling:** `NotificationBell` (`src/components/features/notifications/notification-bell.tsx`) nhận `initialUnreadCount` từ SSR (`src/app/(dashboard)/layout.tsx` -> `<AppShell>`), không dùng `setInterval` hay auto-fetch khi đổi route, chỉ gọi API khi user chủ động bấm mở hoặc bấm nút làm mới.
- **Single Daily Cron Schedule:** `vercel.json` chỉ có duy nhất một cron `"0 1 * * *"` gọi `/api/internal/notifications/process` ở vùng `sin1` (có `timingSafeEqual` trên `CRON_SECRET`, `LIMIT 200` cleanup cho `RateLimitEvent` và `SmtpQuotaAttempt`).
- **On-Demand Healthchecks:** `/api/health` và `/api/v1/health` dùng `export const dynamic = "force-dynamic"`, trả `200 { status: "ok", db: "up" }` hoặc sanitized `503 { status: "error", db: "down" }` với `Cache-Control: no-store, max-age=0`.

---

## 4. Database Schema, Migration & Safe Seed Audit

| Thành phần | Trạng thái | Chi tiết xác minh |
|---|---|---|
| `prisma/schema.prisma` | Validated | `npx prisma validate` PASS. Bổ sung `User.tokenVersion`, `NotificationDeliveryStatus.UNKNOWN`, default `NotificationDelivery.provider = "SMTP"`, `RateLimitEvent`, `SmtpQuotaAttempt`. |
| `prisma/migrations/20261115160000_sprint7_security_rate_limit_and_smtp/migration.sql` | Audited (71 lines) | 100% additive/idempotent (`IF NOT EXISTS`, `WHERE NOT EXISTS`, giữ nguyên quyền role hiện có, chỉ thêm `project.template.manage` và cấp cho `ADMIN` 1 lần). |
| `prisma/seed.ts` + `prisma/seed-helpers.ts` | Verified (Unit 4/4) | `runSafeSeed` upsert permission catalog idempotently, chỉ seed `RolePermission` mặc định cho Role mới tạo (bảo toàn thay đổi RBAC Admin), từ chối mật khẩu yếu, không ghi đè `fullName`/`status`/`passwordHash` của Admin đang tồn tại (Admin `SUSPENDED` không bị tự kích hoạt lại). |

---

## 5. Event-to-Report & Activity Matrix (Đã kiểm thử Unit & E2E Coverage)

| Sự kiện nghiệp vụ | Target Table / Module | Phản ánh sang UI/API nào | Trạng thái verify |
|---|---|---|---|
| Đăng ký & Phê duyệt/Từ chối tài khoản | `User`, `UserRole`, `AuditLog`, `ActivityLog`, `Notification`, `NotificationDelivery` | `/admin/users`, `/notifications`, `/admin/notifications/deliveries` | Unit tests + `01-auth-rbac` & `03-docs-notifications` E2E specs |
| Tạo / Kích hoạt / Lưu trữ / Khôi phục Project | `Project`, `ProjectMember`, `ActivityLog`, `AuditLog` | `/dashboard`, `/projects`, `/reports`, `/activity` (`entityType="Project"`) | Unit tests + `sprint7-cross-module.test.ts` + `02-project-task-sprint.spec.ts` |
| Thêm / Xóa thành viên Project / Đổi Leader | `ProjectMember` (`leftAt`), `ActivityLog`, `Notification`, `NotificationDelivery` | `/reports` (kể cả cựu thành viên `leftAt`), `/activity` (`entityType="ProjectMember"`), SMTP delivery | `sprint6-member-contribution.test.ts` + `sprint6-activity.test.ts` + `sprint7-cross-module.test.ts` |
| Tạo / Phân công / DAG Dependency / Review Task | `Task`, `TaskAssignee`, `TaskHistory`, `TaskReview`, `Notification`, `NotificationDelivery` | `/projects/[projectId]/tasks`, `/reports`, `/dashboard`, `/activity` (`source="TASK"`) | `sprint3-task-services.test.ts` + `sprint6-project-analytics.test.ts` + `02-project-task-sprint.spec.ts` |
| Lập kế hoạch / Kích hoạt / Hoàn thành Sprint | `Sprint`, `Task.sprintId`, `TaskHistory`, `ActivityLog` | `/projects/[projectId]/sprints`, `/reports` (6 metrics Commitment & Rollover + immutable Burndown `DEC-058`) | `sprint6-sprint-analytics.test.ts` + `sprint7-cross-module.test.ts` + `02-project-task-sprint.spec.ts` |
| Thêm / Xóa mềm Tài liệu Drive/Docs | `Document` (`deletedAt`), `ActivityLog`, `AuditLog` | `/documents`, `/projects/[projectId]/documents`, `/activity` (`entityType="Document"`) | `sprint5-documents.test.ts` + `03-docs-notifications-reports.spec.ts` |
| Reminder hạn chót Cron hằng ngày | `Notification`, `NotificationDelivery`, `SmtpQuotaAttempt`, `RateLimitEvent` cleanup | `/notifications`, `/admin/notifications/deliveries`, `dedupKey` tránh gửi trùng trong ngày | `sprint5-notifications.test.ts` + `sprint5-email-worker.test.ts` + `03-docs-notifications-reports.spec.ts` |

---

## 6. Security Verification Matrix

| Hạng mục bảo mật | Cơ chế đã triển khai | Vị trí mã nguồn | Kết quả kiểm tra |
|---|---|---|---|
| **HTTP Security Headers & CSP** | `Content-Security-Policy` (bỏ `unsafe-eval` ở prod), `X-Content-Type-Options: nosniff`, `X-Frame-Options: DENY`, `Referrer-Policy`, `Permissions-Policy`, `HSTS` khi HTTPS, tắt `X-Powered-By` | `next.config.ts` | Unit tests + `04-security-idor-and-ux.spec.ts`; static chunk secret hits = `0` |
| **Session Revocation (`DEC-063`)** | Lưu `tokenVersion` trong JWT và đối chiếu với `User.tokenVersion` ở `loadTrustedAuthContext`; tăng khi đổi mật khẩu, `SUSPEND`, hoặc đổi Role | `src/lib/auth.ts`, `src/lib/auth.config.ts`, `src/modules/auth/auth.service.ts`, `src/modules/users/user.service.ts` | Verified logic + `01-auth-rbac-and-session.spec.ts` |
| **RBAC `project.template.manage` (`DEC-064`)** | Permission #28 chỉ cấp mặc định cho `ADMIN`, giữ Core Admin Locks (`account.*`, `role.manage`, `project.restore`, `notification.delivery.*`) | `src/modules/authorization/constants.ts`, `src/app/(dashboard)/admin/templates/page.tsx`, `src/modules/project-templates/template.service.ts` | `authorization-policy.test.ts` + `sprint2-api-routes.test.ts` |
| **Sliding Window Rate Limit (`DEC-065`)** | `RateLimitEvent` nguyên tử bằng `pg_advisory_xact_lock`, HMAC theo `scope + normalizedIdentifier`, fail-closed `503` cho auth nhạy cảm, `429 + Retry-After`, single check mỗi HTTP request qua `runWithRateLimitContext`, không cộng failure khi login hợp lệ | `src/lib/rate-limit.ts`, `src/app/api/auth/[...nextauth]/route.ts`, `src/modules/auth/sign-in-helper.ts` | `sprint7-rate-limit.test.ts` (5/5 tests pass) + `04-security-idor-and-ux.spec.ts` |
| **Open Redirect & Body Limit & URL Allowlist** | `getSafeCallbackUrl` (chặn protocol-relative & external domain), `MAX_JSON_BODY_BYTES = 64 * 1024` (`413`), Google Drive `https://drive.google.com` / `docs.google.com` | `src/lib/safe-redirect.ts`, `src/lib/request.ts`, `src/modules/documents/document.validation.ts` | `sprint7-security-hardening.test.ts` (6/6 tests pass) + `sprint5-documents.test.ts` |
| **Zero Secret / PII Leak** | Mask email & redaction URL/password/token trong `logger.ts`, health error sanitized, `.env.example` giá trị rỗng `KEY=` | `src/lib/logger.ts`, `src/lib/health.ts`, `.env.example` | `.next/static/chunks/*.js` scan: `STATIC_SECRET_HITS=0`; `sprint7-health-env.test.ts` pass |

---

## 7. Verification Summary (Observed vs Blocked)

### 7.1. Verified Passed Commands (Observed in Session)
- `npx prisma validate`: Valid (`prisma/schema.prisma`).
- `npm run typecheck` (`tsc --noEmit`): Exit 0 (0 errors).
- `npm run lint` (`eslint .`): Exit 0 (0 warnings/errors).
- `npx prettier --check` trên 24 file mới/sửa đổi của Package 4–5 (`e33a4df~1..b34e6ed`): Passed (`All matched files use Prettier code style!`); giữ nguyên định dạng gốc đối với 64/118 file chạm qua ở Package 1–3 để tránh noise diff trên mã nền (`DEC-068` / `OQ-711`).
- `npm run test:unit` (`vitest run tests/unit`): **30 passed (30) files, 178 passed (178) tests** (`sprint7-health-env.test.ts`, `sprint7-seed-safety.test.ts`, `sprint7-bugfixes.test.ts`, `sprint7-smtp-email.test.ts`, `sprint7-rate-limit.test.ts`, `sprint7-security-hardening.test.ts`, `sprint5-email-worker.test.ts`, v.v.).
- `npx playwright test --list`: Discovered **6 tests in 4 files** cleanly (`01`–`04.spec.ts`).
- `npm run build` (`next build`): Exit 0 (Production build succeeded; 30/30 static pages + `/api/health` & `/api/v1/health` dynamic routes).
- Static bundle secret scan (`.next\static\chunks\*.js`): `STATIC_SECRET_HITS=0`.
- Non-secret documentation & ops backup (`backups/akatsuki-yui-docs-ops-backup-20261115.tar.gz`, gitignored): Packages `markdown/`, `report/`, `README.md`, `.env.example`, `vercel.json`, `prisma/schema.prisma`, `prisma/migrations/`; verified via `tar -tzf` (`0` `.env*` files) and clean extraction test (operator copy to off-workstation destination remains manual per `DEC-068`).

### 7.2. Explicitly BLOCKED Items (Cannot Verify Without External Infra/Env)
- **Integration Test Suite (`npm run test:integration`):** Bị chặn có chủ đích bởi `validateTestDatabaseIsolation` (`DEC-066`, `Command exited with code 1`) do chưa có `TEST_DATABASE_URL` riêng. Toàn bộ 8 suite (`tests/integration/sprint1..6-db.test.ts`, `sprint7-seed-safety.test.ts`, `sprint7-cross-module.test.ts`) chờ PostgreSQL test database.
- **Playwright Live E2E Execution (`npm run test:e2e`):** Chưa thực thi runtime browser vs server vì yêu cầu `TEST_DATABASE_URL` đã chạy migration.
- **`PEND-701` — Live Neon Database Provision & Migration Deploy:** Chưa có Neon project/credentials; chưa chạy `pg_dump` + `npx prisma migrate deploy` + `npx prisma db seed` trên Neon.
- **`PEND-702` — Live Vercel Hobby Deployment (`sin1`):** Không có `vercel` CLI và `VERCEL_TOKEN`; chưa gán URL production thực tế (`AUTH_URL`, `NEXT_PUBLIC_APP_URL`) hay kiểm tra HTTP headers live.
- **`PEND-703` — Live SMTP & Daily Cron Smoke Verification:** Chưa thực thi gửi email qua SMTP server thật hoặc kích hoạt Cron live bằng `CRON_SECRET`.
- **`PEND-704` — Production WAN Telemetry (Cold vs Warm Navigation):** Chưa thể đo TTFB / LCP thực tế trên WAN cho tới khi deploy lên Vercel `sin1`.

---

## 8. Operator Handoff Checklist (Trước & Sau khi Deploy Live)

Thực hiện đầy đủ 12 bước trong `markdown/04-Technical-Specifications/Development-Guidelines.md` Section `16.1`, tóm tắt trọng tâm:

1. **Tạo Neon PostgreSQL 18 (Singapore):** Lấy 2 connection strings: `DATABASE_URL` (`-pooler`) cho Vercel Runtime và `DIRECT_URL` (unpooled) cho máy Operator.
2. **Migration & Safe Seed từ Operator CLI:** Chạy `pg_dump` trước (nếu có dữ liệu), chạy `DATABASE_URL="$DIRECT_URL" npx prisma migrate deploy`, và chạy one-time seed `DATABASE_URL="$DIRECT_URL" SEED_ADMIN_EMAIL=... SEED_ADMIN_PASSWORD=... npx prisma db seed`.
3. **Cấu hình Vercel Project (`sin1`):** Nhập đúng nhóm Runtime Env từ `.env.example` (**không** nhập `DIRECT_URL` hay `SEED_ADMIN_*`), xác nhận `AUTH_SECRET` (>= 32 chars), `AUTH_TRUST_HOST=true`, `CRON_SECRET`, và bộ biến `SMTP_*`.
4. **Hậu kiểm Deploy:** Mở `GET /api/health` (`200 { status: "ok", db: "up" }`), kiểm tra security headers trên `/login`, test đổi mật khẩu/thu hồi phiên, kích hoạt Cron `Authorization: Bearer $CRON_SECRET` tới `/api/internal/notifications/process`, xác minh email SMTP thật, và cập nhật Production URL vào báo cáo hoàn thiện (`OQ-705`).
