# SPRINT 2 IMPLEMENTATION REPORT — AUTHORIZATION & PROJECT MANAGEMENT

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 2 — Authorization & Project Management  
**Status:** Completed & Verified  
**Architecture:** Modular Monolith (Next.js 16 App Router + Prisma + PostgreSQL)

---

## 1. Executive Summary

Sprint 2 đã được triển khai đầy đủ theo kế hoạch đã phê duyệt (`report/SPRINT-2-IMPLEMENTATION-PLAN.md`), bao gồm 4 phân hệ trọng tâm:

1. **Permission Management (`UC-006`, `FR-AUTH-007`):** Ma trận Role–Permission thời gian thực, cấp/thu hồi quyền an toàn, bảo vệ các quyền quản trị cốt lõi của Role `ADMIN` (`BR-AUTHZ-008`), và ghi nhận `AuditLog` + `ActivityLog`.
2. **Project Management (`UC-007`–`UC-011`, `UC-034`, `FR-PROJ-001`–`005`, `FR-PROJ-007`):** Tạo/Xem/Cập nhật Project, kích hoạt (`CREATED -> ACTIVE`), lưu trữ (`CREATED | ACTIVE -> ARCHIVED`), khôi phục chỉ dành cho Admin (`ARCHIVED -> CREATED | ACTIVE`, `DEC-008`), thực thi ràng buộc tối đa 01 Project `ACTIVE` toàn Workspace (`BR-PROJ-004`) ở cả tầng Service và PostgreSQL Partial Unique Index.
3. **Project Template Management (`BR-PROJ-010`, `DEC-001`):** Quản lý các mẫu thông tin Project Template dùng chung toàn Workspace (tùy chọn khi khởi tạo Project), hỗ trợ bật/tắt (`isActive`) và chặn xóa cứng khi đang được Project tham chiếu (`TEMPLATE_IN_USE`).
4. **Project Member Management (`UC-012`, `FR-PROJ-006`, `DEC-009`):** Quản lý thành viên Project, chỉ nhận tài khoản `ACTIVE` (`BR-MEM-001`), chuyển giao Project Leader đồng bộ `Project.leaderId` & `ProjectMember`, loại bỏ mềm qua `leftAt` để bảo toàn lịch sử (`BR-MEM-003`, `BR-MEM-004`) kèm guard kiểm tra phân công Task cho Sprint 3 (`taskAssignmentGuard`).

---

## 2. Database & Migration (`S2-DB-01`)

- **Schema:** `prisma/schema.prisma`
  - Thêm enums: `ProjectStatus` (`CREATED`, `ACTIVE`, `ARCHIVED`), `ProjectMemberRole` (`LEADER`, `MEMBER`, `INSTRUCTOR`).
  - Thêm models: `ProjectTemplate`, `Project`, `ProjectMember` và quan hệ trên `User`.
- **Migration:** `prisma/migrations/20261114193729_sprint2_projects_and_members/migration.sql`
  - Bổ sung PostgreSQL Partial Unique Index `Project_single_active_idx` trên `"Project"("status") WHERE "status" = 'ACTIVE'`.
  - Bổ sung PostgreSQL Partial Unique Index `ProjectMember_active_project_user_idx` trên `"ProjectMember"("projectId", "userId") WHERE "leftAt" IS NULL`.
  - Bổ sung Check Constraint `Project_date_range_chk` (`CHECK ("endDate" >= "startDate")`).

---

## 3. Modules & Endpoints Implemented

### 3.1. Module 1 — Role & Permission Matrix (`src/modules/roles/*`)
- Services & Actions: `role.schema.ts`, `role.repository.ts`, `role.service.ts`, `role.actions.ts`.
- REST Endpoints:
  - `GET /api/v1/roles`
  - `POST / PATCH / DELETE /api/v1/roles/[roleId]/permissions`
- Bảo vệ `CORE_ADMIN_PERMISSION_CODES` (`account.read`, `account.approve`, `account.manage`, `role.manage`, `project.restore`) khỏi bị thu hồi trên Role `ADMIN` với mã lỗi `409 CORE_ADMIN_PERMISSION_LOCKED`.
- UI: `src/components/roles/permission-matrix.tsx`, trang `/admin/roles` (`role.manage`).

### 3.2. Module 3 — Project Templates (`src/modules/project-templates/*`)
- Services & Actions: `template.schema.ts`, `template.repository.ts`, `template.service.ts`, `template.actions.ts`.
- REST Endpoints:
  - `GET / POST /api/v1/project-templates`
  - `GET / PATCH / DELETE /api/v1/project-templates/[templateId]`
- UI: `src/components/templates/templates-manager.tsx`, trang `/admin/templates` (`project.create` hoặc `role.manage`).

### 3.3. Module 2 — Project Lifecycle (`src/modules/projects/*`)
- Services & Access & Actions: `project.schema.ts`, `project.access.ts`, `project.repository.ts`, `project.service.ts`, `project.actions.ts`.
- REST Endpoints:
  - `GET / POST /api/v1/projects`
  - `GET / PATCH /api/v1/projects/[projectId]`
  - `POST /api/v1/projects/[projectId]/activate`
  - `POST /api/v1/projects/[projectId]/archive`
  - `POST /api/v1/projects/[projectId]/restore`
- UI: `src/components/projects/{project-list-client,project-form,project-detail-actions}.tsx`, các trang `/projects`, `/projects/new`, `/projects/[projectId]`, `/projects/[projectId]/edit`.

### 3.4. Module 4 — Project Members (`src/modules/project-members/*`)
- Services & Guard & Actions: `member.schema.ts`, `member.repository.ts`, `task-assignment-guard.ts`, `member.service.ts`, `member.actions.ts`.
- REST Endpoints:
  - `GET / POST /api/v1/projects/[projectId]/members`
  - `DELETE /api/v1/projects/[projectId]/members/[userId]`
  - `PATCH /api/v1/projects/[projectId]/leader`
- UI: `src/components/projects/project-members-panel.tsx` (tích hợp trong `/projects/[projectId]`).

### 3.5. Shared Infrastructure, Navigation & Documentation
- Cập nhật `src/types/api.ts` với các mã lỗi Sprint 2 (`CORE_ADMIN_PERMISSION_LOCKED`, `PROJECT_ALREADY_ACTIVE`, `PROJECT_ARCHIVED`, `PROJECT_NOT_ARCHIVED`, `ALREADY_PROJECT_MEMBER`, `TASK_ASSIGNEE_REASSIGN_REQUIRED`, `TEMPLATE_IN_USE`).
- Thêm helper dùng chung `src/lib/prisma-errors.ts` (`isPrismaUniqueViolation`) và `src/components/ui/textarea.tsx`, mở rộng `src/components/shared/status-badge.tsx`.
- Cập nhật `src/components/layout/app-shell.tsx` (menu điều hướng theo quyền cho Projects, Project Templates, Phân quyền Roles) và `src/app/(dashboard)/dashboard/page.tsx` (thống kê Project & nổi bật Project `ACTIVE`).
- Cập nhật tài liệu API tại `markdown/04-Technical-Specifications/API-Specification.md`.

---

## 4. Verification Summary

Tất cả các kiểm tra chất lượng và bộ test Sprint 1 + Sprint 2 đã chạy sau chỉnh sửa cuối cùng và đạt kết quả PASS:

| Check / Suite | Command | Result |
|---|---|---|
| Prisma Schema Validate | `npx prisma validate` | Valid |
| Prettier Format Check | `npm run format:check` | Passed |
| TypeScript Check | `npm run typecheck` | Passed (0 errors) |
| ESLint | `npm run lint` | Passed (0 problems) |
| Unit & PostgreSQL Integration Tests | `npm run test` (`vitest run`) | **10 test files passed (10), 49 tests passed (49)** |
| Production Build | `npm run build` (`next build`) | Compiled & built cleanly (39 routes) |

### Test Coverage Highlights
- `tests/unit/sprint2-services.test.ts` (11 tests): Validation schema ngày tháng/URL/technologies, Last Admin Core Permission Lock, `TEMPLATE_IN_USE`, Leader auto-assignment (`BR-PROJ-003`), chặn sửa Project `ARCHIVED`, chặn Activate Project thứ 2, Admin-only Restore, chặn thêm user `PENDING`/trùng lặp, và `TASK_ASSIGNEE_REASSIGN_REQUIRED`.
- `tests/unit/sprint2-api-routes.test.ts` (5 tests): REST contract cho `/api/v1/roles*`, `/api/v1/project-templates*`, `/api/v1/projects*`, `/members*`, `/leader`.
- `tests/integration/sprint2-db.test.ts` (3 tests trên PostgreSQL thật): Hiệu lực Permission Matrix tức thì qua `loadTrustedAuthContext`, PostgreSQL partial unique index `Project_single_active_idx`, `ProjectMember_active_project_user_idx` khi soft-leave + rejoin giữ đủ lịch sử, Admin Restore, và chuyển giao Project Leader.
- Toàn bộ 7 test files của Sprint 1 (`30 tests`) tiếp tục PASS đầy đủ không hồi quy.
