# SPRINT 2 IMPLEMENTATION PLAN — AKATSUKI YUI

**Project:** Akatsuki Yui — Team & Project Management System  
**Sprint:** Sprint 2 — Authorization & Project Management  
**Phase:** Implementation Planning (Planning Only — No Code Changes)  
**Architecture:** Modular Monolith (Next.js 16 App Router + TypeScript + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5 JWT + Tailwind CSS v4 + shadcn/ui + Zod + React Hook Form)  
**Baseline:** `AGENT.md`, `markdown/DECISION-LOG.md` (`DEC-001`–`DEC-018`), Sprint 1 Codebase

---

## 1. Sprint Overview

Sprint 2 mở rộng hệ thống từ nền tảng xác thực và quản lý tài khoản (Sprint 1) sang **hệ thống phân quyền động (Permission Matrix)** và **quản lý vòng đời Project** (`Project`, `ProjectTemplate`, `ProjectMember`). Đây là nền tảng trực tiếp cho Sprint 3 (Task Management) và Sprint 4 (Sprint & Kanban).

---

## 2. Sprint Goal

Hoàn thiện phân hệ **Authorization (Permission Matrix)** cho phép Admin quản lý chi tiết quyền theo Role kèm AuditLog, đồng thời xây dựng đầy đủ phân hệ **Project Management**, **Project Template** (tùy chọn) và **Project Member Management** tuân thủ nghiêm ngặt invariant **tối đa 1 Active Project** và **bảo toàn lịch sử thành viên/lịch sử Project**.

---

## 3. Sprint Scope

1. **Module 1 — Permission Management (`UC-006`, `FR-AUTH-007`):**
   - Xem danh sách Roles (`ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER`) và Permissions hiện tại.
   - Hiển thị Permission Matrix (Role × Permission).
   - Grant / Revoke Permission cho từng Role từ phía Server.
   - Bảo vệ Last Admin Protection (`BR-AUTHZ-008`) — không cho phép thu hồi các quyền quản trị cốt lõi (`account.read`, `account.manage`, `role.manage`, `project.restore`) của Role `ADMIN`.
   - Ghi `AuditLog` và `ActivityLog` cho mọi thay đổi Permission.
2. **Module 2 — Project Management (`UC-007`–`UC-011`, `FR-PROJ-001`–`FR-PROJ-005`, `FR-PROJ-007`):**
   - Create Project (Admin/Leader; Leader tạo tự động trở thành Project Leader; `templateId` và `instructorId` tùy chọn).
   - View Project list & Project detail (theo phạm vi quyền `project.read`).
   - Update Project (`project.update`; chặn chỉnh sửa thông thường khi Project ở trạng thái `ARCHIVED`).
   - Activate Project (`CREATED -> ACTIVE`), Archive Project (`CREATED/ACTIVE -> ARCHIVED`), Restore Archived Project (`ARCHIVED -> CREATED | ACTIVE`, Admin only `project.restore`).
   - Bảo vệ invariant **tối đa 1 Project `ACTIVE`** bằng PostgreSQL Partial Unique Index + Prisma Transaction.
3. **Module 3 — Project Template (`BR-PROJ-010`, `DEC-001`, `Database-Design.md §6.2`):**
   - CRUD Project Template (`ProjectTemplate` là global workspace template).
   - Chọn Template (tùy chọn) khi tạo Project, hoặc tạo Project không cần Template.
   - Xóa / vô hiệu hóa Template an toàn (`isActive = false` hoặc chỉ xóa khi chưa gắn Project nào để bảo toàn FK).
4. **Module 4 — Project Member Management (`UC-012`, `FR-PROJ-006`, `DEC-009`):**
   - Thêm thành viên `ACTIVE` vào Project (`LEADER`, `MEMBER`, `INSTRUCTOR`), chống trùng thành viên đang hoạt động.
   - Xem danh sách và chi tiết thành viên trong Project.
   - Đổi Project Leader (giữ đồng bộ `Project.leaderId` và `ProjectMember`).
   - Gỡ thành viên bằng soft-leave (`leftAt = now()`) để bảo toàn lịch sử; chuẩn bị guard interface cho quy tắc reassign Task (`DEC-009` / `BR-MEM-005`).

---

## 4. Out of Scope

- Task, TaskAssignee, TaskDependency, Task Review (Sprint 3).
- Sprint, Backlog, Kanban Board (Sprint 4).
- Document Library, Notification Center, SMTP Live Dispatch (Sprint 5).
- Full Dashboard Metrics, Burndown Chart & Reports (Sprint 6).
- Tự động sinh Task/Sprint từ Project Template (chỉ khởi tạo metadata/thông tin Project mặc định vì Task/Sprint chưa có ở Sprint 2).

---

## 5. Existing Implementation Baseline (Verified in Sprint 1)

- **Auth (`src/lib/auth.ts`, `src/lib/auth.config.ts`, `src/middleware.ts`):** Auth.js v5 JWT + Credentials, giữ nguyên không viết lại.
- **Authorization (`src/modules/authorization/`):**
  - `constants.ts` đã định nghĩa đủ 4 Roles và 25 Permission Codes (bao gồm `role.manage`, `project.*`).
  - `policy.service.ts` (`loadTrustedAuthContext`, `hasPermission`, `assertPermission`) nạp trực tiếp Roles & Permissions từ PostgreSQL trên mỗi request bảo vệ.
  - `require-auth.ts` (`requireActiveUser`, `requirePermission`, `requirePermissionOrRedirect`) sẵn sàng tái sử dụng.
- **Database (`prisma/schema.prisma`):** Đã có `User`, `Role`, `Permission`, `UserRole`, `RolePermission`, `ActivityLog`, `AuditLog` cùng migration `20261114181931_init_sprint1`.
- **UI & API Conventions:** `apiSuccess` / `apiError` (`src/lib/api-response.ts`), `ActionResult<T>` (`src/lib/request.ts`), `AppShell` (`src/components/layout/app-shell.tsx`), shadcn/ui (`button`, `card`, `table`, `select`, `alert-dialog`, `badge`, `input`, `label`, `alert`).
- **Testing (`tests/`):** Vitest 5.1.0 + `tests/setup-env.ts` + PostgreSQL integration harness (`tests/integration/sprint1-db.test.ts`).

---

## 6. Requirement Traceability Matrix

| Module | Requirement / UC | Business Rule | Decision | Planned Implementation |
| --- | --- | --- | --- | --- |
| **Permission Management** | `FR-AUTH-007`, `UC-006` | `BR-AUTHZ-001`, `BR-AUTHZ-002`, `BR-AUTHZ-003`, `BR-AUTHZ-007`, `BR-AUTHZ-008` | `DEC-012` | Service + API `/api/v1/roles*` + UI `/admin/roles` (Permission Matrix) + AuditLog/ActivityLog |
| **Project Management** | `FR-PROJ-001`–`005`, `FR-PROJ-007`, `UC-007`–`011` | `BR-PROJ-001`–`008`, `BR-PROJ-011`, `BR-PROJ-012` | `DEC-002`, `DEC-008` | Model `Project` + Partial Unique Index `ACTIVE` + Service/API `/api/v1/projects*` + UI `/projects*` |
| **Project Template** | `FR-PROJ-001` (Template optional), `UC-007` | `BR-PROJ-010` | `DEC-001` | Model `ProjectTemplate` + Service/API `/api/v1/project-templates*` + UI `/admin/templates` & selector trong Create Project |
| **Project Member** | `FR-PROJ-006`, `UC-012` | `BR-PROJ-009`, `BR-MEM-001`–`005` | `DEC-009` | Model `ProjectMember` + Partial Unique Index `(projectId, userId) WHERE leftAt IS NULL` + Service/API `/api/v1/projects/:id/members*` + UI tab/section Members |

---

## 7. Module Breakdown

- **Module 1:** `src/modules/roles/` (Role & Permission Matrix management)
- **Module 2:** `src/modules/projects/` (Project CRUD, lifecycle `CREATED -> ACTIVE -> ARCHIVED`, Restore, single Active invariant)
- **Module 3:** `src/modules/project-templates/` (Template CRUD & activation/deletion safety)
- **Module 4:** `src/modules/project-members/` (Member add/list/remove/leader-change + Task reassignment guard interface)

---

## 8. Detailed Task Breakdown

| Task ID | Module | Task Name | Description | Requirements | Dependencies | Files | DB Impact | API Impact | Authorization | Validation | Tests | Acceptance Criteria | Priority |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| `S2-DB-01` | Shared DB | Prisma Schema & Migration for Sprint 2 | Thêm `ProjectStatus`, `ProjectMemberRole`, `ProjectTemplate`, `Project`, `ProjectMember` + Partial Unique Indexes (single `ACTIVE` Project, active `ProjectMember`) | `DEC-001`, `DEC-002`, `DEC-008`, `BR-PROJ-004` | Sprint 1 DB | `prisma/schema.prisma`, `prisma/migrations/*` | CREATE models, enums, custom SQL partial unique indexes | None | None | Schema constraints | Migration & `prisma validate` | Migration sạch trên PostgreSQL 18; partial unique index hoạt động | HIGH |
| `S2-AUTHZ-01` | Permission Mgmt | Role & Permission Matrix Service | Lấy danh sách Roles/Permissions, Grant/Revoke `RolePermission`, bảo vệ Admin core permissions, ghi `AuditLog` + `ActivityLog` | `UC-006`, `FR-AUTH-007`, `BR-AUTHZ-007`, `BR-AUTHZ-008` | `S2-DB-01` (none actually, Sprint 1 DB) | `src/modules/roles/{role.schema,role.repository,role.service,role.actions}.ts` | Reuse `Role`, `Permission`, `RolePermission` | Server Actions + REST | `role.manage` | Zod `roleId`, `permissionCode` | Unit + DB Integration | Admin grant/revoke được; từ chối non-admin & core Admin lock | HIGH |
| `S2-AUTHZ-02` | Permission Mgmt | Role & Permission API + UI | Endpoints `/api/v1/roles` & `/api/v1/roles/[roleId]/permissions`; trang `/admin/roles` hiển thị Permission Matrix | `UC-006`, `FR-AUTH-007` | `S2-AUTHZ-01` | `src/app/api/v1/roles/**`, `src/app/(dashboard)/admin/roles/page.tsx`, `src/components/roles/permission-matrix.tsx` | None | `GET /roles`, `PATCH /roles/:id/permissions` | `role.manage` | Zod | API + UI tests | Matrix load đúng từ DB; thay đổi có hiệu lực ngay ở request sau | HIGH |
| `S2-TPL-01` | Project Template | Template Service, API & UI | CRUD `ProjectTemplate` (`name`, `description`, `configuration`, `isActive`), xóa/vô hiệu hóa an toàn | `BR-PROJ-010`, `DEC-001` | `S2-DB-01` | `src/modules/project-templates/*`, `src/app/api/v1/project-templates/**`, `src/app/(dashboard)/admin/templates/page.tsx`, `src/components/templates/*` | Uses `ProjectTemplate` | `GET/POST /project-templates`, `PATCH/DELETE /project-templates/:id` | `project.create` / `role.manage` (Admin) | Zod (`name` required) | Unit + API + Integration | Admin tạo/sửa/vô hiệu hóa Template; Template đang dùng không bị xóa vỡ FK | MEDIUM |
| `S2-PROJ-01` | Project Mgmt | Project Repository & Core Service | Create (optional `templateId`, `instructorId`, Creator=Leader), List/Detail scoped by role, Update (block when `ARCHIVED`), Activate/Archive/Restore | `UC-007`–`011`, `FR-PROJ-001`–`005`, `FR-PROJ-007`, `DEC-008` | `S2-DB-01`, `S2-TPL-01` | `src/modules/projects/{project.schema,project.repository,project.service,project.actions}.ts` | Uses `Project`, `ProjectMember`, `AuditLog`, `ActivityLog` | Server Actions | `project.create`, `project.read`, `project.update`, `project.activate`, `project.archive`, `project.restore` | `startDate <= endDate`, valid URL, non-empty name | Unit + Integration (single Active invariant) | Chỉ tối đa 1 Project `ACTIVE`; Restore chỉ cho Admin; Archived không sửa được | HIGH |
| `S2-PROJ-02` | Project Mgmt | Project REST API & UI Pages | REST `/api/v1/projects*` + UI `/projects`, `/projects/new`, `/projects/[projectId]` (Overview, Edit, Activate/Archive/Restore dialogs) | `UC-007`–`011` | `S2-PROJ-01` | `src/app/api/v1/projects/**`, `src/app/(dashboard)/projects/**`, `src/components/projects/*` | None | All `/projects` endpoints | Server-side per endpoint | Zod | API contract tests | UI đầy đủ loading/empty/error/confirm states; responsive | HIGH |
| `S2-MEM-01` | Project Member | Project Member Service, API & UI | List/Add/Remove (`leftAt`) thành viên `ACTIVE`, đổi Project Leader, guard interface `BR-MEM-005` / `DEC-009` | `UC-012`, `FR-PROJ-006`, `BR-MEM-001`–`005`, `DEC-009` | `S2-PROJ-01` | `src/modules/project-members/*`, `src/app/api/v1/projects/[projectId]/members/**`, `src/components/projects/project-members-panel.tsx` | Uses `ProjectMember` | `GET/POST /projects/:id/members`, `DELETE /projects/:id/members/:userId`, `PATCH /projects/:id/leader` | `project.member.manage`, `project.read` | User phải `ACTIVE`, không trùng member đang hoạt động | Unit + Integration | Không thêm được `PENDING`/`SUSPENDED`; soft-leave giữ `leftAt` | HIGH |
| `S2-NAV-01` | Shared UI | Navigation & Dashboard Integration | Cập nhật `AppShell` sidebar (`/projects`, `/admin/roles`, `/admin/templates` theo permission) | `UI-UX-Design.md` | `S2-AUTHZ-02`, `S2-TPL-01`, `S2-PROJ-02` | `src/components/layout/app-shell.tsx` | None | None | Permission-gated links | None | Build & lint check | Menu hiển thị đúng theo Permission của từng Role | MEDIUM |

---

## 9. Dependency Map

```text
S2-AUTHZ-01 ──▶ S2-AUTHZ-02 ─────────────────────────┐
                                                     ├──▶ S2-NAV-01
S2-DB-01 ──▶ S2-TPL-01 ──▶ S2-PROJ-01 ──▶ S2-PROJ-02 ┤
                                  │                  │
                                  └──▶ S2-MEM-01 ────┘
```
- **Song song được:** `S2-AUTHZ-01/02` (chỉ dùng bảng Sprint 1) có thể làm song song với `S2-DB-01`.
- **Tuần tự bắt buộc:** `S2-DB-01` → `S2-TPL-01` → `S2-PROJ-01` → `S2-MEM-01` & `S2-PROJ-02` → `S2-NAV-01`.

---

## 10. Database Impact Analysis

- **Tái sử dụng:** `User`, `Role`, `Permission`, `UserRole`, `RolePermission`, `ActivityLog`, `AuditLog`.
- **Thêm mới (`prisma/schema.prisma`):**
  1. `enum ProjectStatus { CREATED ACTIVE ARCHIVED }`
  2. `enum ProjectMemberRole { LEADER MEMBER INSTRUCTOR }`
  3. `model ProjectTemplate` (`id`, `name` unique, `description`, `configuration Json?`, `isActive Boolean @default(true)`, `createdAt`, `updatedAt`)
  4. `model Project` (`id`, `name`, `description`, `objectives`, `scope`, `startDate`, `endDate`, `status`, `repositoryUrl`, `technologies Json?`, `templateId?`, `leaderId`, `instructorId?`, `createdById`, `createdAt`, `updatedAt`, `archivedAt?`)
  5. `model ProjectMember` (`id`, `projectId`, `userId`, `projectRole`, `joinedAt`, `leftAt?`, `createdAt`)
- **Ràng buộc & Indexes bắt buộc (qua raw SQL trong migration):**
  - Partial Unique Index 1 (Single Active Project):
    `CREATE UNIQUE INDEX "Project_single_active_idx" ON "Project" ("status") WHERE "status" = 'ACTIVE';`
  - Partial Unique Index 2 (Active ProjectMember uniqueness):
    `CREATE UNIQUE INDEX "ProjectMember_active_project_user_idx" ON "ProjectMember" ("projectId", "userId") WHERE "leftAt" IS NULL;`
- **Transactions:**
  - Create Project: tạo `Project` + tạo bản ghi `ProjectMember` cho `leaderId` (và `instructorId` nếu có) + `ActivityLog`.
  - Activate / Restore to `ACTIVE`: kiểm tra & cập nhật trong `prisma.$transaction` (bắt lỗi unique violation `P2002` từ PostgreSQL thành `409 ACTIVE_PROJECT_EXISTS`).
  - Change Leader / Remove Member: cập nhật đồng bộ `Project.leaderId` và `ProjectMember` + `AuditLog` + `ActivityLog`.

---

## 11. API and Server Action Plan

- **Reused Contracts:** `apiSuccess`, `apiError`, `ActionResult<T>`, `requireActiveUser`, `requirePermission`.
- **Endpoints mới cần thêm & cập nhật vào `API-Specification.md`:**
  - `GET /api/v1/roles` (`role.manage`) — danh sách Roles kèm Permissions và danh mục 25 Permissions.
  - `PATCH /api/v1/roles/[roleId]/permissions` (`role.manage`) — `{ permissionCode, action: "GRANT" | "REVOKE" }`.
  - `GET /api/v1/project-templates`, `POST /api/v1/project-templates`, `PATCH /api/v1/project-templates/[templateId]`, `DELETE /api/v1/project-templates/[templateId]`.
  - `GET/POST /api/v1/projects`, `GET/PATCH /api/v1/projects/[projectId]`, `POST /api/v1/projects/[projectId]/{activate,archive,restore}`.
  - `GET/POST /api/v1/projects/[projectId]/members`, `DELETE /api/v1/projects/[projectId]/members/[userId]`, `PATCH /api/v1/projects/[projectId]/leader`.

---

## 12. UI/UX Implementation Plan

- **Trang mới (trong `(dashboard)`):**
  - `/admin/roles`: Bảng Permission Matrix (cột là 4 Roles, hàng là 25 Permissions nhóm theo module, toggle switch có xác nhận & khóa các quyền lõi của `ADMIN`).
  - `/admin/templates`: Danh sách & Dialog tạo/sửa/vô hiệu hóa Project Template.
  - `/projects`: Danh sách Project (lọc theo `status`: `ALL`, `CREATED`, `ACTIVE`, `ARCHIVED`), nút Create Project.
  - `/projects/new`: Form tạo Project (chọn Template tùy chọn, chọn Instructor tùy chọn, nhập Start/End Date, Technologies, Repository URL, Objectives/Scope).
  - `/projects/[projectId]`: Chi tiết Project, tab/section Thông tin chung + Chỉnh sửa + Activate/Archive/Restore (với `AlertDialog`), và section Thành viên Project (Add Member, Change Leader, Remove Member).
- **Trạng thái UI:** Mọi bảng/form đều có loading state, empty state, error `Alert` + `toast`, và `AlertDialog` cho thao tác nhạy cảm (Revoke Admin permission, Archive, Restore, Remove Member).

---

## 13. Authorization Plan

- Tái sử dụng 100% `loadTrustedAuthContext` + `assertPermission` từ `src/modules/authorization/`.
- **Project-scoped access (`project.read`):**
  - `ADMIN`: xem tất cả Projects.
  - `LEADER`, `MEMBER`, `INSTRUCTOR`: chỉ xem các Project mà user là thành viên đang hoạt động (`ProjectMember` có `leftAt IS NULL`) hoặc `createdById`/`leaderId`/`instructorId`.
- **Single-role & Last Admin Protection:** Không cho phép thu hồi các quyền nền tảng của `ADMIN` (`account.read`, `account.manage`, `role.manage`, `project.restore`) để tránh tự khóa quản trị viên cuối cùng.

---

## 14. Testing Plan

- **Unit Tests:**
  - `role.service`: Grant/Revoke, chặn thu hồi core Admin permissions.
  - `project.service`: Date validation (`startDate <= endDate`), Creator=Leader khi Leader tạo, chặn update khi `ARCHIVED`, Restore chỉ cho Admin, Single Active Project invariant.
  - `project-template.service`: Name validation, soft-disable vs delete guard.
  - `project-member.service`: Chặn thêm user `PENDING`/`SUSPENDED`, chống trùng member, soft-leave `leftAt`, `BR-MEM-005` guard interface.
- **Integration Tests (PostgreSQL):**
  - Kiểm chứng Partial Unique Index `Project_single_active_idx` ở mức DB.
  - Kiểm chứng Partial Unique Index `ProjectMember_active_project_user_idx` (cho phép rejoin sau khi đã `leftAt`).
  - Kiểm chứng Permission Matrix thay đổi trong DB có hiệu lực ngay ở `loadTrustedAuthContext`.
- **API Tests:**
  - `200`/`201` hợp lệ, `400` Zod validation, `401` chưa đăng nhập, `403` thiếu quyền/ngoài phạm vi Project, `409` xung đột Active Project hoặc trùng thành viên.
- **Regression Tests:** Chạy lại toàn bộ 7 test files (30 tests) của Sprint 1 để đảm bảo không ảnh hưởng Auth/User/Profile.

---

## 15. File Ownership & Change Boundaries

- **CREATE:**
  - `src/modules/roles/*`, `src/modules/projects/*`, `src/modules/project-templates/*`, `src/modules/project-members/*`
  - `src/app/api/v1/roles/**`, `src/app/api/v1/project-templates/**`, `src/app/api/v1/projects/**`
  - `src/app/(dashboard)/admin/roles/**`, `src/app/(dashboard)/admin/templates/**`, `src/app/(dashboard)/projects/**`
  - `src/components/roles/*`, `src/components/templates/*`, `src/components/projects/*`
  - `tests/unit/{role,project,project-template,project-member}-*.test.ts`, `tests/integration/sprint2-db.test.ts`
- **MODIFY (Single Designated Owner per shared file):**
  - `prisma/schema.prisma` (Owner: `S2-DB-01`)
  - `src/components/layout/app-shell.tsx` (Owner: `S2-NAV-01`)
  - `src/types/api.ts` (Owner: `S2-PROJ-01` — nếu cần bổ sung ErrorCode như `ACTIVE_PROJECT_EXISTS`, `PROJECT_ARCHIVED`)
  - `markdown/04-Technical-Specifications/API-Specification.md` (Owner: `S2-PROJ-02`)
- **REVIEW ONLY (Không sửa):** `src/lib/auth.ts`, `src/lib/auth.config.ts`, `src/middleware.ts`, `src/modules/auth/*`, `src/modules/users/*`, `prisma/migrations/20261114181931_init_sprint1/*`.

---

## 16. Risks and Mitigation

| Risk | Impact | Mitigation |
| --- | --- | --- |
| Race condition khi 2 request cùng Activate/Restore Project | Vi phạm Single Active Project | Dùng PostgreSQL Partial Unique Index `Project_single_active_idx` + bắt `P2002` trả `409` |
| Thành viên rời Project rồi quay lại bị lỗi unique `(projectId, userId)` | Không thể tái tham gia Project | Dùng Partial Unique Index `WHERE "leftAt" IS NULL` thay vì unique cứng |
| Xóa Template đã được Project tham chiếu | Lỗi FK hoặc mất dữ liệu | Chặn hard-delete nếu có Project đang tham chiếu; hỗ trợ toggle `isActive = false` |
| `BR-MEM-005` phụ thuộc Task (Sprint 3) | Không có bảng `TaskAssignee` ở Sprint 2 | Tạo guard interface rõ ràng trong `project-member.service.ts` để Sprint 3 nối trực tiếp |

---

## 17. Acceptance Criteria

- [ ] Admin xem và chỉnh sửa được Permission Matrix (`/admin/roles`), thay đổi áp dụng ngay phía Server và lưu `AuditLog`.
- [ ] Admin & Leader tạo được Project (có hoặc không có Template/Instructor); Leader tạo tự động làm Leader.
- [ ] Chỉ tồn tại tối đa 1 Project `ACTIVE` tại mọi thời điểm (được bảo vệ ở DB).
- [ ] Archive giữ nguyên dữ liệu và chặn sửa; chỉ Admin mới Restore được Project `ARCHIVED`.
- [ ] CRUD Project Template hoạt động và tích hợp vào form tạo Project.
- [ ] Quản lý thành viên Project (Add `ACTIVE` user, Change Leader, Soft-leave `leftAt`) hoạt động đúng quyền.
- [ ] Toàn bộ test Unit, Integration, API và Regression Sprint 1 pass; `typecheck`, `lint`, `build` pass.

---

## 18. Definition of Done

- Code tuân thủ Modular Monolith, Prettier, ESLint (`0` errors/warnings), TypeScript strict (`0` errors).
- Migration Prisma sạch, không sửa migration Sprint 1.
- Đầy đủ Unit + PostgreSQL Integration + API + Sprint 1 Regression tests pass.
- `npm run build` thành công.
- Cập nhật `API-Specification.md` và xuất `SPRINT-2-IMPLEMENTATION-REPORT.md` sau khi hoàn tất triển khai.

---

## 19. Suggested Implementation Sequence

1. `S2-DB-01` (Schema & Migration) + song song `S2-AUTHZ-01` (Role/Permission Service).
2. `S2-AUTHZ-02` (Role/Permission API & UI `/admin/roles`).
3. `S2-TPL-01` (Project Template Service, API & UI).
4. `S2-PROJ-01` → `S2-PROJ-02` (Project Service, API & UI).
5. `S2-MEM-01` (Project Member Service, API & UI).
6. `S2-NAV-01` (Cập nhật `AppShell` navigation) → Full Testing & Verification.

---

## 20. Deferred Items & Unresolved Questions

- **Deferred to Sprint 3:** Kiểm tra thực tế `TaskAssignee` khi xóa thành viên (`BR-MEM-005` / `DEC-009`), sinh Task/Sprint tự động từ Template (nếu có).
- **Open Questions for User Confirmation (if needed before coding):**
  1. **Project Template Ownership:** Thiết kế hiện tại xem `ProjectTemplate` là **Global Workspace Template** do Admin quản lý (`/admin/templates`), còn Leader/Admin được chọn khi tạo Project. Bạn có muốn giữ như vậy không?
  2. **API Routes mới:** `API-Specification.md` chưa liệt kê sẵn endpoint cho `/roles` và `/project-templates`. Đề xuất bổ sung `/api/v1/roles*` và `/api/v1/project-templates*` theo chuẩn `/api/v1` hiện tại.

---

## Sprint 2 Completion Checklist

- [ ] `S2-DB-01`: Migration Sprint 2 đã chạy thành công trên PostgreSQL
- [ ] `S2-AUTHZ-01` & `S2-AUTHZ-02`: Permission Matrix hoạt động + AuditLog
- [ ] `S2-TPL-01`: Project Template CRUD & tích hợp Create Project
- [ ] `S2-PROJ-01` & `S2-PROJ-02`: Project CRUD, Activate, Archive, Restore & Single Active Index
- [ ] `S2-MEM-01`: Project Member Add/List/Leader/Soft-leave
- [ ] `S2-NAV-01`: AppShell Sidebar cập nhật đầy đủ
- [ ] `typecheck`, `lint`, `format:check`, `vitest run`, `next build` đều Pass
