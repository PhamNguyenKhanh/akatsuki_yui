# SPRINT 3 IMPLEMENTATION PLAN — TASK MANAGEMENT

**Dự án:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 3 — Task Management (Core Task, Assignment, Review Workflow, Dependency & Task History)  
**Giai đoạn:** Implementation Planning Only (Chưa chỉnh sửa code, schema hoặc migration)  
**Kiến trúc:** Modular Monolith — Next.js 16 App Router + TypeScript + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5  
**Baseline:** `AGENT.md`, `markdown/*`, `report/SPRINT-1-IMPLEMENTATION-REPORT.md`, `report/SPRINT-2-IMPLEMENTATION-REPORT.md`, codebase thực tế trên branch `dev` (`4339882`)  
**Ngày lập:** 2026-11-15  

---

## 1. Sprint Overview

Sprint 3 xây dựng **phân hệ Quản lý Công việc (Task Management)** — lõi vận hành hằng ngày của nhóm sinh viên trong từng Project của hệ thống Akatsuki Yui. Sau khi Sprint 1 hoàn thiện Authentication/Account Lifecycle và Sprint 2 hoàn thiện RBAC Permission Matrix, Project Lifecycle, Project Template và Project Member Management, Sprint 3 chuyển hóa phạm vi Project thành các đơn vị công việc cụ thể (`Task`) có:

- Thời hạn bắt buộc (`deadline`), thời gian bắt đầu tùy chọn (`startDate`), ước lượng giờ tùy chọn (`estimateHours`), độ ưu tiên (`LOW | MEDIUM | HIGH | CRITICAL`), tài liệu tham chiếu (`referenceLinks`) và ghi chú tiến độ (`progressNotes`).
- Mô hình **đa người thực hiện trên một trạng thái chung** (`TaskAssignee` N-N giữa `Task` và `User`, hỗ trợ Task chưa có Assignee và bảo lưu lịch sử phân công).
- **Quy trình trạng thái và Review kiểm soát chặt** (`TODO → IN_PROGRESS → REVIEW → DONE`, hoặc Reject `REVIEW → IN_PROGRESS` kèm lý do bắt buộc).
- **Quản lý phụ thuộc giữa các Task (`TaskDependency`)** với kiểm tra trùng lặp, tự tham chiếu, phát hiện chu trình (cycle detection) và ràng buộc hoàn thành toàn bộ Task tiền nhiệm trước khi chuyển sang `DONE` (`DEC-005`).
- **Nhật ký lịch sử Task tập trung (`TaskHistory`) & hồ sơ duyệt (`TaskReview`)** không trùng lặp với `AuditLog`/`ActivityLog`.
- **Nối guard ràng buộc gỡ thành viên Sprint 2 (`taskAssignmentGuard`)** vào `TaskAssignee` thực tế (`DEC-009` / `BR-MEM-005`).

---

## 2. Sprint Goal

Hoàn thiện end-to-end phân hệ **Task Management** bảo đảm toàn bộ quy tắc nghiệp vụ và phân quyền được thực thi tại Server Layer (Service + PostgreSQL Transaction + Constraints):

1. Leader (và Workspace Admin theo phạm vi quyền) tạo, xem, cập nhật Task thuộc Project chưa bị `ARCHIVED`.
2. Hỗ trợ gán 0, 1 hoặc nhiều `ProjectMember` đang hoạt động (tài khoản `ACTIVE`, `leftAt IS NULL`) cho một Task với **một trạng thái chung duy nhất**.
3. Member được phân công cập nhật tiến độ trong phạm vi trường cho phép theo `DEC-015` (`status`, `referenceLinks`, `progressNotes`) và gửi Task sang `REVIEW`.
4. Leader duyệt (`Approve`: `REVIEW → DONE`) hoặc từ chối (`Reject`: `REVIEW → IN_PROGRESS`) với **lý do bắt buộc**, được lưu vết đầy đủ.
5. Quản lý quan hệ phụ thuộc (`TaskDependency`): chống tự phụ thuộc, chống trùng, chống chu trình và chặn hoàn thành Task nếu còn tiền nhiệm chưa `DONE` (`DEC-005`), nhưng không chặn bắt đầu làm việc.
6. Nối `taskAssignmentGuard` vào `TaskAssignee` để chặn loại bỏ thành viên khỏi Project khi còn Task chưa `DONE` (`DEC-009`), đồng thời bảo toàn toàn bộ lịch sử phân công.
7. Bảo đảm nền tảng dữ liệu sạch để Sprint 4 bổ sung `Sprint`, Backlog, Sprint Planning và Kanban Board mà không phá vỡ cấu trúc hiện tại.

---

## 3. Scope

Sprint 3 bao gồm 5 module nghiệp vụ cốt lõi + tầng giao diện & kiểm thử tương ứng:

1. **Module 1 — Task Core Management:**
   - CRUD nghiệp vụ Task trong Project (Create, List với tìm kiếm/lọc/phân trang, View Detail, Update).
   - Hỗ trợ trường theo SRS/Database/DEC-003/DEC-004/DEC-015: `title`, `description`, `priority`, `status`, `startDate` (tùy chọn), `deadline` (bắt buộc), `estimateHours` (tùy chọn), `referenceLinks`, `progressNotes`, `projectId`, `createdById`, `createdAt`, `updatedAt`.
   - Khóa thao tác tạo/sửa khi Project đang ở trạng thái `ARCHIVED`.
2. **Module 2 — Task Assignment Management:**
   - Phân công / gỡ phân công / thay đổi danh sách Assignees (0..N active Project Members trên một Task).
   - Kiểm tra User `ACTIVE` và là `ProjectMember` đang hoạt động (`leftAt IS NULL`) trong đúng `projectId`.
   - Bảo toàn Assignment History (`assignedAt`, `removedAt`, `assignedById`) qua soft-unassign kết hợp partial unique index.
   - Kích hoạt `taskAssignmentGuard` (`src/modules/project-members/task-assignment-guard.ts`) cho Sprint 2 Member Removal.
3. **Module 3 — Task Status & Review Workflow:**
   - Kiểm soát chuyển trạng thái chặt theo luồng `TODO → IN_PROGRESS → REVIEW → DONE` (và Reject `REVIEW → IN_PROGRESS`).
   - Member cập nhật trường được phép theo `DEC-015`; gửi `Submit for Review`.
   - Leader thực hiện `Approve` (kiểm tra đủ điều kiện Dependency trước khi `DONE`) hoặc `Reject` với `reason` bắt buộc; lưu `TaskReview` + `TaskHistory`.
   - Chuẩn bị domain event hook (`taskEventHook`) cho Sprint 5 (Notification & Email cho Assignees / Leader).
4. **Module 4 — Task Dependency:**
   - Thêm / Xóa quan hệ phụ thuộc giữa các Task cùng Project.
   - Chặn self-dependency, chặn duplicate dependency, kiểm tra cycle detection (BFS/DFS trong Transaction kèm lock đồng thời theo Project).
   - Áp dụng cổng kiểm tra `DEC-005` khi chuyển Task sang `DONE`.
5. **Module 5 — Task History Integration:**
   - Lưu lịch sử tập trung các sự kiện: `CREATED`, `INFO_UPDATED`, `PROGRESS_UPDATED`, `ASSIGNEE_ADDED`, `ASSIGNEE_REMOVED`, `STATUS_CHANGED`, `REVIEW_SUBMITTED`, `REVIEW_APPROVED`, `REVIEW_REJECTED`, `DEPENDENCY_ADDED`, `DEPENDENCY_REMOVED`.
   - API và UI xem dòng thời gian lịch sử Task, phân định rạch ròi với `AuditLog` và `ActivityLog` hiện tại.
6. **UI, API & Regression Verification:**
   - Route UI dưới `/projects/[projectId]/tasks/*`, tích hợp `/projects/[projectId]` và `/dashboard`, cảnh báo tái phân công khi xóa Member.
   - REST API `/api/v1/...` + Server Actions + Unit / API Contract / PostgreSQL Integration / Sprint 1–2 Regression Tests.

---

## 4. Out of Scope

Các hạng mục sau **không triển khai** trong Sprint 3:

- **Sprint Management, Project Backlog UI, Sprint Planning & Kanban Board** (Sprint 4 — bảng `Sprint` và cột `sprintId` để dành cho Sprint 4 hoặc phân tích khả năng tương thích ở Section 10).
- **Document Library (Google Drive links)** gắn theo Project (Sprint 5).
- **In-app Notification Center & Resend Email Delivery thực tế** (Sprint 5 — Sprint 3 chỉ cung cấp typed event hook `taskEventHook`).
- **Báo cáo tiến độ nâng cao, Burndown Chart & Contribution Metrics** (Sprint 6).
- **Actual Time Tracking, Subtasks, File Upload, Comment Thread, Drag-and-drop Kanban, Hard/Bulk Delete Task.**
- Thay đổi cấu trúc Authentication, User Management, Role Matrix của Sprint 1–2 (trừ nối `taskAssignmentGuard` và cập nhật nhỏ UI Project Detail / Members / Shell).

---

## 5. Existing Implementation Baseline & Findings

### 5.1. Hiện trạng Codebase đã xác minh

| Hạng mục | Hiện trạng thực tế trên branch `dev` (`4339882`) |
|---|---|
| **Git & Branch** | `dev` đồng bộ `origin/dev` (working tree sạch). Sprint 2 đã merge vào `dev` (`f5d5101` → `21aff16`); `main` đang ở `29f6505` (Sprint 1). `.gitignore` bỏ qua `docs/`, `markdown/`, `report/`. |
| **Stack & Packages** | Next.js `^16.4.6`, React `^19.3.1`, TypeScript `^5.9.0`, Prisma `6.19.3`, `next-auth` `5.0.0-beta.32`, Zod `^4.6.7`, `react-hook-form` `^7.92.0`, `@radix-ui/react-dialog` `^1.1.15`, `@radix-ui/react-alert-dialog`, `@radix-ui/react-select`, `sonner`, `vitest` `^5.1.0`. |
| **Database & Migrations** | 2 migrations: `20261114181931_init_sprint1` và `20261114193729_sprint2_projects_and_members`. Đang có custom partial unique indexes & check constraints viết bằng SQL: `Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `Project_date_range_chk`. |
| **Authorization Core** | `loadTrustedAuthContext(userId)` đọc User `ACTIVE`, Roles, Permissions trực tiếp từ PostgreSQL. Đã seed sẵn 25 permissions gồm đủ 7 quyền Task: `task.create`, `task.read`, `task.update`, `task.assign`, `task.submit_review`, `task.review`, `task.history.read`. |
| **Project Access & Scope** | `src/modules/projects/project.access.ts` đã có `assertProjectReadAccess(actor, projectId, tx)` (Admin hoặc active `ProjectMember` hoặc `leaderId`/`instructorId`), `assertProjectLeaderAccess(actor, projectId, tx)`, `assertActiveUsersExist`, `isWorkspaceAdmin`, `parseProjectId`. |
| **Member Guard Hook** | `src/modules/project-members/member.service.ts` (dòng 309) gọi `await taskAssignmentGuard.assertNoActiveProjectTasks(tx, project.id, validUserId)` trước khi set `leftAt` cho `ProjectMember`. File `task-assignment-guard.ts` hiện là no-op trả về `Promise<void>`. |
| **Error & Action Patterns** | `src/lib/errors.ts` dùng `400` (`VALIDATION_ERROR`), `401`, `403`, `404`, `409` (`conflictError(code, message, details)`). `src/types/api.ts` đã khai báo sẵn `"TASK_ASSIGNEE_REASSIGN_REQUIRED"`. `src/lib/request.ts` cung cấp `ActionResult<T>`, `parseJsonBody`, `toActionError`. |
| **UI Components** | `src/components/ui/` hiện có: `alert`, `alert-dialog`, `badge`, `button`, `card`, `input`, `label`, `select`, `table`, `textarea`. Chưa có `dialog.tsx` (dù `@radix-ui/react-dialog` đã cài trong `package.json`). |
| **Test Baseline** | Theo `report/SPRINT-2-IMPLEMENTATION-REPORT.md` và danh sách file thực tế trong `tests/`: 10 test files (8 unit, 2 integration PostgreSQL), 49 test cases pass, `next build` đạt 39 routes. |

### 5.2. Document, Report & Codebase Findings (Phát hiện sai lệch cần lưu ý)

1. **Handoff & Tài liệu trạng thái hơi lệch nhẹ so với Git thực tế:**
   - Handoff note cũ ghi Sprint 2 chưa commit/push, nhưng kiểm tra thực tế trên `dev` cho thấy Sprint 2 đã commit & merge vào `dev` (`4339882`); chỉ `main` vẫn ở `29f6505`.
   - `AGENT.md §13.4` vẫn ghi Next Sprint là Sprint 2 (chưa cập nhật lên Sprint 3).
2. **Thiếu cột `referenceLinks` và `progressNotes` trong `Database-Design.md §7.1`:**
   - `DECISION-LOG.md` (`DEC-015`), `UI-UX-Design.md §6.5.2–6.5.3` và `Prompt §5` bắt buộc Member được sửa `referenceLinks` và `progressNotes`, nhưng bảng `Task` trong `Database-Design.md §7.1` lại thiếu 2 cột này.
   - **Đề xuất:** Bổ sung `referenceLinks Json?` và `progressNotes String? @db.Text` vào model `Task` trong Sprint 3 (chờ duyệt trước khi migrate).
3. **Sai lệch kiểu dữ liệu ngày & tên cột giữa `Database-Design.md` và `prisma/schema.prisma`:**
   - `Database-Design.md` ghi `DATE` cho `startDate`/`endDate`, nhưng `prisma/schema.prisma` đang dùng `DateTime` (`TIMESTAMP(3)`). `ProjectMember` cũng không có cột `createdAt`.
   - **Đề xuất:** `Task.startDate`, `Task.deadline`, `TaskAssignee.assignedAt/removedAt` tiếp tục dùng `DateTime` thống nhất với `prisma/schema.prisma`.
4. **Trường `Task Code` xuất hiện trong `UI-UX-Design.md §6.5.1` nhưng không có trong `Database-Design.md` & `SRS`:**
   - UI spec bảng danh sách Task có cột `Task Code`, trong khi `Database-Design.md §7.1`, `SRS §4.3`, `BR §3.5` và `API-Specification.md §5` không hề định nghĩa cột `code` hay quy tắc sinh mã (ví dụ `AKY-001` hay `TSK-1`).
   - **Đề xuất:** Không tự ý bịa quy tắc sinh mã. Đưa vào Open Questions (`TBD`); mặc định hiển thị short UUID (8 ký tự đầu) hoặc bỏ qua `code` DB nếu chưa chốt định dạng mã Task.
5. **Chưa thống nhất xóa / hủy Task (`TBD-022`, `OI-008`, `DB-007`) và HTTP Status `422` vs `409`:**
   - `Business-Rules §7` và `SRS §14` ghi `[CHƯA XÁC ĐỊNH]` việc xóa/hủy Task; `Database-Design §14.4` nêu `"Hạn chế xóa sau khi tạo"`; `TaskStatus` chỉ có 4 giá trị (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`); `API-Specification §5` không có endpoint `DELETE /tasks/:taskId`.
   - `API-Specification.md §9` liệt kê HTTP `422 Business Rule Violation`, nhưng codebase Sprint 1–2 dùng HTTP `400` cho validation và HTTP `409` (`conflictError`) cho vi phạm quy tắc nghiệp vụ.
   - **Đề xuất:** Giữ chuẩn `400`/`409` của codebase hiện tại; không tự ý tạo trạng thái `CANCELLED` hay hard-delete Task đã có lịch sử — đánh dấu `TBD` phần Delete/Archive Task.
6. **Nguy cơ mất Custom Partial Indexes khi chạy `prisma migrate dev`:**
   - `20261114193729_sprint2_projects_and_members/migration.sql` chứa `Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `Project_date_range_chk` bằng SQL thuần ngoài `schema.prisma`. Nếu chạy `prisma migrate dev` trực tiếp, Prisma có thể sinh lệnh `DROP INDEX` làm mất invariant Sprint 2.
   - **Đề xuất:** Bắt buộc dùng `npx prisma migrate dev --create-only`, rà soát và xóa mọi `DROP INDEX` nhầm cho Sprint 2, đồng thời thêm custom SQL tương tự cho Sprint 3 (`TaskAssignee` partial unique index & `CHECK` constraints).
7. **Khác biệt nhẹ trong đường dẫn REST API & đồng bộ UI Leader check:**
   - `API-Specification.md §5` dùng `/api/v1/projects/:projectId/tasks` cho list/create và `/api/v1/tasks/:taskId/...` cho thao tác trên 1 Task; Prompt §10 gợi ý lồng `/api/v1/projects/[projectId]/tasks/[taskId]/...`. (Phân tích chi tiết và chọn phương án chuẩn tại Section 11).
   - Ở `src/app/(dashboard)/projects/[projectId]/page.tsx` (dòng 53), UI kiểm tra `project.leaderId === actor.userId`, trong khi `assertProjectLeaderAccess` kiểm tra cả `ProjectMember.projectRole === LEADER`. Dù `member.service.ts` đồng bộ cả hai, Sprint 3 nên dùng helper nhất quán hoặc expose capability từ server.
   - Ở `src/components/projects/project-members-panel.tsx` (dòng 148–151), khi `removeProjectMemberAction` trả lỗi `TASK_ASSIGNEE_REASSIGN_REQUIRED`, hiện chỉ show chuỗi `errorMessage` chung; nên nâng cấp nhẹ để hiển thị danh sách Task đang chặn và link tới màn hình Task của Project.
   - `src/components/layout/app-shell.tsx` (dòng 124) đang ghi tĩnh `"Sprint 2 · RBAC & Projects"` — cần cập nhật gọn khi hoàn tất Sprint 3.

---

## 6. Requirement Traceability Matrix

| Requirement / Decision ID | Mô tả yêu cầu / Quyết định | Module Sprint 3 | Thành phần thiết kế chính |
|---|---|---|---|
| **FR-TASK-001, UC-013, DEC-011** | Tạo Task trong Project chưa Archive; Priority `LOW/MEDIUM/HIGH/CRITICAL`; Deadline bắt buộc; Start Date & Estimate tùy chọn; Assignees tùy chọn (0..N) | Module 1, 2 | `task.schema.ts`, `task.service.ts`, `tasks/new` UI |
| **FR-TASK-002, UC-014, DEC-009** | Gán / thay đổi / gỡ nhiều `ProjectMember` đang hoạt động (`ACTIVE`, `leftAt IS NULL`) cho Task; bảo toàn lịch sử phân công | Module 2 | `task-assignment.service.ts`, `TaskAssignee` (partial unique), `taskAssignmentGuard` |
| **FR-TASK-003, DEC-015, Authorization-Design §7** | Member chỉ cập nhật `status` (`TODO → IN_PROGRESS → REVIEW`), `referenceLinks`, `progressNotes` trên Task được phân công; khóa các trường quản lý | Module 1, 3 | `task.service.ts`, `task-workflow.service.ts`, field whitelist Zod |
| **FR-TASK-004, FR-TASK-005, UC-015, UC-016** | Member gửi Review (`IN_PROGRESS → REVIEW`); Leader Approve (`→ DONE`) hoặc Reject (`→ IN_PROGRESS`) với Reason bắt buộc; lưu lịch sử & chuẩn bị sự kiện thông báo | Module 3, 5 | `task-workflow.service.ts`, `TaskReview`, `TaskHistory`, `taskEventHook` |
| **FR-TASK-006, UC-018, DEC-005** | Thêm/xóa Dependency giữa các Task cùng Project; chặn trùng, tự phụ thuộc, chu trình; chỉ cho phép `DONE` khi tất cả tiền nhiệm đã `DONE` | Module 4, 3 | `task-dependency.service.ts`, `TaskDependency`, BFS/DFS + `pg_advisory_xact_lock` |
| **FR-TASK-007, FR-TASK-008, UC-017** | Xem danh sách Task (lọc theo status, priority, assignee, tìm kiếm) & chi tiết Task theo phạm vi Project access | Module 1, UI | `task.repository.ts`, `/projects/[projectId]/tasks`, `/tasks/[taskId]` |
| **FR-TASK-009, UC-019, BR §6.1 & §6.4** | Ghi và xem lịch sử các thay đổi quan trọng của Task (`TaskHistory` bất biến, append-only) | Module 5 | `task-history.repository.ts`, `task-history.service.ts`, Timeline UI |
| **BR-MEM-005, DEC-009** | Chặn xóa `ProjectMember` nếu còn Task chưa `DONE` trong Project (`TASK_ASSIGNEE_REASSIGN_REQUIRED`) | Module 2 | `src/modules/project-members/task-assignment-guard.ts` |
| **BR-NOTIF-004 – 007** | Chuẩn bị sự kiện khi Assign, Submit Review, Approve, Reject Review cho Sprint 5 | Module 3, 2 | `src/modules/tasks/task-events.ts` (`taskEventHook`) |

---

## 7. Module Breakdown

Sprint 3 tổ chức toàn bộ logic nghiệp vụ vào module mới `src/modules/tasks/` (tuân thủ `Software-Architecture-Document.md §6`), kết nối với `src/modules/projects/project.access.ts` và `src/modules/project-members/task-assignment-guard.ts`.

| Thứ tự | Module / Workstream | Trách nhiệm cốt lõi | Lý do sắp xếp |
|---|---|---|---|
| **M0** | **Database Schema & Shared Contracts** | Bổ sung model `Task`, `TaskAssignee`, `TaskDependency`, `TaskHistory`, `TaskReview`, enums + migration SQL an toàn + mở rộng `ErrorCode` trong `src/types/api.ts` | Tạo nền dữ liệu & hợp đồng lỗi thống nhất trước khi viết Repository/Service |
| **M1** | **Task Core Management** | `task.schema.ts`, `task.access.ts`, `task.repository.ts`, `task.service.ts`: CRUD Task, lọc/phân trang, khóa Project `ARCHIVED`, phân quyền trường Admin/Leader vs Member | Mọi module khác (`Assignment`, `Workflow`, `Dependency`, `History`) đều thao tác trên thực thể `Task` |
| **M2** | **Task Assignment & Guard Integration** | `task-assignment.service.ts`: assign/unassign/sync nhiều Assignees, kiểm tra User `ACTIVE` + `ProjectMember` hoạt động, soft-unassign bảo lưu lịch sử + nối `taskAssignmentGuard` | Tách rõ quản lý thành viên trên Task để `M3` (kiểm tra Assigned Member) và Sprint 2 Removal Guard sử dụng |
| **M3** | **Task Status & Review Workflow** | `task-workflow.service.ts`, `task-events.ts`: state machine `TODO → IN_PROGRESS → REVIEW → DONE` & Reject `→ IN_PROGRESS`, CAS chống race condition, kiểm tra Dependency `DONE`, lưu `TaskReview`, phát `taskEventHook` | Phụ thuộc `M1`, `M2` và gọi truy vấn tiền nhiệm từ `TaskDependency` |
| **M4** | **Task Dependency Management** | `task-dependency.service.ts`: thêm/gỡ phụ thuộc cùng Project, check self/duplicate/completed-target, `pg_advisory_xact_lock` + BFS/DFS chống cycle | Kết hợp chặt với cổng `DONE` ở `M3` |
| **M5** | **Task History Integration** | `task-history.repository.ts`, `task-history.service.ts`: helper ghi `TaskHistory` dùng chung trong cùng `tx` cho `M1–M4`, API/UI đọc timeline không trùng lặp `AuditLog`/`ActivityLog` | Ghi xuyên suốt `M1–M4`, có thể viết helper từ đầu nhưng hoàn thiện tích hợp & query ở bước này |
| **M6** | **API Routes, Server Actions & UI/UX** | `/api/v1/...` route handlers, `task.actions.ts`, `dialog.tsx`, badges, các trang `/projects/[projectId]/tasks/*`, tích hợp Project Detail / Member Panel / Dashboard | Chỉ xây dựng sau khi Service Layer & Authorization ổn định |
| **M7** | **Testing & Regression Verification** | Unit tests, API Contract tests, PostgreSQL Integration tests (gồm Guard Sprint 2 & concurrency), chạy regression Sprint 1 + Sprint 2 + build/lint/typecheck | Xác minh toàn bộ trước khi chốt Sprint 3 |

*(Ghi chú điều chỉnh thứ tự so với gợi ý Prompt §13: đưa helper `task-history.repository.ts` lên cùng giai đoạn xây `M1` để các Service `M1–M4` gọi ghi lịch sử ngay trong cùng Transaction ngay từ lần viết đầu tiên, tránh phải sửa đi sửa lại các Service sau đó.)*

---

## 8. Detailed Task Breakdown

> Quy ước Priority: **P0** = Blocker/Core bắt buộc phải xong theo thứ tự; **P1** = Nghiệp vụ chính; **P2** = Mở rộng/UX phụ trợ & hoàn thiện.

### S3-T01 — Prisma Schema, Migration SQL & ErrorCode Contract
- **Module:** M0 — Database & Shared Types
- **Description:** Cập nhật `prisma/schema.prisma` thêm enums & 5 models Task Management; sinh migration qua `--create-only`, rà soát giữ nguyên custom index Sprint 2, bổ sung partial unique index cho `TaskAssignee` và `CHECK` constraints cho `Task` & `TaskDependency`; mở rộng `ErrorCode` trong `src/types/api.ts`.
- **Requirements:** FR-TASK-001 – 009, DEC-003, DEC-004, DEC-005, DEC-009, DEC-011, DEC-015
- **Business Rules:** BR-TASK-001 – 013, BR-MEM-005
- **Dependencies:** Không (Task khởi đầu)
- **Files to Create:** `prisma/migrations/<timestamp>_sprint3_task_management/migration.sql` (khi triển khai)
- **Files to Modify:** `prisma/schema.prisma`, `src/types/api.ts`
- **Database Impact:** Thêm `TaskStatus`, `TaskPriority`, `ReviewDecision`, `TaskHistoryAction`; thêm bảng `Task`, `TaskAssignee`, `TaskDependency`, `TaskHistory`, `TaskReview`; thêm quan hệ ngược trên `Project` và `User`.
- **API Impact:** Bổ sung error codes: `TASK_DEPENDENCY_NOT_COMPLETED`, `TASK_DEPENDENCY_CYCLE`, `TASK_DEPENDENCY_SELF_REFERENCE`, `TASK_DEPENDENCY_EXISTS`, `REVIEW_REASON_REQUIRED`, `ASSIGNEE_NOT_PROJECT_MEMBER`.
- **Authorization:** N/A (Layer schema & types)
- **Validation:** `npx prisma validate`, kiểm tra thủ công SQL migration.
- **Tests:** Schema constraint tests nằm trong `S3-T16` (Integration DB test).
- **Acceptance Criteria:** Migration chạy sạch trên PostgreSQL; toàn bộ partial index Sprint 2 (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `Project_date_range_chk`) còn nguyên vẹn; `prisma generate` thành công.
- **Priority:** P0

### S3-T02 — Task Validation Schemas, Access Helpers & Notification Event Hook
- **Module:** M1 / M2 / M3 — Foundation Helpers
- **Description:** Viết Zod schemas chuẩn cho Create/Update/Filter Task, Member Progress Update, Assign/Sync Assignees, Approve/Reject Review, Add Dependency; viết `task.access.ts` tái sử dụng `assertProjectReadAccess` / `assertProjectLeaderAccess` và helper `assertTaskAccess`; định nghĩa `task-events.ts` làm hook cho Sprint 5.
- **Requirements:** FR-TASK-001 – 008, DEC-003, DEC-004, DEC-015, BR-NOTIF-004 – 007
- **Business Rules:** BR-TASK-001 – 013
- **Dependencies:** `S3-T01`
- **Files to Create:** `src/modules/tasks/task.schema.ts`, `src/modules/tasks/task.access.ts`, `src/modules/tasks/task-events.ts`
- **Files to Modify:** Không
- **Database Impact:** Chỉ đọc (`Project`, `Task`, `TaskAssignee`) trong `task.access.ts` qua `Prisma.TransactionClient`.
- **API Impact:** Chuẩn hóa payload & query param validation cho toàn bộ API & Actions.
- **Authorization:** Kiểm tra Permission (`task.*`) + Project Scope (`assertProjectReadAccess` / `assertProjectLeaderAccess`) + Assigned Member (`TaskAssignee.removedAt IS NULL`).
- **Validation:** `title` non-empty (3–200 ký tự), `deadline` bắt buộc hợp lệ, `startDate <= deadline` khi có cả hai, `estimateHours >= 0` (tùy chọn, số thực/số giờ dương hoặc `null`), `referenceLinks` mảng tối đa N URL `http/https` hợp lệ, `reason` trim non-empty (tối thiểu 3 hoặc 5 ký tự, max 1000).
- **Tests:** Unit test schema validation trong `S3-T15`.
- **Acceptance Criteria:** Schema reject mọi input sai định dạng/URL/ngày/giờ âm; Member payload schema tách biệt rõ không chấp nhận trường bị khóa.
- **Priority:** P0

### S3-T03 — Task & Task History Repositories
- **Module:** M1 / M5 — Data Access Layer
- **Description:** Xây dựng `task.repository.ts` (findManyPaginated kèm filters `search`, `status`, `priority`, `assigneeId`, `unassignedOnly`, `overdueOnly`; findDetailById kèm active/historical assignees, dependencies `dependsOn`/`dependents`, latest reviews; dashboard `myTasks` query) và `task-history.repository.ts` (append `TaskHistory` records và paginated/timeline query).
- **Requirements:** FR-TASK-001, FR-TASK-007, FR-TASK-009, UC-017, UC-019
- **Business Rules:** History Integrity (append-only, không update/delete history)
- **Dependencies:** `S3-T01`, `S3-T02`
- **Files to Create:** `src/modules/tasks/task.repository.ts`, `src/modules/tasks/task-history.repository.ts`
- **Files to Modify:** Không
- **Database Impact:** Truy vấn & chèn dữ liệu trên `Task`, `TaskAssignee`, `TaskDependency`, `TaskReview`, `TaskHistory`.
- **API Impact:** Định nghĩa DTO (`TaskSummaryDTO`, `TaskDetailDTO`, `TaskAssigneeDTO`, `TaskDependencyItemDTO`, `TaskHistoryItemDTO`, `TaskReviewDTO`).
- **Authorization:** Repository chỉ nhận query đã qua authorization từ Service; `myTasks` filter theo Project user có quyền truy cập.
- **Validation:** Bảo đảm serialize ISO string cho mọi `Date`, map JSON `referenceLinks` an toàn thành `string[]`.
- **Tests:** Kiểm tra thông qua `S3-T15` & `S3-T16`.
- **Acceptance Criteria:** Queries không dính N+1 trên danh sách Task; DTO ẩn hoàn toàn dữ liệu nhạy cảm (`passwordHash`); `TaskHistory` chỉ có hàm `create`/`createMany`/`findByTaskId`.
- **Priority:** P0

### S3-T04 — Task Core Management Service (Create, List, Detail, Update)
- **Module:** M1 — Task Core
- **Description:** Triển khai `listProjectTasksService`, `listMyAssignedTasksService`, `getTaskDetailService`, `createTaskService` (hỗ trợ assign danh sách thành viên ban đầu hoặc rỗng `DEC-011` trong cùng Transaction), và `updateTaskService` (tách rạch ròi quyền Admin/Leader sửa metadata vs Member sửa `progressNotes`/`referenceLinks` theo `DEC-015`).
- **Requirements:** FR-TASK-001, FR-TASK-003, FR-TASK-007, UC-013, UC-017
- **Business Rules:** BR-TASK-001, BR-TASK-002, BR-PROJ-008 (block `ARCHIVED`), DEC-003, DEC-004, DEC-011, DEC-015
- **Dependencies:** `S3-T02`, `S3-T03`
- **Files to Create:** `src/modules/tasks/task.service.ts`
- **Files to Modify:** Không
- **Database Impact:** Ghi `Task`, optional `TaskAssignee` khi tạo, `TaskHistory` (`CREATED`, `INFO_UPDATED`, `PROGRESS_UPDATED`, `ASSIGNEE_ADDED`), optional `ActivityLog` milestone `TASK_CREATED`.
- **API Impact:** Phục vụ `GET/POST /projects/[projectId]/tasks`, `GET/PATCH /tasks/[taskId]`, Server Actions.
- **Authorization:** `task.read` + `assertProjectReadAccess`; `task.create` + `assertProjectLeaderAccess`; `task.update` + (`assertProjectLeaderAccess` HOẶC active `TaskAssignee`). Member gửi field bị khóa (`title`, `priority`, `deadline`, `startDate`, `estimateHours`, `description`) → ném `403 FORBIDDEN`.
- **Validation:** Khóa sửa/tạo nếu Project `ARCHIVED` (`409 PROJECT_ARCHIVED`); `startDate <= deadline` kể cả khi chỉ PATCH một trong hai trường (kiểm tra với giá trị hiện lưu trong DB).
- **Tests:** Unit tests trong `S3-T15` + Integration tests trong `S3-T16`.
- **Acceptance Criteria:** Tạo Task có/không có Assignee thành công; Member sửa trường khóa bị 403; sửa metadata tạo `TaskHistory` ghi rõ `oldValue`/`newValue`.
- **Priority:** P0

### S3-T05 — Task Assignment Management & `taskAssignmentGuard` Integration
- **Module:** M2 — Task Assignment
- **Description:** Triển khai `assignTaskMembersService`, `addTaskAssigneeService`, `removeTaskAssigneeService`, `listTaskAssigneesService` (tùy chọn lấy lịch sử); chỉ cho phép gán User `ACTIVE` và là `ProjectMember` đang hoạt động (`leftAt IS NULL`) trong cùng Project; soft-unassign qua `removedAt` để giữ Assignment History; nối `taskAssignmentGuard.assertNoActiveProjectTasks` vào `TaskAssignee` với `status !== DONE`.
- **Requirements:** FR-TASK-002, UC-014, DEC-009, DEC-011, BR-NOTIF-004
- **Business Rules:** BR-MEM-005, BR-TASK-004, BR-TASK-005
- **Dependencies:** `S3-T03`, `S3-T04`
- **Files to Create:** `src/modules/tasks/task-assignment.service.ts`
- **Files to Modify:** `src/modules/project-members/task-assignment-guard.ts`
- **Database Impact:** Ghi `TaskAssignee` (`assignedAt`, `assignedById`, `removedAt`), `TaskHistory` (`ASSIGNEE_ADDED`, `ASSIGNEE_REMOVED`), truy vấn chặn xóa member từ `TaskAssignee JOIN Task`.
- **API Impact:** Phục vụ `GET/PUT/POST/DELETE /tasks/[taskId]/assignees` (chi tiết Section 11) + làm lỗi `409 TASK_ASSIGNEE_REASSIGN_REQUIRED` từ `DELETE /projects/[projectId]/members/[userId]` mang `details` danh sách Task đang chặn.
- **Authorization:** `task.assign` + `assertProjectLeaderAccess` (Leader của Project hoặc Workspace Admin); Member không được tự assign/unassign.
- **Validation:** Project không `ARCHIVED`; target users phải có `User.status === ACTIVE` và `ProjectMember(projectId, userId, leftAt: null)`. Cho phép danh sách rỗng (gỡ hết thành viên). Gán lại user từng bị gỡ → tạo record `TaskAssignee` mới (partial unique index bảo vệ không trùng active row).
- **Tests:** Unit + Integration test cho multi-assignee, rejoin assignment history, member removal block (`TODO/IN_PROGRESS/REVIEW`) vs allow (`DONE` hoặc đã reassigned).
- **Acceptance Criteria:** `removeProjectMemberService` bị chặn với `409 TASK_ASSIGNEE_REASSIGN_REQUIRED` khi user còn Task `TODO`/`IN_PROGRESS`/`REVIEW`; sau khi unassign/reassign trên Task thì xóa member thành công và Assignment History vẫn nguyên vẹn.
- **Priority:** P0

### S3-T06 — Task Status Transition & Review Workflow Service
- **Module:** M3 — Workflow & Review
- **Description:** Triển khai `updateTaskStatusService` (chỉ bước tiến hợp lệ `TODO → IN_PROGRESS`), `submitTaskForReviewService` (`IN_PROGRESS → REVIEW`), `approveTaskReviewService` (`REVIEW → DONE`), `rejectTaskReviewService` (`REVIEW → IN_PROGRESS`). Áp dụng optimistic CAS guard (`updateMany` với điều kiện `status` hiện tại), kiểm tra toàn bộ `TaskDependency` đã `DONE` trước khi Approve (`DEC-005`), bắt buộc nhập `reason` khi Approve/Reject, ghi `TaskReview` + `TaskHistory` trong Transaction và kích hoạt `taskEventHook` sau khi commit.
- **Requirements:** FR-TASK-003, FR-TASK-004, FR-TASK-005, UC-015, UC-016, DEC-005, DEC-015, BR-NOTIF-005 – 007
- **Business Rules:** BR-TASK-006 – 011, EX-007, EX-008
- **Dependencies:** `S3-T04`, `S3-T05`
- **Files to Create:** `src/modules/tasks/task-workflow.service.ts`
- **Files to Modify:** Không
- **Database Impact:** Cập nhật `Task.status`, ghi `TaskReview` (decision, reason, reviewerId, submittedById), ghi `TaskHistory` (`STATUS_CHANGED`, `REVIEW_SUBMITTED`, `REVIEW_APPROVED`, `REVIEW_REJECTED`), optional `ActivityLog` milestone (`TASK_REVIEW_APPROVED`, `TASK_COMPLETED`).
- **API Impact:** Phục vụ `PATCH /tasks/[taskId]` (chuyển `TODO → IN_PROGRESS`), `POST /tasks/[taskId]/submit-review`, `POST /tasks/[taskId]/approve`, `POST /tasks/[taskId]/reject`.
- **Authorization:**
  - `TODO → IN_PROGRESS`: `task.update` + (`assertProjectLeaderAccess` HOẶC active `TaskAssignee`).
  - `IN_PROGRESS → REVIEW`: `task.submit_review` + (`assertProjectLeaderAccess` HOẶC active `TaskAssignee`).
  - `Approve / Reject`: `task.review` + `assertProjectLeaderAccess`.
- **Validation:** Từ chối chuyển nhảy cóc (`TODO → DONE`, `TODO → REVIEW`, `DONE → *`) bằng `409 INVALID_STATUS_TRANSITION`; từ chối `Approve/Reject` thiếu `reason` bằng `400 VALIDATION_ERROR` (hoặc `409 REVIEW_REASON_REQUIRED` khi bỏ trống nghiệp vụ); từ chối `Approve` khi còn dependency chưa `DONE` bằng `409 TASK_DEPENDENCY_NOT_COMPLETED`.
- **Tests:** Full workflow state matrix unit & DB integration tests (bao gồm concurrent submit/approve race check).
- **Acceptance Criteria:** Mọi transition sai trả lỗi chuẩn; mọi Approve/Reject lưu đủ `TaskReview` + `TaskHistory` với `reason`; không thể Approve Task khi có predecessor chưa `DONE`.
- **Priority:** P0

### S3-T07 — Task Dependency Service & Cycle Detection
- **Module:** M4 — Task Dependency
- **Description:** Triển khai `listTaskDependenciesService`, `addTaskDependencyService`, `removeTaskDependencyService`. Kiểm tra hai Task cùng `projectId`, không tự phụ thuộc, không trùng lặp, không tạo chu trình bằng BFS/DFS trên đồ thị Dependency của Project trong Transaction kèm `SELECT pg_advisory_xact_lock(hashtext(...))`, chặn thêm dependency chưa `DONE` vào Task đã `DONE`, ghi `TaskHistory`.
- **Requirements:** FR-TASK-006, UC-018, DEC-005
- **Business Rules:** BR-TASK-012, BR-TASK-013, EX-013
- **Dependencies:** `S3-T04`, `S3-T03`
- **Files to Create:** `src/modules/tasks/task-dependency.service.ts`
- **Files to Modify:** Không
- **Database Impact:** Chèn/Xóa `TaskDependency`, ghi `TaskHistory` (`DEPENDENCY_ADDED`, `DEPENDENCY_REMOVED`).
- **API Impact:** Phục vụ `GET/POST /tasks/[taskId]/dependencies` và `DELETE /tasks/[taskId]/dependencies/[dependsOnTaskId]`.
- **Authorization:** `GET`: `task.read` + `assertProjectReadAccess`; `POST/DELETE`: `task.update` + `assertProjectLeaderAccess` (Member bị chặn hoàn toàn theo `DEC-015`).
- **Validation:** Không cho thao tác khi Project `ARCHIVED`; `taskId !== dependsOnTaskId` (`400`/`409 TASK_DEPENDENCY_SELF_REFERENCE`); 2 Task khác Project → `409` / `400`; trùng cạnh → `409 TASK_DEPENDENCY_EXISTS`; cycle (trực tiếp `A↔B` hoặc gián tiếp `A→B→C→A`) → `409 TASK_DEPENDENCY_CYCLE`.
- **Tests:** Direct cycle, 3-node indirect cycle, diamond DAG hợp lệ (không báo nhầm cycle!), duplicate, self-ref, completed-task guard, concurrent deadlock/cycle test.
- **Acceptance Criteria:** Đồ thị hình thoi `A→B, A→C, B→D, C→D` hợp lệ; mọi chu trình bị chặn tức thì kèm chuỗi đường đi cycle trong `details`; gỡ dependency hoạt động & lưu lịch sử.
- **Priority:** P0

### S3-T08 — Task History Query Service & Activity/Audit Boundary
- **Module:** M5 — Task History
- **Description:** Triển khai `listTaskHistoryService` trả về dòng thời gian thống nhất (`TaskHistory` + gắn context `TaskReview` / User info) và kiểm soát quy tắc ghi `ActivityLog` tối giản cho mốc quan trọng mà không trùng lặp 3 nơi.
- **Requirements:** FR-TASK-009, UC-019
- **Business Rules:** History Integrity (bất biến, theo quyền `task.history.read`)
- **Dependencies:** `S3-T03`, `S3-T04` – `S3-T07`
- **Files to Create:** `src/modules/tasks/task-history.service.ts`
- **Files to Modify:** Không
- **Database Impact:** Đọc `TaskHistory` (join User actor), hỗ trợ phân trang cursor/page.
- **API Impact:** Phục vụ `GET /tasks/[taskId]/history`.
- **Authorization:** `task.history.read` + `assertProjectReadAccess`.
- **Validation:** Validate `taskId` UUID, pagination query params.
- **Tests:** Xác minh toàn bộ 11 action events đều tạo đúng 1 `TaskHistory` record có `actorId`, `oldValue`/`newValue`, `reason`; User thiếu `task.history.read` nhận `403`.
- **Acceptance Criteria:** Xem được lịch sử đầy đủ theo thứ tự thời gian giảm dần; không có sự kiện nào bị ghi trùng 2–3 lần trong các bảng log khác nhau.
- **Priority:** P1

### S3-T09 — Task Server Actions
- **Module:** M6 — Application Interface (UI Actions)
- **Description:** Tạo `src/modules/tasks/task.actions.ts` bọc mỏng các Service M1–M4 (`requireActiveUser` → Service → `revalidatePath` → `toActionError`) theo đúng chuẩn `project.actions.ts` / `member.actions.ts`.
- **Requirements:** FR-TASK-001 – 009
- **Business Rules:** Toàn bộ quy tắc thực thi tại Service Layer
- **Dependencies:** `S3-T04` – `S3-T08`
- **Files to Create:** `src/modules/tasks/task.actions.ts`
- **Files to Modify:** Không
- **Database Impact:** Gián tiếp qua Services.
- **API Impact:** Cung cấp typed `ActionResult<T>` cho Client Components (`/projects/[projectId]/tasks*`, `/projects/[projectId]`, `/dashboard`).
- **Authorization:** Gọi `requireActiveUser()` tại đầu mỗi Action trước khi truyền `actor` xuống Service.
- **Validation:** Gián tiếp qua Services.
- **Tests:** Kiểm tra thông qua UI integration & unit behavior.
- **Acceptance Criteria:** Revalidate đúng paths (`/projects/[projectId]/tasks`, `/projects/[projectId]/tasks/[taskId]`, `/projects/[projectId]`, `/dashboard`); lỗi luôn map qua `toActionError`.
- **Priority:** P1

### S3-T10 — REST API v1 Task Route Handlers
- **Module:** M6 — REST API Layer
- **Description:** Triển khai đầy đủ Route Handlers dưới `src/app/api/v1/` theo đúng quy ước `apiSuccess` / `apiError` / `parseJsonBody` / `requireActiveUser`:
  - `src/app/api/v1/projects/[projectId]/tasks/route.ts` (`GET`, `POST`)
  - `src/app/api/v1/tasks/[taskId]/route.ts` (`GET`, `PATCH`)
  - `src/app/api/v1/tasks/[taskId]/assignees/route.ts` (`GET`, `PUT`, `POST`)
  - `src/app/api/v1/tasks/[taskId]/assignees/[userId]/route.ts` (`DELETE`)
  - `src/app/api/v1/tasks/[taskId]/submit-review/route.ts` (`POST`)
  - `src/app/api/v1/tasks/[taskId]/approve/route.ts` (`POST`)
  - `src/app/api/v1/tasks/[taskId]/reject/route.ts` (`POST`)
  - `src/app/api/v1/tasks/[taskId]/dependencies/route.ts` (`GET`, `POST`)
  - `src/app/api/v1/tasks/[taskId]/dependencies/[dependsOnTaskId]/route.ts` (`DELETE`)
  - `src/app/api/v1/tasks/[taskId]/history/route.ts` (`GET`)
- **Requirements:** API-Specification §5 & §9
- **Business Rules:** Tái sử dụng 100% Service Layer
- **Dependencies:** `S3-T04` – `S3-T08`
- **Files to Create:** 10 route files liệt kê ở trên.
- **Files to Modify:** Không
- **Database Impact:** Không trực tiếp.
- **API Impact:** Chuẩn hóa HTTP `200`, `201`, `400`, `401`, `403`, `404`, `409`.
- **Authorization:** `requireActiveUser()` + Service-layer authz.
- **Validation:** `parseJsonBody`, searchParams sanitization.
- **Tests:** API Contract tests trong `S3-T16`.
- **Acceptance Criteria:** Mọi Route Handler mỏng (<50 dòng), không chứa business logic, trả envelope `{ data, meta? }` / `{ error }` đồng bộ.
- **Priority:** P1

### S3-T11 — UI Primitives (`Dialog`), Shared Badges & AppShell Update
- **Module:** M6 — Shared UI Foundation
- **Description:** Tạo `src/components/ui/dialog.tsx` bọc `@radix-ui/react-dialog` đã cài sẵn (dùng cho Modal nhập Review Reason & Quick Reassign notice); bổ sung `TaskStatusBadge` (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`) và `TaskPriorityBadge` (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`) vào `src/components/shared/status-badge.tsx`; cập nhật footer trong `app-shell.tsx`.
- **Requirements:** UI-UX-Design §6.5, §7
- **Business Rules:** Nhất quán màu sắc & nhãn trạng thái/độ ưu tiên
- **Dependencies:** `S3-T01` (dùng Prisma enums `TaskStatus`, `TaskPriority`)
- **Files to Create:** `src/components/ui/dialog.tsx`
- **Files to Modify:** `src/components/shared/status-badge.tsx`, `src/components/layout/app-shell.tsx`
- **Database Impact:** Không
- **API Impact:** Không
- **Authorization:** `app-shell` giữ nguyên filter menu theo `user.permissions`.
- **Validation:** Tuân thủ Radix single-child `<Slot>` rule.
- **Tests:** ESLint + TypeScript + Build.
- **Acceptance Criteria:** Badges render chuẩn 4 Status & 4 Priority; Dialog đóng/mở bằng bàn phím (ESC) hoạt động chuẩn accessibility.
- **Priority:** P1

### S3-T12 — Task List Page, Project Detail Task Overview, Member Removal UX & Dashboard Widget
- **Module:** M6 — Task List & Existing Pages Integration
- **Description:** Tạo trang `/projects/[projectId]/tasks` (`page.tsx` + `task-list-client.tsx`) hiển thị bảng Task (Title, Status, Priority, Deadline + quá hạn indicator, Assignees, Estimate Hours, Dependency blocked indicator), search, filter (status, priority, assignee, unassignedOnly) & pagination. Cập nhật `/projects/[projectId]/page.tsx` thêm Card tổng quan Task (số lượng theo status, Task chờ Review, nút mở `/projects/[projectId]/tasks`). Cập nhật `project-members-panel.tsx` hiển thị danh sách Task đang chặn và link trực tiếp `/projects/[projectId]/tasks?assigneeId=...` khi gặp lỗi `TASK_ASSIGNEE_REASSIGN_REQUIRED`. Bổ sung Card `"Công việc được giao cho tôi"` trên `/dashboard`.
- **Requirements:** UI-UX-Design §6.5.1, FR-TASK-007, DEC-009
- **Business Rules:** Project Read/Create/Assign visibility theo capability server truyền xuống; cảnh báo khi Project `ARCHIVED`
- **Dependencies:** `S3-T04`, `S3-T09`, `S3-T11`
- **Files to Create:** `src/app/(dashboard)/projects/[projectId]/tasks/page.tsx`, `src/components/tasks/task-list-client.tsx`
- **Files to Modify:** `src/app/(dashboard)/projects/[projectId]/page.tsx`, `src/components/projects/project-members-panel.tsx`, `src/app/(dashboard)/dashboard/page.tsx`
- **Database Impact:** Server Components gọi Service (`listProjectTasksService`, `listMyAssignedTasksService`).
- **API Impact:** Đọc qua Service; không fetch thừa từ client.
- **Authorization:** Server Component dùng `requirePermissionOrRedirect(PERMISSIONS.TASK_READ)` và `assertProjectReadAccess`; re-throw lỗi không phải `AppError` để giữ `NEXT_REDIRECT`.
- **Validation:** Radix `<SelectItem>` luôn dùng sentinel `"__ALL__"` / `"__UNASSIGNED__"`, tuyệt đối không dùng `""`.
- **Tests:** Build & UI verification.
- **Acceptance Criteria:** Lọc URL query params mượt mà (`?status=REVIEW&priority=HIGH`); Project Detail liên kết sang danh sách Task; khi xóa Member còn Task chưa `DONE`, UI hiển thị rõ Task nào cần phân công lại kèm link đi thẳng tới Task đó.
- **Priority:** P1

### S3-T13 — Task Create & Edit Form UI (`/tasks/new`, `/tasks/[taskId]/edit`)
- **Module:** M6 — Task Form UI
- **Description:** Tạo trang `/projects/[projectId]/tasks/new` và `/projects/[projectId]/tasks/[taskId]/edit` cùng Client Component `task-form.tsx` dùng React Hook Form + Zod resolver (hoặc state + Zod chuẩn đồng bộ với `project-form.tsx`), hỗ trợ chọn Priority (`DEC-003`), Deadline bắt buộc, Start Date tùy chọn, Estimate Hours tùy chọn (`DEC-004`), nhập động danh sách Reference Links, chọn nhiều Assignees từ danh sách `ProjectMember` đang hoạt động (cho phép để trống `DEC-011`).
- **Requirements:** UC-013, UI-UX-Design §6.5.2, DEC-003, DEC-004, DEC-011
- **Business Rules:** Chỉ Admin/Project Leader (có `task.create`/`task.update`) mở được form tạo/sửa metadata; Project `ARCHIVED` chuyển hướng hoặc báo khóa
- **Dependencies:** `S3-T04`, `S3-T05`, `S3-T09`, `S3-T11`
- **Files to Create:** `src/app/(dashboard)/projects/[projectId]/tasks/new/page.tsx`, `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/edit/page.tsx`, `src/components/tasks/task-form.tsx`
- **Files to Modify:** Không
- **Database Impact:** Không
- **API Impact:** Gọi `createTaskAction` / `updateTaskAction`.
- **Authorization:** Server Component kiểm tra quyền `TASK_CREATE` / `TASK_UPDATE` + `assertProjectLeaderAccess` trước khi render form; redirect `/access-denied` nếu không đủ quyền.
- **Validation:** Đồng bộ client-server qua Zod (`startDate <= deadline`, valid URL, non-negative hours).
- **Tests:** Build & manual E2E / action validation check.
- **Acceptance Criteria:** Form xử lý loading/disabled/validation error/toast success đầy đủ; Edit form điền sẵn giá trị hiện tại và không làm mất Assignees khi chỉ sửa thông tin Task.
- **Priority:** P1

### S3-T14 — Task Detail, Progress, Review Modal, Dependencies & History Timeline UI
- **Module:** M6 — Task Detail & Workflow UI
- **Description:** Tạo trang `/projects/[projectId]/tasks/[taskId]` (`page.tsx`) cùng bộ Client Components chuyên biệt (`src/components/tasks/task-detail-panel.tsx`, `task-review-modal.tsx`, `task-assignees-card.tsx`, `task-dependencies-card.tsx`, `task-history-timeline.tsx`):
  - Hiển thị thông tin Task, Progress Notes, Reference Links.
  - Member được phân công có form sửa riêng `progressNotes` & `referenceLinks`, nút `"Bắt đầu làm"` (`TODO → IN_PROGRESS`) và `"Gửi Review"` (`IN_PROGRESS → REVIEW`) kèm Confirm dialog.
  - Leader thấy panel `"Duyệt / Từ chối Task"` khi trạng thái là `REVIEW`, mở Dialog bắt buộc nhập `reason` cho cả **Approve** và **Reject**, hiển thị cảnh báo rõ nếu còn Dependency chưa `DONE` (khóa nút Approve hoặc báo lỗi rõ).
  - Quản lý Assignees (multi-select thêm/gỡ nhanh Project Member đang hoạt động), quản lý Dependencies (chọn Task cùng Project, hiển thị chặn trùng/cycle/status tiền nhiệm) và xem `TaskHistory` timeline.
- **Requirements:** UC-014, UC-015, UC-016, UC-018, UC-019, UI-UX-Design §6.5.3, DEC-005, DEC-009, DEC-015
- **Business Rules:** Ẩn/disable control theo quyền, nhưng mọi Action vẫn kiểm tra lại tại Server
- **Dependencies:** `S3-T04` – `S3-T12`
- **Files to Create:** `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/page.tsx`, `src/components/tasks/task-detail-panel.tsx`, `src/components/tasks/task-review-modal.tsx`, `src/components/tasks/task-assignees-card.tsx`, `src/components/tasks/task-dependencies-card.tsx`, `src/components/tasks/task-history-timeline.tsx`
- **Files to Modify:** Không
- **Database Impact:** Không
- **API Impact:** Gọi `task.actions.ts`.
- **Authorization:** Server Component tính capability flags (`canEditMetadata`, `canEditProgress`, `canAssign`, `canStartWork`, `canSubmitReview`, `canReview`, `canManageDependencies`, `canReadHistory`) từ `actor` + active membership + active assignment + `project.status !== ARCHIVED`.
- **Validation:** Reject Review modal chặn submit nếu `reason.trim().length === 0`; không đặt `setState` trong `useEffect`.
- **Tests:** Build & E2E smoke test.
- **Acceptance Criteria:** Trải nghiệm trọn vẹn 1 vòng đời Task (`Create → Assign → Start → Update Notes/Links → Submit Review → Reject → Update → Re-submit → Dependency block → Complete Predecessor → Approve → View History`).
- **Priority:** P1

### S3-T15 — Unit Tests (Schemas, Services, Authorization, Cycles, Guard)
- **Module:** M7 — Unit Verification
- **Description:** Viết bộ Unit Tests (`tests/unit/sprint3-task-services.test.ts` và/hoặc `tests/unit/sprint3-task-validation.test.ts`) mock Prisma & Repositories tương tự `tests/unit/sprint2-services.test.ts`, phủ toàn bộ rule bắt buộc ở Prompt §12.
- **Requirements:** Testing-Strategy §6.6 – §6.7 (`TC-TASK-001 – 028`, `TC-MEMBER-007 – 008`)
- **Business Rules:** Toàn bộ `DEC-003/004/005/009/011/015` và `BR-TASK-*`
- **Dependencies:** `S3-T02` – `S3-T08`
- **Files to Create:** `tests/unit/sprint3-task-services.test.ts`
- **Files to Modify:** Không
- **Database Impact:** Không (mocked `$transaction` & repos)
- **API Impact:** Không
- **Authorization:** Test matrix cho ADMIN / INSTRUCTOR / LEADER / Assigned MEMBER / Unassigned MEMBER / Non-member.
- **Validation:** Test toàn bộ Zod schemas (URLs, dates, estimates, blank review reasons).
- **Tests:** Tối thiểu 25–30 test cases độc lập.
- **Acceptance Criteria:** `npx vitest run tests/unit/sprint3-task-services.test.ts` pass 100%, không skip/suppress assertions.
- **Priority:** P0

### S3-T16 — API Contract Tests & PostgreSQL Integration Tests
- **Module:** M7 — API & DB Integration Verification
- **Description:** Viết `tests/unit/sprint3-api-routes.test.ts` kiểm tra đủ mã HTTP `200`, `201`, `400`, `401`, `403`, `404`, `409` cho toàn bộ Task API routes; và viết `tests/integration/sprint3-db.test.ts` chạy trên PostgreSQL thật (`akatsuki_yui`) kiểm tra CRUD, partial unique index `TaskAssignee`, check constraints, Dependency cycle detection, Review workflow persistence, `TaskHistory`, `Project ARCHIVED` block và **Sprint 2 `removeProjectMemberService` + `taskAssignmentGuard` integration**.
- **Requirements:** Testing-Strategy §8.3 – §8.4, Prompt §12
- **Business Rules:** Toàn bộ invariants ở tầng DB & Service
- **Dependencies:** `S3-T05`, `S3-T06`, `S3-T07`, `S3-T10`, `S3-T15`
- **Files to Create:** `tests/unit/sprint3-api-routes.test.ts`, `tests/integration/sprint3-db.test.ts`
- **Files to Modify:** Không
- **Database Impact:** Tạo & dọn sạch test data tag `runTag` trong `afterAll` (theo đúng mẫu `tests/integration/sprint2-db.test.ts`).
- **API Impact:** Xác nhận toàn bộ REST routes trả đúng JSON envelope.
- **Authorization:** Test unauthenticated `401`, unauthorized role/non-member `403`.
- **Validation:** Test PostgreSQL constraints trực tiếp qua Prisma raw update/create (partial unique + check constraint).
- **Tests:** 100% pass khi chạy `npm run test`.
- **Acceptance Criteria:** DB constraints thực sự chặn dữ liệu bẩn ngay cả khi gọi thẳng `prisma`; Member Removal Guard từ `member.service.ts` hoạt động thật trên DB.
- **Priority:** P0

### S3-T17 — Full Regression, Verification Gates & Sprint 3 Report
- **Module:** M7 — Final Gate & Documentation
- **Description:** Chạy toàn bộ regression tests Sprint 1 + Sprint 2 + Sprint 3 (không sửa test cũ để ép pass), kiểm tra format/lint/typecheck/build, đối chiếu cập nhật tài liệu kỹ thuật (nếu được duyệt) và viết `report/SPRINT-3-IMPLEMENTATION-REPORT.md`.
- **Requirements:** `AGENT.md §15` Definition of Done
- **Business Rules:** N/A
- **Dependencies:** `S3-T11` – `S3-T16`
- **Files to Create:** `report/SPRINT-3-IMPLEMENTATION-REPORT.md`
- **Files to Modify:** (Chỉ khi kết thúc code & được phép đồng bộ doc) `AGENT.md` / `markdown/04-Technical-Specifications/API-Specification.md` / `markdown/03-Architecture-and-Design/Database-Design.md`
- **Database Impact:** `npx prisma migrate status` xác nhận clean.
- **API Impact:** Xác nhận build mọi route handlers.
- **Authorization:** Rà soát lần cuối tất cả route/action/page.
- **Validation:** Zero ESLint errors, zero TypeScript errors, zero Prettier issues.
- **Tests:** `npm run test` (Sprint 1 + 2 + 3), `npm run build`, smoke test UI với tài khoản ADMIN / LEADER / MEMBER / INSTRUCTOR.
- **Acceptance Criteria:** Toàn bộ checks pass exit code 0 và báo cáo phản ánh trung thực kết quả đo được.
- **Priority:** P0

---

## 9. Dependency Map

```mermaid
flowchart TD
    T01["S3-T01: Schema, Migration & ErrorCode"] --> T02["S3-T02: Zod Schemas, TaskAccess & Events"]
    T01 --> T11["S3-T11: Dialog UI, Badges & AppShell"]
    T02 --> T03["S3-T03: Task & History Repositories"]
    T03 --> T04["S3-T04: Task Core Service"]
    T04 --> T05["S3-T05: Assignment Service & Guard"]
    T04 --> T07["S3-T07: Dependency Service & Cycle Check"]
    T05 --> T06["S3-T06: Workflow & Review Service"]
    T07 --> T06
    T04 --> T08["S3-T08: History Service & Activity Boundary"]
    T05 --> T08
    T06 --> T08
    T07 --> T08
    T08 --> T09["S3-T09: Server Actions"]
    T08 --> T10["S3-T10: REST API v1 Route Handlers"]
    T09 --> T12["S3-T12: Task List, Project Detail & Guard UX"]
    T11 --> T12
    T09 --> T13["S3-T13: Task Create & Edit Form UI"]
    T11 --> T13
    T12 --> T14["S3-T14: Task Detail, Review Modal & Timeline UI"]
    T13 --> T14
    T08 --> T15["S3-T15: Unit Tests (Services & Schemas)"]
    T10 --> T16["S3-T16: API Contract & PG Integration Tests"]
    T15 --> T16
    T14 --> T17["S3-T17: Regression, Build & Sprint 3 Report"]
    T16 --> T17
```

**Đường găng (Critical Path):** `S3-T01 → S3-T02 → S3-T03 → S3-T04 → S3-T05 / S3-T07 → S3-T06 → S3-T08 → S3-T10 / S3-T09 → S3-T14 / S3-T16 → S3-T17`.

---

## 10. Database Impact Analysis

> **Lưu ý:** Toàn bộ định nghĩa Prisma dưới đây là **Thiết kế dự kiến (Design Blueprint)** — chưa chỉnh sửa `prisma/schema.prisma` trong giai đoạn Planning.

### 10.1. Enums mới cần bổ sung

```prisma
enum TaskStatus {
  TODO
  IN_PROGRESS
  REVIEW
  DONE
}

enum TaskPriority {
  LOW
  MEDIUM
  HIGH
  CRITICAL
}

enum ReviewDecision {
  APPROVED
  REJECTED
}

enum TaskHistoryAction {
  CREATED
  INFO_UPDATED
  PROGRESS_UPDATED
  ASSIGNEE_ADDED
  ASSIGNEE_REMOVED
  STATUS_CHANGED
  REVIEW_SUBMITTED
  REVIEW_APPROVED
  REVIEW_REJECTED
  DEPENDENCY_ADDED
  DEPENDENCY_REMOVED
}
```

### 10.2. Thiết kế các Models mới & Quan hệ

#### 1) `Task` (Module 1 + nền Sprint 4)
| Field | Type (Prisma / PostgreSQL) | Nullable / Default | Ghi chú & Constraints |
|---|---|---|---|
| `id` | `String @id @default(uuid()) @db.Uuid` | No | PK |
| `projectId` | `String @db.Uuid` | No | FK → `Project.id` (`onDelete: Cascade` hoặc `Restrict` — thống nhất dùng `Cascade` như `ProjectMember` nhưng hạn chế xóa Project qua Archive) |
| `createdById` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) |
| `title` | `String @db.VarChar(200)` | No | Tiêu đề Task |
| `description` | `String? @db.Text` | Yes | Mô tả chi tiết |
| `priority` | `TaskPriority @default(MEDIUM)` | No | Theo `DEC-003` |
| `status` | `TaskStatus @default(TODO)` | No | Trạng thái chung duy nhất cho toàn bộ Assignees |
| `startDate` | `DateTime?` | Yes | Tùy chọn |
| `deadline` | `DateTime` | No | Bắt buộc |
| `estimateHours` | `Float?` *(hoặc `Decimal? @db.Decimal(6, 2)`)* | Yes | Thời gian ước lượng tính bằng giờ (`DEC-004`). Khuyến nghị `Float` hoặc `Decimal(6,2)` *(lưu ý Prisma `Decimal` serialize phức tạp ở Client Component nên `Float` với làm tròn 2 chữ số thập phân ở Zod giữ DTO đồng nhất JSON `number` cho Burndown Sprint 6)* |
| `referenceLinks` | `Json?` | Yes | Lưu `string[]` các URL tham chiếu (`DEC-015`) |
| `progressNotes` | `String? @db.Text` | Yes | Ghi chú tiến độ của Member (`DEC-015`) |
| `completedAt` | `DateTime?` | Yes | Ghi nhận thời điểm Approve sang `DONE` (hỗ trợ báo cáo Sprint 6) |
| `createdAt` | `DateTime @default(now())` | No | Timestamp tạo |
| `updatedAt` | `DateTime @updatedAt` | No | Timestamp cập nhật |

- **Indexes:**
  - `@@index([projectId, status])` (lọc Task trong Project theo status & Board Sprint 4)
  - `@@index([projectId, priority])`
  - `@@index([projectId, deadline])`
  - `@@index([createdById])`
- **Custom SQL Check Constraints:**
  - `CONSTRAINT "Task_date_range_chk" CHECK ("startDate" IS NULL OR "deadline" >= "startDate")`
  - `CONSTRAINT "Task_estimate_nonnegative_chk" CHECK ("estimateHours" IS NULL OR "estimateHours" >= 0)`

#### 2) `TaskAssignee` (Module 2 — Multi-Assignee + Assignment History + Guard Index)
| Field | Type | Nullable / Default | Ghi chú |
|---|---|---|---|
| `id` | `String @id @default(uuid()) @db.Uuid` | No | PK |
| `taskId` | `String @db.Uuid` | No | FK → `Task.id` (`onDelete: Cascade`) |
| `userId` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) |
| `assignedById` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) — lưu vết ai phân công |
| `assignedAt` | `DateTime @default(now())` | No | Thời điểm bắt đầu gán |
| `removedAt` | `DateTime?` | Yes | `NULL` = đang giữ Task; có giá trị = đã gỡ nhưng **bảo toàn lịch sử phân công** |

- **Constraints & Indexes:**
  - **Partial Unique Index (Custom SQL, giống hệt mẫu `ProjectMember` Sprint 2):**
    ```sql
    CREATE UNIQUE INDEX "TaskAssignee_active_task_user_idx"
    ON "TaskAssignee"("taskId", "userId")
    WHERE "removedAt" IS NULL;
    ```
    Cho phép một user bị unassign (`removedAt != NULL`) rồi được gán lại lần sau thành dòng mới mà vẫn giữ nguyên toàn bộ lịch sử phân công trước đó!
  - **Index phục vụ `taskAssignmentGuard` & My Tasks:** `@@index([userId, removedAt])` và `@@index([taskId, removedAt])`.

#### 3) `TaskDependency` (Module 4 — Precedence Edge)
| Field | Type | Nullable / Default | Ghi chú |
|---|---|---|---|
| `id` | `String @id @default(uuid()) @db.Uuid` | No | PK |
| `taskId` | `String @db.Uuid` | No | Task bị phụ thuộc (Dependent) — FK → `Task.id` (`onDelete: Cascade`) |
| `dependsOnTaskId` | `String @db.Uuid` | No | Task tiền nhiệm (Prerequisite phải `DONE` trước) — FK → `Task.id` (`onDelete: Cascade`) |
| `createdById` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) |
| `createdAt` | `DateTime @default(now())` | No | Thời điểm thiết lập |

- **Constraints & Indexes:**
  - `@@unique([taskId, dependsOnTaskId])` — chặn duplicate dependency ngay ở tầng DB.
  - `@@index([dependsOnTaskId])` — tăng tốc tra cứu ngược khi hoàn thành tiền nhiệm hoặc khi cần tải toàn bộ đồ thị của Project.
  - **Custom SQL Check Constraint:**
    ```sql
    ALTER TABLE "TaskDependency"
    ADD CONSTRAINT "TaskDependency_no_self_chk"
    CHECK ("taskId" <> "dependsOnTaskId");
    ```

#### 4) `TaskReview` (Module 3 — Formal Review Submissions & Decisions)
| Field | Type | Nullable / Default | Ghi chú |
|---|---|---|---|
| `id` | `String @id @default(uuid()) @db.Uuid` | No | PK |
| `taskId` | `String @db.Uuid` | No | FK → `Task.id` (`onDelete: Cascade`) |
| `submittedById` | `String? @db.Uuid` | Yes | FK → `User.id` (`onDelete: Restrict`) — người gửi Review |
| `reviewerId` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) — Leader/Admin xử lý Review |
| `decision` | `ReviewDecision` | No | `APPROVED` \| `REJECTED` |
| `reason` | `String @db.Text` | No | Bắt buộc không rỗng theo rule Review |
| `reviewedAt` | `DateTime @default(now())` | No | Thời điểm ra quyết định |

- **Indexes:** `@@index([taskId, reviewedAt])`, `@@index([reviewerId])`.

#### 5) `TaskHistory` (Module 5 — Unified Domain Timeline thay thế `TaskStatusHistory` hẹp)
**Phân tích chống trùng lặp 3 hệ thống log (Prompt §5 Module 5 & §15 Risk #6):**
- Nếu giữ nguyên `TaskStatusHistory` (chỉ có `fromStatus`, `toStatus`, `reason`) từ `Database-Design §7.4`, hệ thống sẽ không lưu được `INFO_UPDATED`, `ASSIGNEE_ADDED/REMOVED`, `DEPENDENCY_ADDED/REMOVED`, dẫn đến phải đẩy sang `ActivityLog` và `AuditLog` → **gây ghi trùng 3 nơi**.
- **Giải pháp hợp nhất sạch sẽ:** Dùng **`TaskHistory`** là bảng nhật ký miền nghiệp vụ duy nhất (Source of Truth) cho mọi biến động của Task:

| Field | Type | Nullable / Default | Ghi chú |
|---|---|---|---|
| `id` | `String @id @default(uuid()) @db.Uuid` | No | PK |
| `taskId` | `String @db.Uuid` | No | FK → `Task.id` (`onDelete: Cascade`) |
| `actorId` | `String @db.Uuid` | No | FK → `User.id` (`onDelete: Restrict`) |
| `action` | `TaskHistoryAction` | No | Loại sự kiện chuẩn hóa (enum 11 giá trị) |
| `fromStatus` | `TaskStatus?` | Yes | Nếu có chuyển trạng thái |
| `toStatus` | `TaskStatus?` | Yes | Nếu có chuyển trạng thái |
| `reason` | `String? @db.Text` | Yes | Lý do Approve / Reject Review hoặc ghi chú transition |
| `oldValue` | `Json?` | Yes | Snapshot trường thay đổi trước đó (chỉ lưu field thay đổi) |
| `newValue` | `Json?` | Yes | Snapshot giá trị mới (hoặc targetUser / dependencyTask) |
| `metadata` | `Json?` | Yes | `reviewId`, `assigneeUserId`, `dependsOnTaskId`, v.v. |
| `createdAt` | `DateTime @default(now())` | No | Append-only |

- **Indexes:** `@@index([taskId, createdAt])`, `@@index([actorId])`.
- **Phân định rõ vai trò 3 bảng log:**
  1. **`TaskHistory`**: Toàn bộ chi tiết vòng đời Task (tạo, sửa metadata/progress, assign/unassign, đổi trạng thái, review, dependency). Không ghi những event này sang `AuditLog`.
  2. **`AuditLog` (Sprint 1–2)**: Chỉ giữ cho quản trị bảo mật & cấu hình cấp Workspace/Project (`User`, `Role`, `RolePermission`, `Project`, `ProjectTemplate`, `ProjectMember`). **Không ghi `Task` vào `AuditLog`** để tránh phình & trùng lặp.
  3. **`ActivityLog` (Sprint 1–2)**: Để chuẩn bị cho Bảng tin hoạt động Project ở Sprint 6 (`Report & Activity Feed`), chỉ ghi **tóm tắt cấp cao** ở 4 mốc cộng tác chính (`TASK_CREATED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, `TASK_REVIEW_REJECTED` — hoặc truy vấn kết hợp từ `TaskHistory` ở Sprint 6). Khuyến nghị: **mặc định không ghi trùng sang `ActivityLog` ở Sprint 3**, mà để Sprint 6 tổng hợp feed Project từ `ActivityLog` (Project/Member) + `TaskHistory` (Task), HOẶC chỉ ghi 4 mốc review/tạo Task nếu Sprint 6 cần đọc đơn bảng `ActivityLog` *(cần xác nhận ngắn tại Section 20)*.

### 10.3. Transaction Boundaries & Concurrency
- Mọi write flow đều chạy trong `await prisma.$transaction(async (tx) => { ... })`:
  1. **Create Task:** Validate Project → Validate active Assignees (nếu có) → Create `Task` → CreateMany `TaskAssignee` → Create `TaskHistory(CREATED)` + `TaskHistory(ASSIGNEE_ADDED)` → Emit event sau khi `tx` resolve.
  2. **Status / Review Transition:** Đọc `Task` & active `TaskAssignee` trong `tx` → Nếu Approve, kiểm tra toàn bộ `TaskDependency` của `taskId` đều có `dependsOnTask.status === DONE` → Thực hiện CAS `tx.task.updateMany({ where: { id: taskId, status: expectedCurrentStatus }, data: { status: nextStatus, completedAt } })` (nếu `count === 0` → `409 INVALID_STATUS_TRANSITION` chống 2 người bấm cùng lúc) → Tạo `TaskReview` (nếu Approve/Reject) → Tạo `TaskHistory` → Emit event sau commit.
  3. **Add Dependency:** Lấy Project lock trong TX bằng `await tx.$executeRaw\`SELECT pg_advisory_xact_lock(hashtext(${'task_dep:' + projectId}))\`` → Kiểm tra 2 Task cùng Project, không phải `DONE` khi thêm tiền nhiệm chưa `DONE`, chưa tồn tại edge → Tải tất cả edges của Project đó trong `tx` → Chạy BFS/DFS từ `dependsOnTaskId`; nếu chạm `taskId` → ném `409 TASK_DEPENDENCY_CYCLE` → Create `TaskDependency` + `TaskHistory(DEPENDENCY_ADDED)`.
  4. **Remove Project Member (Sprint 2 + Hook Sprint 3):** Inside `member.service.ts` TX → `taskAssignmentGuard.assertNoActiveProjectTasks(tx, project.id, targetUserId)` thực thi `tx.taskAssignee.findMany({ where: { userId, removedAt: null, task: { projectId, status: { not: TaskStatus.DONE } } }, select: { task: { select: { id, title, status } } } })` → nếu `length > 0` → ném `conflictError("TASK_ASSIGNEE_REASSIGN_REQUIRED", ..., blockingTasksDetails)` trước khi chạm `leftAt`.

### 10.4. Bảo vệ Sprint 2 Custom Indexes & Tương thích Sprint 4 (Sprint, Backlog, Kanban)
- **Sprint 2 Preservation Checklist khi chạy Migration Sprint 3:**
  - Chạy `npx prisma migrate dev --create-only --name sprint3_task_management`.
  - Kiểm tra file `migration.sql` sinh ra, bảo đảm **KHÔNG** có `DROP INDEX "Project_single_active_idx"`, `DROP INDEX "ProjectMember_active_project_user_idx"` hay `DROP CONSTRAINT "Project_date_range_chk"`.
- **Khả năng mở rộng sang Sprint 4 (`Sprint`, `Backlog`, `Kanban`):**
  - **Không tạo model `Sprint` hoặc cột `sprintId` ở Sprint 3** (tránh tạo schema chết chưa có logic và giữ đúng Prompt §7: *"Ưu tiên không tạo bảng hoặc quan hệ Sprint trước khi Sprint 4 thực sự triển khai"*).
  - **Migration dự kiến ở Sprint 4:** Thêm model `Sprint` và thêm cột **`sprintId String? @db.Uuid`** (nullable, mặc định `NULL`) vào model `Task` kèm `@@index([projectId, sprintId, status])`.
  - **Biểu diễn Backlog:** Mọi Task có sẵn từ Sprint 3 mặc định nhận `sprintId = NULL`, tức tự nhiên nằm trong **Project Backlog** của Sprint 4 mà không cần migrate dữ liệu cũ.
  - **Ảnh hưởng lên Lịch sử:** `TaskHistory`, `TaskReview` và `TaskAssignee` gắn với `taskId`, hoàn toàn độc lập với `sprintId`. Khi Sprint 4 cho phép kéo Task vào Sprint hoặc trả về Backlog, chỉ cần bổ sung thêm giá trị enum mới (ví dụ `SPRINT_CHANGED`) vào `TaskHistoryAction` mà không mất hay lệch dữ liệu Sprint 3.

---

## 11. API & Server Action Plan

### 11.1. Lựa chọn & Chuẩn hóa REST API Endpoint Structure
Đối chiếu `API-Specification.md §5` với gợi ý trong Prompt §10:
- `API-Specification.md §5` dùng `/api/v1/projects/:projectId/tasks` cho List/Create và `/api/v1/tasks/:taskId/...` cho thao tác theo `taskId`.
- **Phương án chọn:** Áp dụng theo **`API-Specification.md §5`** (`/api/v1/projects/[projectId]/tasks` + `/api/v1/tasks/[taskId]/...`).
  - *Lý do:* (1) Khớp đặc tả chuẩn sẵn có trong `markdown/04-Technical-Specifications/API-Specification.md`; (2) `taskId` là UUID v4 duy nhất toàn cục, Sprint 4 (Kanban / Backlog) và Dashboard "My Tasks" thao tác trực tiếp bằng `taskId`; (3) Service vẫn tự truy vấn `task.projectId` từ PostgreSQL và kiểm tra `assertProjectReadAccess`/`assertProjectLeaderAccess`, nên bảo mật Project-scoped **an toàn 100% tương đương**, không tin tưởng `projectId` do client gửi.

### 11.2. Danh sách REST API Endpoints (`/api/v1`)

Mọi endpoint sử dụng JSON response envelope `{ data, meta? }` và `{ error: { code, message, details? } }` từ `src/lib/api-response.ts`.

| Method & Path | Permission + Scope | Request / Query | Success | Business Errors (`400` / `401` / `403` / `404` / `409`) |
|---|---|---|---|---|
| `GET /api/v1/projects/[projectId]/tasks` | `task.read` + `assertProjectReadAccess` | Query: `search`, `status`, `priority`, `assigneeId`, `unassignedOnly`, `page`, `pageSize` | `200` `{ data: TaskSummaryDTO[], meta }` | `400 VALIDATION_ERROR`, `401`, `403 FORBIDDEN`, `404 NOT_FOUND` |
| `POST /api/v1/projects/[projectId]/tasks` | `task.create` + `assertProjectLeaderAccess` | Body: `{ title, description?, priority, startDate?, deadline, estimateHours?, referenceLinks?, assigneeIds? }` | `201` `{ data: TaskDetailDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 ACCOUNT_NOT_ACTIVE`, `409 ASSIGNEE_NOT_PROJECT_MEMBER` |
| `GET /api/v1/tasks/[taskId]` | `task.read` + `assertProjectReadAccess` | — | `200` `{ data: TaskDetailDTO }` | `400`, `401`, `403`, `404` |
| `PATCH /api/v1/tasks/[taskId]` | `task.update` + (`Leader/Admin` hoặc active `TaskAssignee`) | **Leader/Admin:** metadata + `status: IN_PROGRESS` (từ `TODO`), `progressNotes`, `referenceLinks`. **Member:** chỉ `status: IN_PROGRESS` (từ `TODO`), `progressNotes`, `referenceLinks` | `200` `{ data: TaskDetailDTO }` | `400`, `401`, `403 FORBIDDEN` (sửa trường bị khóa / chưa được assign), `404`, `409 PROJECT_ARCHIVED`, `409 INVALID_STATUS_TRANSITION` |
| `GET /api/v1/tasks/[taskId]/assignees` | `task.read` + `assertProjectReadAccess` | Query: `includeHistory=true\|false` | `200` `{ data: TaskAssigneeDTO[] }` | `400`, `401`, `403`, `404` |
| `PUT /api/v1/tasks/[taskId]/assignees` | `task.assign` + `assertProjectLeaderAccess` | Body: `{ assigneeIds: string[] }` (đồng bộ danh sách mới, cho phép `[]`) | `200` `{ data: TaskAssigneeDTO[] }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 ACCOUNT_NOT_ACTIVE`, `409 ASSIGNEE_NOT_PROJECT_MEMBER` |
| `POST /api/v1/tasks/[taskId]/assignees` | `task.assign` + `assertProjectLeaderAccess` | Body: `{ userId: string }` (thêm nhanh 1 assignee) | `201` `{ data: TaskAssigneeDTO }` | Nt trên + `409 CONFLICT` (nếu user đã là active assignee) |
| `DELETE /api/v1/tasks/[taskId]/assignees/[userId]` | `task.assign` + `assertProjectLeaderAccess` | — | `200` `{ data: TaskAssigneeDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED` |
| `POST /api/v1/tasks/[taskId]/submit-review` | `task.submit_review` + (`Leader/Admin` hoặc active `TaskAssignee`) | Body (tùy chọn): `{ note?: string, progressNotes?: string, referenceLinks?: string[] }` | `200` `{ data: TaskDetailDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 INVALID_STATUS_TRANSITION` (chỉ từ `IN_PROGRESS`) |
| `POST /api/v1/tasks/[taskId]/approve` | `task.review` + `assertProjectLeaderAccess` | Body: `{ reason: string }` (bắt buộc) | `200` `{ data: TaskDetailDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 REVIEW_REASON_REQUIRED`, `409 INVALID_STATUS_TRANSITION` (chỉ từ `REVIEW`), `409 TASK_DEPENDENCY_NOT_COMPLETED` |
| `POST /api/v1/tasks/[taskId]/reject` | `task.review` + `assertProjectLeaderAccess` | Body: `{ reason: string }` (bắt buộc) | `200` `{ data: TaskDetailDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 REVIEW_REASON_REQUIRED`, `409 INVALID_STATUS_TRANSITION` (chỉ từ `REVIEW`) |
| `GET /api/v1/tasks/[taskId]/dependencies` | `task.read` + `assertProjectReadAccess` | — | `200` `{ data: { dependsOn: TaskDependencyItemDTO[], dependents: TaskDependencyItemDTO[] } }` | `400`, `401`, `403`, `404` |
| `POST /api/v1/tasks/[taskId]/dependencies` | `task.update` + `assertProjectLeaderAccess` | Body: `{ dependsOnTaskId: string }` | `201` `{ data: TaskDependencyItemDTO }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED`, `409 TASK_DEPENDENCY_SELF_REFERENCE`, `409 TASK_DEPENDENCY_EXISTS`, `409 TASK_DEPENDENCY_CYCLE`, `409 INVALID_STATUS_TRANSITION` (nếu task đã `DONE` mà thêm tiền nhiệm chưa `DONE`) |
| `DELETE /api/v1/tasks/[taskId]/dependencies/[dependsOnTaskId]` | `task.update` + `assertProjectLeaderAccess` | — | `200` `{ data: { removed: true } }` | `400`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED` |
| `GET /api/v1/tasks/[taskId]/history` | `task.history.read` + `assertProjectReadAccess` | Query: `page`, `pageSize` | `200` `{ data: TaskHistoryItemDTO[], meta }` | `400`, `401`, `403`, `404` |

*(Ghi chú: Không dùng `DELETE /api/v1/tasks/[taskId]` vì chính sách xóa/hủy Task đang là `TBD` ở tài liệu gốc — xem Section 20.)*

### 11.3. Server Actions (`src/modules/tasks/task.actions.ts`)
Theo đúng mẫu Sprint 2 (`project.actions.ts`, `member.actions.ts`), Server Actions gọi cùng Service Layer, trả `Promise<ActionResult<T>>` và gọi `revalidatePath`:
- `createTaskAction(projectId, input)`
- `updateTaskAction(taskId, input)` (dùng chung cho cả form Edit của Leader và form Progress / Start Work của Member)
- `syncTaskAssigneesAction(taskId, input)` / `addTaskAssigneeAction(taskId, userId)` / `removeTaskAssigneeAction(taskId, userId)`
- `submitTaskForReviewAction(taskId, input?)`
- `approveTaskReviewAction(taskId, input)`
- `rejectTaskReviewAction(taskId, input)`
- `addTaskDependencyAction(taskId, dependsOnTaskId)`
- `removeTaskDependencyAction(taskId, dependsOnTaskId)`

---

## 12. Authorization Plan

### 12.1. Tái sử dụng Permission Codes hiện có
Kiểm tra `src/modules/authorization/constants.ts`: cả **7 permissions Task** đã tồn tại & được seed sẵn trong DB:
- `task.create` (`ADMIN`, `LEADER`)
- `task.read` (`ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER`)
- `task.update` (`ADMIN`, `LEADER`, `MEMBER`)
- `task.assign` (`ADMIN`, `LEADER`)
- `task.submit_review` (`ADMIN`, `LEADER`, `MEMBER`)
- `task.review` (`ADMIN`, `LEADER`)
- `task.history.read` (`ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER`)

**Không thêm permission mới** để giữ đúng ma trận 25 permissions hiện tại (`ROLE_MANAGE` matrix không bị xáo trộn). Quyền quản lý `TaskDependency` sử dụng `task.update` + điều kiện Project Leader / Workspace Admin (bị khóa đối với Member theo `DEC-015`).

### 12.2. Ma trận Action × Role × Scope × Field Rules

| Hành động | Permission bắt buộc | Workspace ADMIN | INSTRUCTOR (được gắn Project) | Project LEADER (của Project) | Project MEMBER (active member) | Người ngoài Project |
|---|---|---|---|---|---|---|
| **Xem danh sách / chi tiết Task** | `task.read` | Mọi Project | Chỉ đọc Project được phân công | Project mình quản lý | Project mình tham gia (`leftAt IS NULL`) | `403 FORBIDDEN` |
| **Xem Lịch sử Task** | `task.history.read` | Mọi Project | Chỉ đọc trong Project | Project mình quản lý | Project mình tham gia | `403 FORBIDDEN` |
| **Tạo Task mới** | `task.create` | Được phép (trừ `ARCHIVED`) | `403` (mặc định read-only) | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | `403 FORBIDDEN` |
| **Sửa Metadata Task** (`title`, `description`, `priority`, `startDate`, `deadline`, `estimateHours`) | `task.update` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` (**DEC-015** khóa cứng) | `403 FORBIDDEN` |
| **Sửa Tiến độ (`progressNotes`, `referenceLinks`) & Start (`TODO → IN_PROGRESS`)** | `task.update` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | **Chỉ khi đang là active Assignee của Task** (`403` nếu không được gán) | `403 FORBIDDEN` |
| **Gán / Gỡ Assignees** | `task.assign` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | `403 FORBIDDEN` |
| **Submit for Review (`IN_PROGRESS → REVIEW`)** | `task.submit_review` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | **Chỉ khi đang là active Assignee của Task** | `403 FORBIDDEN` |
| **Approve / Reject Review** | `task.review` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | `403 FORBIDDEN` |
| **Thêm / Gỡ Dependency** | `task.update` + Leader | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` | Được phép (trừ `ARCHIVED`) | `403 FORBIDDEN` (**DEC-015**) | `403 FORBIDDEN` |

*(Ghi chú bảo mật quan trọng: Nếu Admin dùng Ma trận Role tại `/admin/roles` thu hồi một quyền như `task.update` khỏi `MEMBER`, `loadTrustedAuthContext` lập tức cập nhật từ PostgreSQL và chặn Member ở request tiếp theo mà không cần đăng nhập lại.)*

### 12.3. 9 Bước Enforcement tại Server Layer
1. Xác thực phiên (`requireActiveUser()` / `requireActiveUserOrRedirect()`), kiểm tra `User.status === ACTIVE` trong PostgreSQL.
2. Validate UUID (`parseProjectId`, `parseTaskId`, `parseUserId`) trước khi chạm DB.
3. Kiểm tra Permission code (`assertPermission(actor, ...)`).
4. Load `Task` + `Project` từ DB (trả `404` nếu không tồn tại).
5. Kiểm tra Project Scope (`assertProjectReadAccess` hoặc `assertProjectLeaderAccess` cho Admin/Leader).
6. Với thao tác sửa Member: kiểm tra `isActiveTaskAssignee(taskId, actor.userId, tx)` nếu không phải Admin/Leader.
7. Với mutation: kiểm tra `project.status !== ProjectStatus.ARCHIVED` (`409 PROJECT_ARCHIVED`).
8. Validate Field-Level Permission (`DEC-015`: Member gửi bất kỳ metadata field nào → `403 FORBIDDEN` trước khi vào DB write).
9. Kiểm tra Business Rules trạng thái (`INVALID_STATUS_TRANSITION`, `TASK_DEPENDENCY_NOT_COMPLETED`, `REVIEW_REASON_REQUIRED`, Cycle) bên trong Prisma Transaction.

---

## 13. UI/UX Plan

### 13.1. Sơ đồ Routes & Tích hợp Navigation

| Route / Component | Mục đích | Ai truy cập |
|---|---|---|
| `/projects/[projectId]` *(Modify)* | Bổ sung Block "Công việc (Tasks)" tóm tắt số lượng (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, quá hạn) + nút `"Quản lý Tasks"` dẫn tới `/projects/[projectId]/tasks` | Thành viên Project / Admin / Instructor |
| `/projects/[projectId]/tasks` *(New)* | Danh sách Task của Project: Search theo tiêu đề, lọc Status, Priority, Assignee / Chưa phân công; badge cảnh báo quá hạn & bị chặn Dependency; nút `+ Tạo Task` | `task.read` + Project Scope |
| `/projects/[projectId]/tasks/new` *(New)* | Form tạo Task mới: Title, Description, Priority, Start Date (opt), Deadline (req), Estimate Hours (opt), Reference Links động, Multi-select Active Project Members (opt) | `task.create` + Leader/Admin |
| `/projects/[projectId]/tasks/[taskId]` *(New)* | Trang chi tiết Task toàn diện: Thông tin chung, Chỉnh sửa Progress Notes & Reference Links (Member/Leader), Action Bar chuyển trạng thái + Review Modal (`Approve`/`Reject` bắt buộc Reason), Quản lý Assignees, Quản lý Dependencies + trạng thái tiền nhiệm, Bảng Lịch sử Review & Dòng thời gian `TaskHistory` | `task.read` + Project Scope |
| `/projects/[projectId]/tasks/[taskId]/edit` *(New)* | Form chỉnh sửa toàn bộ metadata Task cho Leader/Admin | `task.update` + Leader/Admin |
| `/dashboard` *(Modify)* | Thêm Card `"Công việc được giao cho tôi"` liệt kê tối đa 5–8 Task chưa `DONE` user đang giữ + link mở thẳng `/projects/[projectId]/tasks/[taskId]` | User `ACTIVE` có `task.read` |
| `ProjectMembersPanel` *(Modify)* | Khi lỗi `TASK_ASSIGNEE_REASSIGN_REQUIRED`, hiển thị danh sách Task chưa `DONE` của member đó (từ `error.details`) + link `/projects/[projectId]/tasks?assigneeId=<userId>` để Leader reassign nhanh | Leader / Admin |

### 13.2. UI States Matrix
- **Loading:** Disable buttons + hiện spinner (`Loader2`), không cho submit trùng.
- **Empty:** Empty state rõ ràng khi Project chưa có Task, chưa có Assignee (`"Chưa phân công — có thể gán sau theo DEC-011"`), chưa có Dependency, hoặc chưa có History.
- **Error:** Alert banner nổi bật cho business error (vd `TASK_DEPENDENCY_NOT_COMPLETED` liệt kê tên Task tiền nhiệm chưa `DONE`; `TASK_DEPENDENCY_CYCLE` chỉ rõ vòng lặp); Toast notification (`sonner`) khi thao tác API/Action xong.
- **Disabled / Archived Lock:** Khi `project.status === ARCHIVED`, hiện Alert cảnh báo trên đầu trang và disable mọi nút tạo/sửa/assign/review/dependency.
- **Confirmation Dialogs:** Dùng `AlertDialog` cho `"Gửi sang Review"`, `"Gỡ Assignee"`, `"Gỡ Dependency"`; dùng **`Dialog`** (`src/components/ui/dialog.tsx`) có form bắt buộc nhập lý do cho `"Approve Task"` và `"Reject Task"`.

### 13.3. Ràng buộc kỹ thuật React 19 / Radix UI từ Sprint 1–2
- Không truyền `value=""` cho Radix `<SelectItem>` (dùng `"__ALL__"` / `"__UNASSIGNED__"`).
- Luôn dùng phần tử con duy nhất bên trong `<Button asChild>` / `<AlertDialogTrigger asChild>`.
- Tránh `setState` đồng bộ trong `useEffect` (tuân thủ `react-hooks/set-state-in-effect` ESLint).
- Server Components luôn `if (isAppError(error)) ... throw error;` để không nuốt `NEXT_REDIRECT`.

---

## 14. Testing Plan

Tối ưu theo `Testing-Strategy.md` và mô hình đã chạy thành công ở Sprint 1–2:

### 14.1. Unit Tests (`tests/unit/sprint3-task-services.test.ts`)
Bao phủ tối thiểu:
1. **Validation Schema:** Deadline bắt buộc, `startDate <= deadline`, optional `startDate`/`estimateHours`, negative `estimateHours` rejected, URL validation trong `referenceLinks`, lý do Review rỗng bị từ chối.
2. **Task Core CRUD:** Tạo Task có/không có Assignees (`DEC-011`); khóa khi Project `ARCHIVED`; cập nhật từng phần `startDate`/`deadline` vẫn kiểm tra date range; Member bị chặn `403` khi cố gửi `title`, `priority`, `deadline`, `estimateHours`, `description`; Member không được gán bị `403` khi sửa `progressNotes`.
3. **Assignment & Guard:** Chặn user không `ACTIVE` (`ACCOUNT_NOT_ACTIVE`), chặn user không phải active `ProjectMember` (`ASSIGNEE_NOT_PROJECT_MEMBER`), cho phép đồng bộ danh sách nhiều Assignees hoặc rỗng `[]`, bảo toàn lịch sử `removedAt`, `taskAssignmentGuard` chặn `TODO/IN_PROGRESS/REVIEW` và bỏ qua `DONE`.
4. **Status & Review Workflow:** Hợp lệ `TODO → IN_PROGRESS → REVIEW → DONE` và `REVIEW → IN_PROGRESS`; chặn nhảy cóc `TODO → DONE`, `TODO → REVIEW`, `DONE → IN_PROGRESS`; Approve/Reject thiếu `reason` bị chặn; Approve bị chặn khi predecessor chưa `DONE` (`DEC-005`); `taskEventHook` được gọi đúng lúc khi assign/submit/approve/reject.
5. **Dependencies:** Chặn self-dependency, duplicate edge, khác Project, cycle 2 đỉnh (`A↔B`) và nhiều đỉnh (`A→B→C→A`), cho phép DAG hình thoi (`A→B, A→C, B→D, C→D`), chặn thêm dependency chưa `DONE` vào Task đã `DONE`.
6. **Task History:** Kiểm tra mọi sự kiện đều gọi `tx.taskHistory.create` với đúng `action`, `actorId`, `oldValue`/`newValue`, `reason`, từ chối đọc History khi thiếu `task.history.read`.

### 14.2. REST API Contract Tests (`tests/unit/sprint3-api-routes.test.ts`)
Kiểm tra trực tiếp Route Handlers (mock `requireActiveUser` & Services như `tests/unit/sprint2-api-routes.test.ts`) xác minh mã HTTP & payload JSON:
- `200` (List, Detail, Patch, Approve/Reject, Assignees, Dependencies, History)
- `201` (Create Task, Add Assignee, Add Dependency)
- `400` (Bad UUID, invalid JSON/schema)
- `401` (`AUTH_REQUIRED`)
- `403` (`FORBIDDEN` theo Role / Member field / Unassigned)
- `404` (`NOT_FOUND` Project hoặc Task không tồn tại)
- `409` (`PROJECT_ARCHIVED`, `INVALID_STATUS_TRANSITION`, `TASK_DEPENDENCY_NOT_COMPLETED`, `TASK_DEPENDENCY_CYCLE`, `REVIEW_REASON_REQUIRED`, `ASSIGNEE_NOT_PROJECT_MEMBER`)

### 14.3. PostgreSQL Integration Tests (`tests/integration/sprint3-db.test.ts`)
Chạy trực tiếp trên PostgreSQL (`akatsuki_yui`) với cleanup chuẩn theo `runTag`:
1. Task CRUD + date/estimate PostgreSQL `CHECK` constraints (cố tình chèn `deadline < startDate` hoặc `estimateHours < 0` ở `prisma.task` bị DB từ chối).
2. `TaskAssignee` multi-assign + partial unique index (`WHERE "removedAt" IS NULL`) cho phép unassign → re-assign giữ đủ 2 dòng lịch sử, nhưng chặn chèn trùng 2 dòng active.
3. **End-to-End Sprint 2 Member Removal Guard:** Gán Member vào Task `IN_PROGRESS` → `removeProjectMemberService` bị lỗi `409 TASK_ASSIGNEE_REASSIGN_REQUIRED` kèm chi tiết Task → Unassign/Reassign hoặc hoàn thành Task sang `DONE` → `removeProjectMemberService` thành công và `TaskAssignee` history vẫn giữ nguyên.
4. Full Review Flow + `TaskReview` + `TaskHistory` persistence + chặn Approve khi Dependency chưa `DONE` → Approve predecessor → Approve dependent thành công (`completedAt` được điền).
5. `TaskDependency` cycle & `TaskDependency_no_self_chk` DB constraint + diamond DAG hợp lệ.
6. Khóa mọi mutation khi Project `ARCHIVED`.

### 14.4. Regression & Verification Gates
- Chạy toàn bộ test suite (`npm run test`: 10 files Sprint 1–2 cũ + 3 files Sprint 3 mới, **không sửa test cũ**).
- `npx prisma validate` & `npx prisma migrate status`.
- `npm run format:check`, `npm run typecheck`, `npm run lint`, `npm run build`.

---

## 15. File Ownership & Change Boundaries

Bảo đảm mỗi tệp dùng chung chỉ thuộc quyền sửa của **duy nhất 1 task** để tránh xung đột:

### 15.1. Files to CREATE
| Path | Owner Task | Ghi chú |
|---|---|---|
| `prisma/migrations/<ts>_sprint3_task_management/migration.sql` | `S3-T01` | Sinh qua `--create-only`, review SQL giữ nguyên index Sprint 2 |
| `src/modules/tasks/task.schema.ts` | `S3-T02` | Zod schemas & types |
| `src/modules/tasks/task.access.ts` | `S3-T02` | Scope & assignee guards |
| `src/modules/tasks/task-events.ts` | `S3-T02` | Notification event hook interface (Sprint 5 ready) |
| `src/modules/tasks/task.repository.ts` | `S3-T03` | Task / Assignee / Dependency / Review queries & DTOs |
| `src/modules/tasks/task-history.repository.ts` | `S3-T03` | Append-only `TaskHistory` writer & reader |
| `src/modules/tasks/task.service.ts` | `S3-T04` | Core Task CRUD + field permission |
| `src/modules/tasks/task-assignment.service.ts` | `S3-T05` | Multi-assignee + soft-unassign |
| `src/modules/tasks/task-workflow.service.ts` | `S3-T06` | Status transitions + Submit/Approve/Reject Review |
| `src/modules/tasks/task-dependency.service.ts` | `S3-T07` | Dependencies + cycle check + lock |
| `src/modules/tasks/task-history.service.ts` | `S3-T08` | Task history query service |
| `src/modules/tasks/task.actions.ts` | `S3-T09` | Next.js Server Actions |
| `src/app/api/v1/projects/[projectId]/tasks/route.ts` | `S3-T10` | `GET`, `POST` |
| `src/app/api/v1/tasks/[taskId]/route.ts` | `S3-T10` | `GET`, `PATCH` |
| `src/app/api/v1/tasks/[taskId]/assignees/route.ts` | `S3-T10` | `GET`, `PUT`, `POST` |
| `src/app/api/v1/tasks/[taskId]/assignees/[userId]/route.ts` | `S3-T10` | `DELETE` |
| `src/app/api/v1/tasks/[taskId]/submit-review/route.ts` | `S3-T10` | `POST` |
| `src/app/api/v1/tasks/[taskId]/approve/route.ts` | `S3-T10` | `POST` |
| `src/app/api/v1/tasks/[taskId]/reject/route.ts` | `S3-T10` | `POST` |
| `src/app/api/v1/tasks/[taskId]/dependencies/route.ts` | `S3-T10` | `GET`, `POST` |
| `src/app/api/v1/tasks/[taskId]/dependencies/[dependsOnTaskId]/route.ts` | `S3-T10` | `DELETE` |
| `src/app/api/v1/tasks/[taskId]/history/route.ts` | `S3-T10` | `GET` |
| `src/components/ui/dialog.tsx` | `S3-T11` | Radix Dialog wrapper |
| `src/components/tasks/task-list-client.tsx` | `S3-T12` | Task table, filters, search |
| `src/components/tasks/task-form.tsx` | `S3-T13` | Create/Edit metadata + assignees + ref links |
| `src/components/tasks/task-detail-panel.tsx` | `S3-T14` | Main Task Detail layout + progress form |
| `src/components/tasks/task-review-modal.tsx` | `S3-T14` | Approve / Reject dialog với lý do bắt buộc |
| `src/components/tasks/task-assignees-card.tsx` | `S3-T14` | Manage Assignees UI |
| `src/components/tasks/task-dependencies-card.tsx` | `S3-T14` | Manage Dependencies + status gate UI |
| `src/components/tasks/task-history-timeline.tsx` | `S3-T14` | Chronological TaskHistory + Review records UI |
| `src/app/(dashboard)/projects/[projectId]/tasks/page.tsx` | `S3-T12` | Project Tasks page |
| `src/app/(dashboard)/projects/[projectId]/tasks/new/page.tsx` | `S3-T13` | New Task page |
| `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/page.tsx` | `S3-T14` | Task Detail page |
| `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/edit/page.tsx` | `S3-T13` | Edit Task page |
| `tests/unit/sprint3-task-services.test.ts` | `S3-T15` | Unit tests |
| `tests/unit/sprint3-api-routes.test.ts` | `S3-T16` | REST API tests |
| `tests/integration/sprint3-db.test.ts` | `S3-T16` | PostgreSQL integration tests |
| `report/SPRINT-3-IMPLEMENTATION-REPORT.md` | `S3-T17` | Final Sprint 3 report |

### 15.2. Files to MODIFY (Single-Owner Strict Locks)
| Path | Owner Task | Phạm vi thay đổi cho phép |
|---|---|---|
| `prisma/schema.prisma` | `S3-T01` | Thêm enums, 5 models Task & inverse relations trên `Project`, `User` |
| `src/types/api.ts` | `S3-T01` | Bổ sung Sprint 3 `ErrorCode` union values |
| `src/modules/project-members/task-assignment-guard.ts` | `S3-T05` | Thay thế no-op bằng truy vấn `TaskAssignee JOIN Task` (`status !== DONE`), giữ nguyên chữ ký `(tx, projectId, userId)` |
| `src/components/shared/status-badge.tsx` | `S3-T11` | Thêm `TaskStatusBadge` & `TaskPriorityBadge` |
| `src/components/layout/app-shell.tsx` | `S3-T11` | Cập nhật text footer `"Sprint 3 · Task Management"` (không đổi nav auth logic) |
| `src/app/(dashboard)/projects/[projectId]/page.tsx` | `S3-T12` | Thêm Task summary card + nút điều hướng tới `/projects/[projectId]/tasks` |
| `src/components/projects/project-members-panel.tsx` | `S3-T12` | Cải thiện hiển thị chi tiết Task chặn & link reassign khi gặp `TASK_ASSIGNEE_REASSIGN_REQUIRED` |
| `src/app/(dashboard)/dashboard/page.tsx` | `S3-T12` | Thêm card `"Công việc được giao cho tôi"` gọi `listMyAssignedTasksService` |

### 15.3. Files ONLY REVIEW (Không sửa trong Sprint 3)
- Toàn bộ `src/modules/auth/*`, `src/modules/authorization/*`, `src/modules/users/*`, `src/modules/roles/*`, `src/modules/project-templates/*`, `src/modules/projects/*` (`project.access.ts`, `project.service.ts`), `src/modules/project-members/member.service.ts` (vì đã gọi `taskAssignmentGuard.assertNoActiveProjectTasks` sẵn ở dòng 309!), `src/lib/*`, và toàn bộ test Sprint 1 & Sprint 2.

---

## 16. Risks & Mitigation

| # | Rủi ro | Ảnh hưởng | Phương án xử lý đề xuất | Ưu / Nhược điểm | Cần xác nhận? |
|---|---|---|---|---|---|
| 1 | **Chu trình Dependency & race condition khi 2 request thêm cạnh ngược chiều đồng thời** | Mất DAG bất biến, deadlock hoàn thành Task (A chờ B, B chờ A) | Trong `prisma.$transaction`, dùng `SELECT pg_advisory_xact_lock(hashtext('task_dep:' \|\| projectId))` rồi load danh sách cạnh Project chạy BFS/DFS `O(V+E)` từ `dependsOnTaskId` tìm `taskId`. | *Ưu:* Đơn giản, không cần bảng closure phức tạp hay retry `P2034`; lock chỉ scoped theo từng Project. *Nhược:* Serialize write Dependency cùng 1 Project (chấp nhận được với quy mô nhóm). | Không |
| 2 | **Concurrent updates khi nhiều Assignees cùng sửa Task hoặc Leader Approve đúng lúc Member submit** | Ghi đè nhầm `progressNotes` hoặc Approve trùng tạo 2 `TaskReview` | Các transition trạng thái dùng atomic CAS (`updateMany` kèm điều kiện `where: { id, status: expectedStatus }`, `count === 0` → `409`). Với field update, hỗ trợ optional `expectedUpdatedAt` và luôn tải lại state mới nhất trong TX. | *Ưu:* Không cần thêm cột mới; chặn triệt để double-approve/reject. *Nhược:* Nếu client gửi concurrent patch text không kèm `expectedUpdatedAt` thì áp dụng last-write-wins cho text note. | Không |
| 3 | **Task nhiều Assignees nhưng chỉ 1 Status chung** | Assignee A bấm `Submit Review` trong khi Assignee B chưa xong phần việc nhỏ của mình | Thực thi đúng `Module 2 & BR`: Task giữ duy nhất 1 `status`; hiển thị rõ trên UI danh sách toàn bộ Assignees và lưu `submittedById` trong `TaskReview` / `actorId` trong `TaskHistory` để minh bạch ai gửi Review; nếu Leader thấy chưa đạt thì `Reject` kèm lý do về `IN_PROGRESS`. | *Ưu:* Đơn giản, tránh state ma trận per-assignee gây vỡ Kanban Sprint 4. *Nhược:* Yêu cầu giao tiếp nhóm hoặc tách nhỏ Task khi phần việc độc lập. | Không |
| 4 | **Member rời Project khi còn giữ Task** | Nếu bỏ qua sẽ tạo Task "mồ côi" hoặc lỗi FK; nếu xóa TaskAssignee mất lịch sử | Kích hoạt `taskAssignmentGuard` chặn xóa Member khi còn Task `status != DONE` (`409 TASK_ASSIGNEE_REASSIGN_REQUIRED`). Leader unassign/reassign trên Task (ghi `removedAt` để giữ Assignment History) hoặc Task chuyển `DONE` rồi mới xóa Member được. | *Ưu:* Tuân thủ tuyệt đối `DEC-009` & `BR-MEM-005`; giữ sạch dữ liệu lịch sử. *Nhược:* Cần thêm 1 bước thao tác trước khi xóa Member (giảm nhẹ bằng link điều hướng nhanh trên UI). | Không |
| 5 | **Workflow Review & quyền Leader (kể cả khi Leader tự làm Task)** | Member tự bấm `DONE` bỏ qua kiểm soát; hoặc Leader làm Assignee tự Approve? | Khóa cứng Member không bao giờ set `DONE`, chỉ `Submit Review` (`IN_PROGRESS → REVIEW`); chỉ `assertProjectLeaderAccess` + `task.review` được Approve/Reject với `reason` bắt buộc. | *Ưu:* Minh bạch lý do đạt/không đạt. *Nhược:* Nhóm nhỏ Leader vừa code vừa duyệt có thể tự approve nếu không cấm — xem Open Question `OQ-03` về self-review. | **Có (`OQ-03`)** |
| 6 | **Trùng lặp giữa `TaskHistory`, `TaskStatusHistory`, `ActivityLog` và `AuditLog`** | Ghi 2–3 bảng cho 1 hành động gây phình DB, lệch dữ liệu timeline | Hợp nhất timeline Task vào **`TaskHistory`** + hồ sơ duyệt chính thức **`TaskReview`** + lịch sử gán **`TaskAssignee`**; **không ghi Task events vào `AuditLog`**, và chỉ đồng bộ mốc cao lên `ActivityLog` nếu Sprint 6 cần (mặc định tách rạch ròi). | *Ưu:* Single source of truth cho lịch sử Task, giảm write amplification trong TX. *Nhược:* Báo cáo Feed tổng thể Sprint 6 sẽ đọc kết hợp `ActivityLog` và `TaskHistory`. | **Có (`OQ-04`)** |
| 7 | **Project bị Archive khi đang còn Task chưa `DONE`** | User tiếp tục thao tác Task thuộc Project đã đóng | Chặn mọi mutation (`Create`, `Update`, `Assign`, `Submit Review`, `Approve/Reject`, `Add/Remove Dependency`) khi `project.status === ARCHIVED` bằng `409 PROJECT_ARCHIVED`; chỉ giữ quyền đọc (`GET`) và đọc History. | *Ưu:* Bảo toàn snapshot Project khi đóng. *Nhược:* Nếu cần sửa tiếp, Admin phải Restore Project trước. | Không |
| 8 | **Tương thích Sprint 4 (Sprint, Backlog, Kanban)** | Phải đập đi viết lại schema hoặc mất tương thích API | Không tạo bảng `Sprint` sớm ở Sprint 3; Sprint 4 chỉ thêm `sprintId String?` (default `NULL` = Backlog) lên `Task` và mở rộng enum `TaskHistoryAction` + filter `sprintId` trên `GET /tasks`. | *Ưu:* Zero breaking change, tách phạm vi sạch giữa Sprint 3 và Sprint 4. *Nhược:* Sprint 4 sẽ có 1 migration nhỏ bổ sung FK `sprintId`. | Không |
| 9 | **Authorization thiếu hoặc không đồng nhất (Server Components vs API vs Actions)** | Lộ dữ liệu hoặc lách được kiểm tra quyền từ UI | Tách `task.access.ts` gọi chung từ cả Services và Server Components (`assertTaskReadAccess`, `assertTaskLeaderAccess`, `assertTaskProgressUpdateAccess`); kiểm tra thực tế từ PostgreSQL qua `loadTrustedAuthContext`. | *Ưu:* Không bao giờ tin client; kiểm thử tập trung ở Unit & API tests. | Không |
| 10 | **Lỗi kỹ thuật môi trường (Prisma partial index & Windows EPERM & Next.js)** | Mất partial unique index Sprint 2, khóa file `prisma generate`, nuốt `NEXT_REDIRECT` | Bắt buộc dừng `next dev` trước `prisma generate`; migration luôn chạy `--create-only` và kiểm tra SQL; Server Component rethrow non-`AppError`; Radix `<SelectItem>` không dùng `""`. | *Ưu:* Tránh toàn bộ bẫy đã gặp ở Sprint 1–2. | Không |

---

## 17. Acceptance Criteria

Sprint 3 chỉ được coi là hoàn thành khi đạt **tất cả** các tiêu chí sau:

- [ ] Leader (và Admin) tạo được Task thuộc Project chưa `ARCHIVED` với đầy đủ trường hợp lệ (`title`, `priority` 4 mức, `deadline` bắt buộc, `startDate` & `estimateHours` tùy chọn, `referenceLinks`, `description`).
- [ ] Tạo Task không có Assignee (`[]`) hợp lệ (`DEC-011`); gán nhiều active Project Members cho 1 Task hoạt động bình thường với 1 trạng thái chung.
- [ ] Hệ thống chặn gán User không `ACTIVE` hoặc không phải active `ProjectMember` của Project đó.
- [ ] Member được phân công chỉ sửa được `status` (`TODO → IN_PROGRESS → REVIEW`), `referenceLinks`, `progressNotes`; mọi cố gắng sửa trường quản lý hoặc sửa Task không được phân công đều trả `403 FORBIDDEN`.
- [ ] Workflow `TODO → IN_PROGRESS → REVIEW → DONE` và Reject `REVIEW → IN_PROGRESS` chạy đúng; Approve & Reject bắt buộc có `reason` và tạo bản ghi `TaskReview` + `TaskHistory`.
- [ ] Thêm/xóa Dependency cùng Project hoạt động; tự tham chiếu, trùng lặp và chu trình (trực tiếp & gián tiếp) bị chặn; Task có predecessor chưa `DONE` không thể chuyển sang `DONE` (`DEC-005`), nhưng vẫn bắt đầu làm (`TODO → IN_PROGRESS`) được.
- [ ] Gỡ `ProjectMember` ở màn hình Project bị chặn (`409 TASK_ASSIGNEE_REASSIGN_REQUIRED`) nếu thành viên còn Task `TODO`/`IN_PROGRESS`/`REVIEW`; gỡ được sau khi reassign/unassign và toàn bộ lịch sử phân công trước đó vẫn còn nguyên (`DEC-009`).
- [ ] Lịch sử Task (`TaskHistory`) ghi nhận đầy đủ mọi sự kiện tạo, sửa, assign/unassign, status, review, dependency và xem được trên UI/API mà không trùng lặp với `AuditLog`.
- [ ] Toàn bộ UI (`/projects/[projectId]/tasks`, `/new`, `/[taskId]`, `/[taskId]/edit`) có đủ loading, empty, error, disabled (khi `ARCHIVED`), dialog xác nhận / bắt buộc lý do.
- [ ] Toàn bộ Unit Tests, API Contract Tests, PostgreSQL Integration Tests mới + Regression Tests Sprint 1 & Sprint 2 + `lint` + `typecheck` + `format:check` + `build` đều pass 100%.

---

## 18. Definition of Done

Theo `AGENT.md §15`:
1. Code tuân thủ Modular Monolith (Client Components không gọi Prisma; Route Handlers & Server Actions mỏng, gọi chung Service Layer; Server Components gọi Service Layer trực tiếp).
2. Toàn bộ phân quyền, validation (Zod) và Transaction (`prisma.$transaction`) được thực thi đầy đủ tại Server Layer.
3. Database migration chạy sạch, giữ nguyên toàn bộ custom partial unique index & check constraints của Sprint 2, đồng thời có partial unique index & check constraints cho Sprint 3.
4. Không tồn tại lỗi TypeScript (`tsc --noEmit`), ESLint (`npm run lint`), Prettier (`npm run format:check`), hay lỗi Next.js production build (`npm run build`).
5. Toàn bộ tests (`vitest run`) chạy thật và đạt tỷ lệ pass 100% sau chỉnh sửa cuối cùng.
6. Cập nhật đồng bộ tài liệu nếu được yêu cầu và xuất `report/SPRINT-3-IMPLEMENTATION-REPORT.md` phản ánh đúng kết quả thực tế.

---

## 19. Suggested Implementation Sequence

Thứ tự triển khai theo 4 đợt rõ ràng (giảm rủi ro xung đột file và test liên tục):

1. **Đợt 1 — Database & Core Domain (Backend Foundation):**
   - `S3-T01` (Schema + Migration SQL + `src/types/api.ts`) → Chạy `prisma validate` & `prisma migrate dev` trên PostgreSQL local.
   - `S3-T02` (Schemas, Access, Event Hook) → `S3-T03` (Repositories).
   - `S3-T04` (Task Core Service) → `S3-T05` (Assignment Service & nối `taskAssignmentGuard`).
   - `S3-T07` (Dependency Service & Cycle Detection) → `S3-T06` (Workflow & Review Service) → `S3-T08` (History Service).
   - *Checkpoint:* Viết & chạy `S3-T15` (Unit Tests) ngay để chốt cứng logic nghiệp vụ trước khi làm UI/API.
2. **Đợt 2 — API & Server Actions:**
   - `S3-T09` (`task.actions.ts`) song song `S3-T10` (10 REST Route Handlers).
   - *Checkpoint:* Viết & chạy `S3-T16` (API Contract Tests + PostgreSQL Integration Tests) để xác minh DB constraints, concurrency và Member Removal Guard hoạt động thật.
3. **Đợt 3 — UI/UX Integration:**
   - `S3-T11` (`dialog.tsx`, Badges, Shell) → `S3-T12` (Task List, Project Detail, Member Guard UX, Dashboard).
   - `S3-T13` (Create/Edit Task Forms) → `S3-T14` (Task Detail, Review Modal, Dependencies & History Timeline).
4. **Đợt 4 — Verification & Report:**
   - `S3-T17`: Chạy toàn bộ regression tests (`npm run test`), `format:check`, `typecheck`, `lint`, `build`, smoke-test giao diện qua từng Role và lập `report/SPRINT-3-IMPLEMENTATION-REPORT.md`.

---

## 20. Deferred Items & Open Questions (Đã xác nhận cho Sprint 3)

Toàn bộ câu hỏi mở `OQ-01` – `OQ-07` đã được Product Owner xác nhận chính thức và ghi nhận vào `markdown/DECISION-LOG.md` (`DEC-019` – `DEC-025`):

| ID | Chủ đề | Quyết định đã chốt (`Confirmed`) | Mã tham chiếu |
|---|---|---|---|
| **OQ-01** | **Xóa hoặc Hủy Task (`Delete / Cancel Task`)** | Không hỗ trợ xóa hoặc hủy Task trong Sprint 3. Không tạo `DELETE /tasks/:taskId`, không thêm trạng thái `CANCELLED`. *(Deferred sau Sprint 3)* | `DEC-019` |
| **OQ-02** | **Trường `Task Code` trên UI** | Dùng 8 ký tự đầu của UUID hiển thị dạng `#a1b2c3d4`. Không thêm cột `code` vào Database. | `DEC-020` |
| **OQ-03** | **Leader Self-Review** | Cho phép Project Leader hoặc Admin có quyền `task.review` duyệt/từ chối Task kể cả khi tự làm Assignee; vẫn bắt buộc `reason` và lưu đủ `TaskReview` + `TaskHistory`. | `DEC-021` |
| **OQ-04** | **Đồng bộ `ActivityLog` / `AuditLog` với `TaskHistory`** | Không ghi Task events vào `ActivityLog` hoặc `AuditLog`. Toàn bộ lịch sử nghiệp vụ Task nằm trong `TaskHistory`; Review lưu thêm trong `TaskReview`. | `DEC-022` |
| **OQ-05** | **Mở lại Task `DONE` (Reopen Task)** | Không cho phép chuyển `DONE` về `IN_PROGRESS` hoặc trạng thái khác trong Sprint 3. Không bổ sung chức năng Reopen. *(Deferred sau Sprint 3)* | `DEC-023` |
| **OQ-06** | **Tạo Task khi Project ở trạng thái `CREATED`** | Cho phép tạo Task khi Project ở trạng thái `CREATED` hoặc `ACTIVE`. Chỉ khóa toàn bộ mutation khi Project `ARCHIVED`. | `DEC-024` |
| **OQ-07** | **Phân quyền của `INSTRUCTOR` trên Task** | Chỉ có quyền đọc (`task.read`, `task.history.read`) trong Project được phân công. Không được tạo, sửa, assign, submit review, approve/reject hay quản lý Dependency. | `DEC-025` |
