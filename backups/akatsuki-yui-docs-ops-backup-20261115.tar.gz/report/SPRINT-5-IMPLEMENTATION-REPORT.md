# SPRINT 5 IMPLEMENTATION REPORT — DOCUMENT LIBRARY & NOTIFICATIONS

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 5 — Document Library & Notifications  
**Status:** Completed & Verified  
**Architecture:** Modular Monolith (Next.js 16 App Router + TypeScript 5.9 + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5 + Resend)

---

## 1. Executive Summary

Sprint 5 đã hoàn thiện toàn bộ hai phân hệ trọng tâm **Document Library** và **Notification Center & Email Delivery** trên nền Modular Monolith hiện hữu, bám sát `report/SPRINT-5-IMPLEMENTATION-PLAN.md` và 13 quyết định nghiệp vụ đã chốt (`DEC-034`–`DEC-046` trong `markdown/DECISION-LOG.md`):

1. **Document Library (`DEC-034`, `DEC-035`, `DEC-036`, `DEC-046`):**
   - Lưu trữ metadata tài liệu liên kết Google Drive / Google Docs (`https://drive.google.com`, `https://docs.google.com`) bằng server-side `URL` parser; chặn `http:`, credentials trong URL, domain giả mạo, subdomain lạ và đường dẫn gốc rỗng.
   - Phân quyền theo `document.read` và `document.manage`: mặc định `ADMIN` và `LEADER` quản lý; nếu `ADMIN` bật `document.manage` cho `MEMBER` qua Permission Matrix, `MEMBER` quản lý được tài liệu trong các Project hợp lệ mà mình tham gia (`assertProjectReadAccess`). `INSTRUCTOR` chỉ có quyền đọc.
   - Ràng buộc Project-Sprint Integrity ở cả Service Layer (`409 CROSS_PROJECT_SPRINT_MISMATCH`) và tầng PostgreSQL (trigger `trg_document_sprint_same_project`), hỗ trợ Soft Delete (`Document.deletedAt`) kèm `ActivityLog` & `AuditLog`, và khóa mọi mutation khi Project ở trạng thái `ARCHIVED` bằng row-level lock serialization.
   - Triển khai đồng thời `/documents` (Global) và `/projects/[projectId]/documents` (Project-scoped) dùng chung `DocumentLibraryClient` và `Document Service Layer`, cùng `ProjectDocumentSummaryCard` nhúng trên trang tổng quan Project.

2. **Notification Center & Header Bell (`DEC-043`):**
   - Triển khai trang `/notifications` (`NotificationCenterClient`) và chuông thông báo `NotificationBell` tích hợp trong `AppShell` header.
   - Hỗ trợ đầy đủ `Mark as Read`, `Mark as Unread`, `Mark All as Read` và điều hướng trực tiếp qua `targetUrl` (không thêm UI xóa/lưu trữ phía người dùng theo `DEC-043`).

3. **Transactional Notification Events (`DEC-037`, `DEC-038`, `DEC-044`):**
   - Tự động khởi tạo đồng bộ `Notification` (In-app) + `NotificationDelivery` (`EMAIL`, `PENDING`) trong cùng `prisma.$transaction` cho các sự kiện:
     - **Account Lifecycle:** `ACCOUNT_REGISTERED` (tới tất cả Admin `ACTIVE`; đăng ký vẫn thành công nếu chưa có Admin `ACTIVE`), `ACCOUNT_APPROVED`, `ACCOUNT_REJECTED` (với `ACCOUNT_REJECTED`, tạo cả `Notification` + `NotificationDelivery(EMAIL)` theo `DEC-038`); không phát sinh thông báo cho `SUSPEND` / `ACTIVATE`.
     - **Project Membership & Leadership:** `PROJECT_MEMBER_ADDED`, `PROJECT_MEMBER_REMOVED`, `PROJECT_LEADER_CHANGED` (tạo Project hoặc thêm/xóa/chuyển Leader), loại trừ tự thông báo (`recipient !== actor`) và người nhận không ở trạng thái `ACTIVE`.
     - **Task Assignment & Workflow:** `TASK_ASSIGNED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, `TASK_REVIEW_REJECTED`.
   - Khi thao tác DB gặp lỗi khiến transaction rollback, `Notification` và `NotificationDelivery` rollback đồng bộ cùng bản ghi nghiệp vụ gốc.

4. **Resend Email Delivery, Retry Backoff & Lease Concurrency (`DEC-040`, `DEC-041`, `DEC-044`, `DEC-045`):**
   - Sử dụng duy nhất Resend SDK (`RESEND_API_KEY`, `EMAIL_FROM`) với khóa chống trùng lặp ổn định `idempotencyKey = "notification-delivery:${delivery.id}"`; loại bỏ hoàn toàn các biến `SMTP_*`.
   - Kích hoạt gửi email ngay sau commit bằng Next.js `after()` (`schedulePostCommitEmailDispatch`).
   - Worker nhận việc an toàn qua PostgreSQL `FOR UPDATE SKIP LOCKED` kèm lease timeout (`lockedAt`, `lockToken`) tránh gửi trùng lặp đồng thời.
   - Áp dụng giới hạn tối đa 1 lần gửi ban đầu (`retryCount = 0`) + 3 lần thử lại (`retryCount = 1..3`) với lịch backoff `+1m`, `+5m`, `+15m`; sau lần retry thứ 3 thất bại (hoặc lỗi vĩnh viễn từ nhà cung cấp), chuyển sang terminal `FAILED` (`nextRetryAt = null`).

5. **Daily Deadline Reminder & Internal Cron (`DEC-039`, `DEC-044`):**
   - Triển khai `runDeadlineReminderBatch()` và cấu hình Vercel Cron (`vercel.json`: `"0 1 * * *"` -> `/api/internal/notifications/process`, xác thực `CRON_SECRET` Bearer timing-safe).
   - Quét Task chưa `DONE` thuộc Project `ACTIVE` có `deadline` trong `[now - 24h, now + 24h]` (bao gồm sắp đến hạn trong 24h và mới quá hạn trong 24h), gửi nhắc hạn tới các Assignee đang `ACTIVE` với `dedupKey = deadline-reminder:${taskId}:${recipientUserId}:${YYYY-MM-DD}` theo múi giờ `Asia/Ho_Chi_Minh`.

6. **Admin Delivery Monitoring & Manual Retry (`DEC-042`, `DEC-046`):**
   - Bổ sung quyền `notification.delivery.read` và `notification.delivery.retry` (gán riêng cho vai trò `ADMIN`, nâng tổng Permission Catalog từ 25 lên 27 quyền).
   - Triển khai trang `/admin/notifications/deliveries` (`AdminDeliveryHistoryClient`) và REST API xem lịch sử gửi email, thống kê trạng thái (`PENDING`, `SENT`, Retryable `FAILED`, Terminal `FAILED`), cùng nút Manual Retry (`retryCount < 3`) có ghi `AuditLog`.

---

## 2. Database & Migration (`20261115090002_sprint5_document_notification`)

- **Schema (`prisma/schema.prisma`):**
  - **Enums mới:** `DocumentCategory` (`SPECIFICATION`, `DESIGN`, `REPORT`, `OTHER`), `NotificationType` (`ACCOUNT_REGISTERED`, `ACCOUNT_APPROVED`, `ACCOUNT_REJECTED`, `PROJECT_MEMBER_ADDED`, `PROJECT_MEMBER_REMOVED`, `PROJECT_LEADER_CHANGED`, `TASK_ASSIGNED`, `TASK_SUBMITTED_FOR_REVIEW`, `TASK_REVIEW_APPROVED`, `TASK_REVIEW_REJECTED`, `TASK_DEADLINE_REMINDER`), `NotificationChannel` (`IN_APP`, `EMAIL`), `NotificationDeliveryStatus` (`PENDING`, `SENT`, `FAILED`).
  - **Models mới:**
    - `Document`: khóa ngoại `projectId`, `sprintId` (nullable, `onDelete: SetNull`), `uploadedById`, `deletedAt`, các index `[projectId, deletedAt]`, `[projectId, category, deletedAt]`, `[sprintId, deletedAt]`, `[uploadedById]`.
    - `Notification`: `userId`, `actorId`, `projectId`, `type`, `title`, `message`, `targetUrl`, `entityType`, `entityId`, `metadata`, `dedupKey`, `isRead`, `readAt`, kèm `@@unique([userId, dedupKey])` và các index tối ưu đọc/đếm thông báo chưa đọc.
    - `NotificationDelivery`: `notificationId`, `channel`, `recipientEmail`, `status`, `provider`, `providerMessageId`, `retryCount`, `lastAttemptAt`, `nextRetryAt`, `lockedAt`, `lockToken`, `sentAt`, `failedAt`, `errorCode`, `errorMessage`, kèm `@@unique([notificationId, channel])` và index `[status, nextRetryAt]`, `[lockedAt]`.
- **PostgreSQL Custom Constraints & Trigger (`prisma/migrations/20261115090002_sprint5_document_notification/migration.sql`):**
  - `Document_title_nonempty_chk`: `length(btrim("title")) > 0`.
  - `NotificationDelivery_retry_count_chk`: `"retryCount" >= 0 AND "retryCount" <= 3`.
  - Hàm `check_document_sprint_same_project()` & trigger `trg_document_sprint_same_project` (`BEFORE INSERT OR UPDATE OF "projectId", "sprintId"` trên `"Document"`): ném lỗi PostgreSQL (`ERRCODE = '23514'`) nếu `sprintId` thuộc về một Project khác `Document.projectId`.

---

## 3. Modules, Services, Actions & Integrations

### 3.1. Authorization & Environment
- `src/modules/authorization/constants.ts`: bổ sung `NOTIFICATION_DELIVERY_READ` (`notification.delivery.read`) và `NOTIFICATION_DELIVERY_RETRY` (`notification.delivery.retry`) vào `PERMISSIONS`, `CORE_ADMIN_PERMISSION_CODES`, `PERMISSION_CATALOG` (27 quyền) và `ROLE_DEFINITIONS.ADMIN.permissions` (27 quyền).
- `src/lib/env.ts` & `.env.example`: xóa toàn bộ biến `SMTP_*`, thêm `CRON_SECRET` và cấu hình `RESEND_API_KEY` / `EMAIL_FROM`.
- `src/types/api.ts`: mở rộng `ErrorCode` thêm `DOCUMENT_NOT_FOUND`, `CROSS_PROJECT_SPRINT_MISMATCH`, `NOTIFICATION_NOT_FOUND`, `DELIVERY_NOT_FOUND`, `DELIVERY_ALREADY_SENT`, `DELIVERY_STILL_PENDING`, `DELIVERY_RETRY_LIMIT_EXCEEDED`, `DELIVERY_LOCKED_OR_INELIGIBLE`, `CRON_UNAUTHORIZED`.

### 3.2. Document Module (`src/modules/documents/*`)
- `src/modules/documents/document.types.ts`: DTOs (`DocumentDTO`, `DocumentListResponseDTO`, `AccessibleProjectOptionDTO`, `DocumentSprintSummaryDTO`).
- `src/modules/documents/document.validation.ts`: `validateGoogleDriveUrl` + Zod v4 schemas (`createDocumentSchema`, `updateDocumentSchema`, `documentListQuerySchema`).
- `src/modules/documents/document.access.ts`: `canActorManageProjectDocuments`, `lockProjectRowForDocumentMutation`, `assertSprintBelongsToDocumentProject`, kiểm tra đọc/quản lý Project và trạng thái `ARCHIVED`.
- `src/modules/documents/document.repository.ts`: truy vấn luôn lọc `deletedAt: null` cho mọi thao tác chuẩn.
- `src/modules/documents/document.service.ts`: `listGlobalDocumentsService`, `listProjectDocumentsService`, `listAccessibleProjectsForDocumentsService`, `getDocumentDetailService`, `createDocumentService`, `updateDocumentService`, `deleteDocumentService` (Soft Delete + `AuditLog` + `ActivityLog`).
- `src/modules/documents/document.actions.ts`: 3 Server Actions (`createDocumentAction`, `updateDocumentAction`, `deleteDocumentAction`) với `ActionResult` và `revalidateDocumentPaths`.

### 3.3. Notification & Email Delivery Module (`src/modules/notifications/*` & `src/server/integrations/*`)
- `src/modules/notifications/notification.types.ts` & `notification.validation.ts`: DTOs và Zod schemas (`notificationListQuerySchema`, `markNotificationReadSchema`, `deliveryHistoryQuerySchema`).
- `src/modules/notifications/notification.repository.ts`: `notificationRepository` (truy vấn hộp thư cá nhân, đếm chưa đọc, và lịch sử delivery + summary stats cho Admin).
- `src/modules/notifications/notification.service.ts`: `listUserNotificationsService`, `getUserUnreadNotificationCountService`, `markNotificationReadStateService`, `markAllNotificationsReadService`, `createNotificationsInTransaction`.
- `src/modules/notifications/notification-domain-events.ts`: tích hợp các hàm ghi nhận sự kiện trong transaction (`recordAccountRegisteredNotifications`, `recordAccountStatusDecisionNotifications`, `recordProjectMemberAddedNotification`, `recordProjectMemberRemovedNotification`, `recordProjectLeaderChangedNotifications`, `recordTaskEventNotifications`).
- Đã nối hook phát sinh thông báo trong transaction + `schedulePostCommitEmailDispatch` vào các service hiện hữu: `src/modules/auth/auth.service.ts`, `src/modules/users/user.service.ts`, `src/modules/projects/project.service.ts`, `src/modules/project-members/member.service.ts`, `src/modules/tasks/task.service.ts`, `src/modules/tasks/task-assignment.service.ts`, `src/modules/tasks/task-workflow.service.ts`.
- `src/server/integrations/email.ts` & `src/server/integrations/resend.ts`: tích hợp Resend SDK, `buildDeliveryIdempotencyKey`, `classifyEmailProviderError`, `sendEmailViaResend`.
- `src/modules/notifications/notification-email.templates.ts`: chuẩn hóa template HTML + plain text cho toàn bộ 11 loại thông báo Sprint 5.
- `src/modules/notifications/notification-delivery.service.ts`: `computeRetryBackoffNextAt`, `claimDeliveryLeaseById` (`FOR UPDATE SKIP LOCKED` với cast `::timestamp`), `executeClaimedDelivery`, `processSingleNotificationDelivery`, `processDueEmailDeliveriesBatch`, `schedulePostCommitEmailDispatch` (Next.js `after()`), `listAdminNotificationDeliveriesService`, `manualRetryNotificationDeliveryService`.
- `src/modules/notifications/notification-deadline.service.ts`: `runDeadlineReminderBatch`, `formatDateKeyInHoChiMinh`, `buildDeadlineReminderDedupKey`.
- `src/modules/notifications/notification.actions.ts`: `markNotificationReadStateAction`, `markAllNotificationsReadAction`, `manualRetryNotificationDeliveryAction`.

---

## 4. API Route Handlers & UI Pages

### 4.1. Route Handlers (`/api/v1/*`, `/api/*`, `/api/internal/*`)
- **Documents:**
  - `GET /api/v1/documents` *(và wrapper `/api/documents`)*
  - `GET / POST /api/v1/projects/[projectId]/documents` *(và wrapper `/api/projects/[projectId]/documents`)*
  - `GET / PATCH / DELETE /api/v1/documents/[documentId]` *(và wrapper `/api/documents/[documentId]`)*
- **Notifications:**
  - `GET /api/v1/notifications` *(và wrapper `/api/notifications`)*
  - `GET /api/v1/notifications/unread-count` *(và wrapper `/api/notifications/unread-count`)*
  - `PATCH /api/v1/notifications/[notificationId]/read` *(và wrapper `/api/notifications/[notificationId]/read`)*
  - `POST /api/v1/notifications/mark-all-read` *(và wrapper `/api/notifications/mark-all-read`)*
- **Admin Delivery Monitoring:**
  - `GET /api/v1/admin/notifications/deliveries` *(và wrapper `/api/admin/notifications/deliveries`)*
  - `POST /api/v1/admin/notifications/deliveries/[deliveryId]/retry` *(và wrapper `/api/admin/notifications/deliveries/[deliveryId]/retry`)*
- **Internal Cron Processor (`vercel.json`: `"0 1 * * *"`):**
  - `GET / POST /api/internal/notifications/process` *(và alias `/api/v1/internal/notifications/process`)* — xác thực `CRON_SECRET` Bearer (`timingSafeEqual`).

### 4.2. UI Components & App Router Pages
- `src/components/layout/app-shell.tsx`: bổ sung liên kết điều hướng `/documents`, `/notifications`, `/admin/notifications/deliveries` theo quyền, nhúng `<NotificationBell />` ở header, và cập nhật footer sidebar `Sprint 5 · Documents & Notifications`.
- `src/components/features/documents/document-library-client.tsx` & `project-document-summary-card.tsx`: UI thư viện tài liệu dùng chung + card tóm tắt nhúng tại `src/app/(dashboard)/projects/[projectId]/page.tsx`.
- `src/components/features/notifications/notification-bell.tsx`: Header Notification Bell dropdown + badge đếm chưa đọc.
- `src/components/features/notifications/notification-center-client.tsx`: UI hộp thư `/notifications`.
- `src/components/features/notifications/admin-delivery-history-client.tsx`: UI giám sát gửi email & Manual Retry `/admin/notifications/deliveries`.
- App Router Pages:
  - `src/app/(dashboard)/documents/page.tsx` (`/documents`)
  - `src/app/(dashboard)/projects/[projectId]/documents/page.tsx` (`/projects/[projectId]/documents`)
  - `src/app/(dashboard)/notifications/page.tsx` (`/notifications`)
  - `src/app/(dashboard)/admin/notifications/deliveries/page.tsx` (`/admin/notifications/deliveries`)

---

## 5. Verification Summary & Test Suites

Toàn bộ các kiểm tra dưới đây được chạy trực tiếp và xác minh thành công (0 lỗi, 0 warning ESLint, 0 test skipped):

| Check / Suite | Command | Result |
|---|---|---|
| Guard Check (`SMTP_` removal) | `Select-String` trên `src/`, `prisma/`, `tests/`, `.env.example` | **0 matches** (exit 0) |
| Prisma Schema Validate | `npx prisma validate` | Valid (exit 0) |
| Prisma Migration Status | `npx prisma migrate status` | **5 migrations found**, database schema is up to date (exit 0) |
| Prettier Format Check (Sprint 5 files) | `npx prettier --check` *(toàn bộ file tạo mới/chỉnh sửa trong Sprint 5)* | **All matched files use Prettier code style!** (exit 0) |
| TypeScript Check | `npm run typecheck` (`tsc --noEmit`) | **Passed — 0 errors** (exit 0) |
| ESLint | `npm run lint` (`eslint .`) | **Passed — 0 errors, 0 warnings** (exit 0) |
| Unit & PostgreSQL Integration Tests | `npm test` (`vitest run`) | **21 test files passed (21), 131 tests passed (131), 0 skipped** (exit 0) |
| Production Build | `npm run build` (`next build`) | Compiled & built cleanly — **28/28 static pages**, **94 route entries** (`/_not-found` + 93 app/API routes) (exit 0) |

### 5.1. Sprint 5 Test Suites Added (`5 files, 27 tests`)
- `tests/unit/sprint5-documents.test.ts` (**7 tests**): Google Drive/Docs URL validation (`DEC-035`), Document RBAC & Permission Matrix (`ADMIN`, `LEADER`, `MEMBER` mặc định vs được cấp quyền, `INSTRUCTOR`, `ARCHIVED`), cross-project Sprint lock (`409 CROSS_PROJECT_SPRINT_MISMATCH`), Soft Delete + `AuditLog` / `ActivityLog`, và validation input rỗng.
- `tests/unit/sprint5-notifications.test.ts` (**8 tests**): lọc self-notification, deduplication trong batch, bỏ qua user không `ACTIVE` (`ALLOW_NON_ACTIVE` riêng cho `ACCOUNT_REJECTED`), `ACCOUNT_REGISTERED` không lỗi khi chưa có Admin `ACTIVE`, backoff schedule (`+1m`, `+5m`, `+15m`, `null` ở retry 3), `idempotencyKey`, timezone `Asia/Ho_Chi_Minh` cho `dedupKey` Deadline Reminder, constant-time `CRON_SECRET` check, và permission guard `notification.delivery.read`.
- `tests/unit/sprint5-email-worker.test.ts` (**3 tests**): `executeClaimedDelivery` với Resend mock — kiểm tra trạng thái `SENT` + `idempotencyKey`, chuỗi backoff `0 -> 1 -> 2 -> 3` cho lỗi tạm thời, và terminal `FAILED` ngay lập tức cho lỗi vĩnh viễn (`422`).
- `tests/unit/sprint5-api-routes.test.ts` (**6 tests**): Contract tests `200`/`201`/`400`/`401`/`403`/`404`/`409` cho toàn bộ endpoint Documents (`/api/v1/documents`, `/api/v1/projects/[projectId]/documents`, `/api/v1/documents/[documentId]`), Notifications (`/api/v1/notifications`, `/unread-count`, `/[notificationId]/read` kèm empty-body fallback, `/mark-all-read`), Admin Deliveries (`/api/v1/admin/notifications/deliveries`, `/[deliveryId]/retry`), và `/api/internal/notifications/process`.
- `tests/integration/sprint5-db.test.ts` (**3 tests**): PostgreSQL integration tests cho Document CRUD + Soft Delete + Project `ARCHIVED` lock + `MEMBER` `document.manage` grant + PostgreSQL trigger `trg_document_sprint_same_project`; transactional `Notification` + `NotificationDelivery` cho Account/Project/Task events; `FOR UPDATE SKIP LOCKED` lease claiming + cap 3 retries (`DELIVERY_RETRY_LIMIT_EXCEEDED`) + Deadline Reminder deduplication + chứng minh PostgreSQL rollback toàn phần khi notification insert thất bại (`P2003`) trong `$transaction`.

### 5.2. Regression Baseline Verified (Sprint 1–4 — `16 files, 104 tests`)
- Toàn bộ 16 file test của Sprint 1–4 (`auth-validation.test.ts` (8), `authorization-policy.test.ts` (4), `user-service.test.ts` (6), `password.test.ts` (1), `button-slot.test.ts` (2), `api-routes.test.ts` (6), `sprint1-db.test.ts` (3), `sprint2-services.test.ts` (11), `sprint2-api-routes.test.ts` (5), `sprint2-db.test.ts` (3), `sprint3-task-services.test.ts` (21), `sprint3-api-routes.test.ts` (5), `sprint3-db.test.ts` (5), `sprint4-services.test.ts` (14), `sprint4-api-routes.test.ts` (5), `sprint4-db.test.ts` (5)) đều chạy và pass 100%.

---

## 6. Out of Scope / Remaining Work Beyond Sprint 5

- **Sprint 6:** Member Contribution Report & Advanced Analytics Dashboard, cùng các quyết định ngoài phạm vi Sprint 5 còn lại trong `markdown/DECISION-LOG.md` (Actual Time, non-FS dependencies, Task reopen/delete sau Sprint 4).
- **Email Production Testing:** Trong môi trường test tự động không gọi ra mạng ngoài (`NODE_ENV === "test"` và Resend SDK được mock); khi triển khai production/staging cần cấu hình biến môi trường thật `RESEND_API_KEY`, `EMAIL_FROM` (domain đã verify trên Resend) và `CRON_SECRET`.
