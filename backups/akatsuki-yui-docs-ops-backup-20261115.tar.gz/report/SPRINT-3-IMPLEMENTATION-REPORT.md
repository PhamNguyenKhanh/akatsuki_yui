# SPRINT 3 IMPLEMENTATION REPORT — TASK MANAGEMENT

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 3 — Task Management  
**Status:** Completed & Verified  
**Architecture:** Modular Monolith (Next.js 16 App Router + TypeScript + PostgreSQL 18 + Prisma 6.19.3)

---

## 1. Executive Summary

Sprint 3 đã hoàn thiện phân hệ **Task Management** end-to-end theo đúng kế hoạch `report/SPRINT-3-IMPLEMENTATION-PLAN.md` và 07 quyết định nghiệp vụ đã xác nhận (`OQ-01`–`OQ-07` / `DEC-019`–`DEC-025`):

1. **Task Core & Member Field-Level Security (`DEC-015`, `DEC-024`, `DEC-025`):** CRUD/Filter/Detail cho Task theo phạm vi Project, cho phép khởi tạo Task trong Project `CREATED` hoặc `ACTIVE` (khóa mutation khi `ARCHIVED` -> `409 PROJECT_ARCHIVED`), thực thi chế độ chỉ xem cho `INSTRUCTOR` và chặn strict `403 FORBIDDEN` khi `MEMBER` gửi các field của Leader (`title`, `description`, `priority`, `startDate`, `deadline`, `estimateHours`, ...).
2. **Task Assignment & Member Removal Guard (`DEC-009`, `BR-MEM-005`):** Phân công đồng loạt hoặc từng thành viên (`ACTIVE` system user & active `LEADER`/`MEMBER` trong Project, loại trừ `INSTRUCTOR`), bảo lưu lịch sử gỡ phân công qua `TaskAssignee.removedAt`, và kích hoạt `taskAssignmentGuard` chặn loại thành viên khỏi Project khi còn Task chưa `DONE` (`409 TASK_ASSIGNEE_REASSIGN_REQUIRED` kèm danh sách Task chặn).
3. **Review Workflow & Concurrency Safety (`DEC-021`, `DEC-023`):** Chu trình trạng thái `TODO -> IN_PROGRESS -> REVIEW -> DONE` và Reject `REVIEW -> IN_PROGRESS`, dùng Atomic Compare-and-Set (`updateMany` với điều kiện `status`) bên trong `prisma.$transaction`, cho phép Leader/Admin self-review có lý do bắt buộc (`REVIEW_REASON_REQUIRED`), khóa `DONE` không cho Reopen, và phát event hook sau commit (`emitTaskEventAfterCommit`).
4. **Task Dependency DAG & Approve Gate (`DEC-005`):** Cho phép bắt đầu thực hiện Task phụ thuộc nhưng chặn Approve lên `DONE` nếu còn tiền điều kiện chưa `DONE` (`409 TASK_DEPENDENCY_NOT_COMPLETED`); hỗ trợ diamond DAG, chặn self-reference / cross-project / duplicate / thêm tiền điều kiện chưa `DONE` vào Task `DONE` / cycle, và serial hóa tranh chấp đồng thời bằng `pg_advisory_xact_lock`.
5. **Task History & Review Audit (`DEC-022`):** Lưu toàn bộ lịch sử nghiệp vụ Task trong `TaskHistory` và quyết định Review chính thức trong `TaskReview`; không ghi trùng sự kiện Task vào `ActivityLog` hay `AuditLog`.

---

## 2. Database & Migration (`20261115063614_sprint3_task_management`)

- **Schema:** `prisma/schema.prisma`
  - **Enums mới:** `TaskStatus` (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`), `TaskPriority` (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`), `ReviewDecision` (`APPROVED`, `REJECTED`), `TaskHistoryAction` (11 actions).
  - **Models mới:** `Task`, `TaskAssignee`, `TaskDependency`, `TaskReview`, `TaskHistory` cùng quan hệ ngược trên `User` và `Project`.
- **PostgreSQL Custom Constraints & Indexes (migration SQL):**
  - Partial Unique Index `TaskAssignee_active_task_user_idx` trên `"TaskAssignee"("taskId", "userId") WHERE "removedAt" IS NULL`.
  - Check Constraint `Task_date_range_chk`: `"startDate" IS NULL OR "deadline" >= "startDate"`.
  - Check Constraint `Task_estimate_nonnegative_chk`: `"estimateHours" IS NULL OR "estimateHours" >= 0`.
  - Check Constraint `TaskDependency_no_self_chk`: `"taskId" <> "dependsOnTaskId"`.
  - Check Constraint `TaskReview_reason_nonempty_chk`: `length(btrim("reason")) > 0`.

---

## 3. Modules, Services, Actions & REST API Implemented

### 3.1. Task Module (`src/modules/tasks/*`) & Shared Updates
- `src/modules/tasks/task.schema.ts`: Zod validation (`createTaskSchema`, `updateTaskSchema`, `taskListQuerySchema`, `syncTaskAssigneesSchema`, `addTaskAssigneeSchema`, `submitTaskReviewSchema`, `reviewDecisionSchema`, `addTaskDependencySchema`, `taskHistoryQuerySchema`), `formatTaskCode(id)` (`#xxxxxxxx`).
- `src/modules/tasks/task.access.ts`: UUID parsing, Project Archived lock guard, Leader/Admin & active `TaskAssignee` checks.
- `src/modules/tasks/task-events.ts`: `registerTaskEventHandler` & `emitTaskEventAfterCommit` (chỉ chạy sau khi `$transaction` commit xong).
- `src/modules/tasks/task-history.repository.ts` & `src/modules/tasks/task.repository.ts`: Query/DTO phân trang, thống kê Task theo Project, "My Assigned Tasks", danh sách ứng viên Dependency.
- `src/modules/tasks/task.service.ts`: `listProjectTasksService`, `getProjectTaskStatsService`, `listProjectTaskOptionsService`, `listMyAssignedTasksService`, `getTaskDetailService`, `createTaskService`, `updateTaskService`.
- `src/modules/tasks/task-assignment.service.ts`: `validateEligibleTaskAssignees`, `listTaskAssigneesService`, `syncTaskAssigneesService`, `addTaskAssigneeService`, `removeTaskAssigneeService`.
- `src/modules/tasks/task-dependency.service.ts`: `hasDependencyPath`, `listTaskDependenciesService`, `addTaskDependencyService`, `removeTaskDependencyService`.
- `src/modules/tasks/task-workflow.service.ts`: `updateTaskStatusService`, `submitTaskForReviewService`, `approveTaskReviewService`, `rejectTaskReviewService`.
- `src/modules/tasks/task-history.service.ts`: `listTaskHistoryService`.
- `src/modules/tasks/task.actions.ts`: 11 Server Actions có `revalidatePath` cho Dashboard, Project và Task routes.
- `src/modules/project-members/task-assignment-guard.ts`: Kích hoạt guard kiểm tra `TaskAssignee` (`removedAt IS NULL`) cho Task có `status !== DONE`.
- `src/types/api.ts`: Bổ sung các error codes Sprint 3 (`ASSIGNEE_NOT_PROJECT_MEMBER`, `TASK_DEPENDENCY_NOT_COMPLETED`, `TASK_DEPENDENCY_SELF_REFERENCE`, `TASK_DEPENDENCY_EXISTS`, `TASK_DEPENDENCY_CYCLE`, `REVIEW_REASON_REQUIRED`) và mở rộng `ApiErrorDetail` (`taskId`, `taskTitle`, `taskStatus`).

### 3.2. REST API Route Handlers (`/api/v1/*`)
- `GET / POST /api/v1/projects/[projectId]/tasks`
- `GET / PATCH /api/v1/tasks/[taskId]` *(không có `DELETE` theo `OQ-01 / DEC-019`)*
- `GET / PUT / POST /api/v1/tasks/[taskId]/assignees`
- `DELETE /api/v1/tasks/[taskId]/assignees/[userId]`
- `POST /api/v1/tasks/[taskId]/submit-review` *(hỗ trợ body rỗng hoặc JSON `{ note, progressNotes, referenceLinks }`)*
- `POST /api/v1/tasks/[taskId]/approve`
- `POST /api/v1/tasks/[taskId]/reject`
- `GET / POST /api/v1/tasks/[taskId]/dependencies`
- `DELETE /api/v1/tasks/[taskId]/dependencies/[dependsOnTaskId]`
- `GET /api/v1/tasks/[taskId]/history`

---

## 4. UI Components & Pages Implemented

- **UI Primitives & Shared Badges:**
  - `src/components/ui/dialog.tsx`: Dialog wrapper trên `@radix-ui/react-dialog`.
  - `src/components/shared/status-badge.tsx`: Bổ sung `TaskStatusBadge` và `TaskPriorityBadge`.
  - `src/components/layout/app-shell.tsx`: Cập nhật footer sang `Sprint 3 · Task Management`.
- **Task UI Components (`src/components/tasks/*`):**
  - `task-list-client.tsx`, `task-form.tsx`, `task-review-modal.tsx`, `task-assignees-card.tsx`, `task-dependencies-card.tsx`, `task-history-timeline.tsx`, `task-detail-panel.tsx`, `project-task-summary-card.tsx`, `my-assigned-tasks-card.tsx`.
- **Pages & Integrations:**
  - `src/app/(dashboard)/projects/[projectId]/tasks/page.tsx`: Danh sách & bộ lọc công việc theo Project.
  - `src/app/(dashboard)/projects/[projectId]/tasks/new/page.tsx`: Khởi tạo Task mới (Leader/Admin).
  - `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/page.tsx`: Chi tiết Task, tiến độ, assignees, dependencies, review actions và timeline lịch sử.
  - `src/app/(dashboard)/projects/[projectId]/tasks/[taskId]/edit/page.tsx`: Cập nhật metadata Task (Leader/Admin).
  - `src/app/(dashboard)/projects/[projectId]/page.tsx`: Tích hợp Card **Tổng quan công việc (Tasks)** và liên kết điều hướng.
  - `src/components/projects/project-members-panel.tsx`: Hiển thị danh sách Task đang chặn loại thành viên (`TASK_ASSIGNEE_REASSIGN_REQUIRED`) kèm link thao tác nhanh.
  - `src/app/(dashboard)/dashboard/page.tsx`: Tích hợp Card **Công việc được giao cho tôi**.

---

## 5. Verification Summary

Các bước kiểm tra được thực thi sau lần chỉnh sửa code cuối cùng:

| Check / Suite | Command | Result |
|---|---|---|
| Prisma Schema Validate | `npx prisma validate` | Valid (exit 0) |
| Prisma Migration Status | `npx prisma migrate status` | 3 migrations found, database schema up to date (exit 0) |
| TypeScript Check | `npm run typecheck` | Passed — 0 errors (exit 0) |
| ESLint | `npm run lint` | Passed — 0 errors, 0 warnings (exit 0) |
| Unit & PostgreSQL Integration Tests | `npm run test` (`vitest run`) | **13 test files passed (13), 80 tests passed (80), 0 skipped** (exit 0) |
| Production Build | `npm run build` (`next build`) | Compiled & built cleanly — 52 app/API routes + `/_not-found` (exit 0) |
| Prettier Format Check (Sprint 3 files) | `npx prettier --check` *(các file Sprint 3)* | All Sprint 3 created/modified files follow Prettier code style (exit 0) |

> **Lưu ý về `npm run format:check` toàn repo:** Lệnh `npm run format:check` chạy trên cả các file Sprint 1/2 chưa chỉnh sửa và báo `[warn]` line-ending/style cho các file cũ đó do checkout CRLF trên Windows; nhóm file Sprint 1/2 không thuộc phạm vi thay đổi nên được giữ nguyên nguyên trạng.

### Test Suites Added in Sprint 3 (`3 files, 31 tests`)
- `tests/unit/sprint3-task-services.test.ts` (**21 tests**): Validation, Task Core, `DEC-015` field-level 403, `CREATED`/`ARCHIVED` lock, `INSTRUCTOR` read-only, Assignment & Guard, Review Workflow, Self-Review, Dependency cycle/diamond DAG/approve gate, Task History.
- `tests/unit/sprint3-api-routes.test.ts` (**5 tests**): Contract `200`/`201`/`400`/`401`/`403`/`404`/`409` cho toàn bộ 10 route handlers và xác nhận vắng mặt `DELETE /api/v1/tasks/[taskId]`.
- `tests/integration/sprint3-db.test.ts` (**5 tests**): Real PostgreSQL CHECK constraints & partial unique index, soft-unassign/reassign history, real `removeProjectMemberService` guard, full Review + TaskHistory without `ActivityLog`/`AuditLog`, Diamond DAG + cycle rejection, concurrent status CAS race (`Promise.allSettled`), concurrent opposite dependency race (`pg_advisory_xact_lock`), và transaction rollback integrity.

---

## 6. Out of Scope / Deferred to Later Sprints

- **Sprint 4:** `Sprint` model, `Task.sprintId`, Product Backlog & Sprint Planning, Kanban Board UI, Workload & Progress Dashboard.
- **Sprint 5:** Notification Center UI & Email dispatch tiêu thụ `taskEventHook`, Comments / Discussions, File Uploads & Attachments.

---

## 7. Next / Local Verification Guide

```powershell
# 1. Verify DB & Regression Tests
npx prisma migrate status
npm run test

# 2. Run local dev server
npm run dev
```

Chưa thực hiện `git commit` hoặc `git push`; toàn bộ thay đổi Sprint 3 đang ở working tree để Lead/PO review trước khi commit.
