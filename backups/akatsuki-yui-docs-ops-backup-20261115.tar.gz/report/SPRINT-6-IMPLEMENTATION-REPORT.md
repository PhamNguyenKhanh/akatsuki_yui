# SPRINT 6 IMPLEMENTATION REPORT — DASHBOARD, REPORTS, ANALYTICS & UNIFIED ACTIVITY HISTORY

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 6 — Dashboard, Member Contribution Report, Advanced Analytics & Unified Activity History  
**Status:** Completed & Verified  
**Architecture:** Modular Monolith (Next.js 16.4.6 App Router + TypeScript 5.9 + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5 + Vitest 5.1.0)

---

## 1. Executive Summary

Sprint 6 đã triển khai hoàn chỉnh các phân hệ phân tích, báo cáo, bảng điều khiển vận hành và dòng thời gian hoạt động hợp nhất dựa trên [`report/SPRINT-6-IMPLEMENTATION-PLAN.md`](file:///d:/Akatsuki%20Yui/report/SPRINT-6-IMPLEMENTATION-PLAN.md), tuân thủ đầy đủ 12 quyết định đã phê duyệt (`DEC-047`–`DEC-058` trong [`markdown/DECISION-LOG.md`](file:///d:/Akatsuki%20Yui/markdown/DECISION-LOG.md)) cùng các cải tiến kỹ thuật Section 18 (`P0-01`, `P0-02`, `P1-01`, `P1-02`, `P1-03`):

1. **Timezone Standard & Database Migration (`20261115114856_sprint6_reporting_indexes_and_activity_project`):**
   - Chuẩn hóa xử lý ngày và tuần ISO 8601 theo múi giờ **`Asia/Ho_Chi_Minh` (`UTC+7`)** qua [`src/lib/timezone.ts`](file:///d:/Akatsuki%20Yui/src/lib/timezone.ts), nhất quán giữa PostgreSQL `AT TIME ZONE` và TypeScript.
   - Thêm cột nullable `ActivityLog.projectId` (FK `ON DELETE SET NULL`), thực hiện SQL backfill có điều kiện an toàn cho bản ghi cũ của `Project`, `ProjectMember`, `Sprint`, `Document` (`DEC-055`), cập nhật đầy đủ các lời gọi ghi `ActivityLog` tại Service Layer, đồng thời bổ sung 7 chỉ mục báo cáo và giữ nguyên 100% các partial unique index (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`) và trigger từ Sprint 2–5.

2. **Operational Dashboard (`DEC-051`, `DEC-053`, `P1-02`):**
   - Triển khai trang [`/dashboard`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/dashboard/page.tsx) và API `GET /api/v1/dashboard` (`getOperationalDashboardService`), ưu tiên chọn Project `ACTIVE` đầu tiên, kế tiếp `CREATED`, sau cùng `ARCHIVED`, kèm **Project Switcher** cho phép xem Project `ARCHIVED` ở chế độ Read-only (`isReadOnly: true`).
   - Widget tự động ẩn/hiện dựa theo các permission sẵn có (`account.read`, `role.manage`, `project.read`, `project.create`, `task.read`, `sprint.read`, `report.read`, `activity.read`, `notification.read`) mà **không** tách thêm quyền `dashboard.read`.
   - Tách bạch hoàn toàn **Task Work Progress (`DONE / Total`)** và **Project Timeline Progress (`computeProjectTimelineProgress`)**, không nhúng biểu đồ báo cáo phân tích vào `/dashboard`.

3. **Objective Non-Additive Member Contribution Report (`DEC-047`–`DEC-050`, `DEC-052`, `P0-02`, `P1-03`):**
   - Triển khai `getMemberContributionReportService` và `GET /api/v1/reports/projects/[projectId]/members` với quy tắc **phi cộng dồn (`DEC-047`)**: tách rõ `soleAssignedCount` và `coAssignedCount` bên cạnh bảng đối chiếu **Project Totals** (`soleAssignedTasks`, `coAssignedTasks`, `unassignedTasks`, `totalTasks`).
   - Tách biệt **Current Active Assignments** (yêu cầu đồng thời `TaskAssignee.removedAt IS NULL` **và** tư cách thành viên `isActiveParticipant === true` trong Project theo `P1-03`) với **Historical Assignments** (`formerTasksDistinctCount`, `historicalDoneDistinctCount`, `uniqueTasksEverAssigned` đếm `DISTINCT taskId` tách khỏi `totalAssignmentEpisodes` và `removedOrDepartedEpisodeCount` theo `P0-02`).
   - Bao gồm cựu thành viên (`leftAt !== null`) với huy hiệu `"Đã rời Project"` và tham số `includeRemoved` (`true` mặc định, `DEC-050`).
   - Chỉ sử dụng `estimateHours` như **Planned Workload** (không theo dõi Actual Hours theo `DEC-048`), hiển thị số Task chưa nhập estimate và tổng hợp hành động xác thực từ `TaskHistory` / `TaskReview`.
   - Tài khoản có role `MEMBER` (và không giữ quyền `LEADER`/`INSTRUCTOR`/`ADMIN`) chỉ nhận `viewScope: "SELF_ONLY"` chứa duy nhất dòng của chính mình (`DEC-052`).

4. **Project Advanced Analytics (`DEC-054`, `DEC-056`, `DEC-057`):**
   - Triển khai `getProjectAnalyticsService` và `GET /api/v1/reports/projects/[projectId]` cung cấp 6 nhóm phân tích bằng truy vấn tổng hợp PostgreSQL (`projectAnalyticsRepository`): Completion & Created Trend, Status Distribution, Priority Distribution (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`), Review Approval & Rework Trend, Overdue Aging Buckets & Late Completion Slip Trend, và Sprint/Backlog Planned Estimate Workload.
   - Hỗ trợ preset `7d`, `30d` (mặc định), `90d`, `all`, `custom` với giới hạn tối đa **365 ngày**, tự động gom nhóm tuần ISO (thứ Hai) khi khoảng thời gian `> 90` ngày theo múi giờ `Asia/Ho_Chi_Minh` (`DEC-057`).

5. **Sprint Commitment, Rollover & Historical Estimate Reconstruction Fix (`DEC-058`, `P0-01`):**
   - Triển khai `getProjectSprintReportService` và `GET /api/v1/reports/projects/[projectId]/sprints` tái dựng 6 nhóm chỉ số (`baselineCommitment`, `scopeAdded`, `scopeRemoved`, `completedTasks`, `rolledOverToBacklog`, `rolledOverToSprint`) trực tiếp từ lịch sử mà **không** tạo thêm snapshot table mới (`DEC-058`).
   - Khắc phục triệt để bug Burndown và tái dựng `estimateHours` lịch sử (`src/modules/sprints/estimate-reconstruction.ts`):
     - Ngày đóng Sprint không tụt giả về `0` khi rollover Task chưa xong thông qua bỏ qua các sự kiện `SPRINT_COMPLETION` / `SPRINT_CANCELLED` cùng ngày đóng trên biểu đồ Burndown (`computeSprintBurndownAnalytics`).
     - Đóng băng `estimateHours` tại thời điểm kích hoạt (`SPRINT_ACTIVATED` metadata `baselineTasks`) và thời điểm đóng Sprint bằng cơ chế rollback chuỗi `TaskHistory.INFO_UPDATED` + gắn cờ `hasPostSprintEstimateEdits` và `estimateSnapshotMode` (`P0-01`).

6. **Unified Activity History & Cursor Pagination (`DEC-052`, `DEC-055`, `P1-01`):**
   - Hợp nhất `ActivityLog` (`WORKSPACE`) và `TaskHistory` (`TASK`) trên [`/activity`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/activity/page.tsx) và `GET /api/v1/activity`.
   - Sử dụng **Keyset Cursor (`createdAt DESC, source DESC, id DESC`)** giúp ổn định phân trang khi có sự kiện mới phát sinh đồng thời (`P1-01`).
   - Thực thi cô lập chặt cho `MEMBER` (`DEC-052`): ẩn hoàn toàn nhật ký đồng nghiệp, Task chưa từng/không được giao và nhật ký toàn Workspace có `projectId IS NULL`.

7. **Pure React + SVG Charts & View-Only UI (`DEC-054`, `DEC-056`):**
   - Không cài `recharts` hoặc bất kỳ thư viện chart bên thứ ba nào (`package.json` = 0 kết quả `recharts`).
   - Triển khai 4 component SVG thuần tái sử dụng trong [`src/components/reports/svg-charts.tsx`](file:///d:/Akatsuki%20Yui/src/components/reports/svg-charts.tsx): `SvgDualLineTrendChart`, `SvgDonutChart`, `SvgStackedBarChart`, và `HorizontalBreakdownBars`.
   - Toàn bộ trang báo cáo [`/reports`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/reports/page.tsx) và [`/projects/[projectId]/reports`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/projects/[projectId]/reports/page.tsx) ở chế độ **chỉ xem** (không có chức năng xuất CSV/PDF/Excel theo `DEC-054`).

---

## 2. Database & Migration (`20261115114856_sprint6_reporting_indexes_and_activity_project`)

- **Schema ([`prisma/schema.prisma`](file:///d:/Akatsuki%20Yui/prisma/schema.prisma)):**
  - Bổ sung `projectId String? @db.Uuid` và quan hệ `project Project? @relation(..., onDelete: SetNull)` vào model `ActivityLog`, cùng các index `@@index([projectId, createdAt(sort: Desc), id(sort: Desc)])`, `@@index([userId, createdAt(sort: Desc), id(sort: Desc)])`, `@@index([createdAt(sort: Desc), id(sort: Desc)])`.
  - Bổ sung index phục vụ Analytics & Contribution trên `Task`, `TaskHistory`, `TaskReview`:
    - `Task_projectId_completedAt_idx`
    - `TaskHistory_actorId_action_createdAt_idx`
    - `TaskHistory_createdAt_id_idx`
    - `TaskReview_taskId_decision_reviewedAt_idx`
- **SQL Migration ([`prisma/migrations/20261115114856_sprint6_reporting_indexes_and_activity_project/migration.sql`](file:///d:/Akatsuki%20Yui/prisma/migrations/20261115114856_sprint6_reporting_indexes_and_activity_project/migration.sql)):**
  - Thực hiện SQL backfill an toàn (kiểm tra regex UUID `^[0-9a-f]{8}-...$` và `EXISTS` trong bảng `Project` trước khi cast UUID) đối với các bản ghi `ActivityLog` cũ của `Project`, `ProjectMember`, `Sprint`, `Document`.
  - Bảo toàn toàn bộ 4 partial unique/filter index từ Sprint 2–4 (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`) và 2 trigger (`trg_task_sprint_same_project`, `trg_document_sprint_same_project`).

---

## 3. Modules, Services, Route Handlers & UI Pages

### 3.1. Shared Utilities & Sprint Enhancements
- [`src/lib/timezone.ts`](file:///d:/Akatsuki%20Yui/src/lib/timezone.ts): chuẩn hóa chuyển đổi `Asia/Ho_Chi_Minh`, ISO Monday week key, dải ngày/tuần, format hiển thị tiếng Việt (`formatHcmDateVi`, `formatHcmDateTimeVi`).
- [`src/modules/projects/project-progress.ts`](file:///d:/Akatsuki%20Yui/src/modules/projects/project-progress.ts): `computeProjectTimelineProgress` (xử lý đủ 4 trạng thái `NO_DATES`, `NOT_STARTED`, `IN_WINDOW`, `PAST_END_DATE`).
- [`src/modules/sprints/estimate-reconstruction.ts`](file:///d:/Akatsuki%20Yui/src/modules/sprints/estimate-reconstruction.ts): `normalizeEstimateHours`, `groupAndSortEstimateEvents`, `resolveTaskEstimateAt`, `resolveSprintTasksEstimatesAt` (`P0-01`).
- Cập nhật ghi `ActivityLog.projectId` và metadata baseline/planning trên các service: `src/modules/projects/project.access.ts`, `src/modules/projects/project.service.ts`, `src/modules/project-members/member.service.ts`, `src/modules/documents/document.service.ts`, `src/modules/notifications/notification-deadline.service.ts`, `src/modules/sprints/sprint.repository.ts`, `src/modules/sprints/sprint.service.ts`, `src/modules/sprints/sprint-planning.service.ts`, `src/modules/sprints/sprint-completion.service.ts`, `src/modules/sprints/sprint-analytics.service.ts`.

### 3.2. Dashboard Module (`src/modules/dashboard/*`)
- [`src/modules/dashboard/dashboard.schema.ts`](file:///d:/Akatsuki%20Yui/src/modules/dashboard/dashboard.schema.ts): `dashboardQuerySchema`.
- [`src/modules/dashboard/dashboard.service.ts`](file:///d:/Akatsuki%20Yui/src/modules/dashboard/dashboard.service.ts): `sortAndSelectDashboardProject`, `getOperationalDashboardService`.

### 3.3. Reports & Analytics Module (`src/modules/reports/*`)
- [`src/modules/reports/report.schema.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/report.schema.ts): `analyticsQuerySchema`, `memberContributionQuerySchema`, `resolveAnalyticsDateWindow`.
- [`src/modules/reports/project-analytics.repository.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/project-analytics.repository.ts) & [`project-analytics.service.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/project-analytics.service.ts): `computeProjectAnalytics`, `getProjectAnalyticsService`.
- [`src/modules/reports/member-contribution.repository.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/member-contribution.repository.ts) & [`member-contribution.service.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/member-contribution.service.ts): `computeMemberContributionReport`, `getMemberContributionReportService`.
- [`src/modules/reports/sprint-report.repository.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/sprint-report.repository.ts) & [`sprint-report.service.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/sprint-report.service.ts): `computeProjectSprintReport`, `getProjectSprintReportService`.
- [`src/modules/reports/project-reports-loader.ts`](file:///d:/Akatsuki%20Yui/src/modules/reports/project-reports-loader.ts): `loadAccessibleReportProjects`, `loadProjectReportsPageBundle`.

### 3.4. Unified Activity Module (`src/modules/activity/*`)
- [`src/modules/activity/activity.schema.ts`](file:///d:/Akatsuki%20Yui/src/modules/activity/activity.schema.ts): `activityQuerySchema`, `encodeActivityCursor`, `decodeActivityCursor`.
- [`src/modules/activity/activity.repository.ts`](file:///d:/Akatsuki%20Yui/src/modules/activity/activity.repository.ts): `activityRepository` (`resolveVisibilityScope`, `queryWorkspaceArm`, `queryTaskArm`, `compareActivityEntriesDesc`).
- [`src/modules/activity/activity.service.ts`](file:///d:/Akatsuki%20Yui/src/modules/activity/activity.service.ts): `listUnifiedActivityService`, `getActivityFilterOptionsService`.

### 3.5. API Route Handlers & UI Routes
- **REST API Route Handlers:**
  - `GET /api/v1/dashboard` ([`src/app/api/v1/dashboard/route.ts`](file:///d:/Akatsuki%20Yui/src/app/api/v1/dashboard/route.ts))
  - `GET /api/v1/reports/projects/[projectId]` ([`src/app/api/v1/reports/projects/[projectId]/route.ts`](file:///d:/Akatsuki%20Yui/src/app/api/v1/reports/projects/[projectId]/route.ts))
  - `GET /api/v1/reports/projects/[projectId]/members` ([`src/app/api/v1/reports/projects/[projectId]/members/route.ts`](file:///d:/Akatsuki%20Yui/src/app/api/v1/reports/projects/[projectId]/members/route.ts))
  - `GET /api/v1/reports/projects/[projectId]/sprints` ([`src/app/api/v1/reports/projects/[projectId]/sprints/route.ts`](file:///d:/Akatsuki%20Yui/src/app/api/v1/reports/projects/[projectId]/sprints/route.ts))
  - `GET /api/v1/activity` ([`src/app/api/v1/activity/route.ts`](file:///d:/Akatsuki%20Yui/src/app/api/v1/activity/route.ts))
- **UI Components & App Router Pages:**
  - [`src/components/layout/app-shell.tsx`](file:///d:/Akatsuki%20Yui/src/components/layout/app-shell.tsx): bổ sung liên kết điều hướng `Báo cáo & Phân tích` (`/reports`, quyền `report.read`) và `Lịch sử hoạt động` (`/activity`, quyền `activity.read`).
  - [`src/app/(dashboard)/projects/[projectId]/page.tsx`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/projects/[projectId]/page.tsx): thêm liên kết nhanh tới `/projects/[projectId]/reports` và `/activity?projectId=[projectId]`.
  - [`src/components/dashboard/operational-dashboard-client.tsx`](file:///d:/Akatsuki%20Yui/src/components/dashboard/operational-dashboard-client.tsx) + [`src/app/(dashboard)/dashboard/page.tsx`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/dashboard/page.tsx) (`/dashboard`).
  - [`src/components/reports/svg-charts.tsx`](file:///d:/Akatsuki%20Yui/src/components/reports/svg-charts.tsx) + [`src/components/reports/project-reports-client.tsx`](file:///d:/Akatsuki%20Yui/src/components/reports/project-reports-client.tsx) + [`src/app/(dashboard)/reports/page.tsx`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/reports/page.tsx) (`/reports`) + [`src/app/(dashboard)/projects/[projectId]/reports/page.tsx`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/projects/[projectId]/reports/page.tsx) (`/projects/[projectId]/reports`).
  - [`src/components/activity/activity-log-client.tsx`](file:///d:/Akatsuki%20Yui/src/components/activity/activity-log-client.tsx) + [`src/app/(dashboard)/activity/page.tsx`](file:///d:/Akatsuki%20Yui/src/app/(dashboard)/activity/page.tsx) (`/activity`).

---

## 4. Verification Summary & Test Suites

Toàn bộ các kiểm tra dưới đây được chạy trực tiếp sau khi hoàn tất mã nguồn và kiểm thử (0 lỗi, 0 warning ESLint, 0 test skipped):

| Check / Suite | Command | Result |
|---|---|---|
| No Recharts Guard | `Select-String -Path "package.json" -Pattern "recharts"` | **0 matches** (`DEC-056`) |
| Prisma Schema Format & Validate | `npx prisma format` & `npx prisma validate` | Valid (exit 0) |
| Prisma Migration Status | `npx prisma migrate status` | **6 migrations found**, database schema is up to date (exit 0) |
| Prettier Format Check (Sprint 6 files) | `npx prettier --check` *(50 file nguồn, test & README Sprint 6)* | **All matched files use Prettier code style!** (exit 0) |
| TypeScript Check | `npm run typecheck` (`tsc --noEmit`) | **Passed — 0 errors** (exit 0) |
| ESLint | `npm run lint` (`eslint .`) | **Passed — 0 errors, 0 warnings** (exit 0) |
| Full Unit & PostgreSQL Integration Suite | `npm test` (`vitest run`) | **29 test files passed (29), 165 tests passed (165), 0 skipped** (exit 0) |
| Production Build | `npm run build` (`next build`) | **Compiled cleanly — 30/30 static pages, 102 route entries** (exit 0) |

### 4.1. Sprint 6 Test Suites Added (`8 files, 34 tests`)
- [`tests/unit/sprint6-timezone.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-timezone.test.ts) (**4 tests**): chuẩn ranh giới ngày `16:59:59.999Z` vs `17:00:00.000Z` theo `Asia/Ho_Chi_Minh`, tính tuần ISO thứ Hai, giới hạn 365 ngày và tự động chuyển granularity sang tuần khi vượt quá 90 ngày.
- [`tests/unit/sprint6-activity.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-activity.test.ts) (**5 tests**): validation tham số lọc, encode/decode cursor keyset, thứ tự sắp xếp xác định `(createdAt DESC, source DESC, id DESC)`, quyền `activity.read`, và quy tắc cô lập `MEMBER` (`projectId IS NULL` và Task đồng nghiệp bị ẩn).
- [`tests/unit/sprint6-sprint-analytics.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-sprint-analytics.test.ts) (**5 tests**): tái dựng `P0-01` qua chuỗi diff `INFO_UPDATED`, đánh dấu `INCOMPLETE_HISTORY` khi thiếu lịch sử diff, sửa lỗi Burndown không tụt sai về `0` ở ngày đóng Sprint + miễn nhiễm chỉnh sửa `estimateHours` sau đóng Sprint, và báo cáo 6 nhóm chỉ số `DEC-058`.
- [`tests/unit/sprint6-project-analytics.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-project-analytics.test.ts) (**5 tests**): kiểm tra tổng hợp 6 biểu đồ Advanced Analytics, tách Project Timeline Progress vs Task Work Progress, độ phủ `estimateHours`, `Priority` `CRITICAL`, `granularity = "week"` khi > 90 ngày và đọc Project `ARCHIVED`.
- [`tests/unit/sprint6-member-contribution.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-member-contribution.test.ts) (**2 tests**): kiểm tra báo cáo phi cộng dồn (`Sole` vs `Co-Assigned` + `Project Totals`), `P0-02` deduplicate theo `DISTINCT taskId` tách khỏi episodes, `P1-03` dịch chuyển bài của cựu thành viên sang lịch sử, bộ lọc `includeRemoved`, và giới hạn `SELF_ONLY` cho `MEMBER`.
- [`tests/unit/sprint6-dashboard.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-dashboard.test.ts) (**3 tests**): thứ tự chọn Project ưu tiên `ACTIVE -> CREATED -> ARCHIVED`, Read-only banner cho `ARCHIVED`, và ẩn/hiện widget theo permission không dùng `dashboard.read`.
- [`tests/unit/sprint6-api-routes.test.ts`](file:///d:/Akatsuki%20Yui/tests/unit/sprint6-api-routes.test.ts) (**3 tests**): HTTP contract `200`/`400`/`401`/`403` cho `/api/v1/dashboard`, `/api/v1/activity`, `/api/v1/reports/projects/[projectId]`, `/members`, và `/sprints`.
- [`tests/integration/sprint6-db.test.ts`](file:///d:/Akatsuki%20Yui/tests/integration/sprint6-db.test.ts) (**7 tests**): kiểm thử trực tiếp trên PostgreSQL 18 về bảo toàn 4 partial index + 2 trigger cũ và 7 index Sprint 6 mới; SQL backfill an toàn với UUID lỗi/mồ côi; rollover hoàn thành Sprint + Burndown không tụt về `0` + miễn nhiễm sửa `estimateHours` sau khi đóng Sprint; đối chiếu ranh giới `UTC+7` (`16:59:59.999Z` vs `17:00:00.000Z`) & gộp tuần ISO trong SQL `AT TIME ZONE`; cựu thành viên (`LEFT_PROJECT`), `P0-02`, `P1-03`, `SELF_ONLY`; cursor pagination đồng thời với bản ghi chèn giữa trang & cô lập `MEMBER`; và khả năng đọc toàn bộ phân hệ trên Project `ARCHIVED`.

### 4.2. Regression Baseline Verified (Sprint 1–5 — `21 files, 131 tests`)
- Toàn bộ 21 file test nền tảng của Sprint 1–5 (bao gồm unit tests, API route contracts, và các PostgreSQL integration test `sprint1-db.test.ts` đến `sprint5-db.test.ts`) đều chạy và pass 100%.

---

## 5. Documentation Synchronization

Đã đồng bộ các tài liệu dự án trong thư mục cục bộ theo thực tế triển khai Sprint 6:
- [`README.md`](file:///d:/Akatsuki%20Yui/README.md): cập nhật Tech Stack (Pure SVG Charts, Resend + `CRON_SECRET`) và bổ sung tóm tắt Sprint 3–6.
- [`markdown/02-Requirements/Business-Rules-and-Workflows.md`](file:///d:/Akatsuki%20Yui/markdown/02-Requirements/Business-Rules-and-Workflows.md): đồng bộ mục `3.11.5` và chốt `TBD-014`, `TBD-029`, `TBD-030`.
- [`markdown/02-Requirements/Software-Requirements-Specification.md`](file:///d:/Akatsuki%20Yui/markdown/02-Requirements/Software-Requirements-Specification.md): đồng bộ `FR-DASH-001`–`005`, `FR-ACT-001`–`002`, chốt `OI-013` và lịch sử phiên bản `1.3`.
- [`markdown/02-Requirements/Use-Case-Specification.md`](file:///d:/Akatsuki%20Yui/markdown/02-Requirements/Use-Case-Specification.md): đồng bộ `UC-030`, `UC-031`, `UC-032`, chốt `TBD-UC-017`, `TBD-UC-018` và lịch sử phiên bản `1.2`.
- [`markdown/03-Architecture-and-Design/UI-UX-Design.md`](file:///d:/Akatsuki%20Yui/markdown/03-Architecture-and-Design/UI-UX-Design.md): chuyển Recommended Charting Stack sang Pure React + Accessible SVG + Tailwind (`DEC-056`).
- [`markdown/DOCUMENT-INVENTORY.md`](file:///d:/Akatsuki%20Yui/markdown/DOCUMENT-INVENTORY.md): bổ sung ghi chú đồng bộ Sprint 6 (Update V2.2).

---

## 6. Git Working Tree Status

- Nhánh làm việc hiện tại: `feat/sprint5-document-library-notifications` (nối tiếp commit `3ce5414`).
- Toàn bộ thay đổi nguồn, migration Prisma, bài test unit/integration và `README.md` của Sprint 6 hiện đang ở trạng thái **chưa commit** trong Git working tree để người dùng review trước khi tạo commit/push riêng.
- Các thư mục tài liệu nội bộ (`docs/`, `markdown/`, `report/`) nằm trong `.gitignore` theo quy ước dự án nên không xuất hiện trong `git status`.
