# SPRINT 4 IMPLEMENTATION PLAN — SPRINT MANAGEMENT, PRODUCT BACKLOG & KANBAN BOARD

**Dự án:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 4 — Sprint Management, Product Backlog & Kanban Board  
**Giai đoạn:** Implementation Planning Only *(Chưa chỉnh sửa source code, Prisma schema, migration, API hoặc UI)*  
**Kiến trúc:** Modular Monolith — Next.js 16 App Router + React 19 + TypeScript 5.9 + PostgreSQL 18 + Prisma 6.19.3 + Auth.js v5  
**Baseline thực tế:** `feat/sprint3-task-management` (`ed883a4`), `AGENT.md`, `markdown/*`, `report/SPRINT-3-IMPLEMENTATION-PLAN.md`, `report/SPRINT-3-IMPLEMENTATION-REPORT.md`, mã nguồn Sprint 1–3 đã kiểm tra trực tiếp  
**Ngày lập:** 2026-11-15  

---

## 1. Objective & Scope

### 1.1. Mục tiêu Sprint 4

Xây dựng hoàn chỉnh phân hệ **Sprint Management, Product Backlog, Sprint Planning, Sprint Completion, Kanban Board và Sprint Progress / Burndown** trên nền Modular Monolith đã hoàn thiện ở Sprint 1–3, tuân thủ tuyệt đối nguyên tắc:

1. **Một nguồn dữ liệu Task duy nhất:** Không nhân bản bản ghi `Task`, không tạo bảng Kanban Task hay Backlog Task tách biệt; Backlog là góc nhìn các `Task` có `sprintId IS NULL`, còn Sprint là tập các `Task` gắn `sprintId = sprint.id`.
2. **Tái sử dụng trọn vẹn Task Workflow & Authorization của Sprint 3:** Mọi thao tác chuyển trạng thái trên Kanban (`TODO → IN_PROGRESS → REVIEW → DONE` và `REJECT: REVIEW → IN_PROGRESS`) đi qua `task-workflow.service.ts` (`updateTaskStatusService`, `submitTaskForReviewService`, `approveTaskReviewService`, `rejectTaskReviewService`), giữ nguyên khóa trường `DEC-015`, lý do Review bắt buộc `REVIEW_REASON_REQUIRED`, cổng chặn `DEC-005` (`TASK_DEPENDENCY_NOT_COMPLETED`) và lịch sử `TaskHistory` + `TaskReview`.
3. **Bảo vệ toàn vẹn dữ liệu ở cả Service Layer và PostgreSQL:** Một `Task` chỉ thuộc tối đa một `Sprint`; một `Project` được phép có nhiều `ACTIVE` Sprints (`DEC-006`); không cho phép gắn `Task` của Project A vào `Sprint` của Project B; khóa toàn bộ thao tác lập kế hoạch / cập nhật / kết thúc Sprint khi `Project.status = ARCHIVED` (`BR-PROJ-008`).
4. **Kết thúc Sprint an toàn, có kiểm soát (`DEC-007`, `UC-035`):** Tuyệt đối không tự động đẩy Task chưa `DONE` về Backlog hoặc Sprint khác; bắt buộc Leader ra quyết định tường minh cho từng Task chưa hoàn thành trong cùng một PostgreSQL Transaction.

### 1.2. Trong phạm vi (In Scope)

| Module | Hạng mục triển khai chi tiết | Tham chiếu nguồn |
|---|---|---|
| **Module 1 — Sprint Core Management** | Create Sprint (`PLANNED`), List Sprints theo Project, Sprint Detail, Update Sprint (`name`, `goal`, `startDate`, `endDate`), Activate Sprint, Complete Sprint, Sprint Status Lifecycle & History (`ActivityLog` + `TaskHistory`), Sprint Cancellation *(chỉ `PLANNED` Sprint)* | `UC-020`, `UC-023`, `FR-SPRINT-001`, `FR-SPRINT-002`, `Database-Design.md §8` |
| **Module 2 — Product Backlog** | Liệt kê Backlog Tasks (`Task.sprintId IS NULL`), Search (`title`, `description`, `#code`), Filter (`priority`, `assigneeId`, `unassignedOnly`, `overdueOnly`, `deadlineFrom`/`deadlineTo`), xem Task Detail, chọn 1 hoặc nhiều Backlog Tasks để đưa vào Sprint Planning | `UC-021`, `FR-SPRINT-003`, `Database-Design.md §8.2`, `UI-UX-Design.md §6.7.4` |
| **Module 3 — Sprint Planning** | Đưa Backlog Tasks vào Sprint (`PLANNED` hoặc `ACTIVE`), gỡ Task khỏi Sprint về Backlog, chuyển Task giữa các Sprint `PLANNED \| ACTIVE` cùng Project *(cấm chuyển Task `DONE`; cho phép chuyển Task `REVIEW` kèm cảnh báo)*, kiểm tra quyền & trạng thái, xử lý tranh chấp đồng thời bằng Transaction + Lock | `UC-022`, `BR-SPR-004`–`BR-SPR-010`, `FR-SPRINT-004` |
| **Module 4 — Kanban Board** | Kanban 4 cột (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`), chuyển đổi Project-wide Board vs Sprint-filtered Board, lọc đa tiêu chí (Search, Sprint, Assignee, Priority, Deadline), thao tác chuyển cột an toàn qua Sprint 3 Workflow Services & Review Modals | `UC-024`, `UC-025`, `BR-KAN-001`–`BR-KAN-006`, `FR-KANBAN-001`–`004` |
| **Module 5 — Sprint Completion** | Màn hình/Modal Complete Sprint liệt kê các Task chưa `DONE`, bắt buộc Leader chọn disposition từng Task, giữ nguyên `sprintId` lịch sử của các Task đã `DONE`, cập nhật `Sprint.status = COMPLETED` và ghi lịch sử nguyên tử | `UC-035`, `DEC-007`, `BR-SPR-011`, `FR-SPRINT-005`, `API-Specification.md §6` |
| **Module 6 — Sprint Progress & Dashboard Metrics** | Thống kê tiến độ theo **Task Count (`DONE / Total`)**, số Task hoàn thành / còn lại / phân bố 4 trạng thái / quá hạn, tổng hợp `Estimate Hours` thực tế, và **Sprint Burndown Chart** theo Estimate Hours với thông báo thiếu dữ liệu nếu Sprint chưa có Estimate (`DEC-017`) | `DEC-017`, `FR-DASH-002`, `FR-DASH-003`, `Business-Rules §3.11`, `UI-UX-Design.md §6.7.3` |

### 1.3. Ngoài phạm vi (Out of Scope)

- **Document Library (`Google Drive URL`, `Document.sprintId`)** và **Notification Center / Resend Email Delivery** *(Sprint 5)*.
- **Workspace Dashboard tổng hợp nhiều Project, Velocity liên Sprint, Báo cáo đóng góp thành viên (`FR-DASH-004`, `FR-DASH-005`)** *(Sprint 6)*.
- **Xếp hạng cơ học thành viên / KPI Leaderboard** *(cấm theo `Business-Rules §3.11.5`)*.
- **Xóa cứng Sprint (`DELETE /sprints/:sprintId`)**, **Story Points**, **Subtasks**, **Custom Kanban Columns** ngoài `TODO / IN_PROGRESS / REVIEW / DONE`.
- **Thay đổi cơ chế Authentication, User Management, Role Matrix hiện hữu** hoặc **sửa nghiệp vụ cốt lõi Sprint 1–3**.

---

## 2. Existing System Baseline

### 2.1. Hiện trạng Repository đã xác minh trực tiếp

| Hạng mục | Trạng thái xác minh thực tế |
|---|---|
| **Git Branch & Commit** | Branch `feat/sprint3-task-management` tại commit `ed883a4` (`feat(sprint-3): implement task management, assignment, dependency DAG, review workflow, and history`); working tree sạch. |
| **Runtime & Packages (`package.json`)** | `next` `^16.4.6`, `react` `^19.3.1`, `typescript` `^5.9.0`, `prisma` & `@prisma/client` `6.19.3`, `next-auth` `5.0.0-beta.32`, `zod` `^4.6.7`, `react-hook-form` `^7.92.0`, `@radix-ui/react-dialog` `^1.1.15`, `@radix-ui/react-alert-dialog` `^1.1.15`, `@radix-ui/react-select` `^2.2.6`, `lucide-react` `^1.73.0`, `sonner` `^2.0.8`, `vitest` `^5.1.0`. **Lưu ý quan trọng:** hiện tại `package.json` **chưa cài `recharts`** và **chưa cài `@dnd-kit/*`**. |
| **Database & Migrations (`prisma/`)** | PostgreSQL 18 với 3 migration đã áp dụng: `20261114181931_init_sprint1`, `20261114193729_sprint2_projects_and_members`, `20261115063614_sprint3_task_management`. Các model hiện có: `User`, `Role`, `Permission`, `UserRole`, `RolePermission`, `ActivityLog`, `AuditLog`, `ProjectTemplate`, `Project`, `ProjectMember`, `Task`, `TaskAssignee`, `TaskDependency`, `TaskReview`, `TaskHistory`. |
| **Permissions đã seed sẵn (`src/modules/authorization/constants.ts` & `prisma/seed.ts`)** | `PERMISSIONS.SPRINT_MANAGE = "sprint.manage"` (đã gán mặc định cho `ADMIN`, `LEADER`) và `PERMISSIONS.SPRINT_READ = "sprint.read"` (đã gán mặc định cho `ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER`) đã tồn tại sẵn trong code và database seed. |
| **Test Baseline (`report/SPRINT-3-IMPLEMENTATION-REPORT.md` & `tests/`)** | 13 file test (unit + API contract + PostgreSQL integration `sprint1-db.test.ts`, `sprint2-db.test.ts`, `sprint3-db.test.ts`), tổng 80 test pass, `next build` ra 52 app/API routes. |

### 2.2. Các thành phần Sprint 1–3 được tái sử dụng trực tiếp trong Sprint 4

| Thành phần hiện có (`src/...`) | Chức năng tái sử dụng cho Sprint 4 | Ghi chú tích hợp |
|---|---|---|
| `src/modules/authorization/constants.ts`, `policy.service.ts`, `require-auth.ts` | `assertPermission`, `hasPermission`, `requireActiveUser`, `requirePermissionOrRedirect`, `PERMISSIONS.SPRINT_MANAGE`, `PERMISSIONS.SPRINT_READ`, `PERMISSIONS.TASK_READ` | Không cần thêm permission mới vào matrix mặc định (`§8`). |
| `src/modules/projects/project.access.ts` | `parseProjectId`, `isWorkspaceAdmin`, `assertProjectReadAccess`, `assertProjectLeaderAccess` | Đã kiểm tra tồn tại Project + thành viên active (`leftAt IS NULL`) + `ADMIN` workspace scope. |
| `src/modules/tasks/task.access.ts` | `parseTaskId`, `assertProjectNotArchivedForTaskMutation`, `isProjectLeaderOrAdmin`, `assertTaskReadAccess`, `assertTaskLeaderAccess`, `assertTaskProgressOrReviewActorAccess` | Có sẵn lock `PROJECT_ARCHIVED` (409) và kiểm tra quyền Member/Leader trên Task. |
| `src/modules/tasks/task.schema.ts` | `formatTaskCode`, `taskListQuerySchema`, `taskPrioritySchema`, `taskStatusSchema`, `createTaskSchema`, `updateTaskSchema` | Mở rộng `taskListQuerySchema` thêm `sprintId`, `backlogOnly`, `deadlineFrom`, `deadlineTo` cho Backlog & Kanban (`§6.2`). |
| `src/modules/tasks/task.repository.ts` | `taskRepository.findManyByProjectPaginated`, `findDetailById`, `findSummaryById`, `TaskSummaryDTO`, `TaskDetailDTO` | Thêm trường `sprint` tóm tắt vào DTO + điều kiện lọc `sprintId` / `backlogOnly` / deadline range trong `where`. **Quan trọng:** phát hiện Sprint 3 hiện chỉ có `overdueOnly` boolean, chưa có bộ lọc khoảng ngày `deadlineFrom`/`deadlineTo`. |
| `src/modules/tasks/task-workflow.service.ts` | `updateTaskStatusService`, `submitTaskForReviewService`, `approveTaskReviewService`, `rejectTaskReviewService` | Kanban board ủy quyền 100% logic chuyển cột + Atomic CAS + Dependency gate (`DEC-005`) + `TaskReview` cho service này. |
| `src/modules/tasks/task-history.repository.ts` | `appendTaskHistory`, `appendManyTaskHistories`, `findTaskHistoryPaginated` | Ghi nhận sự kiện thay đổi Sprint (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`) vào timeline chung của Task. |
| `src/modules/tasks/task.actions.ts` | `updateTaskStatusAction`, `submitTaskForReviewAction`, `approveTaskReviewAction`, `rejectTaskReviewAction`, `revalidateTaskPaths` | Kanban gọi trực tiếp các action này; chỉ cần bổ sung `revalidatePath` cho các route Sprint/Backlog/Kanban mới. |
| `src/modules/project-members/task-assignment-guard.ts` | `taskAssignmentGuard.assertNoActiveProjectTasks` | Không bị ảnh hưởng vì Sprint/Backlog không thay đổi `TaskAssignee` hay điều kiện `DONE`. |
| `src/lib/errors.ts`, `src/lib/api-response.ts`, `src/lib/request.ts`, `src/types/api.ts` | `AppError`, `badRequestError`, `conflictError`, `apiSuccess`, `apiError`, `parseJsonBody`, `toActionError` | Mở rộng `ErrorCode` union trong `src/types/api.ts` với error code Sprint 4. |
| `src/components/shared/status-badge.tsx`, `src/components/tasks/task-review-modal.tsx`, `src/components/layout/app-shell.tsx` | `TaskStatusBadge`, `TaskPriorityBadge`, `TaskReviewModal`, Sidebar Navigation & App Layout | Bổ sung `SprintStatusBadge`, tích hợp `TaskReviewModal` trực tiếp vào Kanban Board. |

---

## 3. Confirmed Business Rules

Bảng dưới đây tổng hợp các quy tắc **đã được chốt chắc chắn** từ `DECISION-LOG.md`, `Business-Rules-and-Workflows.md`, `Use-Case-Specification.md`, `SRS`, `Database-Design.md` và yêu cầu Product Owner Sprint 4:

| Mã quy tắc / Quyết định | Nội dung đã xác nhận (Bắt buộc giữ nguyên) | Nơi thực thi |
|---|---|---|
| **DEC-006 / BR-SPR-010** | Một Project được phép có **nhiều `ACTIVE` Sprints cùng lúc** (ví dụ nhóm chia song song Frontend Sprint và Backend Sprint). Tuyệt đối không đặt unique index giới hạn 1 Active Sprint per Project. | `Sprint` model + `activateSprintService` |
| **BR-SPR-007** | Một `Task` chỉ thuộc **tối đa một `Sprint`** tại một thời điểm. | `Task.sprintId` nullable FK |
| **BR-SPR-008 / DB §8.2** | `Task` có `sprintId IS NULL` thuộc **Project Backlog**. Không tạo bảng Backlog hay nhân bản `Task`. | `Task.sprintId` + `listBacklogTasksService` |
| **BR-SPR-009 / UC-022** | Sprint Planning gán/di chuyển chính bản ghi `Task` hiện có (`Task.sprintId`), không tạo bản ghi mới. | `sprint-planning.service.ts` |
| **BR-SPR-001, 002, 003** | Mỗi Sprint thuộc đúng 1 Project; phải có `name` và khoảng thời gian (`startDate`, `endDate`); không cho `endDate < startDate`. | `sprint.schema.ts` + DB `CHECK` |
| **BR-SPR-004, 005** | Chỉ đưa Task cùng `projectId` vào Sprint; phải từ chối hoặc xử lý theo luật rõ ràng nếu Task đang thuộc Sprint khác. | `sprint-planning.service.ts` + DB trigger |
| **DEC-007 / BR-SPR-011 / UC-035** | Khi kết thúc (`Complete`) Sprint, hệ thống **tuyệt đối không tự động di chuyển Task chưa `DONE`**; Leader phải quyết định hướng xử lý từng Task chưa hoàn thành, lưu lịch sử thay đổi và cập nhật Sprint sang `COMPLETED` trong cùng transaction. Các Task đã `DONE` giữ nguyên liên kết `sprintId` lịch sử với Sprint đã hoàn thành. | `sprint-completion.service.ts` |
| **BR-PROJ-008 / DEC-024** | Project ở trạng thái `ARCHIVED` khóa toàn bộ thao tác tạo, sửa, kích hoạt, hủy, hoàn thành Sprint và mọi thao tác Sprint Planning / Kanban transition (`409 PROJECT_ARCHIVED`). | `sprint.access.ts` + `task.access.ts` |
| **BR-KAN-001..006 / UC-024..025** | Kanban có 4 cột cố định: `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`; hỗ trợ Project-wide và Sprint-filtered view; hỗ trợ Search + Filter (Sprint, Assignee, Priority, Deadline); không được bypass Sprint 3 Workflow (`DEC-015`, `DEC-005`, `REVIEW_REASON_REQUIRED`). | `kanban.service.ts` + `task-workflow.service.ts` |
| **DEC-017 / §3.11** | Tiến độ Project/Sprint tính theo **tỷ lệ số Task (`DONE / Total Tasks`)**. **Burndown Chart** tính theo **Estimate Hours**; nếu Sprint chưa có Task nào có `estimateHours`, hiển thị thông báo thiếu dữ liệu Estimate (không dựng số liệu giả). Tuyệt đối không tạo bảng xếp hạng đánh giá thành viên máy móc. | `sprint-analytics.service.ts` + Sprint Detail UI |
| **DEC-022** | Sự kiện gán/gỡ/chuyển Sprint của từng Task ghi vào **`TaskHistory`**; sự kiện vòng đời bản thân `Sprint` (Create, Update, Activate, Complete, Cancel) ghi vào **`ActivityLog`** (và `AuditLog` đối với chuyển trạng thái vòng đời quan trọng), không ghi trùng Task event sang `AuditLog`. | `taskHistoryRepository` + `tx.activityLog` |

| **DEC-026..033 (PO Confirmed)** | **Sprint 4 PO Final Decisions:** (1) `ACTIVE` Project mới được Activate Sprint; cho phép Activate trước `startDate`; Cancel chỉ áp dụng cho `PLANNED`; `ACTIVE` Sprint khóa `startDate`, sửa được `name/goal/endDate`; `COMPLETED`/`CANCELLED` read-only hoàn toàn. (2) Task mới tạo luôn vào Backlog (`sprintId = NULL`). (3) Chuyển trực tiếp giữa Sprint `PLANNED\|ACTIVE` hợp lệ; chuyển Task `REVIEW` có cảnh báo; cấm chuyển Task `DONE`. (4) Complete Sprint **không có `KEEP_IN_SPRINT`**, chỉ còn `MOVE_TO_BACKLOG` và `MOVE_TO_SPRINT`; Sprint `COMPLETED` không được còn Task chưa `DONE`. (5) Kanban dùng Native HTML5 DnD + Action Buttons (không cài `@dnd-kit`); Burndown dùng **SVG thuần** (không cài Recharts), múi giờ `Asia/Ho_Chi_Minh`. | Toàn bộ Sprint 4 Services, API & UI |

---

## 4. Resolved Product Owner Decisions *(Đã chốt — Không còn Open Questions)*

Toàn bộ câu hỏi mở (`OQ-4.01`..`OQ-4.12`) đã được Product Owner xác nhận tại `markdown/DECISION-LOG.md` (`DEC-026`–`DEC-033`) và loại bỏ các lựa chọn bị bác bỏ:

| ID | Chủ đề | Quyết định cuối cùng đã chốt | Ghi chú kỹ thuật thực thi |
|---|---|---|---|
| **OQ-4.01** (`DEC-026`, `DEC-028`) | **Sprint Lifecycle & Project `ACTIVE` Gate** | Giữ 4 trạng thái `PLANNED`, `ACTIVE`, `COMPLETED`, `CANCELLED`. Cho phép Create/Plan khi Project `CREATED` hoặc `ACTIVE` (khóa khi `ARCHIVED`), nhưng **chỉ Project `ACTIVE` mới được Activate Sprint**. **Cancel chỉ áp dụng cho Sprint `PLANNED`** (`ACTIVE` phải dùng Complete Sprint). Task chưa `DONE` thuộc Sprint `PLANNED` bị Cancel được trả về Backlog (`sprintId = NULL`) kèm `TaskHistory` (`SPRINT_REMOVED`). | Enum `SprintStatus`; `POST /cancel` chỉ chấp nhận `PLANNED`. |
| **OQ-4.02** (`DEC-026`) | **Overlapping Sprint Date Ranges** | Cho phép trùng/giao khoảng ngày giữa các Sprint; UI hiển thị cảnh báo non-blocking (`meta.overlappingSprints`), không chặn tạo/sửa. | Không có exclusion constraint ngày ở DB. |
| **OQ-4.03** (`DEC-026`) | **Activate Before `startDate`** | Cho phép Activate Sprint `PLANNED` trước `startDate`, giữ nguyên `startDate` kế hoạch làm mốc Sprint & Burndown; UI dialog nhắc nhẹ nếu kích hoạt sớm. | Không tự đổi `startDate` khi Activate; không auto-complete/auto-activate theo ngày. |
| **OQ-4.04** (`DEC-027`) | **Edit Sprint Rules** | `PLANNED`: sửa `name`, `goal`, `startDate`, `endDate`. `ACTIVE`: **khóa `startDate`**, được sửa `name`, `goal`, `endDate` (`endDate >= startDate`). `COMPLETED` / `CANCELLED`: khóa read-only hoàn toàn, không thể sửa hay kích hoạt lại. | Kiểm tra `sprint.status` trong `updateSprintService` + optimistic lock `expectedUpdatedAt`. |
| **OQ-4.05** (`DEC-030`) | **Direct Sprint-to-Sprint Move** | Cho phép chuyển thẳng Task chưa `DONE` giữa 2 Sprint (`PLANNED \| ACTIVE`) cùng Project, ghi `TaskHistory` (`SPRINT_MOVED`). | Endpoint `POST /api/v1/sprints/[sprintId]/tasks/[taskId]/move`. |
| **OQ-4.06** (`DEC-030`) | **Move `REVIEW` Tasks** | Cho phép Leader chuyển Task đang ở `REVIEW` về Backlog hoặc sang Sprint khác hợp lệ, giữ nguyên trạng thái `REVIEW`; UI bắt buộc hiển thị cảnh báo `"Task đang chờ Review"`. | Flag cảnh báo trên Planning / Complete Sprint UI. |
| **OQ-4.07** (`DEC-031`) | **Complete Sprint Dispositions** | **Loại bỏ hoàn toàn `KEEP_IN_SPRINT`.** Chỉ hỗ trợ **`MOVE_TO_BACKLOG`** và **`MOVE_TO_SPRINT`** (Sprint đích cùng Project đang `PLANNED \| ACTIVE`). Mọi Sprint `COMPLETED` bắt buộc có `0` Task chưa `DONE` còn sót lại. | `completeSprintService` từ chối mọi action ngoài `MOVE_TO_BACKLOG` / `MOVE_TO_SPRINT`. |
| **OQ-4.08** (`DEC-030`, `DEC-031`) | **Lock `DONE` Tasks** | Không được phép di chuyển Task đã `DONE` (cấm thêm vào Sprint, cấm gỡ về Backlog, cấm chuyển Sprint khác kể cả khi Complete Sprint). Task `DONE` giữ nguyên `sprintId` lịch sử. | Reject `409 TASK_ALREADY_COMPLETED` / `INVALID_STATUS_TRANSITION`. |
| **OQ-4.09** (`DEC-029`) | **Task Creation Location & Planning Actors** | **Không tạo Task trực tiếp vào Sprint trong Sprint 4:** form tạo Task luôn tạo trong Product Backlog (`sprintId = NULL`). Chỉ `ADMIN` / Project `LEADER` (`sprint.manage`) được thực hiện Sprint Planning. Task chưa có Assignee vẫn được đưa vào Sprint (`DEC-011`). | Giữ nguyên `createTaskSchema` không nhận `sprintId` ở Sprint 4. |
| **OQ-4.10** (`DEC-029`) | **Cross-Sprint Dependency** | `TaskDependency` giữa các Task khác Sprint hoặc Backlog đều hợp lệ (`DEC-005`). UI Backlog, Planning, Kanban và Completion Modal hiển thị cảnh báo `Blocked by N` rõ ràng. | Tái sử dụng `blockedByCount` từ `taskRepository`. |
| **OQ-4.11** (`DEC-032`) | **Kanban Interaction (No External DnD Lib)** | Desktop: **Native HTML5 Drag & Drop + Action Buttons**. Mobile/Keyboard: **Action Buttons/Menu** là phương thức chính. **Không cài `@dnd-kit`**. Kéo/bấm chuyển trạng thái vẫn gọi Sprint 3 Workflow Services & mở `TaskReviewModal` cho Review/Approve/Reject. | Zero package mới cho DnD. |
| **OQ-4.12** (`DEC-033`) | **Burndown Rendering & Timezone** | Vẽ biểu đồ bằng **SVG thuần** (không cài `recharts` trong Sprint 4). Chuẩn hóa toàn bộ ngày lịch Sprint & ngày thực tế Burndown theo múi giờ **`Asia/Ho_Chi_Minh` (`+07:00`)**. Tái dựng từ `Task` + `TaskHistory` và hiển thị rõ giới hạn dữ liệu khi thiếu Estimate hoặc thay đổi phạm vi/estimate. | Zero package mới cho Chart. |

---

## 5. Database Design

### 5.1. Đánh giá Schema hiện tại (`prisma/schema.prisma`)

Hiện trạng `Task` (lines 228–256) đã có `projectId`, `status`, `priority`, `deadline`, `estimateHours`, `completedAt`, các quan hệ `assignees`, `dependencies`, `dependents`, `reviews`, `history`, nhưng **chưa có** cột `sprintId` và chưa có model `Sprint`.  
`Project` (lines 126–170) và `User` (lines 12–48) sẽ nhận quan hệ ngược tới `Sprint`.  
`TaskHistoryAction` (lines 214–226) hiện có 11 giá trị và cho phép mở rộng an toàn bằng `ALTER TYPE ... ADD VALUE`.

### 5.2. Đề xuất thay đổi Prisma Schema (Chỉ thiết kế — chưa sửa file)

#### A. Enum mới `SprintStatus`
*(Tham chiếu `Database-Design.md §8`, `OQ-4.01`)*

```prisma
enum SprintStatus {
  PLANNED
  ACTIVE
  COMPLETED
  CANCELLED // Lưu ý: chỉ mở luồng API/UI chuyển sang CANCELLED nếu PO chốt giữ ở OQ-4.01
}
```

#### B. Mở rộng Enum `TaskHistoryAction`

```prisma
enum TaskHistoryAction {
  CREATED
  INFO_UPDATED
  PROGRESS_UPDATED
  ASSIGNEE_ADDED
  ASSIGNEE_REMOVED
  STATUS_CHANGED
  REVIEW_SUBMITTED
  REVIEW_APPROVED
  REVIEW_REJECTED
  DEPENDENCY_ADDED
  DEPENDENCY_REMOVED
  // --- Bổ sung Sprint 4 ---
  SPRINT_ASSIGNED   // Backlog (null) -> Sprint
  SPRINT_REMOVED    // Sprint -> Backlog (null), bao gồm cả MOVE_TO_BACKLOG khi Complete Sprint
  SPRINT_MOVED      // Sprint A -> Sprint B (bao gồm Planning & MOVE_TO_SPRINT khi Complete Sprint)
}
```

#### C. Model mới `Sprint`

```prisma
model Sprint {
  id          String       @id @default(uuid()) @db.Uuid
  projectId   String       @db.Uuid
  project     Project      @relation(fields: [projectId], references: [id], onDelete: Cascade)
  name        String       @db.VarChar(150)
  goal        String?      @db.Text
  startDate   DateTime     @db.Date
  endDate     DateTime     @db.Date
  status      SprintStatus @default(PLANNED)
  activatedAt DateTime?
  completedAt DateTime?
  cancelledAt DateTime?
  createdById String       @db.Uuid
  createdBy   User         @relation("SprintCreator", fields: [createdById], references: [id], onDelete: Restrict)
  tasks       Task[]
  createdAt   DateTime     @default(now())
  updatedAt   DateTime     @updatedAt

  @@unique([projectId, id]) // Phục vụ tra cứu định danh theo Project & sẵn sàng cho FK tổ hợp nếu cần
  @@index([projectId, status])
  @@index([projectId, startDate, endDate])
  @@index([createdById])
}
```

> **Ghi chú kỹ thuật về `@db.Date` vs `DateTime`:** Trong Sprint 2 & 3, `Project.startDate/endDate` và `Task.startDate/deadline` đang dùng `DateTime` (`TIMESTAMP(3)`). Dùng `@db.Date` cho `Sprint.startDate` / `Sprint.endDate` khớp `Database-Design.md §8` (`DATE`) và loại bỏ lệch múi giờ cho lịch trình Sprint theo ngày (`YYYY-MM-DD`). Nếu muốn đồng bộ 100% kiểu `DateTime` với `Project`/`Task` để đơn giản serializer, vẫn giữ validation chuẩn `YYYY-MM-DD` khi parse ở Zod (`z.coerce.date()` chuẩn hóa UTC 00:00:00Z). Đề xuất `@db.Date` vì Burndown & Sprint Date dùng lịch ngày.

#### D. Cập nhật Model `Task`, `Project` và `User`

Trên `Project`:
```prisma
  sprints Sprint[]
```

Trên `User`:
```prisma
  createdSprints Sprint[] @relation("SprintCreator")
```

Trên `Task`:
```prisma
  sprintId String? @db.Uuid
  sprint   Sprint? @relation(fields: [sprintId], references: [id], onDelete: SetNull)
```

Kèm các index bổ sung trên `Task`:
```prisma
  @@index([projectId, sprintId, status])
  @@index([sprintId, status])
```
Và **PostgreSQL Partial Index** trong custom migration SQL để tăng tốc truy vấn Backlog (`sprintId IS NULL`):
```sql
CREATE INDEX "Task_projectId_backlog_deadline_idx"
  ON "Task"("projectId", "deadline")
  WHERE "sprintId" IS NULL;
```

### 5.3. Phân tích chuyên sâu: Ràng buộc toàn vẹn cùng Project (`Task.projectId = Sprint.projectId`)

Một `Task` tuyệt đối không được gắn vào `Sprint` thuộc một `Project` khác. Khi đánh giá cơ chế bảo vệ ở tầng PostgreSQL + Prisma 6.19.3, có 2 vấn đề kỹ thuật thực tế cần cân nhắc:

1. **Hạn chế của Composite Foreign Key thuần trong Prisma Schema + Migration Diff:**
   - Nếu viết trên `Task`: `@relation(fields: [projectId, sprintId], references: [projectId, id], onDelete: SetNull)`, **PostgreSQL + Prisma gặp 2 trở ngại:**
     - `Task.projectId` là `NOT NULL`, còn `Task.sprintId` là `NULL` (vì Backlog Task có `sprintId = NULL`). Prisma 6 yêu cầu các field trong composite relation nullable đồng nhất hoặc khi render SQL `ON DELETE SET NULL` (không có danh sách cột `"sprintId"`), PostgreSQL sẽ **báo lỗi runtime** nếu Sprint bị xóa vì PostgreSQL cố set cả `"projectId"` thành `NULL`.
     - Ngay cả khi viết tay `ALTER TABLE "Task" ADD CONSTRAINT "Task_project_sprint_fkey" FOREIGN KEY ("projectId", "sprintId") REFERENCES "Sprint"("projectId", "id") MATCH SIMPLE ON DELETE SET NULL ("sprintId")` trong `migration.sql`, **Prisma Migrate diff engine** ở các sprint sau (Sprint 5 thêm `Document`) có thể phát hiện FK này không tồn tại trong `schema.prisma` và tự sinh lệnh `DROP CONSTRAINT "Task_project_sprint_fkey"`.
2. **Giải pháp kiến trúc được khuyến nghị (Database Trigger + Single-column Prisma FK + Service Transaction Lock):**
   - **Tầng Prisma:** Dùng single-column nullable FK `sprintId -> Sprint.id` với `onDelete: SetNull` (an toàn tuyệt đối, không vướng lỗi schema validation và không gây drift ở Sprint 5/6).
   - **Tầng PostgreSQL Migration (`--create-only`):** Tạo hàm & trigger `BEFORE INSERT OR UPDATE OF "projectId", "sprintId" ON "Task"`:
     ```sql
     CREATE OR REPLACE FUNCTION check_task_sprint_same_project()
     RETURNS TRIGGER AS $$
     BEGIN
       IF NEW."sprintId" IS NOT NULL THEN
         IF NOT EXISTS (
           SELECT 1
           FROM "Sprint" s
           WHERE s."id" = NEW."sprintId"
             AND s."projectId" = NEW."projectId"
         ) THEN
           RAISE EXCEPTION 'TASK_SPRINT_PROJECT_MISMATCH: Task % (project %) cannot reference Sprint % from another project',
             NEW."id", NEW."projectId", NEW."sprintId"
             USING ERRCODE = '23514';
         END IF;
       END IF;
       RETURN NEW;
     END;
     $$ LANGUAGE plpgsql;

     CREATE TRIGGER trg_task_sprint_same_project
       BEFORE INSERT OR UPDATE OF "projectId", "sprintId" ON "Task"
       FOR EACH ROW
       EXECUTE FUNCTION check_task_sprint_same_project();
     ```
     *Ưu điểm quyết định:* Trigger bảo vệ toàn vẹn **100% ở cấp DB** (ngay cả khi thao tác bằng raw SQL hoặc giao dịch song song), **cho phép `sprintId IS NULL`** một cách tự nhiên, và **không bị Prisma Migrate introspect/drop trong các Sprint kế tiếp** (giống như `CHECK` constraints và partial unique indexes của Sprint 2–3).
   - **Tầng Service Layer:** Luôn kiểm tra `sprint.projectId === task.projectId` trước khi ghi và trả về HTTP `400 VALIDATION_ERROR` hoặc `409` thân thiện trước khi chạm trigger DB.

### 5.4. Các ràng buộc PostgreSQL bổ sung trên bảng `Sprint`

- `Sprint_date_range_chk`: `CHECK ("endDate" >= "startDate")` *(thống nhất với `Project_date_range_chk` và `Task_date_range_chk` của Sprint 2–3)*.
- `Sprint_name_nonempty_chk`: `CHECK (length(btrim("name")) > 0)`.
- `Sprint_status_timestamps_chk`: `CHECK (("status" <> 'COMPLETED' OR "completedAt" IS NOT NULL) AND ("status" <> 'CANCELLED' OR "cancelledAt" IS NOT NULL))`.
- **Không** tạo partial unique index giới hạn 1 `ACTIVE` Sprint per Project *(tuân thủ tuyệt đối `DEC-006`)*.

---

## 6. Module Breakdown

Theo đúng cấu trúc Modular Monolith hiện có trong `src/modules/`:

### 6.1. Module mới: `src/modules/sprints/`

| File đề xuất | Trách nhiệm duy nhất |
|---|---|
| `src/modules/sprints/sprint.schema.ts` | Zod schemas cho Create/Update Sprint, Query List Sprint, Assign Tasks (`sprintPlanningAssignSchema`), Move Task (`moveSprintTaskSchema`), Complete Sprint Dispositions (`completeSprintSchema`), Kanban Filter (`kanbanQuerySchema`), Analytics/Burndown params. |
| `src/modules/sprints/sprint.access.ts` | `parseSprintId`, `lockProjectRowForSprintMutation` (`FOR SHARE`), `acquireSprintPlanningLock` (`$queryRaw pg_advisory_xact_lock`), `loadSprintWithProjectOrThrow`, `assertSprintReadAccess`, `assertSprintManageAccess`, `assertProjectNotArchivedForSprintMutation`, `assertProjectActiveForSprintActivation`. |
| `src/modules/sprints/sprint.repository.ts` | Truy vấn/DTO cho `SprintSummaryDTO` (kèm `taskStats`: total/todo/inProgress/review/done/overdue/estimateHours), `SprintDetailDTO`, `SprintCompletionPreviewDTO`, `SprintActivityItemDTO`. |
| `src/modules/sprints/sprint.service.ts` | Core Sprint CRUD & Lifecycle: `listProjectSprintsService`, `getSprintDetailService`, `createSprintService`, `updateSprintService`, `activateSprintService`, `cancelSprintService` (`PLANNED` only). |
| `src/modules/sprints/sprint-planning.service.ts` | `listBacklogTasksService`, `assignTasksToSprintService`, `moveSprintTaskService` — toàn bộ kiểm tra quyền, trạng thái Sprint, khóa đồng thời (`FOR SHARE` Project + `pg_advisory_xact_lock`), ghi `TaskHistory` (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`). |
| `src/modules/sprints/sprint-completion.service.ts` | `getSprintCompletionPreviewService`, `completeSprintService` — khóa Project `FOR SHARE`, advisory lock + `SELECT ... FOR UPDATE` trên Task trong Sprint, xác thực 100% disposition (`MOVE_TO_BACKLOG` hoặc `MOVE_TO_SPRINT`) cho Task chưa `DONE`, bảo toàn Task `DONE`, cập nhật `Sprint.status = COMPLETED`, đảm bảo không còn Task chưa `DONE` nào trong Sprint. |
| `src/modules/sprints/kanban.service.ts` | `getKanbanBoardService` — tải danh sách Task đã lọc (`projectId`, optional `sprintId` hoặc `backlogOnly`, `search`, `assigneeId`, `unassignedOnly`, `priority`, `overdueOnly`, `deadlineFrom`, `deadlineTo`), phân nhóm chính xác thành 4 cột `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, kèm metadata `capabilities` từng cột/quyền. |
| `src/modules/sprints/sprint-analytics.service.ts` | `getSprintProgressAndBurndownService` — tính toán chỉ số Task Count (`DEC-017`), phân bố Status, Estimate Hours tổng hợp và chuỗi ngày Burndown thực tế theo `Asia/Ho_Chi_Minh` (`Ideal Remaining Hours` vs `Actual Remaining Hours`) từ `Sprint`, `Task`, `TaskHistory`, kèm metadata giải thích phạm vi & giới hạn dữ liệu. |
| `src/modules/sprints/sprint.actions.ts` | `"use server"` actions bọc toàn bộ mutation Sprint, Planning, Completion kèm `requireActiveUser()`, `toActionError()`, và `revalidatePath`. |

### 6.2. Điểm mở rộng có kiểm soát trên Module `src/modules/tasks/` & `src/modules/projects/`

Không tạo Task Service thứ hai; chỉ mở rộng các điểm cần thiết:

1. `src/modules/tasks/task.schema.ts`:
   - Mở rộng `taskListQuerySchema` thêm: `sprintId?: uuid`, `backlogOnly?: boolean`, `deadlineFrom?: Date`, `deadlineTo?: Date` (validate `sprintId` và `backlogOnly: true` không dùng đồng thời; `deadlineTo >= deadlineFrom`).
   - **Không thêm `sprintId` vào `createTaskSchema` / `createTaskService` (`DEC-029` / `§3.2.14`):** mọi Task mới tạo đều mặc định thuộc Product Backlog (`sprintId = NULL`) rồi mới được đưa vào Sprint qua Sprint Planning.
2. `src/modules/tasks/task.repository.ts`:
   - Bổ sung `sprint: { id, name, status } | null` vào `taskSummarySelect` & `taskDetailSelect` và `mapTaskSummary` & `mapTaskDetail`.
   - Thêm điều kiện `where` trong `findManyByProjectPaginated`: `sprintId`, `backlogOnly` (`{ sprintId: null }`), `deadlineFrom`/`deadlineTo` (`deadline: { gte, lte }`).
3. `src/modules/tasks/task.actions.ts`:
   - Mở rộng `revalidateTaskPaths(projectId, taskId)` để đồng thời `revalidatePath` cho `/projects/${projectId}/backlog`, `/projects/${projectId}/kanban`, và `/projects/${projectId}/sprints` khi Task thay đổi trạng thái hoặc chi tiết từ bất kỳ màn hình nào.
4. `src/modules/projects/project.service.ts` (`archiveProjectService`):
   - Lấy row lock `SELECT "id" FROM "Project" WHERE "id" = $1::uuid FOR UPDATE` *(bên trong `$transaction`, có guard tương thích mock test)* để serialize với `FOR SHARE` của mọi Sprint/Planning/Completion transaction (`§13`).

---

## 7. Service Layer Design

### 7.1. Core Sprint Service (`sprint.service.ts`)

- **`listProjectSprintsService(actor, projectId, rawQuery)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_READ)` + `assertProjectReadAccess(actor, validProjectId)`.
  - Input filter: `status?` (`PLANNED | ACTIVE | COMPLETED | CANCELLED`), `search?` (`name` / `goal`), phân trang hoặc list đầy đủ theo Project.
  - Output: Danh sách `SprintSummaryDTO` kèm `taskStats` (totalTasks, todoCount, inProgressCount, reviewCount, doneCount, remainingTaskCount, overdueCount, progressPercent, totalEstimateHours, completedEstimateHours).

- **`getSprintDetailService(actor, sprintId)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_READ)` + `assertSprintReadAccess(actor, validSprintId)`.
  - Output: `SprintDetailDTO` (metadata Sprint, Project summary, `taskStats`, danh sách `tasks` thuộc Sprint dùng chung `TaskSummaryDTO`, hoạt động Sprint gần đây từ `ActivityLog` + `TaskHistory`).

- **`createSprintService(actor, projectId, rawInput)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertProjectLeaderAccess(actor, validProjectId)` + `assertProjectNotArchivedForSprintMutation(project.status)` *(kèm `FOR SHARE` lock trên `"Project"` trong `$transaction`)*.
  - Validation: `name` (3..150 ký tự), `goal` (optional nullable text <= 5000), `startDate`, `endDate` (`endDate >= startDate`).
  - Transaction: Tạo `Sprint` với `status: SprintStatus.PLANNED`, `createdById: actor.userId`; ghi `ActivityLog` (`SPRINT_CREATED`).
  - Cảnh báo trùng ngày *(non-blocking, `DEC-026`)*: Truy vấn các Sprint cùng Project (`PLANNED | ACTIVE`) có khoảng ngày giao nhau để trả về trong response `meta.overlappingSprints`.

- **`updateSprintService(actor, sprintId, rawInput)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertSprintManageAccess(actor, validSprintId)` + `assertProjectNotArchivedForSprintMutation` *(kèm `FOR SHARE` lock trên `"Project"`)*.
  - Rule vòng đời *(`DEC-027`)*:
    - `COMPLETED` hoặc `CANCELLED`: từ chối hoàn toàn (`409 INVALID_STATUS_TRANSITION`).
    - `ACTIVE`: **khóa `startDate`** (nếu payload truyền `startDate` khác giá trị hiện tại -> `409 INVALID_STATUS_TRANSITION` / `VALIDATION_ERROR`); chỉ cho sửa `name`, `goal`, `endDate` (bắt buộc `endDate >= current.startDate`).
    - `PLANNED`: cho sửa `name`, `goal`, `startDate`, `endDate` (`endDate >= startDate`).
    - Hỗ trợ optimistic concurrency check (`expectedUpdatedAt`) tương tự `updateTaskService`.
  - Transaction: Update `Sprint`, ghi `ActivityLog` (`SPRINT_UPDATED`) kèm danh sách trường thay đổi và `meta.overlappingSprints`.

- **`activateSprintService(actor, sprintId)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertSprintManageAccess(actor, validSprintId)` + `assertProjectNotArchivedForSprintMutation` *(kèm `FOR SHARE` lock trên `"Project"`)*.
  - Preconditions *(`DEC-026`)*:
    - Kiểm tra `project.status === ProjectStatus.ACTIVE` (nếu `CREATED` trả `409 INVALID_STATUS_TRANSITION`; nếu `ARCHIVED` trả `409 PROJECT_ARCHIVED`).
    - Kiểm tra `sprint.status === SprintStatus.PLANNED`. Cho phép kích hoạt trước `startDate`, giữ nguyên `startDate` gốc.
    - **Không giới hạn số lượng Sprint `ACTIVE` trong Project (`DEC-006`)**.
  - Concurrency: Atomic update `tx.sprint.updateMany({ where: { id: sprintId, status: SprintStatus.PLANNED }, data: { status: SprintStatus.ACTIVE, activatedAt: new Date() } })`; nếu `count === 0` -> `409 INVALID_STATUS_TRANSITION`. Ghi `ActivityLog` + `AuditLog` (`SPRINT_ACTIVATED`).

- **`cancelSprintService(actor, sprintId, rawInput)`** *(`DEC-028`)*
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertSprintManageAccess(actor, validSprintId)` + `FOR SHARE` Project lock + `acquireSprintPlanningLock(tx, projectId)`.
  - Precondition nghiêm ngặt: **CHỈ áp dụng cho Sprint đang `PLANNED`** (nếu `ACTIVE` -> `409 INVALID_STATUS_TRANSITION`, hướng dẫn dùng `Complete Sprint`; nếu `COMPLETED`/`CANCELLED` -> `409 INVALID_STATUS_TRANSITION`).
  - Transaction: Tìm các Task chưa `DONE` thuộc Sprint (`status !== DONE`), đưa về Backlog (`sprintId = null`) và append `TaskHistory` (`SPRINT_REMOVED`, `oldValue: { sprintId, sprintName }`, `metadata: { source: "SPRINT_CANCELLED" }`); giữ nguyên Task `DONE` nếu có; cập nhật `Sprint.status = CANCELLED`, `cancelledAt = now`; ghi `ActivityLog` + `AuditLog` (`SPRINT_CANCELLED`).

### 7.2. Product Backlog & Sprint Planning Service (`sprint-planning.service.ts`)

- **`listBacklogTasksService(actor, projectId, rawQuery)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.TASK_READ)` + `assertPermission(actor, PERMISSIONS.SPRINT_READ)` + `assertProjectReadAccess(actor, validProjectId)`.
  - Thực thi: Chuẩn hóa query (`search`, `priority`, `assigneeId`, `unassignedOnly`, `overdueOnly`, `deadlineFrom`, `deadlineTo`, `status`, `sortBy`, `sortOrder`, `page`, `pageSize`), ép `backlogOnly: true`, gọi thẳng **`taskRepository.findManyByProjectPaginated`**. Đảm bảo zero logic trùng lặp với Task List!

- **`assignTasksToSprintService(actor, sprintId, rawInput)`** (`taskIds: string[]`, 1..100 UUID deduped)
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertSprintManageAccess` + `assertProjectNotArchivedForSprintMutation`.
  - Transaction (lấy `FOR SHARE` trên `"Project"` rồi `$queryRaw` `pg_advisory_xact_lock(hashtext('sprint_plan:' + projectId))`):
    1. Re-load `Sprint`, xác nhận `sprint.status === PLANNED || sprint.status === ACTIVE` (từ chối `COMPLETED`/`CANCELLED` với `409 SPRINT_NOT_PLANNING_ELIGIBLE`).
    2. Load toàn bộ `Task` trong `taskIds`:
       - Nếu thiếu bất kỳ ID nào -> `404 NOT_FOUND`.
       - Nếu có Task thuộc `task.projectId !== sprint.projectId` -> `400 VALIDATION_ERROR` (kèm details `taskId`, `taskTitle`).
       - Nếu `task.status === TaskStatus.DONE` (`DEC-030`) -> `409 INVALID_STATUS_TRANSITION` ("Không thể đưa Task đã hoàn thành vào Sprint khác").
       - Nếu `task.sprintId === sprint.id` -> idempotent bỏ qua (chỉ ghi `TaskHistory` cho các Task đang từ Backlog đi vào).
       - **Quan trọng (`BR-SPR-007`, `TC-SPRINT-007`):** Nếu `task.sprintId !== null && task.sprintId !== sprint.id` -> từ chối toàn bộ batch với **`409 SPRINT_TASK_ALREADY_ASSIGNED`** kèm danh sách chi tiết `{ taskId, taskTitle, taskStatus, message: "Đang thuộc Sprint ..." }`.
    3. Thực hiện `tx.task.updateMany({ where: { id: { in: eligibleIds }, projectId: sprint.projectId, sprintId: null }, data: { sprintId: sprint.id } })`. Kiểm tra `updated.count === eligibleIds.length` (nếu mismatch -> `409 CONFLICT`).
    4. Ghi batch `TaskHistory` (`action: SPRINT_ASSIGNED`, `newValue: { sprintId, sprintName }`, `metadata: { source: "PLANNING" }`).
    5. Ghi `ActivityLog` tóm tắt thao tác Planning cho Sprint.

- **`moveSprintTaskService(actor, sprintId, taskId, rawInput)`** (`targetSprintId: string | null`)
  - Bao phủ **cả hai thao tác**:
    - `targetSprintId === null` (**Remove from Sprint to Backlog**): `Task.sprintId` chuyển từ `sprintId` về `null`, ghi `TaskHistory` (`action: SPRINT_REMOVED`, `oldValue: { sprintId, sprintName }`).
    - `targetSprintId === uuid` (**Move Task between Sprints** — `DEC-030`): kiểm tra `targetSprint` tồn tại, cùng `projectId`, `targetSprint.id !== sprintId`, `targetSprint.status` thuộc `PLANNED | ACTIVE`; cập nhật `Task.sprintId = targetSprint.id` và ghi `TaskHistory` (`action: SPRINT_MOVED`, `oldValue: { sprintId, sprintName }`, `newValue: { sprintId: targetSprint.id, sprintName: targetSprint.name }`).
  - Các chốt chặn bên trong Transaction (`FOR SHARE` Project + `pg_advisory_xact_lock('sprint_plan:' + projectId)` + `SELECT ... FOR UPDATE` dòng `Task`):
    - Nguồn `sprint.status` phải là `PLANNED | ACTIVE` (nếu Sprint đã `COMPLETED`/`CANCELLED` -> `409 SPRINT_NOT_PLANNING_ELIGIBLE` / `INVALID_STATUS_TRANSITION`).
    - Kiểm tra `task.sprintId === sprintId` (nếu không phải đang thuộc Sprint nguồn -> `409 CONFLICT`).
    - **Cấm di chuyển Task `DONE` (`DEC-030`):** nếu `task.status === TaskStatus.DONE` -> `409 TASK_ALREADY_COMPLETED` / `INVALID_STATUS_TRANSITION`.
    - **Task `REVIEW` (`DEC-030`):** được phép chuyển, giữ nguyên `status = REVIEW`; UI hiển thị cảnh báo `"Task đang chờ Review"`.

### 7.3. Sprint Completion Service (`sprint-completion.service.ts`)

- **`getSprintCompletionPreviewService(actor, sprintId)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_MANAGE)` + `assertSprintManageAccess`.
  - Trả về:
    - Tóm tắt Sprint hiện tại (tổng Task, số Task đã `DONE`, số Task chưa `DONE`, `sprintUpdatedAt` dùng làm optimistic anchor).
    - Danh sách `unfinishedTasks` (`status !== DONE`), kèm `status`, `priority`, `deadline`, `estimateHours`, `assignees`, `blockedByCount`, `updatedAt`.
    - Danh sách `availableTargetSprints`: các Sprint khác thuộc cùng `projectId` đang ở `PLANNED` hoặc `ACTIVE`.

- **`completeSprintService(actor, sprintId, rawInput)`** *(`DEC-031`)*
  - Input Schema:
    ```ts
    {
      expectedUpdatedAt?: string;
      note?: string | null; // Ghi chú tổng kết Sprint (optional)
      taskDispositions: Array<{
        taskId: string; // UUID
        action: "MOVE_TO_BACKLOG" | "MOVE_TO_SPRINT"; // DEC-031: KHÔNG có KEEP_IN_SPRINT
        targetSprintId?: string | null; // bắt buộc khi action === "MOVE_TO_SPRINT"
        expectedStatus?: TaskStatus; // optional optimistic guard từ Completion Preview
      }>;
    }
    ```
  - Thực thi nguyên tử trong `prisma.$transaction`:
    1. Lock `"Project"` ở chế độ `FOR SHARE`, kiểm tra Project chưa `ARCHIVED`; sau đó lấy `$queryRaw` `pg_advisory_xact_lock(hashtext('sprint_plan:' + sprint.projectId))`.
    2. Re-load `Sprint`, xác nhận `sprint.status === SprintStatus.ACTIVE`; kiểm tra `expectedUpdatedAt` nếu có (`409 CONFLICT` nếu lệch).
    3. Lock toàn bộ dòng `Task` hiện thuộc `sprintId` theo thứ tự UUID cố định bằng `SELECT "id", "status", "updatedAt" FROM "Task" WHERE "sprintId" = ${sprintId}::uuid ORDER BY "id" FOR UPDATE` — đảm bảo serialize tuyệt đối với mọi transaction Sprint 3 Workflow đang chuyển Task sang `DONE` hoặc `REVIEW`.
    4. Phân loại tập Task chưa `DONE` (`status !== TaskStatus.DONE`) thực tế tại DB:
       - **Đối chiếu 1-1 bắt buộc (`DEC-007`, `DEC-031`, `UC-035`):** Mọi Task chưa `DONE` hiện đang nằm trong Sprint PHẢI có đúng 1 phần tử tương ứng trong `taskDispositions` (và không vượt/thiếu). Nếu thiếu -> `409 SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION` (kèm danh sách Task thiếu). Nếu có `taskId` trùng lặp, không còn thuộc Sprint, đã chuyển sang `DONE`, hoặc lệch `expectedStatus` -> `409 CONFLICT` yêu cầu tải lại preview.
    5. Validate tất cả `targetSprintId` của các item `MOVE_TO_SPRINT`: phải tồn tại, cùng `projectId`, khác `sprintId`, và đang ở `PLANNED | ACTIVE` (nếu sai -> `409 SPRINT_INVALID_DISPOSITION_TARGET`).
    6. Thực thi từng nhóm disposition (`where: { id: { in }, projectId, sprintId, status: { not: TaskStatus.DONE } }`) và kiểm tra `count` khớp 100%:
       - `MOVE_TO_BACKLOG`: `Task.sprintId = null`, append `TaskHistory` (`SPRINT_REMOVED`, `oldValue: { sprintId, sprintName }`, `metadata: { source: "SPRINT_COMPLETION", completedSprintId: sprintId }`).
       - `MOVE_TO_SPRINT`: `Task.sprintId = targetSprintId`, append `TaskHistory` (`SPRINT_MOVED`, `oldValue: { sprintId, sprintName }`, `newValue: { sprintId: targetSprintId, sprintName: targetSprintName }`, `metadata: { source: "SPRINT_COMPLETION", completedSprintId: sprintId }`).
    7. Assert invariant trước khi đóng Sprint: `tx.task.count({ where: { sprintId: sprint.id, status: { not: TaskStatus.DONE } } }) === 0`. Các Task đã `DONE` **không bị chạm tới** (`sprintId` giữ nguyên).
    8. Cập nhật `Sprint`: `status = COMPLETED`, `completedAt = now`.
    9. Ghi `AuditLog` & `ActivityLog` (`SPRINT_COMPLETED`) kèm thống kê hoàn thành và tóm tắt số Task trả Backlog / chuyển Sprint / note.

### 7.4. Kanban Board Service (`kanban.service.ts`)

- **`getKanbanBoardService(actor, projectId, rawQuery)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.TASK_READ)` + `assertPermission(actor, PERMISSIONS.SPRINT_READ)` + `assertProjectReadAccess`.
  - Hỗ trợ:
    - **Scope:** `scope = "PROJECT" | "SPRINT"` (hoặc truyền `sprintId` -> lọc theo Sprint đó; truyền `backlogOnly: true` hoặc không truyền `sprintId` -> mặc định Project-wide toàn bộ Task trong Project trừ khi user chọn lọc Sprint cụ thể / Backlog; đề xuất trên Kanban UI có 3 chế độ chọn Scope rõ: **Toàn Project**, **Theo Sprint cụ thể**, **Chỉ Backlog**, hoặc filter `sprintId`).
    - **Filters (`UC-025`):** `search`, `sprintId`, `backlogOnly`, `assigneeId`, `unassignedOnly`, `priority`, `overdueOnly`, `deadlineFrom`, `deadlineTo`.
  - Gọi repository (tái sử dụng `taskSummarySelect` & `mapTaskSummary` của Sprint 3, bỏ giới hạn page 10 nếu Board view hoặc hỗ trợ limit an toàn như tối đa 200 card kèm bộ lọc rõ ràng), phân bucket theo thứ tự ưu tiên/deadline vào 4 cột:
    - `columns: { TODO: TaskSummaryDTO[], IN_PROGRESS: TaskSummaryDTO[], REVIEW: TaskSummaryDTO[], DONE: TaskSummaryDTO[] }`
  - Trả thêm thông tin quyền thao tác của `actor` (`canManageSprint`, `canUpdateTask`, `canSubmitReview`, `canReviewTask`, `currentUserId`) để UI Kanban hiển thị chính xác action khả dụng cho từng Card.
  - **Kanban Card Status Changes:** Không tạo service mới; API/UI Kanban gọi thẳng:
    - `TODO → IN_PROGRESS`: `updateTaskStatusAction(taskId, "IN_PROGRESS")` (hoặc `PATCH /api/v1/tasks/[taskId]`) -> `updateTaskStatusService`.
    - `IN_PROGRESS → REVIEW`: mở `TaskReviewModal(mode="submit")` -> `submitTaskForReviewAction(taskId, ...)` (hoặc `POST /api/v1/tasks/[taskId]/submit-review`).
    - `REVIEW → DONE`: mở `TaskReviewModal(mode="approve")` -> `approveTaskReviewAction(taskId, { reason })` (hoặc `POST /api/v1/tasks/[taskId]/approve`).
    - `REVIEW → IN_PROGRESS`: mở `TaskReviewModal(mode="reject")` -> `rejectTaskReviewAction(taskId, { reason })` (hoặc `POST /api/v1/tasks/[taskId]/reject`).

### 7.5. Sprint Progress & Burndown Service (`sprint-analytics.service.ts`)

- **`getSprintProgressAndBurndownService(actor, sprintId)`**
  - Quyền: `assertPermission(actor, PERMISSIONS.SPRINT_READ)` + `assertSprintReadAccess`.
  - **1. Sprint Progress Metrics (`DEC-017`):**
    - `totalTasks`: tổng số Task hiện có trong Sprint.
    - `countsByStatus`: `{ TODO, IN_PROGRESS, REVIEW, DONE }`.
    - `completedTaskCount`: `countsByStatus.DONE`.
    - `remainingTaskCount`: `totalTasks - completedTaskCount`.
    - `progressPercent`: `totalTasks === 0 ? 0 : Math.round((completedTaskCount / totalTasks) * 100)`. *(Đo bằng Task Count theo đúng `DEC-017`, tuyệt đối không lấy % theo giờ ở chỉ số Progress).*
    - `overdueCount`: số Task trong Sprint có `status !== DONE` và `deadline < now`.
  - **2. Estimate Hours Aggregation (`FR-DASH-003`):**
    - `tasksWithEstimateCount`, `totalEstimateHours`, `completedEstimateHours`, `remainingEstimateHours`.
    - `hasEstimateData`: `tasksWithEstimateCount > 0 && totalEstimateHours > 0`.
  - **3. Burndown Chart Series (chỉ dựng khi `hasEstimateData === true`, `DEC-017`, `DEC-033`):**
    - Nếu `!hasEstimateData`: trả về `burndown: { hasEstimateData: false, timezone: "Asia/Ho_Chi_Minh", insufficientDataMessage: "Sprint chưa có Task nào khai báo Estimate Hours nên chưa đủ dữ liệu vẽ biểu đồ Burndown.", limitations: [...], points: [] }`.
    - Nếu `hasEstimateData === true`:
      - Sinh dải ngày `D_0 .. D_N` từ `Sprint.startDate` đến `Sprint.endDate` theo múi giờ chuẩn **`Asia/Ho_Chi_Minh` (`+07:00`)** (`endOfDay(d)` = `23:59:59.999+07:00`).
      - **Xác định phạm vi ban đầu (`initialScopeHours`) và phạm vi theo ngày (`scopeHours(d)`):** Tái dựng lịch sử thành viên Sprint của từng `Task` (từng hoặc đang có liên hệ `sprintId`) từ `TaskHistory` (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`). Một `Task` thuộc scope của Sprint tại thời điểm cuối ngày `d` khi sự kiện đưa vào Sprint gần nhất trước hoặc bằng `endOfDay(d)` chưa bị sự kiện rời Sprint theo sau trước hoặc bằng `endOfDay(d)`.
      - **Ideal Remaining Hours:** Giảm tuyến tính từ baseline đầu Sprint (`initialScopeHours` ở cuối/đầu `D_0`, dùng `baselineScopeHours = max(scopeHours(D_0), currentPlannedHours)` hoặc `initialScopeHours` khi `> 0`) xuống `0` ở `D_N` (`idealRemainingHours = totalDays === 0 ? 0 : round(baselineHours * (1 - dayIndex / totalDays), 2)`).
      - **Actual Remaining Hours tại cuối mỗi ngày `d <= today`:** (ngày tương lai `> today` trả `actualRemainingHours: null` để đường thực tế không kéo tụt giả xuống 0): Tổng `estimateHours` của các Task thuộc scope Sprint tại `endOfDay(d)` mà chưa hoàn thành tính tới `endOfDay(d)` (`completedAt === null` hoặc `completedAt > endOfDay(d)`).
      - **Limitations công khai (`DEC-033`):** MVP tái dựng từ `estimateHours` hiện tại trên `Task` + `TaskHistory` (`sprintId` & `completedAt`), chưa lưu snapshot `estimateHours` theo ngày; điều này được ghi rõ trên response & tooltip/note UI.

---

## 8. Authorization & Permission Matrix

### 8.1. Phân tích nhu cầu Permission

Kiểm tra trực tiếp `src/modules/authorization/constants.ts`:
- `PERMISSIONS.SPRINT_MANAGE = "sprint.manage"` **đã tồn tại**, được gán mặc định cho **`ADMIN`** và **`LEADER`**.
- `PERMISSIONS.SPRINT_READ = "sprint.read"` **đã tồn tại**, được gán mặc định cho **`ADMIN`**, **`INSTRUCTOR`**, **`LEADER`**, **`MEMBER`**.
- Các quyền Task (`task.read`, `task.update`, `task.submit_review`, `task.review`) **đã tồn tại** và đang hoạt động.

**Kết luận & Khuyến nghị:** **Không thêm permission mới và không thay đổi Role Definition mặc định** trong Sprint 4. Sử dụng lại `sprint.manage` + `sprint.read` + `task.*` kết hợp **Resource Scope Guard** (`assertProjectLeaderAccess`, `assertProjectReadAccess`, `assertTaskProgressOrReviewActorAccess`) là vừa đủ, khớp 100% `Authorization-Design.md §4–§6` và không làm xáo trộn Permission Matrix đã kiểm thử ở Sprint 2–3.

### 8.2. Ma trận phân quyền chi tiết Sprint 4

| Hành động nghiệp vụ | Permission kiểm tra tại Server | Resource Scope & Rule bổ sung | `ADMIN` | `LEADER` *(cùng Project)* | `LEADER` *(Project khác)* | `MEMBER` *(cùng Project)* | `INSTRUCTOR` *(cùng Project)* | Project `ARCHIVED` |
|---|---|---|---|---|---|---|---|---|
| **List / View Sprint Detail / Progress / Burndown** | `sprint.read` | `assertProjectReadAccess` (Admin xem all; Leader/Member/Instructor phải active trong Project) | Allow | Allow | Deny `403` | Allow | Allow | Read OK |
| **Create / Update Sprint** | `sprint.manage` | `assertProjectLeaderAccess` (`isWorkspaceAdmin` hoặc Project Leader active) | Allow | Allow | Deny `403` | Deny `403` | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **Activate Sprint** | `sprint.manage` | `assertProjectLeaderAccess` + `sprint.status === PLANNED` + **`project.status === ACTIVE`** (`DEC-026`) | Allow | Allow | Deny `403` | Deny `403` | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **Complete Sprint / Completion Preview / Cancel Sprint** | `sprint.manage` | `assertProjectLeaderAccess` + `ACTIVE` (`Complete`) / `PLANNED` (`Cancel`) | Allow | Allow | Deny `403` | Deny `403` | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **View Product Backlog (`backlog.read`)** | `task.read` + `sprint.read` | `assertProjectReadAccess` | Allow | Allow | Deny `403` | Allow | Allow *(Read-only)* | Read OK |
| **Sprint Planning (Add / Remove / Move Task)** | `sprint.manage` | `assertProjectLeaderAccess` + Task & Sprint cùng `projectId` + Sprint `PLANNED \| ACTIVE` + cấm Task `DONE` (`DEC-030`) | Allow | Allow | Deny `403` | Deny `403` | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **View Kanban Board (`kanban.read`)** | `task.read` + `sprint.read` | `assertProjectReadAccess` | Allow | Allow | Deny `403` | Allow | Allow *(Read-only)* | Read OK |
| **Kanban: `TODO → IN_PROGRESS`** | `task.update` | `assertTaskProgressOrReviewActorAccess` (Leader/Admin hoặc Active Assignee) | Allow | Allow | Deny `403` | Allow *(Assigned task only)* | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **Kanban: `IN_PROGRESS → REVIEW`** | `task.submit_review` | `assertTaskProgressOrReviewActorAccess` (Leader/Admin hoặc Active Assignee) | Allow | Allow | Deny `403` | Allow *(Assigned task only)* | Deny `403` | Lock `409 PROJECT_ARCHIVED` |
| **Kanban: `REVIEW → DONE` (Approve) / `REVIEW → IN_PROGRESS` (Reject)** | `task.review` | `assertTaskLeaderAccess` + Reason bắt buộc + Dependency gate `DEC-005` (Approve) | Allow | Allow | Deny `403` | Deny `403` | Deny `403` | Lock `409 PROJECT_ARCHIVED` |

> **Lưu ý bảo mật:** Khi `USER` bị Admin gỡ quyền `sprint.manage` hay `sprint.read` tại `/admin/roles`, `loadTrustedAuthContext` nạp lại quyền từ PostgreSQL ở mỗi request nên hiệu lực tức thì.

---

## 9. API Specification

Tuân thủ convention `/api/v1` của Sprint 2–3 (`API-Specification.md §1–§2, §6`, `apiSuccess`, `apiError`, `parseJsonBody`). Các endpoint collection đặt dưới `/api/v1/projects/[projectId]/...`, còn các thao tác trực tiếp theo tài nguyên Sprint đặt dưới `/api/v1/sprints/[sprintId]/...` (đồng bộ hoàn toàn với pattern `/api/v1/projects/[projectId]/tasks` + `/api/v1/tasks/[taskId]/...` của Sprint 3).

### 9.1. Bảng Endpoint Sprint 4

| Method | Endpoint | Permission | Service gọi | Mục đích |
|---|---|---|---|---|
| `GET` | `/api/v1/projects/[projectId]/sprints` | `sprint.read` | `listProjectSprintsService` | Danh sách Sprints của Project (`?status=`, `?search=`) kèm thống kê Task Count & Progress |
| `POST` | `/api/v1/projects/[projectId]/sprints` | `sprint.manage` | `createSprintService` | Tạo Sprint mới ở trạng thái `PLANNED` |
| `GET` | `/api/v1/projects/[projectId]/backlog` | `task.read` + `sprint.read` | `listBacklogTasksService` | Danh sách Task ở Backlog (`sprintId IS NULL`), search & multi-filter |
| `GET` | `/api/v1/projects/[projectId]/kanban` | `task.read` + `sprint.read` | `getKanbanBoardService` | Dữ liệu Kanban Board 4 cột (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`) theo Project hoặc Sprint |
| `GET` | `/api/v1/sprints/[sprintId]` | `sprint.read` | `getSprintDetailService` | Chi tiết Sprint, thống kê, Task list trong Sprint & Sprint activities |
| `PATCH` | `/api/v1/sprints/[sprintId]` | `sprint.manage` | `updateSprintService` | Cập nhật `name`, `goal`, `startDate`, `endDate` (`PLANNED` sửa tất cả; `ACTIVE` khóa `startDate`, `DEC-027`) |
| `POST` | `/api/v1/sprints/[sprintId]/activate` | `sprint.manage` | `activateSprintService` | Chuyển Sprint từ `PLANNED` sang `ACTIVE` (yêu cầu Project `ACTIVE`, `DEC-026`) |
| `POST` | `/api/v1/sprints/[sprintId]/cancel` | `sprint.manage` | `cancelSprintService` | Hủy Sprint `PLANNED` sang `CANCELLED` và trả Task chưa `DONE` về Backlog (`DEC-028`) |
| `GET` | `/api/v1/sprints/[sprintId]/completion-preview` | `sprint.manage` | `getSprintCompletionPreviewService` | Lấy danh sách Task chưa `DONE` & danh sách Sprint đích khả dụng trước khi Complete |
| `POST` | `/api/v1/sprints/[sprintId]/complete` | `sprint.manage` | `completeSprintService` | Xử lý disposition từng Task chưa `DONE` và hoàn tất Sprint sang `COMPLETED` |
| `PUT` | `/api/v1/sprints/[sprintId]/tasks` | `sprint.manage` | `assignTasksToSprintService` | Đưa một hoặc nhiều Backlog Task vào Sprint (`taskIds: string[]`) |
| `POST` | `/api/v1/sprints/[sprintId]/tasks/[taskId]/move` | `sprint.manage` | `moveSprintTaskService` | Gỡ Task khỏi Sprint về Backlog (`targetSprintId: null`) hoặc chuyển sang Sprint khác cùng Project (`targetSprintId: uuid`) |
| `GET` | `/api/v1/sprints/[sprintId]/burndown` | `sprint.read` | `getSprintProgressAndBurndownService` | Lấy dữ liệu Sprint Progress (`Task Count`) + Estimate Hours + chuỗi điểm Burndown Chart |

*(Không tạo endpoint mới cho chuyển trạng thái Kanban — Frontend/API Client gọi thẳng các endpoint Sprint 3: `PATCH /api/v1/tasks/[taskId]`, `POST /api/v1/tasks/[taskId]/submit-review`, `POST /api/v1/tasks/[taskId]/approve`, `POST /api/v1/tasks/[taskId]/reject`.)*

### 9.2. Chi tiết Schema Payload & Error Codes trọng yếu

1. **`POST /api/v1/projects/[projectId]/sprints`**
   - Request: `{ "name": string (3..150), "goal"?: string | null, "startDate": YYYY-MM-DD | ISO, "endDate": YYYY-MM-DD | ISO }`
   - Response `201`: `{ data: SprintDetailDTO, meta?: { overlappingSprints: { id, name, startDate, endDate, status }[] } }`
   - Errors: `400 VALIDATION_ERROR`, `401 AUTH_REQUIRED`, `403 FORBIDDEN`, `404 NOT_FOUND`, `409 PROJECT_ARCHIVED`.

2. **`PATCH /api/v1/sprints/[sprintId]`**
   - Request: `{ "name"?, "goal"?, "startDate"?, "endDate"?, "expectedUpdatedAt"?: ISO }`
   - Response `200`: `{ data: SprintDetailDTO }`
   - Errors: `400 VALIDATION_ERROR`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED | INVALID_STATUS_TRANSITION | CONFLICT`.

3. **`PUT /api/v1/sprints/[sprintId]/tasks`**
   - Request: `{ "taskIds": string[] (UUID[], 1..100) }`
   - Response `200`: `{ data: { sprintId, addedCount, tasks: TaskSummaryDTO[] } }`
   - Errors: `400 VALIDATION_ERROR` *(sai định dạng hoặc Task thuộc Project khác)*, `401`, `403`, `404`, `409 PROJECT_ARCHIVED | SPRINT_NOT_PLANNING_ELIGIBLE | SPRINT_TASK_ALREADY_ASSIGNED | INVALID_STATUS_TRANSITION`.

4. **`POST /api/v1/sprints/[sprintId]/tasks/[taskId]/move`**
   - Request: `{ "targetSprintId": string | null }` *(null = trả về Backlog; uuid = chuyển sang Sprint đích)*
   - Response `200`: `{ data: TaskDetailDTO }`
   - Errors: `400 VALIDATION_ERROR`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED | SPRINT_NOT_PLANNING_ELIGIBLE | SPRINT_INVALID_DISPOSITION_TARGET | INVALID_STATUS_TRANSITION | CONFLICT`.

5. **`POST /api/v1/sprints/[sprintId]/complete`**
   - Request: `{ "expectedUpdatedAt"?: ISO, "note"?: string | null, "taskDispositions": [{ "taskId": uuid, "action": "MOVE_TO_BACKLOG" | "MOVE_TO_SPRINT", "targetSprintId"?: uuid | null, "expectedStatus"?: TaskStatus }] }`
   - Response `200`: `{ data: SprintDetailDTO }`
   - Errors: `400 VALIDATION_ERROR`, `401`, `403`, `404`, `409 PROJECT_ARCHIVED | INVALID_STATUS_TRANSITION | SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION | SPRINT_INVALID_DISPOSITION_TARGET | CONFLICT`.

6. **Error Codes bổ sung vào `src/types/api.ts`:**
   - `SPRINT_NOT_FOUND`
   - `SPRINT_INVALID_STATUS`
   - `SPRINT_DATE_INVALID`
   - `SPRINT_TASK_ALREADY_ASSIGNED` *(đã được khai báo trong `API-Specification.md §9`)*
   - `SPRINT_NOT_PLANNING_ELIGIBLE` *(Sprint đã `COMPLETED` hoặc `CANCELLED`)*
   - `SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION` *(thiếu quyết định cho Task chưa `DONE` khi Complete Sprint)*
   - `SPRINT_INVALID_DISPOSITION_TARGET` *(Sprint đích không tồn tại, khác Project, trùng Sprint đang đóng hoặc đã đóng/hủy)*
   - `TASK_ALREADY_COMPLETED` *(cấm planning / move Task đã `DONE`)*
   *(Tái sử dụng trực tiếp `PROJECT_ARCHIVED`, `TASK_DEPENDENCY_NOT_COMPLETED`, `CONFLICT`, `FORBIDDEN`, `NOT_FOUND`, `INVALID_STATUS_TRANSITION`, `VALIDATION_ERROR` hiện hữu).*

---

## 10. Server Actions

Tạo `src/modules/sprints/sprint.actions.ts` với cùng mẫu `requireActiveUser()` + `toActionError()` + `revalidatePath` như `src/modules/tasks/task.actions.ts`:

| Server Action | Service tương ứng | Paths cần Revalidate |
|---|---|---|
| `createSprintAction(projectId, input)` | `createSprintService` | `/projects/[id]`, `/projects/[id]/sprints`, `/projects/[id]/backlog`, `/projects/[id]/kanban` |
| `updateSprintAction(sprintId, input)` | `updateSprintService` | `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `/projects/[id]/sprints/[sprintId]/edit` |
| `activateSprintAction(sprintId)` | `activateSprintService` | `/projects/[id]`, `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `/projects/[id]/kanban`, `/dashboard` |
| `cancelSprintAction(sprintId, input)` | `cancelSprintService` | `/projects/[id]`, `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `/projects/[id]/backlog`, `/projects/[id]/kanban` |
| `assignTasksToSprintAction(sprintId, input)` | `assignTasksToSprintService` | `/projects/[id]`, `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `/projects/[id]/backlog`, `/projects/[id]/kanban`, `/projects/[id]/tasks` |
| `moveSprintTaskAction(sprintId, taskId, input)` | `moveSprintTaskService` | `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `(nếu có targetSprintId)`, `/projects/[id]/backlog`, `/projects/[id]/kanban`, `/projects/[id]/tasks`, `/projects/[id]/tasks/[taskId]` |
| `completeSprintAction(sprintId, input)` | `completeSprintService` | `/projects/[id]`, `/projects/[id]/sprints`, `/projects/[id]/sprints/[sprintId]`, `/projects/[id]/backlog`, `/projects/[id]/kanban`, `/projects/[id]/tasks`, `/dashboard` |

- **Kanban Mutations:** Các component Kanban gọi thẳng `updateTaskStatusAction`, `submitTaskForReviewAction`, `approveTaskReviewAction`, `rejectTaskReviewAction` trong `src/modules/tasks/task.actions.ts`, kèm cập nhật `revalidateTaskPaths` để invalidate luôn `/projects/[projectId]/kanban`, `/projects/[projectId]/backlog`, `/projects/[projectId]/sprints`.

---

## 11. UI/UX & Routes

### 11.1. Sơ đồ Routes mới dưới `/projects/[projectId]/`

| Route | Component / Mục đích | Quyền truy cập |
|---|---|---|
| `/projects/[projectId]/sprints` | **Sprint List Page:** Lọc theo `status`/search, phân nhóm/hiển thị rõ `ACTIVE`, `PLANNED`, `COMPLETED`, `CANCELLED`, Progress bar theo Task Count (`DONE / Total`), link sang Sprint Detail, Backlog, Kanban, nút Tạo Sprint mới (nếu có quyền `sprint.manage` và Project chưa Archived). | `sprint.read` + Project access |
| `/projects/[projectId]/sprints/new` | **Create Sprint Page:** Form RHF + Zod (`name`, `goal`, `startDate`, `endDate`), hiển thị warning non-blocking nếu trùng ngày với Sprint khác cùng Project. | `sprint.manage` + Project Leader/Admin + chưa Archived |
| `/projects/[projectId]/sprints/[sprintId]` | **Sprint Detail & Overview Page:** Thông tin Sprint, Sprint Status Badge, Action bar (`Activate`, `Edit`, `Complete Sprint`, `Cancel`), KPI Cards (Total Tasks, Done, Remaining, In Progress, Review, Progress %), **Burndown Chart** (SVG thuần theo Estimate Hours + thông báo thiếu dữ liệu & note giới hạn lịch sử), danh sách Task thuộc Sprint (nút `Chuyển về Backlog` / `Chuyển Sprint`, cảnh báo nếu Task đang `REVIEW`, `Add Tasks from Backlog` modal), link mở **Kanban của Sprint này**, Sprint Activity Feed. | `sprint.read` + Project access |
| `/projects/[projectId]/sprints/[sprintId]/edit` | **Edit Sprint Page:** Form RHF chỉnh sửa theo quy tắc `DEC-027` (tự động khóa `startDate` nếu đang `ACTIVE`, chỉ đọc / cảnh báo nếu đã `COMPLETED`/`CANCELLED`). | `sprint.manage` + Project Leader/Admin + chưa Archived |
| `/projects/[projectId]/backlog` | **Product Backlog Page (`UC-021`, `§6.7.4`):** Danh sách Task chưa gắn Sprint (`sprintId IS NULL`), thanh Search + Filter (Priority, Assignee, Unassigned, Overdue, Deadline range), checkbox chọn nhiều Task, Action Bar "Đưa N Task vào Sprint..." (mở Dialog chọn Sprint `PLANNED` hoặc `ACTIVE`) cùng nút Tạo Task trực tiếp vào Backlog. | `task.read` + `sprint.read` + Project access |
| `/projects/[projectId]/kanban` | **Kanban Board Page (`UC-024`, `§6.6.1`):** Thanh chuyển Scope (**Toàn Project** / **Sprint cụ thể** / **Backlog**), thanh Filter (Search, Sprint, Assignee, Priority, Deadline range, Overdue), lưới **4 cột cố định (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`)** responsive ngang/cuộn trên desktop/tablet/mobile. | `task.read` + `sprint.read` + Project access |

### 11.2. UI Components đề xuất (`src/components/...`)

- `src/components/shared/status-badge.tsx`: Bổ sung `SprintStatusBadge` (`PLANNED` secondary, `ACTIVE` sky/emerald highlight, `COMPLETED` emerald, `CANCELLED` outline/secondary).
- `src/components/sprints/sprint-list-client.tsx`: Danh sách Sprint kèm Progress bar (`DONE / Total Tasks`), ngày chạy, link tới Sprint Kanban & Sprint Detail.
- `src/components/sprints/sprint-form.tsx`: Form Tạo/Sửa Sprint dùng `react-hook-form` + `sprint.schema.ts`, tái sử dụng shadcn `Input`, `Textarea`, `Button`, `Alert`, cảnh báo overlap ngày, khóa `startDate` khi Sprint `ACTIVE`.
- `src/components/sprints/sprint-detail-client.tsx`: Header + Action controls (`Activate`, `Complete`, `Cancel`), thanh công cụ `Planning: Thêm Task từ Backlog` (mở Dialog chọn Backlog Tasks), bảng Task trong Sprint kèm nút `Về Backlog` / `Chuyển Sprint` (disabled trên Task `DONE`; cảnh báo khi Task ở `REVIEW`), nhúng `SprintBurndownChart`.
- `src/components/sprints/sprint-complete-modal.tsx`: Dialog (`@radix-ui/react-dialog`) cho **`UC-035` (`DEC-031`)**:
  - Hiển thị tóm tắt số Task đã `DONE` (giữ nguyên Sprint) vs danh sách các Task chưa `DONE`.
  - Mỗi Task chưa `DONE` có `<Select>` quyết định hướng xử lý bắt buộc: **`Chuyển về Backlog`** hoặc **`Chuyển sang Sprint khác`** (+ `<Select>` chọn Sprint đích `PLANNED | ACTIVE`). Tuyệt đối không có `Giữ lại trong Sprint`.
  - Hiển thị cảnh báo nếu Task chưa `DONE` đang ở `REVIEW`; gửi kèm `expectedUpdatedAt` và `expectedStatus` để server phát hiện state cũ (`409 CONFLICT`) và reload preview.
- `src/components/sprints/sprint-burndown-chart.tsx`: Biểu đồ Burndown dựng bằng **SVG thuần** (`DEC-033`, không cài Recharts) theo `Estimate Hours` (đường Ideal vs Actual Remaining Hours theo ngày `Asia/Ho_Chi_Minh`); hiển thị Empty/Insufficient-data Alert sạch sẽ theo `DEC-017` khi `!hasEstimateData` và note rõ cách tính & giới hạn.
- `src/components/backlog/backlog-list-client.tsx`: Bảng Product Backlog tương tự `TaskListClient`, thêm multi-select checkbox và `AddToSprintDialog`.
- `src/components/kanban/kanban-board-client.tsx` & `src/components/kanban/kanban-task-card.tsx`:
  - Card hiển thị: `code (#xxxxxxxx)`, `title`, `TaskPriorityBadge`, `Assignees`, `deadline`, **Overdue Indicator**, **Sprint badge**, badge **`Waiting Review`** nổi bật (khi `REVIEW`), badge **`Blocked by N`** (nếu `blockedByCount > 0`).
  - Thao tác chuyển trạng thái **tuân thủ phân quyền & workflow (`DEC-032`)**:
    - **Desktop:** HTML5 Native Drag & Drop (`draggable`, `onDragStart`, `onDragOver`, `onDrop`) kết hợp **Nút / Menu hành động nhanh** trên Card (`Bắt đầu làm`, `Gửi Review`, `Approve`, `Reject`). Không cài `@dnd-kit/*`.
    - **Mobile & Keyboard:** Thao tác đầy đủ bằng Nút / Menu hành động rõ ràng, có focus keyboard. Khi API hoặc Modal từ chối (`REVIEW_REASON_REQUIRED`, `409 TASK_DEPENDENCY_NOT_COMPLETED`, `FORBIDDEN`), card giữ nguyên/khôi phục cột cũ kèm toast/alert rõ tên Task chặn.
    - Tái sử dụng trực tiếp **`TaskReviewModal`** cho luồng `Submit Review`, `Approve`, `Reject`.

### 11.3. Tích hợp với màn hình hiện có (giữ giao diện gọn, không phá Layout)

- `src/app/(dashboard)/projects/[projectId]/page.tsx`: Thêm Card hoặc Sub-navigation Bar ngay dưới Header / cạnh `ProjectTaskSummaryCard` dẫn thẳng tới **Sprints**, **Product Backlog**, **Kanban Board**, **Tasks** và hiển thị số lượng Active Sprints hiện tại.
- `src/components/tasks/task-detail-panel.tsx` & `task-list-client.tsx`: Hiển thị tên & badge `Sprint` (hoặc `Backlog`) của Task có liên kết sang `/projects/[projectId]/sprints/[sprintId]`.
- `src/components/layout/app-shell.tsx`: Cập nhật text footer thành `Sprint 4 · Sprints, Backlog & Kanban` (không nhồi route Project-specific vào sidebar toàn workspace vì `Sprint`, `Backlog`, `Kanban` luôn thuộc phạm vi một `Project`).

---

## 12. Migration Strategy

1. **Nguyên tắc tuyệt đối:** Không chỉnh sửa hay gộp 3 file migration của Sprint 1–3; mọi thay đổi Sprint 4 nằm trong một migration cộng thêm mới tạo bằng:
   ```powershell
   npx prisma migrate dev --create-only --name sprint4_sprint_management_backlog_kanban
   ```
2. **Nội dung Migration SQL cần kiểm tra trước khi `migrate dev` / `deploy`:**
   - Tạo enum `"SprintStatus"` (`'PLANNED'`, `'ACTIVE'`, `'COMPLETED'`, `'CANCELLED'`).
   - `ALTER TYPE "TaskHistoryAction" ADD VALUE ...` (`'SPRINT_ASSIGNED'`, `'SPRINT_REMOVED'`, `'SPRINT_MOVED'`). *(Chạy trước mọi DML sử dụng giá trị enum mới; trong PostgreSQL 12+ chạy ngoài/đầu transaction hoặc tách migration block chuẩn của Prisma 6).*
   - Tạo bảng `"Sprint"`, index `"Sprint_projectId_id_key"`, `"Sprint_projectId_status_idx"`, `"Sprint_projectId_startDate_endDate_idx"`, `"Sprint_createdById_idx"`, khóa ngoại tới `"Project"` (`ON DELETE CASCADE`) và `"User"` (`ON DELETE RESTRICT`).
   - Thêm cột nullable `"sprintId" UUID` vào `"Task"`, index `"Task_projectId_sprintId_status_idx"`, `"Task_sprintId_status_idx"`, và khóa ngoại `"Task_sprintId_fkey"` (`REFERENCES "Sprint"("id") ON DELETE SET NULL`).
   - **Append Custom SQL Constraints & Trigger:**
     - `CREATE INDEX "Task_projectId_backlog_deadline_idx" ON "Task"("projectId", "deadline") WHERE "sprintId" IS NULL;`
     - `ALTER TABLE "Sprint" ADD CONSTRAINT "Sprint_date_range_chk" CHECK ("endDate" >= "startDate");`
     - `ALTER TABLE "Sprint" ADD CONSTRAINT "Sprint_name_nonempty_chk" CHECK (length(btrim("name")) > 0);`
     - `ALTER TABLE "Sprint" ADD CONSTRAINT "Sprint_status_timestamps_chk" CHECK (("status" <> 'COMPLETED' OR "completedAt" IS NOT NULL) AND ("status" <> 'CANCELLED' OR "cancelledAt" IS NOT NULL));`
     - Function + Trigger `check_task_sprint_same_project()` / `trg_task_sprint_same_project` *(đã thiết kế ở `§5.3`)*.
3. **Bảo toàn ràng buộc Sprint 1–3:** Xác minh sau migration không làm mất bất kỳ custom constraint/partial index nào đã có (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `Project_date_range_chk`, `TaskAssignee_active_task_user_idx`, `Task_date_range_chk`, `Task_estimate_nonnegative_chk`, `TaskDependency_no_self_chk`, `TaskReview_reason_nonempty_chk`).
4. **An toàn dữ liệu hiện có (Zero-downtime Backfill):** Toàn bộ Task đã tạo ở Sprint 3 tự động có `sprintId = NULL`, nghĩa là mặc định xuất hiện ngay trong **Product Backlog** mà không cần script backfill.

---

## 13. Transaction & Concurrency Strategy

1. **Thứ tự khóa phân cấp (Lock DAG chống Deadlock: `Project` -> `sprint_plan` -> `Task`):**
   - **Lớp 1 (`"Project"` row lock):** Mọi Sprint / Planning / Completion / Cancel mutation bắt đầu trong `$transaction` bằng:
     ```ts
     await tx.$queryRaw`SELECT "id", "status" FROM "Project" WHERE "id" = ${projectId}::uuid FOR SHARE`;
     ```
     Song song đó, `archiveProjectService` lấy lock `FOR UPDATE` trên `"Project"`. Điều này serialize mọi race với thao tác Archive Project mà không phụ thuộc thời điểm đọc trước transaction.
   - **Lớp 2 (Advisory Lock cấp Project):** Sử dụng khóa namespace riêng biệt `sprint_plan:${projectId}` *(không xung đột với khóa `task_dep:${projectId}` của Sprint 3)*:
     ```ts
     await tx.$queryRaw`SELECT pg_advisory_xact_lock(hashtext(${`sprint_plan:${projectId}`}))`;
     ```
     Mọi service thay đổi `Task.sprintId` hoặc kết thúc/hủy `Sprint` (`assignTasksToSprintService`, `moveSprintTaskService`, `completeSprintService`, `cancelSprintService`) đều giữ khóa này -> loại bỏ deadlock giữa Planning song song và Sprint Completion.
   - **Lớp 3 (`"Task"` `FOR UPDATE` theo thứ tự UUID cố định):** Trong `completeSprintService` và `moveSprintTaskService`, sau khi giữ `sprint_plan:${projectId}`, khóa các dòng `Task` liên quan bằng:
     ```ts
     await tx.$queryRaw`SELECT "id", "status", "updatedAt" FROM "Task" WHERE "sprintId" = ${sprintId}::uuid ORDER BY "id" FOR UPDATE`;
     ```
     Khi có giao dịch Workflow Sprint 3 đồng thời (`TODO -> DONE` / `REVIEW -> DONE` / `REJECT`) đang giữ row lock trên Task, `completeSprintService` sẽ chờ giao dịch đó commit và đọc được trạng thái `status` mới nhất để phát hiện stale disposition (`409 CONFLICT`) thay vì ghi đè hay bỏ sót.
2. **Bảo vệ Race Condition khi 2 Leader kéo cùng 1 Task Backlog vào 2 Sprint khác nhau:**
   - Nhờ `pg_advisory_xact_lock`, transaction đến sau đọc được `task.sprintId = Sprint A` (không còn `NULL`), lập tức ném lỗi `409 SPRINT_TASK_ALREADY_ASSIGNED` kèm tên Sprint A. Câu `updateMany` luôn dùng guard `where: { id: { in: eligibleIds }, projectId, sprintId: null }` làm lớp phòng vệ thứ hai.
3. **Bảo vệ Race Condition trong `completeSprintService` vs Thêm Task / Hoàn thành Task đồng thời:**
   - Sau khi lấy lock `Project FOR SHARE`, `sprint_plan:${projectId}` và `Task FOR UPDATE`, server đối chiếu tập Task thực sự chưa `DONE` với `taskDispositions` (+ kiểm tra `expectedUpdatedAt` và optional `expectedStatus`). Nếu có sai khác -> rollback toàn bộ và trả `409 SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION` hoặc `409 CONFLICT` để client tự reload preview.
   - Trước khi `Sprint.status = COMPLETED`, `tx.task.count({ where: { sprintId, status: { not: TaskStatus.DONE } } })` bắt buộc phải bằng `0`.
4. **Atomic Compare-and-Set (CAS) cho Sprint Lifecycle & Optimistic Lock:**
   - `activateSprintService`: `tx.sprint.updateMany({ where: { id: sprintId, status: SprintStatus.PLANNED }, data: { status: SprintStatus.ACTIVE, activatedAt: new Date() } })`; kiểm tra `count === 1`.
   - `updateSprintService`: hỗ trợ `expectedUpdatedAt` từ client (`409 CONFLICT` nếu lệch) và khóa `startDate` khi `status === ACTIVE`.
5. **Kanban Concurrency:** Tái sử dụng 100% cơ chế Atomic CAS (`where: { id, status: expectedStatus }`) đã kiểm chứng trong `task.service.ts` và `task-workflow.service.ts` của Sprint 3.

---

## 14. Testing Strategy

### 14.1. Unit Tests (`tests/unit/sprint4-services.test.ts`)
- Zod validation: thiếu `name`, `endDate < startDate`, empty `taskIds`, `MOVE_TO_SPRINT` thiếu `targetSprintId`, bộ lọc `backlogOnly + sprintId` xung đột.
- Quyền (`sprint.manage`, `sprint.read`, `INSTRUCTOR` read-only, `MEMBER` bị từ chối mọi thao tác Sprint Core & Sprint Planning, `ARCHIVED` Project khóa toàn bộ mutation).
- Vòng đời Sprint: cho phép nhiều Sprint `ACTIVE` cùng lúc (`DEC-006`), chỉ `ACTIVE` Project được Activate Sprint, `ACTIVE` Sprint khóa sửa `startDate`, chặn sửa khi `COMPLETED`/`CANCELLED`, `Cancel` chỉ áp dụng cho `PLANNED`.
- Complete Sprint: chặn hoàn thành nếu thiếu bất kỳ Task chưa `DONE` nào trong `taskDispositions` (`DEC-007`, `DEC-031`), loại bỏ hoàn toàn `KEEP_IN_SPRINT`, giữ nguyên Task `DONE` trong Sprint, chuyển `MOVE_TO_BACKLOG`/`MOVE_TO_SPRINT` đúng.
- Sprint Progress & Burndown (`DEC-017`, `DEC-033`): Progress % tính theo Task Count (`DONE / Total`); `hasEstimateData = false` khi không có Estimate Hours; tính chính xác chuỗi Ideal vs Actual theo `Asia/Ho_Chi_Minh` khi có Task thêm/gỡ giữa Sprint.

### 14.2. API Contract Tests (`tests/unit/sprint4-api-routes.test.ts`)
- Kiểm thử HTTP status `200`, `201`, `400`, `401`, `403`, `404`, `409` cho tất cả 11 route files (13 HTTP handlers) mới dưới `/api/v1/projects/[projectId]/(sprints|backlog|kanban)` và `/api/v1/sprints/[sprintId]/...`.
- Xác nhận format response thống nhất `{ data, meta? }` và `{ error: { code, message, details? } }`.
- Xác nhận **không có route xóa cứng Sprint** (`DELETE /api/v1/sprints/[sprintId]` không tồn tại -> 405).

### 14.3. PostgreSQL Integration & Concurrency Tests (`tests/integration/sprint4-db.test.ts`)
Chạy trực tiếp trên DB PostgreSQL 18 thật (theo mẫu `sprint3-db.test.ts`), kiểm chứng đủ **15 kịch bản bắt buộc**:
1. Create Sprint -> Update Sprint (`PLANNED` & `ACTIVE` lock `startDate`) -> Activate Sprint (chặn Project `CREATED`, cho phép Project `ACTIVE` kích hoạt **nhiều Sprint `ACTIVE` cùng lúc `DEC-006`**).
2. Cancel `PLANNED` Sprint -> trả toàn bộ Task chưa `DONE` về Backlog + ghi `TaskHistory` (`SPRINT_REMOVED`); từ chối Cancel `ACTIVE` Sprint (`409`).
3. Database Constraints & Cross-Project Trigger Integrity (`Sprint_date_range_chk`, `Sprint_name_nonempty_chk`, cố tình gắn `Task.sprintId` khác Project bằng SQL -> Trigger `trg_task_sprint_same_project` chặn).
4. Product Backlog search & multi-filter (Priority, Assignee, Unassigned, Overdue, Deadline range) + phân trang.
5. Sprint Planning: Batch assign Backlog Tasks -> Sprint + Move giữa Sprint (`PLANNED | ACTIVE`) + Remove về Backlog + cấm Task `DONE` + cho phép Task `REVIEW` + `TaskHistory` chuẩn xác (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`).
6. Cross-Project Planning bị chặn 400 ở Service Layer & Trigger ở PostgreSQL.
7. Concurrent Planning Race (`Promise.allSettled`): 2 request song song cùng assign chung 1 Task Backlog vào 2 Sprint khác nhau -> đúng 1 thành công, 1 `409 SPRINT_TASK_ALREADY_ASSIGNED`, `TaskHistory` chỉ ghi 1 dòng.
8. Complete Sprint happy path + Atomicity / Rollback: giữ nguyên Task `DONE`, xử lý `MOVE_TO_BACKLOG` / `MOVE_TO_SPRINT`, đảm bảo `Sprint.status = COMPLETED` và 0 Task chưa `DONE` còn lại; rollback toàn bộ khi disposition invalid.
9. Concurrent Complete Sprint vs Add Task / Workflow Transition Race (`FOR UPDATE`): mô phỏng Complete Sprint chạy song song với Assign Task hoặc Approve Task sang `DONE` -> bảo toàn invariant không đóng Sprint với dữ liệu stale hoặc thiếu disposition.
10. Project Archive vs Sprint Mutation Race (`FOR UPDATE` vs `FOR SHARE`): mô phỏng Archive Project song song với Planning / Complete / Activate Sprint -> bảo toàn `409 PROJECT_ARCHIVED`.
11. Kanban Board filter (Project-wide / Sprint-filtered / Backlog) + chuyển trạng thái qua Sprint 3 Workflow + Dependency Gate (`DEC-005`).
12. Progress % (`DONE / Total`) & Burndown reconstruction từ `Task` + `TaskHistory` + case thiếu `Estimate Hours` (`hasEstimateData = false`).
13. Authorization matrix thực trên DB (`ADMIN`, `LEADER`, `MEMBER`, `INSTRUCTOR` Read-only, role bị thu hồi `sprint.manage` hiệu lực ngay).

### 14.4. Sprint 1–3 Regression Tests
- Chạy lại toàn bộ suite hiện có (`tests/unit/*.test.ts`, `tests/integration/sprint1-db.test.ts`, `sprint2-db.test.ts`, `sprint3-db.test.ts`) sau khi bổ sung `sprintId` nullable vào `Task` để chứng minh 100% tính tương thích ngược (Task Creation, Field-level security `DEC-015`, Assignment Guard `DEC-009`, Dependency Cycle + Approve Gate, Review History).

### 14.5. Role-Based UI Smoke Checklist
- **Admin / Project Leader:** Tạo 2 Sprint -> Activate cả 2 -> Vào Product Backlog chọn nhiều Task đưa vào Sprint 1 -> Mở Kanban lọc theo Sprint 1 & lọc toàn Project -> Mở Complete Sprint xử lý từng Task chưa `DONE` -> Kiểm tra Progress & Burndown.
- **Assigned Member:** Xem Sprint Detail, Backlog, Kanban -> Không thấy nút Create/Edit/Activate/Complete Sprint và Planning -> Kéo/bấm chuyển Task được giao `TODO → IN_PROGRESS → REVIEW`, bị khóa trên Task của người khác.
- **Instructor:** Xem Sprint List, Sprint Detail, Progress, Burndown, Backlog, Kanban ở chế độ Read-Only tuyệt đối (không thấy bất kỳ nút/hành động sửa đổi nào).

---

## 15. File Ownership & Change Boundaries

### 15.1. Danh sách File Sprint 1–3 giữ nguyên (Read-Only — KHÔNG chỉnh sửa)
- Toàn bộ `src/modules/auth/*`, `src/modules/users/*`, `src/modules/roles/*`, `src/modules/project-templates/*`, `src/modules/project-members/*` (bao gồm `task-assignment-guard.ts`).
- `src/modules/authorization/constants.ts`, `policy.service.ts`, `require-auth.ts`.
- `src/modules/projects/project.access.ts`, `project.repository.ts`, `project.actions.ts`.
- `src/modules/tasks/task-assignment.service.ts`, `task-dependency.service.ts`, `task-workflow.service.ts`, `task-events.ts`, `task-history.repository.ts`, `task-history.service.ts`, `task.access.ts`.
- Toàn bộ các migration file cũ trong `prisma/migrations/20261114*` và `20261115*`.
- Toàn bộ test files Sprint 1–3 (`tests/unit/*`, `tests/integration/sprint1*..sprint3*`).

### 15.2. Điểm mở rộng tối thiểu trên file hiện hữu (Allowed Extension Points)
- `prisma/schema.prisma`: Thêm `SprintStatus`, `Sprint`, thêm `SPRINT_*` vào `TaskHistoryAction`, thêm `sprintId`/`sprint` vào `Task`, quan hệ `sprints` vào `Project` và `createdSprints` vào `User`.
- `src/types/api.ts`: Thêm `ErrorCode` Sprint 4 (`SPRINT_NOT_FOUND`, `SPRINT_INVALID_STATUS`, `SPRINT_DATE_INVALID`, `SPRINT_TASK_ALREADY_ASSIGNED`, `SPRINT_NOT_PLANNING_ELIGIBLE`, `SPRINT_UNFINISHED_TASKS_REQUIRE_DISPOSITION`, `SPRINT_INVALID_DISPOSITION_TARGET`, `TASK_ALREADY_COMPLETED`).
- `src/modules/projects/project.service.ts`: Bổ sung row lock `FOR UPDATE` trên `"Project"` trong `archiveProjectService` *(kèm guard kiểm tra `typeof tx.$queryRaw === "function"` để tương thích mock)* nhằm serialize race với Sprint / Planning / Completion (`FOR SHARE`).
- `src/modules/tasks/task.schema.ts`: Mở rộng `taskListQuerySchema` (`sprintId`, `backlogOnly`, `deadlineFrom`, `deadlineTo`). *Giữ nguyên `createTaskSchema` tạo Task vào Backlog (`DEC-029`).*
- `src/modules/tasks/task.repository.ts`: Thêm filter Sprint/Backlog/Deadline vào `where` + chọn `sprint: { id, name, status }` trong `taskSummarySelect`/`taskDetailSelect`.
- `src/modules/tasks/task.actions.ts`: Cập nhật `revalidateTaskPaths` bổ sung `/backlog`, `/kanban`, `/sprints`.
- `src/components/shared/status-badge.tsx`: Thêm `SprintStatusBadge`.
- `src/components/tasks/task-detail-panel.tsx` & `task-list-client.tsx`: Hiển thị Badge/Link Sprint của Task.
- `src/app/(dashboard)/projects/[projectId]/page.tsx`: Tích hợp điều hướng nhanh sang Sprints / Product Backlog / Kanban Board.
- `src/components/layout/app-shell.tsx`: Cập nhật dòng trạng thái footer sang `Sprint 4 · Sprints, Backlog & Kanban`.

### 15.3. Danh sách File mới dự kiến tạo trong Sprint 4
- **Migration:** `prisma/migrations/<timestamp>_sprint4_sprint_management_backlog_kanban/migration.sql`
- **Module Sprints (`src/modules/sprints/`):** `sprint.schema.ts`, `sprint.access.ts`, `sprint.repository.ts`, `sprint.service.ts`, `sprint-planning.service.ts`, `sprint-completion.service.ts`, `kanban.service.ts`, `sprint-analytics.service.ts`, `sprint.actions.ts`
- **API Route Handlers (`src/app/api/v1/`):**
  - `projects/[projectId]/sprints/route.ts` (`GET`, `POST`)
  - `projects/[projectId]/backlog/route.ts` (`GET`)
  - `projects/[projectId]/kanban/route.ts` (`GET`)
  - `sprints/[sprintId]/route.ts` (`GET`, `PATCH`)
  - `sprints/[sprintId]/activate/route.ts` (`POST`)
  - `sprints/[sprintId]/cancel/route.ts` (`POST` — `PLANNED` only)
  - `sprints/[sprintId]/completion-preview/route.ts` (`GET`)
  - `sprints/[sprintId]/complete/route.ts` (`POST`)
  - `sprints/[sprintId]/tasks/route.ts` (`PUT`)
  - `sprints/[sprintId]/tasks/[taskId]/move/route.ts` (`POST`)
  - `sprints/[sprintId]/burndown/route.ts` (`GET`)
- **UI Pages (`src/app/(dashboard)/projects/[projectId]/`):**
  - `sprints/page.tsx`, `sprints/new/page.tsx`, `sprints/[sprintId]/page.tsx`, `sprints/[sprintId]/edit/page.tsx`, `backlog/page.tsx`, `kanban/page.tsx`
- **UI Components (`src/components/`):**
  - `sprints/sprint-list-client.tsx`, `sprints/sprint-form.tsx`, `sprints/sprint-detail-client.tsx`, `sprints/sprint-complete-modal.tsx`, `sprints/sprint-burndown-chart.tsx`
  - `backlog/backlog-list-client.tsx`, `backlog/add-to-sprint-dialog.tsx`
  - `kanban/kanban-board-client.tsx`, `kanban/kanban-task-card.tsx`
- **Tests (`tests/`):**
  - `tests/unit/sprint4-services.test.ts`
  - `tests/unit/sprint4-api-routes.test.ts`
  - `tests/integration/sprint4-db.test.ts`

---

## 16. Implementation Order & Checkpoints

| Checkpoint | Hạng mục triển khai | Điều kiện qua cổng (Gate) |
|---|---|---|
| **Checkpoint 1 — Quyết định & Plan** | Chốt toàn bộ PO decisions `DEC-026..033` vào `markdown/DECISION-LOG.md` và cập nhật dứt điểm `report/SPRINT-4-IMPLEMENTATION-PLAN.md` (không còn OQ mở hay phương án bị loại bỏ). | Toàn bộ tài liệu khớp 100% quy tắc triển khai. |
| **Checkpoint 2 — Database & Migration** | Cập nhật `prisma/schema.prisma`, tạo + review SQL migration `--create-only` (kèm DB trigger `trg_task_sprint_same_project`, partial index Backlog, CHECK constraints), chạy `prisma migrate dev` + `prisma generate`. | `npx prisma validate`, `prisma migrate status`, full Sprint 1–3 regression tests pass 100%. |
| **Checkpoint 3 — Core Services & Unit/DB Tests** | Cập nhật `src/types/api.ts`, `project.service.ts` (`FOR UPDATE`), `task.schema.ts`/`task.repository.ts`; implement toàn bộ `src/modules/sprints/*`; chạy unit & PostgreSQL concurrency tests. | Toàn bộ `sprint4-services.test.ts` và `sprint4-db.test.ts` pass 100%. |
| **Checkpoint 4 — API Routes & Server Actions** | Implement 11 Route Handlers `/api/v1/...` + `sprint.actions.ts` + cập nhật `revalidateTaskPaths`. | `tests/unit/sprint4-api-routes.test.ts` + `npm run typecheck` pass. |
| **Checkpoint 5 — UI Components & App Routes** | Implement badges, Sprint pages, Backlog page, Kanban page (`Native HTML5 DnD + Buttons` + `TaskReviewModal`), Complete Sprint modal (`no KEEP_IN_SPRINT`), Pure SVG Burndown chart, liên kết Project/Task Detail. | Toàn bộ route build & kiểm thử quyền/responsive đạt. |
| **Checkpoint 6 — Final Sign-off & Report** | Chạy `prisma validate`, `prisma migrate status`, Prettier check (file Sprint 4), `npm run lint`, `npm run typecheck`, `npm run test`, `npm run build`; xuất `report/SPRINT-4-IMPLEMENTATION-REPORT.md`. | Zero errors, zero skipped tests, 100% Acceptance Criteria đạt. |

---

## 17. Acceptance Criteria

1. **[Sprint Core]** Leader/Admin tạo, xem, cập nhật và kích hoạt nhiều Sprint `ACTIVE` song song trong cùng một Project (`DEC-006`); chỉ `ACTIVE` Project mới được Activate Sprint; Sprint tuân thủ kiểm tra ngày và lưu `ActivityLog`; Project `ARCHIVED` khóa 100% mutation (`409 PROJECT_ARCHIVED`).
2. **[Product Backlog]** Mọi Task có `sprintId = NULL` hiển thị tại Product Backlog, hỗ trợ search, lọc Priority, Assignee, Unassigned, Overdue, khoảng Deadline; không nhân bản Task; mọi Task tạo mới luôn nằm tại Backlog.
3. **[Sprint Planning]** Leader chọn 1 hoặc nhiều Task từ Backlog đưa vào Sprint (`PLANNED`/`ACTIVE`); hệ thống chặn tuyệt đối Task thuộc Project khác (cả Service và Trigger PostgreSQL) và trả `409 SPRINT_TASK_ALREADY_ASSIGNED` nếu Task đã nằm trong Sprint khác; ghi đầy đủ `TaskHistory`.
4. **[Concurrency]** Hai thao tác Planning, Archive Project, hoặc Complete Sprint (kể cả workflow Sprint 3 song song) được serialize an toàn (`Project FOR SHARE/FOR UPDATE` + `pg_advisory_xact_lock` + `Task FOR UPDATE`), không làm sai lệch `Task.sprintId` hay cho phép đóng Sprint khi còn Task chưa `DONE` thiếu disposition.
5. **[Sprint Completion]** Hoàn thành Sprint `ACTIVE` yêu cầu disposition tường minh (`MOVE_TO_BACKLOG` hoặc `MOVE_TO_SPRINT`, không có `KEEP_IN_SPRINT`) cho từng Task chưa `DONE` (`DEC-007`, `DEC-031`, `UC-035`); không tự động đẩy Task; Task đã `DONE` giữ nguyên liên kết Sprint; toàn bộ thao tác thực hiện trong 1 transaction nguyên tử.
6. **[Kanban Board]** Kanban hiển thị 4 cột chuẩn (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`) ở cả chế độ Project-wide và Sprint-filtered; hỗ trợ HTML5 Native DnD (Desktop) + Action Buttons (Desktop/Mobile/Keyboard); bộ lọc Search/Sprint/Assignee/Priority/Deadline hoạt động chính xác; chuyển trạng thái tuân thủ nghiêm ngặt Sprint 3 Workflow, `DEC-015`, `DEC-005` và yêu cầu lý do Review.
7. **[Progress & Burndown]** Tiến độ tính theo Task Count (`DONE / Total`, `DEC-017`); Burndown dựng bằng SVG thuần theo `Estimate Hours` và múi giờ `Asia/Ho_Chi_Minh`, hiển thị thông báo rõ ràng khi chưa có Estimate và ghi nhận giới hạn dữ liệu; không tạo bảng xếp hạng cơ học.
8. **[Authorization & Quality]** Instructor chỉ xem (`403` mọi mutation); Member không thao tác được Sprint Core & Planning; toàn bộ unit, API contract, PostgreSQL integration và Sprint 1–3 regression tests pass 100%; lint, typecheck và production build thành công.

---

## 18. Risks & Dependencies

| Rủi ro / Phụ thuộc | Mức độ | Phân tích & Phương án giảm thiểu |
|---|---|---|
| **Không cài `recharts` & `@dnd-kit` trong `package.json` (`DEC-032`, `DEC-033`)** | Đã xử lý | Tuân thủ PO: dựng Burndown bằng SVG thuần (`sprint-burndown-chart.tsx`) và Kanban dùng HTML5 Native DnD kết hợp Action Buttons trên từng card. Không thêm dependency mới ngoài `package.json`. |
| **Prisma 6 Migrate Drift nếu thêm FK phức hợp trực tiếp bằng SQL** | Cao *(đã xử lý)* | Prisma diff engine theo dõi Foreign Keys và sẽ tìm cách xóa FK thủ công không có trong `schema.prisma` ở migration sau. Khắc phục triệt để bằng thiết kế đã chọn tại `§5.3`: FK đơn trên `schema.prisma` (`onDelete: SetNull`) kết hợp **PostgreSQL Trigger `trg_task_sprint_same_project`** (Prisma không xóa trigger). |
| **Thay đổi `estimateHours` hoặc di chuyển Task làm lệch Burndown nếu chỉ đọc bảng `Task` hiện tại** | Trung bình | Nếu Task từng ở Sprint từ ngày 1 và bị chuyển sang Sprint khác ngày 5, chỉ query `Task.sprintId = id` hiện tại sẽ làm mất lịch sử phạm vi đầu Sprint. Giảm thiểu bằng thuật toán đọc kết hợp `TaskHistory` (`SPRINT_ASSIGNED` / `SPRINT_REMOVED` / `SPRINT_MOVED` / `completedAt`) tại `sprint-analytics.service.ts`, chuẩn hóa ranh giới ngày theo `Asia/Ho_Chi_Minh`, và hiển thị rõ giới hạn không có snapshot `estimateHours` hàng ngày. |
| **Tương tác Sprint 5 (`Document.sprintId`) khi Sprint `CANCELLED` hoặc `COMPLETED`** | Thấp | Theo `BR-DOC-005`, Sprint 5 sẽ thêm `Document` có `sprintId` nullable (`onDelete: SetNull` / `Restrict`). Vì MVP không xóa cứng `Sprint`, dữ liệu `Sprint` (`COMPLETED`/`CANCELLED`) vẫn giữ ổn định cho `Document` tham chiếu về sau. |
| **Project chuyển sang `ARCHIVED` song song với Sprint Mutation** | Trung bình | Khóa `"Project"` bằng `FOR UPDATE` trong `archiveProjectService` và `FOR SHARE` trong toàn bộ Sprint/Planning/Completion transaction giúp serialize tuyệt đối race giữa Archive Project và Sprint mutations. |

---

## 19. Deferred Scope

Các hạng mục được chủ đích tách sang các Sprint sau (không triển khai trong Sprint 4):

- **Sprint 5 — Document Library & Notifications:**
  - Model `Document` (liên kết `projectId` và tùy chọn `sprintId`), danh mục tài liệu Google Drive URL (`BR-DOC-*`).
  - Notification Center in-app, Resend email delivery + Delivery History tiêu thụ `taskEventHook` từ Sprint 3 và mở rộng thêm `sprintEventHook` (ví dụ thông báo khi Sprint Activate / Complete nếu cần).
  - Comment / Discussion trên Task *(nếu được bổ sung vào phạm vi Sprint 5)*.
- **Sprint 6 — Workspace Dashboard & Project Reports:**
  - Workspace Dashboard tổng hợp liên Project, Overdue & Pending Review cross-project.
  - Project Reports nâng cao, Sprint Velocity lịch sử giữa nhiều Sprint đã hoàn thành, và Member Contribution Report khách quan từ `TaskAssignee` + `TaskHistory` + `TaskReview` (`FR-DASH-004`, `FR-DASH-005`).
- **Sprint 7 — Finalization, Testing & Deployment:**
  - Playwright E2E toàn luồng, security hardening, performance tuning và tài liệu hướng dẫn triển khai/sử dụng hoàn chỉnh.
