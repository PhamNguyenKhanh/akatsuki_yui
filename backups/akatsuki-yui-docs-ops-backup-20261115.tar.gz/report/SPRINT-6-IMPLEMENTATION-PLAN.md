# SPRINT 6 IMPLEMENTATION PLAN — DASHBOARD, REPORTS & ADVANCED ANALYTICS

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 6 — Dashboard, Member Contribution Reports & Advanced Analytics  
**Phase:** Confirmed Decisions Recorded (`DEC-047` – `DEC-058`) — Revised Plan Pending Final PO Approval to Execute  
**Baseline:** Sprint 1–5 Implementation (`prisma/schema.prisma`, `5` applied migrations, `27` permissions, `21` test files / `131` tests passing, `94` Next.js App Router entries)  
**Architecture:** Modular Monolith (Next.js 16.4.6 App Router, React 19, TypeScript 5.9, PostgreSQL 18, Prisma 6.19.3, Auth.js v5, Zod v4, Tailwind CSS v4, shadcn/ui, Vitest 5.1.0)  
**Author:** Senior Software Architect / Technical Lead

---

## 1. Executive Summary

### 1.1. Purpose & Planning Posture

This document defines the revised, implementation-ready technical and product plan for **Sprint 6 — Dashboard, Member Contribution Reports, Sprint Analytics, Unified Activity History, and Advanced Analytics**.

**Planning Status:** **Confirmed Product Decisions Recorded (`DEC-047` – `DEC-058` in `markdown/DECISION-LOG.md`) — Pending Final PO Sign-Off on Revised Plan Before Execution.** No application code, database schema, or Sprint 1–5 functionality has been modified during planning and revision.

### 1.2. Core Deliverables Planned for Sprint 6

1. **Operational Role-Aware Dashboard (`/dashboard`, `GET /api/v1/dashboard`):**
   - Keeps Dashboard focused strictly on **operational status** (without duplicating full historical Reports or full searchable Activity): **Current Project Context** (Active-first + accessible Project Switcher), **Task KPIs** (`Total`, `Completed`, `In Progress`, `Waiting Review`, `Overdue`), **Project Work Progress** (`DONE / Total Tasks`), **Project Timeline Progress** (`StartDate -> EndDate`), **Active Sprint Progress**, **My Assigned Tasks** (`MyAssignedTasksCard`), **Recent Activity**, and **Admin-Only Workspace Summary**.
2. **Project & Advanced Analytics (`/reports`, `/projects/[projectId]/reports`, `GET /api/v1/reports/projects/[projectId]`):**
   - Owns historical trends, breakdowns, Sprint comparisons, and management-question-driven **Pure React + SVG + Tailwind** visualizations (`DEC-056`, no Recharts): **Task Completion Trends**, **Task Status Distribution**, **Priority Distribution**, **Overdue Aging & Slip Trends**, **Sprint Completion / Commitment vs Rollover Trends**, and **Aggregate Estimated Effort Distribution** (explicitly avoiding per-member exposure inside Project Analytics). Reports are **view-only** with JSON APIs and printable layouts (`DEC-054`, no CSV/PDF/Excel exports).
3. **Objective Member Contribution Report (`/projects/[projectId]/reports` tab, `GET /api/v1/reports/projects/[projectId]/members`):**
   - Implements **non-additive participation reporting** (`DEC-047`), separating **Sole-Assigned** vs **Co-Assigned** tasks, separating **current active assignments (`removedAt IS NULL`)** from **historical reassigned assignments (`removedAt IS NOT NULL`)** (`DEC-049`), reporting verifiable `TaskHistory`/`TaskReview` actions without claiming they measure actual effort, including **former Project Members (`ProjectMember.leftAt IS NOT NULL`)** cleanly labeled `"Đã rời Project"` (`DEC-050`), using `estimateHours` strictly as planned workload (`DEC-048`), and enforcing **`MEMBER` own-row privacy** (`DEC-052`).
4. **Sprint Analytics & Commitment/Rollover Reconstruction (`GET /api/v1/reports/projects/[projectId]/sprints`, refining Sprint 4 Burndown):**
   - Reconstructs **Baseline Commitment**, **Scope Added**, **Scope Removed**, **Completed Tasks**, **Rolled Over to Backlog**, and **Rolled Over to Another Sprint** non-destructively from `Sprint` lifecycle timestamps, `TaskHistory`, and `ActivityLog` (`DEC-058`, zero new snapshot table in MVP), fixes Sprint 4 completion-day Burndown rollover distortion, and explicitly documents remaining historical reconstruction limits.
5. **Unified Cursor-Paginated Activity History (`/activity`, `GET /api/v1/activity`):**
   - Adds nullable indexed `ActivityLog.projectId` with idempotent SQL backfill and updates Project-scoped `ActivityLog` call sites (`DEC-055`), unifying `ActivityLog` and `TaskHistory` via **deterministic keyset cursor pagination** (`createdAt DESC, source DESC, id DESC`) under strict `ADMIN` / `INSTRUCTOR` / `LEADER` / `MEMBER` visibility rules (`DEC-052`) and `Asia/Ho_Chi_Minh` (`UTC+07:00`) timezone alignment (`DEC-057`).

### 1.3. Architectural Summary

- **No New Infrastructure or Heavy Client Libraries:** All analytics execute directly against **PostgreSQL 18** via **Prisma 6.19.3** (`groupBy`, bounded queries, and parameterized `$queryRaw` using exact `TIMESTAMP WITHOUT TIME ZONE` / `DATE` conversions) inside new `src/modules/dashboard/`, `src/modules/reports/`, and `src/modules/activity/` modules; all charts use Pure React + SVG + Tailwind (`DEC-056`).
- **No N+1 Queries & No Historical Record Mutation:** Reports read transactional tables in batched queries and never alter historical records (`TaskHistory`, `TaskReview`, `ActivityLog`, `AuditLog`, `TaskAssignee.removedAt`, `ProjectMember.leftAt`).
- **Server-First Authorization:** Server Components invoke Service Layer functions directly; REST routes follow `/api/v1/*` with `{ data, meta? }` / `{ error }` envelopes and Zod v4 validation.

---

## 2. Repository Audit Findings

All findings below were verified directly against the current repository codebase (`prisma/`, `src/`, `package.json`, and `report/SPRINT-1..5`).

### 2.1. Database Schema, Migrations & Column Semantics (`prisma/schema.prisma`, `prisma/migrations/*`)

1. **PostgreSQL Temporal Column Types (CRITICAL FOR SQL AGGREGATION):**
   - **`DATE` (`@db.Date`):** `Sprint.startDate` and `Sprint.endDate` are stored as PostgreSQL **`DATE`** (`20261115072731_sprint4_sprint_management_backlog_kanban/migration.sql`). Application schemas (`parseSprintCalendarDate`, `formatSprintDateYmd` in `src/modules/sprints/sprint.schema.ts`) treat them as pure calendar dates (`YYYY-MM-DD` stored/read at UTC midnight `YYYY-MM-DDT00:00:00.000Z`).
   - **`TIMESTAMP(3)` (`TIMESTAMP WITHOUT TIME ZONE`):** Every `DateTime` field across `User`, `ActivityLog.createdAt`, `AuditLog.createdAt`, `Project` (`startDate`, `endDate`, `archivedAt`, `createdAt`, `updatedAt`), `ProjectMember` (`joinedAt`, `leftAt`), `Sprint` (`activatedAt`, `completedAt`, `cancelledAt`, `createdAt`, `updatedAt`), `Task` (`startDate`, `deadline`, `estimateHours` excluded, `completedAt`, `createdAt`, `updatedAt`), `TaskAssignee` (`assignedAt`, `removedAt`), `TaskReview.reviewedAt`, and `TaskHistory.createdAt` is PostgreSQL **`TIMESTAMP(3)` WITHOUT TIME ZONE** (`init_sprint1` – `sprint5` SQL migrations).
   - **Implication:** Application JS `Date` objects represent UTC instants, which Prisma stores in `TIMESTAMP(3)` as UTC wall-clock values. PostgreSQL expressions must convert `((col AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')` rather than single `col AT TIME ZONE 'Asia/Ho_Chi_Minh'` (which shifts timestamps in the wrong direction), and `DATE` columns (`Sprint.startDate`, `Sprint.endDate`) must never receive `AT TIME ZONE` shifts.
2. **Task & Effort Schema Limitations (`Task`, `TaskAssignee`, `TaskReview`, `TaskHistory`):**
   - `Task` stores `sprintId?`, `status` (`TODO | IN_PROGRESS | REVIEW | DONE`), `priority` (`LOW | MEDIUM | HIGH | CRITICAL`), `startDate?`, `deadline`, `estimateHours` (`Float?`), `completedAt?`, `createdAt`, `updatedAt`.
   - **Verified Absences:** There is **no `actualHours` / time-log table** (`DEC-004` / `DEC-048`), **no Story Points** (`DEC-003` / `DEC-033`), **no `TaskStatus.CANCELLED`**, and **no `Task.deletedAt`**.
   - **Multi-Assignee Shared Status:** `TaskAssignee` models `0..N` assignees per Task with `assignedAt` and `removedAt?` plus partial unique index `TaskAssignee_active_task_user_idx` (`WHERE "removedAt" IS NULL`). Because `status` and `estimateHours` reside on `Task`, multi-assignee tasks share one lifecycle state and one estimate pool.
   - **Review & History Richness:** `TaskReview` preserves `submittedById?`, `reviewerId`, `decision` (`APPROVED | REJECTED`), `reason`, and `reviewedAt`. `TaskHistory` records **14 distinct actions** (`CREATED`, `INFO_UPDATED`, `PROGRESS_UPDATED`, `ASSIGNEE_ADDED`, `ASSIGNEE_REMOVED`, `STATUS_CHANGED`, `REVIEW_SUBMITTED`, `REVIEW_APPROVED`, `REVIEW_REJECTED`, `DEPENDENCY_ADDED`, `DEPENDENCY_REMOVED`, `SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`). Every `Task` starts in Backlog (`sprintId = null` in `createTaskService`), and only `sprint-planning.service.ts` (`source: "PLANNING"`), `sprint-completion.service.ts` (`source: "SPRINT_COMPLETION"`, `completedSprintId`), and `sprint.service.ts` (`cancelSprintService`, `source: "SPRINT_CANCELLED"`) mutate `Task.sprintId`.
3. **Project Membership & Leadership History (`Project`, `ProjectMember`):**
   - `Project` enforces single `ACTIVE` project via partial unique index `Project_single_active_idx` (`WHERE "status" = 'ACTIVE'`). States are `CREATED`, `ACTIVE`, `ARCHIVED`.
   - `ProjectMember` preserves soft-leave history via `leftAt?` and partial unique index `ProjectMember_active_project_user_idx` (`WHERE "leftAt" IS NULL`).
   - **Important Removal Nuance (`task-assignment-guard.ts` & `member.service.ts`):** `taskAssignmentGuard` prevents removing a member **only while they hold active (`removedAt: null`) assignments on unfinished (`status !== DONE`) Tasks**. Consequently, a departed member (`ProjectMember.leftAt != null`) commonly retains **active `TaskAssignee` rows (`removedAt: null`) on already-`DONE` Tasks**, in addition to historical `TaskAssignee` rows (`removedAt != null`) and `TaskHistory`/`TaskReview` trails.
   - **Leader Role Change Nuance (`changeProjectLeaderService` in `member.service.ts`):** Transfers mutate the former leader's `ProjectMember.projectRole` **in place** from `LEADER` to `MEMBER` without closing/re-creating the `ProjectMember` row. Past leadership dates live in `ActivityLog` / `AuditLog` (`PROJECT_LEADER_CHANGED`).
4. **Activity Log vs Audit Log Split (`ActivityLog`, `AuditLog`):**
   - **Verified Complete Call-Site Inventory (30 `activityLog.create` call sites across 10 service files):**
     - *Workspace-scoped (11 call sites, `projectId = null`):* `src/modules/auth/auth.service.ts` (3: `USER_REGISTERED`, `USER_LOGIN`, `USER_LOGOUT`), `src/modules/users/user.service.ts` (3: `ACCOUNT_*`, `USER_ROLE_ASSIGNED`, `PROFILE_UPDATED`), `src/modules/roles/role.service.ts` (2: `ROLE_PERMISSION_GRANTED`, `ROLE_PERMISSION_REVOKED`), `src/modules/project-templates/template.service.ts` (3: `PROJECT_TEMPLATE_CREATED/UPDATED/DELETED`).
     - *Project-scoped (19 call sites):* `src/modules/projects/project.service.ts` (5: `entityType: "Project"`, `entityId: project.id`, no `metadata.projectId`), `src/modules/project-members/member.service.ts` (3: `entityType: "Project"`, `entityId: project.id`), `src/modules/sprints/sprint.service.ts` (4: `entityType: "Sprint"`, `metadata.projectId`), `src/modules/sprints/sprint-planning.service.ts` (3: `entityType: "Sprint"`, `metadata.projectId`), `src/modules/sprints/sprint-completion.service.ts` (1: `SPRINT_COMPLETED`, `metadata.projectId`), `src/modules/documents/document.service.ts` (3: `entityType: "Document"`, `metadata.projectId`).
     - *Tasks (`src/modules/tasks/*`):* **Never write to `ActivityLog`** (`DEC-022`); Task events live solely in `TaskHistory` and `TaskReview`.
     - **Schema Gap:** `ActivityLog` currently has `entityType @db.VarChar(100)`, **no `projectId` column**, and only `@@index([entityType, entityId])` and `@@index([createdAt])` (no `userId` index, no descending tie-breaker index).
5. **Prisma Partial-Index Migration Hazard:**
   - Sprints 2–4 created SQL partial indexes (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`) that Prisma schema syntax cannot represent. Any `prisma migrate dev --create-only` will emit `DROP INDEX` for these indexes unless manually stripped prior to migration apply.

### 2.2. Existing Dashboard, Navigation & APIs

1. **Current `/dashboard` (`src/app/(dashboard)/dashboard/page.tsx`):**
   - Calls **`requireActiveUserOrRedirect()`** directly — **there is NO `dashboard.read` permission token** in `src/modules/authorization/constants.ts`. Individual panels check `PERMISSIONS.ACCOUNT_READ`, `PERMISSIONS.PROJECT_READ`, `PERMISSIONS.TASK_READ`, `PERMISSIONS.CREATE_PROJECT` (`PROJECT_CREATE`), and `PERMISSIONS.ROLE_MANAGE`.
   - Renders: Account stats (Admin), Profile card, `Project & Workspace` summary (`projectRepository.getDashboardProjectStats`), Admin links, `MyAssignedTasksCard` (up to 6 non-`DONE` tasks), and Permissions badge list.
   - **Gaps:** No selected-Project task KPI strip (`Total`, `Done`, `In Progress`, `Review`, `Overdue`), no Task Work Progress / Project Timeline Progress indicators, no Active Sprint operational progress card, and no Recent Activity feed.
2. **Navigation (`src/components/layout/app-shell.tsx`):**
   - Lists 9 `NAV_ITEMS` (Dashboard has no `requiredPermission` gate); footer currently says `Sprint 5 · Documents & Notifications`; missing `Reports` (`/reports`, `PERMISSIONS.REPORT_READ`) and `Activity Logs` (`/activity`, `PERMISSIONS.ACTIVITY_READ`).
3. **API & Charting Gaps:**
   - Zero reporting/dashboard/activity API routes or modules exist yet (`src/modules/dashboard/`, `src/modules/reports/`, `src/modules/activity/`).
   - `recharts` is **not** in `package.json`; Sprint 4 built pure SVG + React (`src/components/sprints/sprint-burndown-chart.tsx`).
4. **Seed Data (`prisma/seed.ts`):**
   - Seeds Roles, 27 Permissions, and an optional Admin account only (no sample Projects/Sprints/Tasks).

### 2.3. Authorization Reality vs Design Docs

- `src/modules/authorization/constants.ts` defines 27 permissions, **already including `REPORT_READ: "report.read"` and `ACTIVITY_READ: "activity.read"`**, granted by default to `ADMIN`, `INSTRUCTOR`, `LEADER`, `MEMBER`.
- `assertProjectReadAccess(actor, projectId)` (`src/modules/projects/project.access.ts`) grants `ADMIN` all Projects and non-Admin roles access iff `project.leaderId === actor.userId || project.instructorId === actor.userId || active ProjectMember (leftAt: null)`.
- Per `DEC-052`, Sprint 6 implements `MEMBER` **limited/own scope** inside `member-contribution.service.ts` and `activity.service.ts` (and forbids per-user breakdowns inside `project-analytics.service.ts`) while preserving `report.read` and `activity.read` tokens in Permission Matrix.

### 2.4. Audit of Existing Sprint 4 Progress, Planning & Burndown Implementation

Direct inspection of `sprint-analytics.service.ts`, `sprint.repository.ts`, `sprint.service.ts`, `sprint-planning.service.ts`, `sprint-completion.service.ts`, `task.service.ts`, `burndown/route.ts`, and `sprint-burndown-chart.tsx` revealed reusable components and verifiable edge cases:

| Finding | File & Lines | Technical Assessment | Impact on Sprint 6 |
|---|---|---|---|
| **1. Completion Rollover & `createdAt` Ordering (CRITICAL)** | `sprint-completion.service.ts:242-350`<br>`sprint-analytics.service.ts:169-171, 230-285` | `completeSprintService` inserts rollover `TaskHistory` (`appendManyTaskHistories`, using PostgreSQL `CURRENT_TIMESTAMP`) at line 312 **before** `const now = new Date()` sets `Sprint.completedAt` at line 329 — so rollover events satisfy `TaskHistory.createdAt <= Sprint.completedAt`! Afterwards only `DONE` tasks remain in `Sprint.tasks`. Consequently: (a) `sprint.taskStats.progressPercent` reads **100%** post-completion regardless of rollover; (b) on `completedAt` day (`hcmEndOfDay`), `isTaskInSprintAt(..., endOfDay)` sees rolled-over tasks removed before `endOfDay`, causing end-of-sprint `actualRemainingHours` to plummet to `0h`. Same artifact affects `cancelSprintService`. | Sprint Commitment & Rollover metrics MUST identify closure rollovers deterministically via `metadata.source === "SPRINT_COMPLETION"` AND `metadata.completedSprintId === sprint.id` (cross-checked against `ActivityLog(SPRINT_COMPLETED)`), NOT `event.createdAt >= completedAt`. Burndown must evaluate pre-rollover remaining work on closure date. |
| **2. Clock Skew & Missing Baseline/Status Tags Around Activation** | `sprint.service.ts:366-408`<br>`sprint-planning.service.ts:205-215, 343-416` | `Sprint.activatedAt` uses Node `new Date()`, whereas `TaskHistory.createdAt` uses PostgreSQL `CURRENT_TIMESTAMP`; `ActivityLog(SPRINT_ACTIVATED)` lacks `baselineTaskIds`; `TaskHistory(PLANNING)` stores `{ source: "PLANNING" }` without `sprintStatus: "PLANNED" \| "ACTIVE"` or `estimateHours` snapshot. | For existing Sprints 4–5, Baseline vs Mid-Sprint Scope Change reconstruction uses `TaskHistory` chronology vs `activatedAt` and explicitly discloses clock-boundary & estimate-snapshot caveats (`DEC-058`). Future Sprints safely enrich existing JSON metadata (`baselineTaskIds`, `sprintStatus`) with zero new schema tables. |
| **3. Project-Wide History Load in `findBurndownSourceData`** | `sprint.repository.ts:532-598` | Queries **all** `SPRINT_ASSIGNED` / `SPRINT_REMOVED` / `SPRINT_MOVED` rows across the entire `projectId` before filtering `relatedTaskIds` in JS memory. | Sprint 6 cross-sprint comparison batches once per Project cleanly (single pass across all Sprints of that Project rather than N separate `findBurndownSourceData` calls). |
| **4. Estimate Coverage & Retrospective Edits** | `sprint-analytics.service.ts:158-181` | Only tasks with `estimateHours > 0` enter Burndown hours; unestimated tasks are omitted silently from hours while counted in `totalTasks`. Daily `estimateHours` snapshots do not exist. | Expose `estimateCoveragePercent` (`tasksWithEstimateCount / totalTasks`) and `limitations` explicitly on Burndown and Project/Sprint Analytics. |
| **5. Existing Burndown Route Permission** | `sprint-analytics.service.ts:314` | `getSprintProgressAndBurndownService` checks `PERMISSIONS.SPRINT_READ`. | Keep `SPRINT_READ` on `GET /api/v1/sprints/[sprintId]/burndown` for Sprint 4 compatibility; check `PERMISSIONS.REPORT_READ` on Sprint 6 `/api/v1/reports/*` endpoints. |
| **6. Duplicate HCM Timezone Logic** | `sprint-analytics.service.ts:15-17, 91-97`<br>`notification-deadline.service.ts:10-24` | Both hardcode `Asia/Ho_Chi_Minh` (`+07:00`) independently. | Consolidate into shared `src/lib/timezone.ts` and ensure exact alignment with PostgreSQL `DATE` vs `TIMESTAMP(3)` queries. |

---

## 3. Existing Functionality Reuse

Sprint 6 must strictly reuse verified modules and components instead of duplicating formulas, access checks, or UI cards:

| Existing Asset | Location | How Sprint 6 Reuses / Extends It |
|---|---|---|
| **Project Task Stats** | `src/modules/tasks/task.repository.ts` (`taskRepository.findProjectTaskStats`, `computeIsTaskOverdue`, `ProjectTaskSummaryStatsDTO`) | Reuse directly for Project-level `Total`, `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, and `Overdue` KPIs on both `/dashboard` and `/reports`. Zero formula drift. |
| **Dashboard Project Stats** | `src/modules/projects/project.repository.ts` (`projectRepository.getDashboardProjectStats`) | Reuse for workspace project counts and active project metadata on `/dashboard`; wrap in unified Dashboard Service (`src/modules/dashboard/dashboard.service.ts`) focused purely on operational navigation & KPIs (`DEC-051`). |
| **My Assigned Tasks** | `src/modules/tasks/task.service.ts` (`listMyAssignedTasksService`), `src/components/tasks/my-assigned-tasks-card.tsx` (`MyAssignedTasksCard`) | Reuse unchanged as the personal task widget on `/dashboard`. |
| **Task & Sprint Summary Cards** | `src/components/tasks/project-task-summary-card.tsx`, `src/components/sprints/project-sprint-summary-card.tsx` | Keep on `/projects/[projectId]` and adapt visual KPI card design tokens (`sky`, `amber`, `emerald`, `red`) consistently across `/dashboard` and `/reports`. |
| **Sprint Task Stats & Burndown Engine** | `src/modules/sprints/sprint.repository.ts` (`computeSprintTaskStats`), `src/modules/sprints/sprint-analytics.service.ts` (`computeSprintBurndownAnalytics`), `src/components/sprints/sprint-burndown-chart.tsx` (`SprintBurndownChart`) | Reuse `computeSprintTaskStats` for operational Active Sprint progress cards on `/dashboard` (without embedding Burndown charts on Dashboard per `DEC-051`). Reuse and extend `SprintBurndownChart` and `computeSprintBurndownAnalytics` on `/projects/[projectId]/reports` and Sprint Detail to fix completion-day rollover and surface `estimateCoveragePercent`. |
| **RBAC & Project Access Guards** | `src/app/(dashboard)/dashboard/page.tsx` (`requireActiveUserOrRedirect`), `src/modules/authorization/policy.service.ts` (`assertPermission`, `hasPermission`), `require-auth.ts` (`requireActiveUser`, `requirePermission`, `requirePermissionOrRedirect`), `src/modules/projects/project.access.ts` (`assertProjectReadAccess`, `isWorkspaceAdmin`, `parseProjectId`) | Enforce at every Server Component, Route Handler, and Service entry point. Note: `/dashboard` uses active authenticated user (`requireActiveUserOrRedirect` / `requireActiveUser`) + per-widget permission checks (`PERMISSIONS.DASHBOARD_READ` does not exist in `src/modules/authorization/constants.ts`). Extract `buildAccessibleProjectsWhere(actor)` from existing Project access logic for `/activity` and `/dashboard` Project Switcher. |
| **HCM Timezone Helpers** | `src/modules/notifications/notification-deadline.service.ts` (`BUSINESS_TIMEZONE`, `formatDateKeyInHoChiMinh`) & `sprint-analytics.service.ts` (`toHcmYmd`, `hcmEndOfDay`) | Consolidate into shared `src/lib/timezone.ts` and re-export so Deadline Reminder, Burndown, Analytics Trends, and Activity filtering share identical `Asia/Ho_Chi_Minh` day and ISO week boundaries (separately handling `TIMESTAMP(3)` UTC instants vs PostgreSQL `DATE` calendar columns). |
| **API & Validation Primitives** | `src/lib/api-response.ts` (`apiSuccess`, `apiError`), `src/lib/errors.ts` (`AppError`, etc.), `src/lib/validations/common.ts` (`uuidSchema`, shared Zod helpers), `src/components/shared/status-badge.tsx` | Reuse across all Sprint 6 Route Handlers, cursor pagination schemas, and React components. |

---

## 4. Sprint 6 Scope

### 4.1. In Scope

1. **Operational Dashboard (`/dashboard`, `GET /api/v1/dashboard`) — `DEC-051`:**
   - **Active-first Project Switcher:** Defaults to the accessible `ACTIVE` Project if present (else most recently updated accessible Project, or empty workspace state), allowing quick switch across accessible `CREATED`, `ACTIVE`, and `ARCHIVED` Projects (read-only banner for `ARCHIVED`). **No analytics date-range filter or duplicated Reports charts on `/dashboard`.**
   - **Operational KPI Cards:** `Total Tasks`, `Completed (DONE)`, `In Progress (IN_PROGRESS)`, `Waiting Review (REVIEW)`, and `Overdue Tasks` for the selected Project, each deep-linking to filtered `/projects/[projectId]/tasks?...`.
   - **Two Separate Progress Indicators:** **Task Work Progress** (`DONE / Total`) alongside **Project Timeline Progress** (elapsed days vs `Project.startDate`–`endDate`) so schedule passage is never confused with completed work.
   - **Operational Active Sprint Progress Summary:** Shows active Sprint(s) for the selected Project (`DONE/Total`, remaining calendar days, overdue badge) with navigation links to Sprint Detail and `/projects/[projectId]/reports` (no embedded Burndown chart on Dashboard).
   - **Recent Activity Feed:** Compact widget (`<= 15` latest events) scoped strictly by `DEC-052`, gated by `activity.read`, linking to `/activity`.
   - **Role-Tailored Workspace Cards:** `MyAssignedTasksCard` across roles; Admin operational shortcuts (`Pending Approval Users`, `Active/Total Projects`, `Failed Email Deliveries`) gated by `account.read` / `notification.delivery.read`.
2. **Project & Advanced Analytics (`/reports`, `/projects/[projectId]/reports`, `GET /api/v1/reports/projects/[projectId]`) — `DEC-052`..`DEC-057`:**
   - **Time Window & Bucketing (`DEC-057`):** Date presets (`7d`, `30d`, `90d`, `all`, `custom`), maximum `365`-day analytics window, automatic weekly aggregation (`Asia/Ho_Chi_Minh` ISO Monday weeks) when effective span `> 90` days, daily otherwise.
   - **Pure SVG Visualizations (`DEC-056`):** Custom lightweight accessible React + SVG + Tailwind components (`SvgLineChart`, `SvgBarChart`, `SvgStackedBarChart`, `SvgDonutChart`); zero external chart library installs.
   - **Executive Data Quality Badges:** `Estimate Coverage %`, `Deadline Overdue %`, plus explicit `limitations[]` banner (`DEC-048`).
   - **Six Management-Question-Driven Aggregate Charts (Project-level only — no per-user series inside Overview so `MEMBER` aggregate view respects `DEC-052`):**
     - **Task Completion Trend** (daily/weekly `DONE` completions & completed `estimateHours` in `Asia/Ho_Chi_Minh`).
     - **Task Status Distribution** (`TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, Backlog vs Sprint split).
     - **Priority Distribution** (`LOW`, `MEDIUM`, `HIGH`, `CRITICAL`, cross-tabulated with Open/Review/Done & Overdue).
     - **Overdue Trend & Aging Breakdown** (open overdue tasks by `1–3d`, `4–7d`, `8–14d`, `>14d` aging + Tasks missing deadline by period).
     - **Sprint Completion & Rollover Trends** (6-metric committed/scope/rollover trend across Sprints).
     - **Estimated Effort Distribution** (planned `estimateHours` by Status, Priority, and Task Assignment state: `Unassigned` / `Sole-Assigned` / `Co-Assigned`, plus explicit `Unestimated Tasks Count`).
3. **Member Contribution Report (`GET /api/v1/reports/projects/[projectId]/members` & `/projects/[projectId]/reports?tab=members`) — `DEC-047`..`DEC-050`, `DEC-052`, `DEC-054`:**
   - **Non-Additive Participation Reporting (`DEC-047`):** Explicit **Sole-Assigned (`assigneeCount === 1`)** and **Co-Assigned (`assigneeCount > 1`)** sub-counts inside assigned/completed columns, paired with a top Project Totals reconciliation banner emphasizing member rows never sum to Project totals.
   - **Planned Effort Without Time Tracking (`DEC-048`):** Shows planned `estimateHours` (`assignedEstimateHours`, `soleEstimateHours`, `coAssignedEstimateHours`, `doneEstimateHours`) strictly labeled as planned workload with member `estimateCoveragePercent` — never claiming actual hours worked.
   - **Current vs Historical Separation (`DEC-049`):** Separates current active assignments (`TaskAssignee.removedAt IS NULL`) from historical removed assignments (`TaskAssignee.removedAt IS NOT NULL`) and reports verifiable execution/review actions (`TaskHistory` progress/action counts, `TaskReview` submitted/approved/rejected counts).
   - **Departed Member Inclusion (`DEC-050`):** Includes former `ProjectMember` rows (`leftAt IS NOT NULL`) with clear `"Đã rời Project"` badge and UI toggle filter.
   - **Role Visibility Isolation (`DEC-052`):** `ADMIN`, `INSTRUCTOR`, and `LEADER` view all Project contributors; `MEMBER` receives `scope: "SELF_ONLY"` containing ONLY their own contribution row alongside Project Total reconciliation headers (never peer member rows or cross-member trend series).
4. **Sprint Analytics Enhancements (`GET /api/v1/reports/projects/[projectId]/sprints` & `/api/v1/sprints/[sprintId]/burndown`) — `DEC-058`:**
   - Reconstructs all 6 distinct Sprint commitment & scope metrics (**Baseline Commitment**, **Scope Added**, **Scope Removed**, **Completed Tasks**, **Rolled Over to Backlog**, **Rolled Over to Another Sprint**) across Sprints using verified `TaskHistory` + `ActivityLog` metadata without adding a snapshot table (`DEC-058`).
   - Fixes completion-day Burndown rollover rendering prior to `Sprint.completedAt` and reports `baselineHours`, `currentScopeHours`, and `estimateCoveragePercent`.
5. **Unified Activity History (`/activity`, `GET /api/v1/activity`) — `DEC-052`, `DEC-055`:**
   - Schema update adding nullable indexed `ActivityLog.projectId`, safe idempotent SQL backfill, call-site population across all 19 project-scoped `activityLog.create` calls, and composite cursor indexes (`DEC-055`).
   - Keyset cursor pagination `(createdAt DESC, source DESC, id DESC)` pushing seeks into `ActivityLog` and `TaskHistory` independently.
   - Strict `DEC-052` filtering: `ADMIN` sees accessible Projects + workspace system events; `LEADER`/`INSTRUCTOR` see accessible Projects; `MEMBER` sees only events performed by themselves (`actorId === memberId`) or on Tasks where they have an active or historical `TaskAssignee` row.

### 4.2. Explicitly Out of Scope (Sprint 6)

- Actual time tracking / timesheets / `actualHours` input (`DEC-004`, `DEC-048`).
- Story Points or custom Scrum points (`DEC-003`, `DEC-033`).
- Automated individual ranking, leaderboards, star ratings, GPA/KPI scoring, or AI employee evaluation (`Project-Scope-and-Roadmap.md`).
- Payroll, attendance, or HR evaluation workflows.
- **CSV, PDF, or Excel file exports** (`DEC-054` — view-only UI + JSON REST APIs in Sprint 6; defer exports to post-MVP).
- **External charting libraries** such as Recharts, Chart.js, or ECharts (`DEC-056`).
- **Database Sprint Snapshot tables** (`DEC-058` — deferred past MVP unless historical precision gaps mandate it later).
- Editing or deleting historical `TaskHistory`, `AuditLog`, or `ActivityLog` records (immutable audit trails).

---

## 5. Functional Requirements

### 5.1. Dashboard (`FR-DASH-601` – `FR-DASH-606`, aligns with SRS `FR-DASH-001`..`005`, `UC-030`, `DEC-051`)

- **FR-DASH-601 (Active-First Project Switcher):** Every active authenticated user (`requireActiveUserOrRedirect` / `requireActiveUser`, matching `src/app/(dashboard)/dashboard/page.tsx`) accessing `/dashboard` sees accessible Projects in a compact Project Switcher. If an `ACTIVE` Project exists and is accessible, it is selected by default; otherwise, the most recently updated accessible Project is selected (or an empty workspace state if none). Users may switch to any accessible `CREATED` or `ARCHIVED` Project (`DEC-053` read-only indicator). Dashboard does **not** render analytics timeframe presets (`7d`/`30d`/`90d`) (`DEC-051`).
- **FR-DASH-602 (Task Status & Overdue KPIs):** When user has `project.read` + `task.read` (or Project member read access), display operational KPIs — Total Tasks, Completed (`DONE`), In-Progress (`IN_PROGRESS`), Waiting for Review (`REVIEW`), and Overdue (`status !== DONE && deadline < now`) — for the selected Project, each deep-linking to `/projects/[projectId]/tasks?...`.
- **FR-DASH-603 (Separate Work Progress vs Timeline Progress):** Display **Task Work Progress** (`DONE / Total`) separately from **Project Timeline Progress** (elapsed calendar days vs `Project.startDate`–`endDate`, bounded `[0, 100]`) so schedule elapsed time is never mistaken for completed deliverables (`DEC-051`).
- **FR-DASH-604 (Operational Active Sprint Summary):** Display operational summary cards for currently `ACTIVE` Sprint(s) of the selected Project (`DEC-029` allows multiple `ACTIVE` Sprints), gated by `sprint.read`, showing Sprint name, `DONE/Total`, remaining days, and overdue count, with links to Sprint Detail and `/projects/[projectId]/reports` (**no embedded Burndown chart preview on `/dashboard`**).
- **FR-DASH-605 (Recent Activity Feed):** Display up to `15` latest unified events (`ActivityLog` + `TaskHistory`) scoped by `DEC-052`, gated by `activity.read` (gracefully hidden if actor lacks `activity.read`), linking to `/activity`.
- **FR-DASH-606 (Role-Tailored Workspace Cards):** Render `MyAssignedTasksCard` across roles (when `task.read` is held); render Admin workspace summary cards (`Pending Approval Users`, `Active/Total Projects`, `Failed Email Deliveries`) conditionally on `account.read`, `project.read`, and `notification.delivery.read`.

### 5.2. Member Contribution Report (`FR-MCR-601` – `FR-MCR-606`, aligns with `UC-031`, `DEC-047`..`DEC-050`, `DEC-052`, `DEC-054`)

- **FR-MCR-601 (Member Roster Consolidation & Role Isolation):** Aggregate Project participants from `ProjectMember` (current & departed), `Project.leaderId`/`instructorId`, and historical task actors (`TaskAssignee`, `TaskHistory.actorId`, `TaskReview`). Apply strict `DEC-052` authority check: `ADMIN`, `INSTRUCTOR` (assigned), and `LEADER` receive full contributor roster (`scope: "PROJECT_FULL"`); `MEMBER` receives `scope: "SELF_ONLY"` containing strictly their own row + Project Totals reconciliation header (never peer rows).
- **FR-MCR-602 (Current vs Historical Assignment Separation — `DEC-049`):** Separately report:
  - Current active task assignments (`TaskAssignee.removedAt IS NULL`) broken down by `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, `Overdue`.
  - Historical removed assignments (`TaskAssignee.removedAt IS NOT NULL` — tasks unassigned or reassigned away from the member).
- **FR-MCR-603 (Non-Additive Sole vs Co-Assigned Reporting — `DEC-047`):** Explicitly break out **Sole-Assigned (`activeAssigneeCount === 1`)** vs **Co-Assigned (`activeAssigneeCount > 1`)** counts for assigned and completed tasks, plus `Sole Done Estimate Hours` vs `Co-Assigned Done Estimate Hours`. Always render a reconciliation callout stating Project Totals (`Total Project Tasks`, `Total Project Done`, `Total Project Planned Hours`) vs member participation so readers never sum member rows.
- **FR-MCR-604 (Planned Workload & Verifiable Action Counters — `DEC-048`, `DEC-049`):** Display `estimateHours` strictly as **Planned Workload (`Khối lượng ước tính`)** with per-member `estimateCoveragePercent`, alongside verifiable immutable log counters within the date range: `TaskHistory` updates (`PROGRESS_UPDATED`, `TOTAL_ACTIONS`) and `TaskReview` counts (`Submitted`, `Approved`, `Rejected`). Zero claim that logs measure actual hours or code complexity.
- **FR-MCR-605 (Departed Member Attribution — `DEC-050`):** Include `ProjectMember` rows with `leftAt IS NOT NULL` tagged `"Đã rời Project (ngày ...)"` plus UI toggle filter (`Hiển thị thành viên đã rời`, enabled by default for full historical transparency).
- **FR-MCR-606 (Objective Presentation & View-Only Constraint — `DEC-054`):** Strictly forbid ranking numbers, medals, productivity indices, or automated performance verdicts. Omit CSV/PDF/Excel download buttons (`DEC-054`).

### 5.3. Sprint Analytics & Commitment Reconstruction (`FR-SPR-601` – `FR-SPR-605`, aligns with `UC-031`, Sprint 4 `DEC-033`, `DEC-058`)

- **FR-SPR-601 (Six-Metric Sprint Commitment & Rollover Semantics):** Every Sprint (`ACTIVE`, `COMPLETED`, `CANCELLED`, plus `PLANNED` as pre-activation preview) MUST cleanly separate six distinct metrics — **never mixing baseline commitment with scope changes**:
  1. **`baselineCommitmentCount` / `baselineCommitmentHours`:** Tasks present in the Sprint at the exact activation instant (`Sprint.activatedAt`). (For `PLANNED` Sprints, labeled `"Planned Queue (Chưa kích hoạt)"` with `baseline = 0`).
  2. **`scopeAddedCount` / `scopeAddedHours`:** Tasks moved/assigned into the Sprint strictly *after* `Sprint.activatedAt` and before closure/now.
  3. **`scopeRemovedCount` / `scopeRemovedHours`:** Tasks moved out of the Sprint to Backlog or another Sprint *after* `Sprint.activatedAt` and *before* closure (excluding completion/cancellation rollover events!).
  4. **`completedTasksCount` / `completedEstimateHours` (split into Committed Completed + Added Scope Completed, matching `committed + added - removed` reconciliation):** Tasks whose final `status = DONE` while residing in this Sprint during the Sprint execution window.
  5. **`rolledOverToBacklogCount` / `rolledOverToBacklogHours`:** Unfinished Tasks moved to Backlog (`toSprintId = null`) *specifically by* Sprint completion (`completeSprintService`) or Sprint cancellation (`cancelSprintService`).
  6. **`rolledOverToSprintCount` / `rolledOverToSprintHours`:** Unfinished Tasks moved to another Sprint (`toSprintId != null`) *specifically by* Sprint completion (`completeSprintService`).
- **FR-SPR-602 (Verified Reconstruction Algorithm & Repository Gap Disclosure — §3.1):**
  Based on direct inspection of `sprint.service.ts`, `sprint-planning.service.ts`, `sprint-completion.service.ts`, and `task.service.ts`:
  - Tasks always enter the Project in Backlog (`sprintId = null`, verified in `task.service.ts`). Only 3 flows mutate `Task.sprintId`: `sprint-planning.service.ts` (`source: "PLANNING"`), `sprint-completion.service.ts` (`source: "SPRINT_COMPLETION", completedSprintId`), and `cancelSprintService` (`source: "SPRINT_CANCELLED"`).
  - **Gap 1 — Completion Rollover Timestamp Ordering (`sprint-completion.service.ts:276-339`):** `appendManyTaskHistories` inserts rollover `TaskHistory` rows using PostgreSQL `CURRENT_TIMESTAMP` *inside the transaction BEFORE* `const now = new Date()` updates `Sprint.completedAt` (`TaskHistory.createdAt <= Sprint.completedAt`). Therefore, timestamp comparison (`createdAt >= completedAt`) **cannot** distinguish completion rollovers from normal mid-sprint removals! **Required Rule:** Rollover detection MUST explicitly filter `TaskHistory` rows where `metadata.source === "SPRINT_COMPLETION"` AND `metadata.completedSprintId === sprint.id` (for Backlog vs Another Sprint disposition), and `metadata.source === "SPRINT_CANCELLED"` for cancellation returns.
  - **Gap 2 — Pre-Activation Baseline & Clock Skew:** `activateSprintService` writes `ActivityLog(SPRINT_ACTIVATED)` without storing `baselineTaskIds`, and `sprint-planning.service.ts` writes `metadata: { source: "PLANNING" }` without `sprintStatus`. Reconstructing `Baseline Commitment` for existing Sprint 4/5 Sprints replays `TaskHistory` (`SPRINT_ASSIGNED`, `SPRINT_REMOVED`, `SPRINT_MOVED`) against `Sprint.activatedAt`. Because `TaskHistory.createdAt` uses PostgreSQL `CURRENT_TIMESTAMP` while `Sprint.activatedAt` uses app JS `new Date()`, a sub-second DB/App clock skew near `activatedAt` could shift an activation-adjacent move between `Baseline` and `Scope Added/Removed`.
  - **Gap 3 — Mutable `estimateHours` & Pre-Activation `DONE` Tasks:** `estimateHours` sums use current `Task.estimateHours` (there are no periodic estimate snapshots, though `INFO_UPDATED` diffs exist), and Tasks completed while a Sprint was still `PLANNED` (`completedAt < activatedAt`) sit outside active execution.
  - **Smallest Safe Solution (`DEC-058` — Zero Snapshot Table):** (a) Use closure metadata (`source = "SPRINT_COMPLETION"` + `completedSprintId`) + chronological replay with current `Task.estimateHours` for historical Sprint 4/5 Sprints, transparently flagging pre-enrichment Sprints via `reconstructionConfidence: "RECONSTRUCTED_FROM_LOGS"` + UI limitation note (`estimateHours` reflects latest value); (b) During Package 3, enrich `activateSprintService` `ActivityLog(SPRINT_ACTIVATED)` JSON metadata minimally with `{ baselineTaskIds, baselineTaskCount, baselineEstimateHours }` and add `sprintStatus` to `sprint-planning.service.ts` `TaskHistory` metadata — giving **exact baseline fidelity for all newly activated Sprints** with zero extra database tables (`DEC-058`). (Existing Sprint 4/5 log-replay fallback stays intact for earlier Sprints.)
- **FR-SPR-603 (Sprint Completion Trend):** Render multi-sprint Pure SVG stacked bar/line trend showing `Baseline Commitment`, `Scope Added`, `Completed`, and `Rolled Over` across Sprints in chronological order to reveal throughput stability and scope creep.
- **FR-SPR-604 (Burndown Rollover Integrity Fix):** Ensure `computeSprintBurndownAnalytics` excludes same-day `SPRINT_COMPLETION` / `SPRINT_CANCELLED` `TaskHistory` moves when reconstructing end-of-day remaining hours on `completedAt`, and expose `baselineHours`, `currentScopeHours`, and `estimateCoveragePercent`.
- **FR-SPR-605 (Insufficient Data Handling):** Preserve Sprint 4 behavior: when a Sprint has `0` tasks or `0` tasks with `estimateHours > 0`, show structured empty/warning alert (`hasEstimateData: false`) instead of fabricated curves.

### 5.4. Advanced Analytics (`FR-ANA-601` – `FR-ANA-606`, aligns with `DEC-052`, `DEC-056`, `DEC-057`)

Every chart and metric in Sprint 6 answers a specific management question (no purely decorative visualizations) and uses Pure React + SVG + Tailwind components (`DEC-056`) respecting the selected time window (`DEC-057`):

| Analytic Module | Management Question Answered | Data Source & Calculation |
|---|---|---|
| **FR-ANA-601: Task Completion Trend** | *"Are tasks reaching `DONE` at a steady pace over time, or stalling until Sprint end?"* | Daily (`<= 90d`) or ISO weekly (`> 90d`, Monday start) bucketed count of Tasks where `status = DONE` and `completedAt` falls in window (`Asia/Ho_Chi_Minh`), plus cumulative `DONE` count and completed `estimateHours`. |
| **FR-ANA-602: Task Status Distribution** | *"Where is work currently piling up (To Do backlog bottleneck vs Review bottleneck)?"* | Exact task counts & percentages across `TODO`, `IN_PROGRESS`, `REVIEW`, `DONE`, filterable by Sprint or Project-wide, plus separate Backlog (`sprintId IS NULL`) vs Assigned-to-Sprint badge. |
| **FR-ANA-603: Priority Distribution** | *"Are `HIGH` and `CRITICAL` tasks progressing on time or accumulating risk?"* | Stacked distribution across `LOW`, `MEDIUM`, `HIGH`, `CRITICAL` cross-tabulated with Status (`Open vs Review vs Done`) and `Overdue` count per priority tier. |
| **FR-ANA-604: Overdue Trend & Aging** | *"Is schedule slip growing worse, and how severely overdue are current tasks?"* | (1) **Overdue Aging Breakdown** of currently unfinished overdue tasks (`1–3 days`, `4–7 days`, `8–14 days`, `>14 days` past deadline); (2) **Deadline Slip Trend** showing daily/weekly buckets of tasks whose `deadline` fell in that bucket and missed completion by deadline (`completedAt > deadline` or still `!== DONE` at end of bucket / `now`). |
| **FR-ANA-605: Sprint Completion Trends** | *"How reliably does the team finish committed Sprint scope without rolling work over or bloating mid-sprint?"* | Cross-sprint summary of `Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed`, and `Rolled Over` tasks & hours (`FR-SPR-601`/`603`). |
| **FR-ANA-606: Estimated Effort Distribution** | *"How is planned effort (`estimateHours`) concentrated across Status, Priority, and Task Assignment coverage, and how much work is unestimated?"* | Sum of `estimateHours` grouped strictly at **Project aggregate level** (`By Status`, `By Priority`, and `By Assignment State: Unassigned / Sole-Assigned / Co-Assigned`), paired with **Unestimated Tasks Count** (`estimateHours IS NULL`). **Never includes per-user series** so aggregate analytics comply cleanly with `DEC-052`. |

### 5.5. Activity History (`FR-ACT-601` – `FR-ACT-605`, aligns with SRS `FR-ACT-001`..`004`, `UC-032`, `DEC-052`, `DEC-055`)

- **FR-ACT-601 (Unified Chronological Timeline & Cursor Pagination):** Present reverse-chronological entries merging `ActivityLog` (`source = "WORKSPACE"`) and `TaskHistory` (`source = "TASK"`) ordered strictly by deterministic tuple **`(createdAt DESC, source DESC, id DESC)`** using opaque keyset cursors (`nextCursor`, `hasNextPage`, `pageSize`) rather than `OFFSET`/`LIMIT`.
- **FR-ACT-602 (Multi-Dimensional Filtering):** Filter by `projectId`, `source` (`ALL | WORKSPACE | TASK`), `entityType` (`Task | Sprint | Document | Project | User | Role | ProjectTemplate`), `userId` (Actor), `action`, `from`–`to` (`Asia/Ho_Chi_Minh` calendar dates), and keyword `search` (matching description/title).
- **FR-ACT-603 (Project, Workspace & Member Visibility Scoping — `DEC-052`):**
  - `ADMIN`: All accessible Projects plus workspace system events (`ActivityLog.projectId IS NULL`: `User`, `Role`, `ProjectTemplate`).
  - `INSTRUCTOR` (assigned) & `LEADER`: All `ActivityLog` and `TaskHistory` events belonging to accessible Projects (`projectId IN accessibleProjectIds`). Zero `projectId IS NULL` system events unless user holds Admin permission.
  - `MEMBER`: Events within accessible Projects where **either** `actorId === member.id` (their own action) **or** target is a Task (`entityType === "Task"` / `source === "TASK"`) where the member holds a current or historical `TaskAssignee` row (`taskId IN memberAssignedTaskIds`). Never receives peer `ProjectMember` changes, Document events authored by others, or Admin system logs.
- **FR-ACT-604 (Deep Links & Context):** Every entry renders actor name, Vietnamese human-readable summary, timestamp formatted in `Asia/Ho_Chi_Minh`, entity badge, and navigable link when target Project/Sprint/Task exists.
- **FR-ACT-605 (Read-Only Immutability):** Zero UI or API endpoints to edit, delete, or purge `ActivityLog` or `TaskHistory`.

---

## 6. Business Rules

1. **BR-S6-001 (Timezone Standard & PostgreSQL Column Semantics):** All date-range query inputs (`YYYY-MM-DD`), daily/weekly trend buckets, and UI timestamp formatting MUST normalize to **`Asia/Ho_Chi_Minh` (`UTC+07:00`)**, consistent with Sprint 4 Burndown (`BURNDOWN_TIMEZONE`) and Sprint 5 Deadline Reminder (`BUSINESS_TIMEZONE`):
   - **Range Filters (`WHERE`):** Convert calendar inputs using `new Date("${from}T00:00:00.000+07:00")` and `new Date("${to}T23:59:59.999+07:00")` so Prisma/PostgreSQL compares UTC instants directly against indexed columns without wrapping columns in functions.
   - **Analytics Window Caps (`DEC-057`):** Presets `7d`, `30d`, `90d`, `all`, `custom`. Any custom or `"all"` effective span is capped at **365 days** (`max 365d` ending at `to` or `today`). Effective spans `<= 90` days bucket **daily**; spans `> 90` days automatically bucket **weekly** (ISO Monday start in `Asia/Ho_Chi_Minh`).
   - **PostgreSQL `TIMESTAMP(3)` vs `DATE` SQL Rule:** All instant columns (`Task.createdAt`, `Task.completedAt`, `Task.deadline`, `TaskHistory.createdAt`, `ActivityLog.createdAt`, `Project.startDate/endDate`, `Sprint.activatedAt/completedAt/cancelledAt`, `TaskReview.reviewedAt`) are stored as PostgreSQL `TIMESTAMP(3)` (**`TIMESTAMP WITHOUT TIME ZONE`** containing UTC values). In raw SQL aggregation, **NEVER** apply single `col AT TIME ZONE 'Asia/Ho_Chi_Minh'`; **ALWAYS** use double conversion `(("col" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')` before `::date` or `date_trunc('week', ...)` (verified parity with JS `Asia/Ho_Chi_Minh` Monday weeks). By contrast, `Sprint.startDate` and `Sprint.endDate` are PostgreSQL `DATE` calendar columns (`YYYY-MM-DD`): read/format directly with `formatSprintDateYmd` and never timezone-shift them.
2. **BR-S6-002 (Task Progress vs Project Timeline Progress — `DEC-051`):** Consistent with `DEC-033`, Task completion rate is `total === 0 ? 0 : Math.round((doneCount / total) * 100)`. Project *Work Progress* equals Project Task completion % (`doneCount / totalTasks`); Project *Timeline Progress* (elapsed days relative to `Project.startDate`–`endDate`, bounded `[0, 100]`) is displayed separately so calendar elapsed time is never mistaken for deliverable progress.
3. **BR-S6-003 (Overdue Classification):** Consistent with `computeIsTaskOverdue`, a Task is currently overdue iff `status !== TaskStatus.DONE && deadline.getTime() < now.getTime()`. Historical deadline slips track `completedAt !== null && completedAt > deadline` (or uncompleted past deadline).
4. **BR-S6-004 (Objectivity & Non-Equivalence Principle — `DEC-048`):** Reports MUST NOT display any composite "Productivity Score", leaderboard rank, medal, or automated verdict. Completed task count does not reflect complexity, and `estimateHours` strictly represents initial/latest planned effort (never `actualHours`).
5. **BR-S6-005 (Multi-Assignee & Departed Member Preservation — `DEC-047`, `DEC-049`, `DEC-050`):**
   - Multi-assignee tasks MUST break out **Sole-Assigned** and **Co-Assigned** counts separately alongside a Project Total reconciliation header, never claiming member rows sum to Project Totals (`DEC-047`).
   - Removed `TaskAssignee` rows (`removedAt IS NOT NULL`) and departed `ProjectMember` rows (`leftAt IS NOT NULL`) remain preserved and queryable as historical participation with clear `"Đã rời Project"` status labels.
6. **BR-S6-006 (Archived Project Historical Integrity — `DEC-053`):** Projects with `status = ARCHIVED` remain 100% readable across Dashboard Project Switcher, Reports, Member Contribution, Sprint Analytics, and Activity History for authorized users (`assertProjectReadAccess`), accompanied by a `"Project đã lưu trữ (Chỉ đọc)"` banner.
7. **BR-S6-007 (Data Quality & Pure SVG Disclosure — `DEC-056`, `DEC-058`):** Every analytics payload includes `dataQuality` (`totalTasks`, `tasksWithEstimateCount`, `estimateCoveragePercent`, `hasDateFilteredResults`, `limitations: string[]`) plus Sprint `reconstructionConfidence`. Charts with `0` matching rows render informative empty states in Pure SVG/Tailwind without extra libraries.
8. **BR-S6-008 (Server-Side Authorization First — `DEC-052`):** All queries enforce verified Sprint 1–5 auth helpers (`requireActiveUser` / `requirePermission(REPORT_READ)` / `requirePermission(ACTIVITY_READ)` + `assertProjectReadAccess` + `MEMBER` contribution/activity scoping) on the server before querying underlying metrics. **Do not invent or require a non-existent `dashboard.read` permission.**

---

## 7. Confirmed Product Decisions & Remaining Technical Uncertainties

All **12 Open Questions (`OQ-601`–`OQ-612`)** have been **reviewed and confirmed by the Product Owner** and recorded in [`markdown/DECISION-LOG.md`](file:///d:/Akatsuki%20Yui/markdown/DECISION-LOG.md) as **`DEC-047` – `DEC-058`** (Option A selected across all 12 items). Remaining engineering/data uncertainties discovered during code verification are explicitly isolated in **Section 7.13**.

### OQ-601 — Attributing Tasks with Multiple Assignees (`TBD-029` / `OI-013`)

1. **Issue:** `Task` supports `0..N` active `TaskAssignee` rows (`BR-TASK-006`), while `Task.status` and `Task.estimateHours` are shared at the Task level. If a Task with `estimateHours = 8h` has 2 active assignees and moves to `DONE`, naive per-member counting credits `1 Task / 8h` to each member (`2 Tasks / 16h` across 2 rows), inflating team totals relative to `Project Total Done = 1 Task / 8h`.
2. **Options Evaluated:**
   - **Option A (Non-Additive Participation Reporting + Co-Assigned Split Columns):** Count each assignee's participated tasks transparently (`Assigned`, `Done`, `In Progress`, `Review`, `Overdue`) alongside explicit sub-counts `Sole-Assigned` vs `Co-Assigned`, while omitting any cross-member sum row and displaying the authoritative **Project Total** in a summary header with an explicit non-additive banner (`"1 Task nhiều người làm được ghi nhận cho từng người tham gia; tổng các hàng không cộng dồn bằng tổng Project"`).
   - **Option B (Strict Fractional Split `1/N`):** Divide task credit and `estimateHours` evenly (`1 / activeAssigneeCount`).
   - **Option C (Dual Metrics — Participation + Equal-Weighted Share):** Show integer `Participated Tasks (Active)` alongside `Weighted Share (1/N)`.
3. **Rationale:** Zero fractional UX confusion (`0.33 tasks`), easiest to audit against Kanban/Task lists, naturally supports multi-person collaboration without pretending equal fractional work.
4. **Confirmed Decision:** **Option A — Non-Additive Participation Reporting (`Sole-Assigned` & `Co-Assigned` sub-counts, Project Totals reconciliation header).**
5. **Status:** **CONFIRMED — `DEC-047`** (resolves `OI-013` / `TBD-029`).

---

### OQ-602 — Actual Time vs Estimated Hours in Member Contribution & Analytics (`DEC-004` / `TBD-014`)

1. **Issue:** `Task.estimateHours` (`Float?`, optional) exists, while `actualHours` / time-logging does **not** exist (`DEC-004`). Showing `estimateHours` per member risks managers misinterpreting planned estimate as actual hours worked, while introducing `actualHours` adds mid-MVP workflow friction.
2. **Options Evaluated:**
   - **Option A (No Actual Time in Sprint 6; Controlled Planned Estimate Workload Only):** Do NOT add `actualHours`. Use `estimateHours` for **Sprint Burndown** and **Project Effort Distribution**, and in Member Contribution show **Estimated Workload (`estimateHours`)** strictly labeled `"Ước lượng kế hoạch (không phải giờ làm thực tế)"` accompanied by `estimateCoveragePercent`.
   - **Option B (Introduce Optional `actualHours` Logging):** Rejected (scope creep, zero historical backfill).
   - **Option C (Exclude `estimateHours` from Member Contribution):** Rejected (hides planned workload disparity).
3. **Confirmed Decision:** **Option A — Controlled Planned Estimate Workload Only, explicit limitations & coverage % (`DEC-004` reaffirmed).**
4. **Status:** **CONFIRMED — `DEC-048`** (reaffirms `DEC-004`, resolves `TBD-014`).

---

### OQ-603 — Current Assignment vs Historical Reassignment & Action Credit

1. **Issue:** Tasks frequently change hands (`TaskAssignee.removedAt` is set on unassign, and `TaskHistory` records `PROGRESS_UPDATED`, `REVIEW_SUBMITTED`, `REVIEW_APPROVED`, `REVIEW_REJECTED`). For instance, Member A may advance a Task to `REVIEW` and later be unassigned before Member B resolves feedback and completes it (`DONE`).
2. **Options Evaluated:**
   - **Option A (Explicit Split: Current State vs Historical Reassignment + Verifiable Actions):** Separate each member's row into: (1) **Current Assignments** (`TaskAssignee.removedAt IS NULL`: `To Do`, `In Progress`, `Review`, `Done`, `Overdue`), (2) **Historical Unassigned (`removedAt IS NOT NULL`)** count, and (3) **Verified Action Counters** (`TaskHistory` progress updates, `TaskReview` submitted/approved/rejected) within date range without claiming actual effort.
   - **Option B (Current Assignees Only):** Rejected (erases pre-reassignment help).
   - **Option C (Credit All Ever-Assigned Users Equally on `DONE`):** Rejected (over-credits brief assignments).
3. **Confirmed Decision:** **Option A — Preserve current and historical assignments separately and report verifiable `TaskHistory`/`TaskReview` actions without claiming they measure actual effort.**
4. **Status:** **CONFIRMED — `DEC-049`**.

---

### OQ-604 — Visibility & Attribution of Members Who Left a Project (`ProjectMember.leftAt IS NOT NULL`)

1. **Issue:** A member removed from a Project keeps a `ProjectMember` row with `leftAt != null`, may still hold active `TaskAssignee` (`removedAt: null`) on already-`DONE` tasks (`taskAssignmentGuard`), and owns historical `TaskHistory`/`TaskReview` events.
2. **Options Evaluated:**
   - **Option A (Include Former Members by Default with `"Đã rời Project"` Badge + Toggle Filter):** Show departed members in Member Contribution Reports by default, tagged `"Đã rời Project (DD/MM/YYYY)"`, with a `"Chỉ hiển thị thành viên hiện tại"` (`includeRemoved=false`) toggle filter.
   - **Option B (Hide by Default):** Rejected (obscures past contributors during retrospectives).
   - **Option C (Anonymized Pool Row):** Rejected (breaks Instructor/Leader traceability).
3. **Confirmed Decision:** **Option A — Include former Project Members in historical contribution reports (`includeRemoved=true` default with toggle) and clearly label membership status (`"Đã rời Project"`).**
4. **Status:** **CONFIRMED — `DEC-050`**.

---

### OQ-605 — Dashboard Focus & Project Progress Formula (`TEST-008` / `TBD-UC-017`)

1. **Issue:** Per `BR-PROJ-004` (`Project_single_active_idx`), at most one Project is `ACTIVE` at a time, while `CREATED` and `ARCHIVED` projects also exist. Dashboard must remain operational and avoid conflating elapsed calendar time with completed Task deliverables, or duplicating full Reports charts.
2. **Options Evaluated:**
   - **Option A (Active-First Operational Dashboard + Project Switcher + Separate Work vs Timeline Progress):** Default `/dashboard` KPIs, Active Sprint operational summary, and Recent Activity to the accessible `ACTIVE` Project (with Project Switcher across accessible `ACTIVE`/`CREATED`/`ARCHIVED` Projects). Separate **Project Work Progress (`DONE / Total Tasks`, `DEC-033`)** from **Project Timeline Progress (`StartDate -> EndDate`)**. Keep `/dashboard` concise and operational (do not duplicate analytics charts or timeframe selectors from `/reports`).
   - **Option B (Workspace-Wide Unfiltered Task Sums):** Rejected (old `ARCHIVED` tasks pollute daily focus).
   - **Option C (`estimateHours`-Weighted Project Progress):** Rejected (`estimateHours` is optional/`null`).
3. **Confirmed Decision:** **Option A — Active-first Operational Dashboard with Project Switcher and separated Task Work Progress vs Project Timeline Progress (no Reports duplication inside Dashboard).**
4. **Status:** **CONFIRMED — `DEC-051`** (resolves `TEST-008` / `TBD-UC-017`).

---

### OQ-606 — Role Scope Differences: `MEMBER` vs `LEADER` vs `INSTRUCTOR` vs `ADMIN` (`TBD-030` / `Authorization-Design.md`)

1. **Issue:** `Authorization-Design.md` and `Business-Rules-and-Workflows.md` mark `report.read` and `activity.read` for `MEMBER` as **"Limited / own scope"**, whereas `constants.ts` currently assigns `report.read` and `activity.read` to `ADMIN`, `INSTRUCTOR`, `LEADER`, and `MEMBER`, and `assertProjectReadAccess` grants full project visibility to active `ProjectMember`s.
2. **Options Evaluated:**
   - **Option A (Enforce `MEMBER` Own-Scope Privacy on Peer Contributions & Personal/Assigned Activity):**
     - `ADMIN`: Full access across all Projects & workspace system logs (`projectId IS NULL`).
     - `INSTRUCTOR`: Full read-only access to Project Reports, Member Contribution, Sprint Analytics, and Activity Logs on Projects where assigned (`instructorId` / `ProjectMember`).
     - `LEADER`: Full access on accessible Projects (`leaderId` / `ProjectMember`).
     - `MEMBER`: Can view **Project-level aggregate KPIs, Project-aggregate Advanced Analytics charts (Status, Priority, Sprint, Overdue, Aggregate Effort), and Sprint Burndown** for accessible Projects, **HOWEVER** in Member Contribution receives **strictly their own row (`scope: "SELF_ONLY"`) + Project Totals context** and in Activity (`/activity` & `/dashboard` Recent Activity) sees **only events performed by self (`actorId = self`) or targeting Tasks currently/historically assigned to self** (never peer contribution rows, unrelated member events, or Admin system logs).
   - **Option B (Full Project Transparency for Members):** Rejected (`Authorization-Design.md` peer-privacy requirement).
   - **Option C (Revoke `report.read` from `MEMBER`):** Rejected (removes Project/Sprint visibility already seeded).
3. **Confirmed Decision:** **Option A — Members see Project-level aggregate analytics (`MEMBER` project charts must avoid per-user breakdowns) but strictly their own contribution row and self/assigned-task activity.**
4. **Status:** **CONFIRMED — `DEC-052`** (resolves `TBD-030` reporting scope).

---

### OQ-607 — Archived Projects in Reports, Dashboard & Activity History

1. **Issue:** Sprint 2 locked `ARCHIVED` projects for mutations while preserving historical data and allowing authorized read access via `assertProjectReadAccess`.
2. **Options Evaluated:**
   - **Option A (Full Read-Only Historical Inspection on `ARCHIVED` Projects):** Keep `ARCHIVED` Projects selectable in `/reports`, `/projects/[projectId]/reports`, `/activity`, and `/dashboard` Project Switcher with a clear `"Project đã lưu trữ (Chỉ đọc)"` banner.
   - **Option B (Hide by Default Behind Opt-In Toggle):** Rejected (extra friction for post-project retrospectives).
   - **Option C (Admin/Instructor-Only Archive Reporting):** Rejected (blocks Leaders/Members from viewing completed history).
3. **Confirmed Decision:** **Option A — Authorized users (`assertProjectReadAccess`) can inspect `ARCHIVED` Projects in read-only mode across Dashboard switcher, Reports, and Activity.**
4. **Status:** **CONFIRMED — `DEC-053`**.

---

### OQ-608 — Report Exportability (`View-Only` vs CSV/PDF/Excel)

1. **Issue:** `Project-Scope-and-Roadmap.md` lists PDF/Excel export outside MVP scope; deciding whether Sprint 6 adds lightweight CSV export or remains view-only UI + JSON APIs.
2. **Options Evaluated:**
   - **Option A (View-Only Reports + JSON APIs in Sprint 6):** Defer all CSV, PDF, and Excel exports out of Sprint 6. Keep clean view-only UI tables and JSON `/api/v1/reports/*` APIs.
   - **Option B (Add UTF-8 CSV Export Endpoints):** Rejected by PO for Sprint 6 MVP (`OQ-608`).
   - **Option C (Full PDF + XLSX Export):** Rejected (heavy dependencies & out of scope).
3. **Confirmed Decision:** **Option A — View-only reports in Sprint 6; defer CSV, PDF, and Excel exports.**
4. **Status:** **CONFIRMED — `DEC-054`**.

---

### OQ-609 — Unifying `ActivityLog` and `TaskHistory` (`ActivityLog.projectId` Schema Decision)

1. **Issue:** Task events live in `TaskHistory`, while Project/Sprint/Document/Member/Account events live in `ActivityLog`, and `ActivityLog` lacks a `projectId` column (`Sprint`/`Document` use `metadata.projectId`; `Project` uses `entityId`; `User`/`Role`/`Template` have `null`).
2. **Options Evaluated:**
   - **Option A (Add Nullable `ActivityLog.projectId`, Backfill, Indexes, Update Call Sites, and Unify Feeds):** Add nullable indexed `projectId String? @db.Uuid` on `ActivityLog`, safely backfill existing rows in migration SQL, populate `projectId` across all project-scoped `activityLog.create` call sites, add composite cursor/reporting indexes, and unify `ActivityLog` + `TaskHistory` in `src/modules/activity/`.
   - **Option B (Zero-Schema JSONB Query Union):** Rejected (unindexed `->>'projectId'` JSONB scans degrade at scale).
   - **Option C (`ActivityLog` Only on `/activity`):** Rejected (misses all Task lifecycle events).
3. **Confirmed Decision:** **Option A — Add nullable indexed `ActivityLog.projectId`, idempotent backfill, update 6 project-scoped service files (19 call sites), add cursor/reporting indexes, and unify `ActivityLog` + `TaskHistory`.**
4. **Status:** **CONFIRMED — `DEC-055`**.

---

### OQ-610 — Charting Implementation: `Pure SVG` vs `Recharts`

1. **Issue:** `PROJECT-IMPLEMENTATION-ROADMAP.md` & `UI-UX-Design.md` mention `Recharts`, whereas `package.json` does **not** include `recharts` and Sprint 4 shipped pure React + SVG (`SprintBurndownChart`) under React 19 / Next 16.
2. **Options Evaluated:**
   - **Option A (Pure React + SVG + Tailwind Chart Components):** Build lightweight accessible SVG chart components unified visually with Sprint 4 `SprintBurndownChart`; do **not** install Recharts.
   - **Option B (Install `recharts`):** Rejected (React 19 peer dependency & bundle bloat risks).
3. **Confirmed Decision:** **Option A — Pure React + SVG + Tailwind chart components only; do NOT install Recharts.**
4. **Status:** **CONFIRMED — `DEC-056`**.

---

### OQ-611 — Default Date Ranges & Maximum Query Window (`Asia/Ho_Chi_Minh`)

1. **Issue:** Unbounded trend queries can strain memory or produce unreadable multi-year daily axes without standardized timezone normalization.
2. **Options Evaluated:**
   - **Option A (Date Presets + 365-Day Max Analytics Window + Auto Weekly > 90d + `Asia/Ho_Chi_Minh`):** Analytics support presets `7d`, `30d` (default), `90d`, `all`, `custom`, strictly bounded to max **365 days** (`> 90 days` automatically switches from daily to ISO weekly buckets), anchored in `Asia/Ho_Chi_Minh` (`+07:00`). `/activity` uses keyset cursor pagination across historical records with optional `from`/`to` date filters.
   - **Option B (Hard 30-Day Cap Everywhere):** Rejected (fails semester-long retrospectives).
   - **Option C (Unbounded Daily Series):** Rejected (query DoS & unreadable 300+ daily ticks).
3. **Confirmed Decision:** **Option A — Presets (`7d`, `30d`, `90d`, `all`, `custom`), max 365-day analytics window, automatic weekly aggregation `> 90d`, timezone `Asia/Ho_Chi_Minh`.**
4. **Status:** **CONFIRMED — `DEC-057`**.

---

### OQ-612 — Reconstructing Sprint Commitment vs Rollover (`completeSprint` Distortion Fix)

1. **Issue:** Sprint 4's `completeSprintService` removes unfinished tasks via `SPRINT_REMOVED` / `SPRINT_MOVED` before setting `Sprint.completedAt`, causing post-completion `Sprint.tasks` to show **100% completion** and `SprintBurndownChart` final day to drop artificially to `0h`.
2. **Options Evaluated:**
   - **Option A (Non-Destructive Reconstruction Without Snapshot Table in MVP):** Reconstruct the 6 Sprint commitment & rollover metrics (`Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed Tasks`, `Rolled Over to Backlog`, `Rolled Over to Another Sprint`) from `TaskHistory` + `ActivityLog` and fix the completion-day Burndown rollover cutoff without creating a new Snapshot table in MVP.
   - **Option B (Add New `SprintCompletionSnapshot` Table):** Rejected by PO for Sprint 6 MVP (`OQ-612`).
   - **Option C (Ignore Rollover Distortion):** Rejected (misleading 100% metrics).
3. **Confirmed Decision:** **Option A — Reconstruct Sprint commitment and rollover from existing history without introducing a snapshot table in MVP.**
4. **Status:** **CONFIRMED — `DEC-058`**.

---

### 7.13. Remaining Technical Uncertainties

Even with `DEC-047`–`DEC-058` finalized, codebase inspection confirms five technical boundary conditions that Sprint 6 engineering & tests must handle explicitly without over-claiming precision:

1. **TU-601 — Pre-Enrichment Sprint Baseline Clock-Skew Sensitivity:** Existing Sprint 4/5 `ActivityLog(SPRINT_ACTIVATED)` entries do not record `baselineTaskIds`, and `sprint-planning.service.ts` writes `TaskHistory` (`metadata.source = "PLANNING"`) without a `sprintStatus` flag. Because `TaskHistory.createdAt` defaults to PostgreSQL `CURRENT_TIMESTAMP` whereas `Sprint.activatedAt` is passed from JS `new Date()`, a DB/App clock offset of even milliseconds on a move executed adjacent to `activateSprintService` can blur `Baseline Commitment` vs `Scope Added/Removed`. *Mitigation:* Package 3 reconstructs earlier Sprints chronologically and adds non-schema-breaking forward JSON metadata enrichment (`baselineTaskIds` on `SPRINT_ACTIVATED` + `sprintStatus` on `PLANNING` history rows) so new Sprints have deterministic baseline precision (`DEC-058`).
2. **TU-602 — Mutable `estimateHours` & Pre-Activation Completions:** Because `Task.estimateHours` has no daily snapshot table, historical Burndown and `baselineCommitmentHours` read current `Task.estimateHours` (though `INFO_UPDATED` history captures scalar edits); similarly, tasks marked `DONE` while a Sprint was still `PLANNED` (`completedAt < activatedAt`) fall outside active Sprint execution. Both must be exposed clearly in `dataQuality.limitations`.
3. **TU-603 — Legacy `ActivityLog` Orphan / Non-UUID `metadata.projectId` Rows:** If ad-hoc test/dev records exist with malformed `metadata->>'projectId'` or referencing a hard-deleted Project, the `ActivityLog.projectId` backfill MUST validate UUID syntax (`~* '^[0-9a-f]{8}-...'`) AND `EXISTS (SELECT 1 FROM "Project" p WHERE p.id = ...)`, leaving unbackfillable rows with `projectId = NULL` safely (Admin-only visibility).
4. **TU-604 — Cursor Behavior Under Live Writes:** Keyset cursor pagination `(createdAt DESC, source DESC, id DESC)` eliminates offset drift (duplicates/skips of older rows when new rows arrive), *except* events committed after the first page load appear only when the user refreshes/resets to page 1, and identical millisecond timestamps rely on `source` (`'WORKSPACE'` > `'TASK'`) then random UUID `id` for deterministic ordering.
5. **TU-605 — Empty Domain Data in `prisma/seed.ts`:** Per repository inspection, `prisma/seed.ts` seeds Roles, Permissions, and base Users without multi-sprint Projects/Tasks/Reviews. Real-PostgreSQL verification in Sprint 6 relies on dedicated transactional/isolated integration fixtures in `tests/integration/sprint6-db.test.ts`.

---

## 8. Proposed Data Model Changes

### 8.1. Sufficiency Evaluation of Existing Models

- **Models Evaluated:** `Project`, `ProjectMember`, `Sprint`, `Task`, `TaskAssignee`, `TaskDependency`, `TaskReview`, `TaskHistory`, `ActivityLog`, `AuditLog`, `User`, `Role`, `Permission`.
- **Conclusion:** Existing core business tables are **sufficient** for all Dashboard KPIs, non-additive Member Contribution metrics (`DEC-047`), planned `estimateHours` coverage (`DEC-048`), separated current/historical assignments (`DEC-049`), departed members (`DEC-050`), Sprint commitment/rollover reconstruction without a snapshot table (`DEC-058`), and 6 aggregate analytics views. No time-tracking or snapshot tables are added in Sprint 6.

### 8.2. Locked Minimal Schema & Index Migration (`DEC-055`)

Per confirmed **`DEC-055` (`OQ-609 Option A`)**, create a single minimal, backward-compatible migration (`sprint6_reporting_indexes_and_activity_project`):

1. **Additive Nullable Column, Relation & Cursor Indexes on `ActivityLog` (plus `Project.activityLogs` relation):**
   - Preserve exact existing column widths (note: `prisma/schema.prisma:102` defines `entityType` as **`@db.VarChar(100)`** — do NOT shrink it!).
   ```prisma
   model ActivityLog {
     id          String   @id @default(uuid()) @db.Uuid
     userId      String?  @db.Uuid
     projectId   String?  @db.Uuid
     action      String   @db.VarChar(100)
     entityType  String   @db.VarChar(100)
     entityId    String?  @db.Uuid
     description String?  @db.Text
     metadata    Json?
     createdAt   DateTime @default(now())

     user    User?    @relation(fields: [userId], references: [id], onDelete: SetNull)
     project Project? @relation(fields: [projectId], references: [id], onDelete: SetNull)

     @@index([entityType, entityId])
     @@index([projectId, createdAt(sort: Desc), id(sort: Desc)])
     @@index([userId, createdAt(sort: Desc), id(sort: Desc)])
     @@index([createdAt(sort: Desc), id(sort: Desc)])
   }
   ```
   - **Also update `model Project`:** Add `activityLogs ActivityLog[]` opposite relation field.
   - **Idempotent Guarded SQL Backfill (inside the same migration):**
     - **Project-entity rows:** Update `"ActivityLog" a` setting `"projectId" = a."entityId"` where `a."projectId" IS NULL AND a."entityType" = 'Project' AND a."entityId" IS NOT NULL AND EXISTS (SELECT 1 FROM "Project" p WHERE p."id" = a."entityId")`.
     - **Metadata-linked Sprint/Document rows:** Update `"ActivityLog" a` setting `"projectId" = (a."metadata"->>'projectId')::uuid` where `a."projectId" IS NULL AND a."entityType" IN ('Sprint', 'Document') AND (a."metadata"->>'projectId') ~* '^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$' AND EXISTS (SELECT 1 FROM "Project" p WHERE p."id" = (a."metadata"->>'projectId')::uuid)`.
   - **Call-Site Population (Exact Verified Audit — 19 Project-Scoped Calls across 6 Files):**
     - `src/modules/projects/project.service.ts` (`5` calls)
     - `src/modules/project-members/member.service.ts` (`3` calls)
     - `src/modules/sprints/sprint.service.ts` (`4` calls)
     - `src/modules/sprints/sprint-planning.service.ts` (`3` calls)
     - `src/modules/sprints/sprint-completion.service.ts` (`1` call)
     - `src/modules/documents/document.service.ts` (`3` calls)
     *(All `11` workspace-scoped calls in `auth.service.ts` [`3`], `user.service.ts` [`3`], `role.service.ts` [`2`], and `template.service.ts` [`3`] intentionally retain `projectId: null`.)*
2. **Targeted Covering & Keyset Cursor Indexes:**
   - `Task`: `@@index([projectId, completedAt])` — accelerates completion trends (`completedAt` range scans per Project).
   - `TaskHistory`: `@@index([actorId, action, createdAt])` and `@@index([createdAt(sort: Desc), id(sort: Desc)])` (and keep `@@index([taskId, createdAt])` or extend to `[taskId, createdAt(sort: Desc), id(sort: Desc)]`) — accelerates Member Contribution counters and pushed-down cursor seeks on unified `/activity`.
   - `TaskReview`: `@@index([taskId, decision, reviewedAt])` — accelerates review approval/rejection metrics.
3. **Mandatory Migration SQL Safety Guard:**
   - Generate migration with `npx prisma migrate dev --create-only --name sprint6_reporting_indexes_and_activity_project`.
   - **Manually verify and strip any Prisma-generated `DROP INDEX`** targeting existing Sprint 2–4 custom partial indexes (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`) before applying `prisma migrate deploy` / `dev`.

---

## 9. API Specification

All Sprint 6 endpoints follow the existing `/api/v1/*` contract (`src/lib/api-response.ts`, Zod v4 validation, `ApiSuccessResponse<T, M>`, `ApiErrorResponse`). CSV/PDF/Excel export routes are omitted per `DEC-054`.

### 9.1. Endpoint Inventory

| Method & Path | Auth & Permission Gate | Access Scope (`DEC-052`, `DEC-053`) | Purpose |
|---|---|---|---|
| `GET /api/v1/dashboard` | `requireActiveUser()` + per-widget checks (`project.read`, `task.read`, `sprint.read`, `activity.read`, `account.read`, `notification.delivery.read`) | Accessible Projects (`ADMIN` all; non-Admin `assertProjectReadAccess`) + Workspace summary | Operational Active-first Dashboard (`selectedProject`, `availableProjects`, `taskStats`, `workProgressPercent`, `timelineProgressPercent`, `activeSprints`, `recentActivity`, `myAssignedTasks`, `adminSummary?`). Accepts optional `?projectId=` only (no analytics date range or Reports charts per `DEC-051`). |
| `GET /api/v1/reports/projects/[projectId]` | `requirePermission(PERMISSIONS.REPORT_READ)` | `assertProjectReadAccess` (includes `ARCHIVED` read-only per `DEC-053`) | Project Report + 6 Aggregate Analytics series (Completion Trend, Status Distribution, Priority Distribution, Overdue Aging & Slip Trend, Sprint 6-Metric Summary, Aggregate Estimated Effort Distribution) + `dataQuality` & `limitations`. **Zero per-user breakdowns** (`DEC-052`). |
| `GET /api/v1/reports/projects/[projectId]/members` | `requirePermission(PERMISSIONS.REPORT_READ)` | `assertProjectReadAccess` + Role Isolation (`DEC-052`): `ADMIN` / assigned `INSTRUCTOR` / `LEADER` -> `PROJECT_FULL`; `MEMBER` -> `SELF_ONLY` | Objective non-additive Member Contribution matrix (`Sole-Assigned` vs `Co-Assigned`, Current Active vs Historical Removed vs `TaskHistory`/`TaskReview` actions, Departed Members badge + `includeRemoved` toggle, planned `estimateHours` + `estimateCoveragePercent`). |
| `GET /api/v1/reports/projects/[projectId]/sprints` | `requirePermission(PERMISSIONS.REPORT_READ)` | `assertProjectReadAccess` (includes `ARCHIVED`) | Cross-Sprint Comparison & Trend returning all 6 distinct metrics (`Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed Tasks`, `Rolled Over to Backlog`, `Rolled Over to Another Sprint`) + `reconstructionConfidence`. |
| `GET /api/v1/sprints/[sprintId]/burndown` | `requirePermission(PERMISSIONS.SPRINT_READ)` *(existing)* | `assertSprintReadAccess` *(existing)* | Preserves Sprint 4 contract; fixes completion-day rollover evaluation & exposes `baselineHours`, `currentScopeHours`, `estimateCoveragePercent`. |
| `GET /api/v1/activity` | `requirePermission(PERMISSIONS.ACTIVITY_READ)` | `ADMIN`: All Projects + system (`projectId IS NULL`); `LEADER`/`INSTRUCTOR`: Accessible Projects only; `MEMBER`: Accessible Projects filtered strictly to `(actorId = self OR assignedTaskIds)` (`DEC-052`) | Unified chronological timeline (`ActivityLog` + `TaskHistory`) using **deterministic keyset cursor pagination** (`cursor`, `limit`, `projectId`, `source`, `entityType`, `userId`, `action`, `from`, `to`, `search`). |

### 9.2. Query Validation, Timezone SQL & Cursor Pagination Controls

- **Zod Schemas (`src/modules/reports/report.schema.ts`, `src/modules/activity/activity.schema.ts`, `src/modules/dashboard/dashboard.schema.ts`):**
  - `projectId` / `sprintId` / `userId`: validated `uuidSchema`.
  - `dashboardQuerySchema`: `{ projectId?: uuid }` only (`DEC-051`).
  - `reportAnalyticsQuerySchema`: `preset: "7d" | "30d" | "90d" | "all" | "custom"` (default `"30d"`), `from?` / `to?` (`YYYY-MM-DD` parsed in `Asia/Ho_Chi_Minh`), rejecting `to < from` (`400 VALIDATION_ERROR`) and enforcing `<= 365 days` max span (`DEC-057`, capping `"all"` cleanly at 365 days ending at `today`/`project.endDate` as bounded window and switching `daily -> weekly` above `90d`).
  - `memberReportQuerySchema`: extends `from`/`to`/`preset` + `includeRemoved: z.coerce.boolean().default(true)` (`DEC-050`).
  - `activityCursorQuerySchema`: `{ projectId?, source?: "ALL" | "WORKSPACE" | "TASK", entityType?, userId?, action?, from?, to?, search?, cursor?, limit: 1..50 (default 20) }`.
- **Deterministic Keyset Cursor Architecture for `/api/v1/activity`:**
  - **Sort Key & Tie-Breaking:** Merge `ActivityLog` (`source = "WORKSPACE"`) and `TaskHistory` (`source = "TASK"`) strictly by tuple **`(createdAt DESC, source DESC, id DESC)`** (`"WORKSPACE"` > `"TASK"` alphabetically for ties at exact same millisecond, then UUID `id DESC`).
  - **Opaque Cursor Contract:** Base64url-encoded JSON `{ createdAt: ISO8601String, source: "WORKSPACE" | "TASK", id: UUID }`, Zod-validated before SQL execution (malformed or tampered cursor throws `400 VALIDATION_ERROR`).
  - **Index-Pushed Dual-Arm Seek Query:** Push both filter predicates (`projectId`, `userId`, `action`, `createdAt >= fromUtc AND createdAt <= toUtc`, `MEMBER` assignment scope) **and** keyset seek predicates down into each table query independently:
    - Arm A (`ActivityLog`, `source = 'WORKSPACE'`): `createdAt < cursor.createdAt OR (createdAt = cursor.createdAt AND ('WORKSPACE' < cursor.source OR ('WORKSPACE' = cursor.source AND id < cursor.id)))`, leveraging `[createdAt DESC, id DESC]` / `[projectId, createdAt DESC, id DESC]`. Fetch **`limit + 1`** rows.
    - Arm B (`TaskHistory`, `source = 'TASK'`): `createdAt < cursor.createdAt OR (createdAt = cursor.createdAt AND ('TASK' < cursor.source OR ('TASK' = cursor.source AND id < cursor.id)))`, leveraging `[createdAt DESC, id DESC]`. Fetch **`limit + 1`** rows.
    - Merge up to `2 * (limit + 1)` candidates in TypeScript by `(createdAt DESC, source DESC, id DESC)`, slice top `limit` items, set `hasNextPage = merged.length > limit`, and return `nextCursor` encoded from `items[limit - 1]` (or `null`).
  - **Concurrent New-Insert Behavior:** When new records are committed after page 1 is loaded, cursor seek guarantees older pages (`page 2+`) experience **zero skips and zero duplicates**; newly arrived head records (`> cursor.createdAt`) appear naturally when the user triggers **"Làm mới"** (clears `cursor`).
- **PostgreSQL `TIMESTAMP(3)` Aggregation & Anti-N+1 Architecture:**
  - Zero per-task or per-member Prisma loops (`< 8` SQL queries per report request).
  - Range filters use UTC `Date` bounds (`new Date("${ymd}T00:00:00.000+07:00")`) directly against indexed `TIMESTAMP(3)` columns.
  - Bucket grouping uses **`(("col" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')`** (and `date_trunc('week', ...)` for ISO Monday weeks) so PostgreSQL `TIMESTAMP WITHOUT TIME ZONE` never double-shifts or wrong-shifts UTC values.

### 9.3. Key Response Shapes (DTO Summary)

- **`DashboardDTO` (`DEC-051`):**
  - `context`: `{ selectedProjectId, selectedProjectStatus, isArchivedReadOnly, projectSummary, availableProjects: ProjectPickerItemDTO[] }`
  - `taskStats`: `ProjectTaskSummaryStatsDTO & { workProgressPercent: number, timelineProgressPercent: number | null }` *(hidden/null if actor lacks Project/`task.read`)*
  - `activeSprints`: `Array<{ id, name, startDate, endDate, status, taskStats: SprintTaskStatsDTO, daysRemaining: number }>` *(gated by `sprint.read`; operational metrics only — no `burndownPreview`)*
  - `recentActivity`: `{ permitted: boolean, items: ActivityEntryDTO[] }` *(gated by `activity.read` + `DEC-052` scope)*
  - `myAssignedTasks`: `MyAssignedTaskDTO[]`
  - `adminSummary?`: `{ workspaceUsers?, workspaceProjects?, failedEmailDeliveriesCount? }` *(gated by `account.read`, `project.read`, `notification.delivery.read`)*
- **`ProjectReportDTO` (`DEC-052`, `DEC-056`, `DEC-057`):**
  - `project`: `{ id, name, status, startDate, endDate, isArchivedReadOnly: boolean }`
  - `dateRange`: `{ preset, fromYmd, toYmd, granularity: "day" | "week", maxWindowDays: 365, timezone: "Asia/Ho_Chi_Minh" }`
  - `summary`: `{ taskStats, workCompletionPercent, overdueRatePercent, reviewPendingPercent }`
  - `distributions`: `{ byStatus, byPriorityWithOverdue, backlogVsSprint, estimateEffortByStatus, estimateEffortByPriority, estimateEffortByAssignmentState, unestimatedTaskCount, estimateCoveragePercent }` *(strictly Project-aggregate; no per-user series)*
  - `trends`: `{ completionSeries: Array<{ bucket, label, completedCount, completedHours, cumulativeDone }>, overdueSlipSeries: Array<{ bucket, label, deadlineDueCount, missedDeadlineCount }> }`
  - `overdueAging`: `Array<{ bucket: "1_3_DAYS" | "4_7_DAYS" | "8_14_DAYS" | "OVER_14_DAYS", count }>`
  - `dataQuality`: `{ totalTasksInScope, tasksWithEstimateCount, estimateCoveragePercent, hasDateFilteredResults, limitations: string[] }`
- **`MemberContributionReportDTO` (`DEC-047`..`DEC-050`, `DEC-052`):**
  - `scope`: `"PROJECT_FULL" | "SELF_ONLY"`
  - `projectTotals`: `ProjectTaskSummaryStatsDTO & { totalEstimateHours: number, nonAdditiveWarning: string }`
  - `members`: `Array<{ userId, fullName, email, membershipStatus: "ACTIVE" | "LEFT_PROJECT" | "HISTORICAL_ONLY", projectRole: ProjectMemberRole | null, leftAt: Date | null, currentAssigned: { total, soleAssignedCount, coAssignedCount, todo, inProgress, review, done, soleDoneCount, coAssignedDoneCount, overdue, plannedEstimateHours, soleEstimateHours, coAssignedEstimateHours, estimateCoveragePercent }, historicalUnassignedCount: number, activities: { progressUpdatesCount, reviewSubmissionsCount, reviewsApprovedCount, reviewsRejectedCount, totalTaskHistoryActions } }>`
  - `methodology`: `{ attributionRule: "NON_ADDITIVE_PARTICIPATION", multiAssigneeNote, estimateHoursNote, limitations: string[] }`
- **`SprintComparisonReportDTO` (`DEC-058`):**
  - `sprints`: `Array<{ sprintId, name, status, startDate, endDate, activatedAt, completedAt, metrics: { baselineCommitmentCount, baselineCommitmentHours, scopeAddedCount, scopeAddedHours, scopeRemovedCount, scopeRemovedHours, completedTasksCount, completedEstimateHours, rolledOverToBacklogCount, rolledOverToBacklogHours, rolledOverToSprintCount, rolledOverToSprintHours }, estimateCoveragePercent, reconstructionConfidence: "SNAPSHOT_METADATA" | "RECONSTRUCTED_FROM_LOGS" }>`
  - `limitations`: `string[]`
- **`ActivityFeedPageDTO` (`DEC-052`, `DEC-055`):**
  - `items`: `ActivityEntryDTO[]` (`{ cursorKey, source: "WORKSPACE" | "TASK", entityType, entityId, projectId, projectName, action, actor, summary, targetUrl, createdAt }`)
  - `pageInfo`: `{ nextCursor: string | null, hasNextPage: boolean, limit: number }`

---

## 10. UI/UX Plan

### 10.1. Navigation & Route Structure

1. **Sidebar Updates (`src/components/layout/app-shell.tsx`):**
   - Add **Báo cáo & Phân tích** (`/reports`, icon `BarChart3`, permission `PERMISSIONS.REPORT_READ`).
   - Add **Lịch sử hoạt động** (`/activity`, icon `History`, permission `PERMISSIONS.ACTIVITY_READ`).
   - Update sidebar footer text from `Sprint 5 · Documents & Notifications` to `Sprint 6 · Dashboard & Reports`.
2. **Project Detail Sub-Navigation (`src/app/(dashboard)/projects/[projectId]/page.tsx`):**
   - Add quick links / summary entry card to `/projects/[projectId]/reports` (`Báo cáo & Đóng góp`) and `/activity?projectId=${projectId}` (`Lịch sử Project`), alongside existing Tasks, Sprints, Backlog, Kanban, and Documents links.
3. **New App Router Pages (`src/app/(dashboard)/...`):**
   - `/reports/page.tsx`: Workspace Report Portal — auto-loads `ACTIVE` Project report (or lets user pick from accessible Projects including `ARCHIVED` / `CREATED`) and embeds the shared `ProjectReportsClient` component (`View-only` per `DEC-054`).
   - `/projects/[projectId]/reports/page.tsx`: Project-pinned Report Page reusing the same `ProjectReportsClient` component.
   - `/activity/page.tsx`: Dedicated Unified Activity History explorer with URL-synced filter state (`projectId`, `source`, `entityType`, `userId`, `action`, `from`, `to`, `search`) and progressive cursor pagination (`cursor` reset on filter change).

### 10.2. Layout & Visualization Design

- **`/dashboard` Operational Layout (`DEC-051`):**
  - **Header Row:** Welcome banner + **Active-First Project Switcher** (`ACTIVE` default, switches across accessible `CREATED`/`ARCHIVED` Projects, read-only badge on `ARCHIVED`) + quick link `"Xem Báo cáo chi tiết"` -> `/projects/[projectId]/reports`. (**No analytics timeframe selector**).
  - **Operational KPI Strip (5 Cards):** `Tổng Task`, `Hoàn thành (Done)`, `Đang làm (In Progress)`, `Chờ Review`, `Quá hạn (Overdue)` — each linking to filtered `/projects/[projectId]/tasks?...`.
  - **Progress & Active Sprint Row (2 Columns):**
    - *Left:* **Project Progress Card** displaying **Task Work Progress (`DONE / Total`, %)** separately from **Project Timeline Progress (`StartDate -> EndDate`, %)** (`DEC-051`).
    - *Right:* **Active Sprint Operational Summary** listing active Sprint(s) with `DONE / Total` bar, remaining calendar days, overdue indicator, and deep links to Sprint Detail / Burndown & Sprint Report (**no embedded Burndown chart widget on Dashboard**).
  - **Operational Row (2 Columns):**
    - *Left:* Reused `MyAssignedTasksCard` (`Công việc được giao cho tôi`).
    - *Right:* **Recent Activity Feed** (`Hoạt động gần đây` `<= 15` items, scoped by `DEC-052`, gated by `activity.read`, linking to `/activity?projectId=...`).
  - **Admin Strip (Bottom / Conditional):** Existing Admin Account Stats + Email Delivery Health shortcut + Workspace Project counts (gated by `account.read` / `project.read` / `notification.delivery.read`).
- **`/reports` & `/projects/[projectId]/reports` Layout (`ProjectReportsClient` — `DEC-047`..`DEC-054`, `DEC-056`, `DEC-057`, `DEC-058`):**
  - Top toolbar: Project Selector, Date Range Preset Switcher (`7d | 30d | 90d | Tất cả (tối đa 365 ngày) | Tùy chọn`, auto-displaying `(Gộp theo tuần)` badge when `> 90d`), Persistent Read-Only Archive Banner when `project.status === ARCHIVED` (`DEC-053`), and **zero export buttons** (`DEC-054`).
  - Clean 4-Tab Workspace (`Tổng quan & Xu hướng` · `Phân tích Sprint` · `Đóng góp thành viên` · `Phân bổ nỗ lực & Tồn đọng`).
  - All charts built strictly with **Pure React + Accessible SVG + Tailwind (`DEC-056`)** featuring keyboard/hover tooltips, responsive containers, explicit **management question subtitles**, `estimateCoveragePercent` badges, and structured empty/insufficient-data alerts.
  - **Member Contribution Tab:** Top **Project Totals Reconciliation & Non-Additive Warning Banner** (`DEC-047`), `"Hiển thị thành viên đã rời"` toggle + `"Đã rời Project"` status pill (`DEC-050`), separated **Sole vs Co-Assigned**, **Current vs Historical Removed (`removedAt`)**, **Planned `estimateHours` (with coverage disclaimer — `DEC-048`)**, and **Verifiable `TaskHistory` / `TaskReview` Actions** (`DEC-049`), plus `"Chỉ hiển thị dữ liệu đóng góp của bạn"` notice when viewer role is `MEMBER` (`DEC-052`), with strictly zero rankings/scores.
  - **Sprint Analysis Tab:** 6-column commitment/scope/rollover matrix (`Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed`, `Rolled Over to Backlog`, `Rolled Over to Next Sprint`) + `SprintBurndownChart` with fixed completion-day rollover and `reconstructionConfidence` note (`DEC-058`).
- **`/activity` Layout (`ActivityLogClient` — `DEC-052`, `DEC-055`):**
  - Filter toolbar (`Project`, `Source [Tất cả | Công việc | Hệ thống & Project]`, `Actor`, `Entity Type`, `From–To` in `Asia/Ho_Chi_Minh`, `Search`) + **"Làm mới"** button resetting to latest head.
  - Reverse-chronological unified timeline `(createdAt DESC, source DESC, id DESC)` with Vietnamese labels, `Asia/Ho_Chi_Minh` timestamps, entity badges, deep links, and **"Xem thêm hoạt động cũ hơn"** cursor-load-more button (`hasNextPage`).

---

## 11. Authorization Matrix

All routes and services enforce **server-side checks** (`requireActiveUser`, `assertPermission`, `assertProjectReadAccess`) reacting dynamically to the Admin **Permission Matrix (`/admin/roles`)** via `loadTrustedAuthContext`. Note: `PERMISSIONS.DASHBOARD_READ` does **not** exist in the catalog (`src/modules/authorization/constants.ts` defines 27 permissions ending with `REPORT_READ` and `ACTIVITY_READ`).

| Feature / Route | `ADMIN` | `INSTRUCTOR` | `LEADER` | `MEMBER` | Notes / Dynamic Matrix Behavior |
|---|---|---|---|---|---|
| **Dashboard (`/dashboard`, `GET /api/v1/dashboard`)** | Workspace KPIs + All Projects + Admin Email/User cards | Accessible Projects (`instructorId` / `ProjectMember`) + `MyAssignedTasks` | Accessible Projects (`leaderId` / `ProjectMember`) + `MyAssignedTasks` | Accessible Projects (`ProjectMember` `leftAt IS NULL`) + `MyAssignedTasks` | Requires active authenticated user (`requireActiveUser` / `requireActiveUserOrRedirect`); KPI/Sprint/Activity/Admin cards each conditionally gated by existing `project.read`, `task.read`, `sprint.read`, `activity.read`, `account.read`, and `notification.delivery.read`. |
| **Project & Advanced Analytics (`/reports`, `/projects/[id]/reports`, `GET /api/v1/reports/projects/[id]`)** | All Projects (`CREATED`, `ACTIVE`, `ARCHIVED`) | Assigned Projects (Read-Only, incl. `ARCHIVED`) | Accessible Projects (incl. `ARCHIVED`) | Accessible Projects (Read-Only Aggregate Charts ONLY, incl. `ARCHIVED`) | Requires `report.read` + `assertProjectReadAccess`. Project-aggregate series exclude per-user series so `MEMBER` never sees peer data (`DEC-052`). Revoking `report.read` returns `403` on API / redirects UI to `/access-denied`. |
| **Member Contribution (`GET /api/v1/reports/projects/[id]/members`)** | `PROJECT_FULL` (all current + departed contributors) | `PROJECT_FULL` (assigned Projects only) | `PROJECT_FULL` (accessible Projects where user holds Leader/Project management authority) | **`SELF_ONLY` (own contribution row + Project Totals reconciliation header; zero peer rows — `DEC-052`)** | Requires `report.read` + `assertProjectReadAccess`. Former members removed from active Project (`leftAt != null` for non-Admin/Leader) receive `403`/`404` on `/reports`. Authority check inspects effective workspace/project role (not merely `ProjectMember` membership). |
| **Sprint Comparison (`GET /api/v1/reports/projects/[id]/sprints`)** | All Projects | Assigned Projects | Accessible Projects | Accessible Projects | Requires `report.read` + `assertProjectReadAccess` (`DEC-053`, `DEC-058`). |
| **Single Sprint Burndown (`GET /api/v1/sprints/[id]/burndown`)** | All Projects | Assigned Projects | Accessible Projects | Accessible Projects | Preserves Sprint 4 `sprint.read` + `assertSprintReadAccess` contract. |
| **Unified Activity History (`/activity`, `GET /api/v1/activity`)** | All Projects + System (`projectId IS NULL`: `User`, `Role`, `Template`) | Assigned Projects (`Project`, `Sprint`, `Document`, `Task` logs) | Accessible Projects (`Project`, `Sprint`, `Document`, `Task` logs) | **Strictly Own Actions (`actorId = self`) OR Events on Tasks currently/historically assigned to self within accessible Projects (`DEC-052`)** | Requires `activity.read`. Never leaks unreachable Projects, Admin system events (`projectId IS NULL`), or unrelated peer events to `MEMBER`. |

---

## 12. Implementation Packages

Execution is divided into **9 sequential, independently reviewable packages (Package 0 – Package 8)** matching the repository's Sprint 5 delivery discipline.

### Package 0 — Decision Lock Verification & Pre-Implementation Baseline
- **Objective:** Confirm PO decisions (`DEC-047` – `DEC-058`) are locked in `markdown/DECISION-LOG.md` *(completed during planning revision)* and verify a clean Sprint 5 technical baseline prior to Package 1 code/migration edits.
- **Files / Modules Affected:** `markdown/DECISION-LOG.md` *(updated with `DEC-047` – `DEC-058`)*, `report/SPRINT-6-IMPLEMENTATION-PLAN.md` *(revised & locked)*.
- **Implementation Tasks:**
  1. Verify committed/clean Sprint 5 baseline (`npx prisma validate`, `npm run typecheck`, `npm test`) immediately before starting Package 1 edits.
- **Dependencies:** None (Pre-execution verification gate).
- **Acceptance Criteria:** `DEC-047`–`DEC-058` signed off; Sprint 5 baseline checks exit 0.
- **Required Tests:** Baseline regression run (`npm test`).

### Package 1 — Shared Timezone Utility, `ActivityLog.projectId` Migration & Cursor/Reporting Indexes (`DEC-055`, `DEC-057`)
- **Objective:** Establish unified `Asia/Ho_Chi_Minh` temporal helpers and apply the single Sprint 6 Prisma migration adding `ActivityLog.projectId`, guarded backfill, reporting/cursor indexes, and all 19 project-scoped `activityLog.create` call-site updates.
- **Files / Modules Affected:** `src/lib/timezone.ts` *(new)*, `src/modules/notifications/notification-deadline.service.ts` *(re-export/use `timezone.ts`)*, `src/modules/sprints/sprint-analytics.service.ts` *(re-export/use `timezone.ts`)*, `prisma/schema.prisma`, `prisma/migrations/<timestamp>_sprint6_reporting_indexes_and_activity_project/migration.sql` *(new)*, `src/modules/projects/project.service.ts` (`5` calls), `src/modules/project-members/member.service.ts` (`3` calls), `src/modules/sprints/sprint.service.ts` (`4` calls), `src/modules/sprints/sprint-planning.service.ts` (`3` calls), `src/modules/sprints/sprint-completion.service.ts` (`1` call), `src/modules/documents/document.service.ts` (`3` calls), plus corresponding unit test mock assertions for `activityLog.create`.
- **Implementation Tasks:**
  1. Build `src/lib/timezone.ts` with `HCM_TIMEZONE = "Asia/Ho_Chi_Minh"`, `parseHcmDateBounds(fromYmd, toYmd)` (returning UTC `Date` bounds for `TIMESTAMP(3)` range scans), `formatHcmYmd`, `enumerateHcmDays`, `enumerateHcmIsoWeeks` (Monday start matching PostgreSQL `date_trunc('week', ...)`), and strict separation of PostgreSQL `DATE` calendar formatting (`formatSprintDateYmd`).
  2. Update `prisma/schema.prisma`: add `ActivityLog.projectId` (`@db.Uuid`), `Project.activityLogs`, cursor indexes (`[projectId, createdAt DESC, id DESC]`, `[userId, createdAt DESC, id DESC]`, `[createdAt DESC, id DESC]` on `ActivityLog`, preserving `@db.VarChar(100)` on `entityType`; `[createdAt DESC, id DESC]` + `[actorId, action, createdAt]` on `TaskHistory`), plus `Task([projectId, completedAt])` and `TaskReview([taskId, decision, reviewedAt])`.
  3. Generate migration `--create-only`, verify/strip any unwanted `DROP INDEX` for Sprint 2–4 partial indexes, inject the UUID-validated + `EXISTS`-guarded SQL backfill inside the migration, and apply cleanly.
  4. Update all `19` project-scoped `activityLog.create` call sites across the `6` service files above to persist `projectId` (leaving all `11` workspace-scoped calls in `auth`, `users`, `roles`, and `project-templates` with `projectId: null`), and update affected Sprint 2–5 unit tests asserting `activityLog.create` payloads.
- **Dependencies:** Package 0.
- **Acceptance Criteria:** `prisma migrate status` clean; all existing partial indexes intact; existing Sprint 1–5 tests pass with updated `activityLog.create` expectations.
- **Required Tests:** Unit tests for `src/lib/timezone.ts` Vietnam midnight & ISO Monday-week boundaries + migration/backfill/partial-index verification in `sprint6-db.test.ts`.

### Package 2 — Unified Activity History Module & Cursor API (`/api/v1/activity`) (`DEC-052`, `DEC-055`)
- **Objective:** Implement unified server-side Activity Log service merging `ActivityLog` and `TaskHistory` with deterministic keyset cursor pagination and strict `DEC-052` role/project scoping.
- **Files / Modules Affected:** `src/modules/activity/activity.schema.ts` *(new)*, `src/modules/activity/activity.repository.ts` *(new)*, `src/modules/activity/activity.service.ts` *(new)*, `src/app/api/v1/activity/route.ts` *(new)*, `src/modules/projects/project.access.ts` *(extract `buildAccessibleProjectsWhere`)*.
- **Implementation Tasks:**
  1. Define normalized `ActivityEntryDTO` (`cursorKey`, `source`, `entityType`, `entityId`, `projectId`, `projectName`, `action`, `actor`, `summary`, `targetUrl`, `createdAt`) and Zod-validated opaque base64url cursor `{ createdAt, source, id }`.
  2. Implement dual-arm keyset seek `(createdAt DESC, source DESC, id DESC)` pushing filters and cursor tuple predicates into `ActivityLog` and `TaskHistory` independently using B-tree indexes, fetching `limit + 1` per arm, merging top `limit` rows, and computing `nextCursor`/`hasNextPage`.
  3. Enforce `PERMISSIONS.ACTIVITY_READ`, accessible project scoping, Admin-only system logs (`projectId IS NULL`), and `MEMBER` strict filter `(actorId = self OR taskId IN assignedTaskIds)`.
- **Dependencies:** Package 1.
- **Acceptance Criteria:** `GET /api/v1/activity` returns deterministic cursor pages with zero duplicate/skip drift across concurrent inserts, returns `400` on invalid cursor tokens, and isolates unauthorized Projects/system events/peer events.
- **Required Tests:** Unit tests (`sprint6-activity.test.ts` + API route auth/cursor validation tests) & real-DB concurrent-insert/tie-breaker tests (`sprint6-db.test.ts`).

### Package 3 — Sprint Commitment/Rollover Reconstruction & Burndown Integrity Fix (`DEC-058`)
- **Objective:** Reconstruct all 6 separated Sprint commitment/scope/rollover metrics without a snapshot table, enrich forward activation/planning JSON metadata minimally, and fix completion-day rollover distortion in `sprint-analytics.service.ts`.
- **Files / Modules Affected:** `src/modules/sprints/sprint-analytics.service.ts`, `src/modules/sprints/sprint.repository.ts`, `src/modules/sprints/sprint.service.ts` *(enrich `SPRINT_ACTIVATED` metadata minimally)*, `src/modules/sprints/sprint-planning.service.ts` *(add `sprintStatus` to `PLANNING` history metadata)*, `src/modules/reports/sprint-report.service.ts` *(new)*, `src/app/api/v1/reports/projects/[projectId]/sprints/route.ts` *(new)*.
- **Implementation Tasks:**
  1. Fix `computeSprintBurndownAnalytics` so closure moves matching `metadata.source === "SPRINT_COMPLETION"` / `"SPRINT_CANCELLED"` are excluded from final-day pre-closure remaining work, and expose `baselineHours`, `currentScopeHours`, `estimateCoveragePercent`.
  2. Implement 6-metric reconstruction (`Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed Tasks`, `Rolled Over to Backlog`, `Rolled Over to Another Sprint`) using `TaskHistory` (`metadata.source = "SPRINT_COMPLETION"` + `completedSprintId`) + `ActivityLog`, distinguishing pre-enrichment Sprint 4/5 replays (`RECONSTRUCTED_FROM_LOGS`) cleanly.
  3. Add zero-table forward metadata enrichment (`{ baselineTaskIds, baselineTaskCount, baselineEstimateHours }` on `ActivityLog(SPRINT_ACTIVATED)` and `sprintStatus` on `PLANNING` `TaskHistory` rows) to eliminate future baseline clock-skew uncertainty (`TU-601`).
  4. Expose `GET /api/v1/reports/projects/[projectId]/sprints` protected by `PERMISSIONS.REPORT_READ` + `assertProjectReadAccess`.
- **Dependencies:** Package 1 (`timezone.ts`).
- **Acceptance Criteria:** Completed Sprints with rollovers accurately display baseline commitment, mid-sprint additions/removals, completions, and backlog/next-sprint rollovers; Sprint 4 tests pass cleanly.
- **Required Tests:** Unit tests (`sprint6-sprint-analytics.test.ts`) + real-DB `completeSprintService` integration verification (`sprint6-db.test.ts`) + Sprint 4 regression check.

### Package 4 — Project Report & 6 Aggregate Analytics Backend + API (`DEC-052`, `DEC-053`, `DEC-057`)
- **Objective:** Build PostgreSQL-aggregated Project Report & 6 management-question-driven Analytics endpoints (`/api/v1/reports/projects/[projectId]`) without per-user leaks.
- **Files / Modules Affected:** `src/modules/reports/report.schema.ts` *(new)*, `src/modules/reports/project-analytics.repository.ts` *(new)*, `src/modules/reports/project-analytics.service.ts` *(new)*, `src/app/api/v1/reports/projects/[projectId]/route.ts` *(new)*.
- **Implementation Tasks:**
  1. Reuse `taskRepository.findProjectTaskStats` and Package 3 Sprint comparison metrics.
  2. Write bounded SQL `GROUP BY` / double-conversion timezone aggregation **`(("col" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')`** (and `date_trunc('week', ...)` for `> 90d`) queries with UTC `Date` bounds for Completion Trend, Status/Priority Distribution, Overdue Aging (`1–3d`, `4–7d`, `8–14d`, `>14d`) + Slip Trend, and **strictly Project-aggregate** Estimated Effort Distribution (`By Status`, `By Priority`, `By Assignment State`, `Unestimated Count` — zero per-user series).
  3. Enforce `365d` max analytics window (`DEC-057`), daily/weekly auto-switching (`> 90d`), `ARCHIVED` project read-only support (`DEC-053`), and `dataQuality` limitations metadata.
- **Dependencies:** Package 1, Package 3.
- **Acceptance Criteria:** Single API call returns complete aggregate `ProjectReportDTO` in `< 8` SQL queries with zero per-user leakage and exact SQL-vs-TS parity at Vietnam midnight/week boundaries.
- **Required Tests:** Unit tests (`sprint6-project-analytics.test.ts`) + real PostgreSQL midnight/ISO-week parity integration tests (`sprint6-db.test.ts`).

### Package 5 — Objective Non-Additive Member Contribution Backend + API (`DEC-047`..`DEC-050`, `DEC-052`, `DEC-054`)
- **Objective:** Implement objective, non-additive, view-only Member Contribution service & API (`/api/v1/reports/projects/[projectId]/members`).
- **Files / Modules Affected:** `src/modules/reports/member-contribution.repository.ts` *(new)*, `src/modules/reports/member-contribution.service.ts` *(new)*, `src/app/api/v1/reports/projects/[projectId]/members/route.ts` *(new)*. *(No CSV export routes per `DEC-054`.)*
- **Implementation Tasks:**
  1. Consolidate Project contributor roster (`ProjectMember` active + departed `leftAt != null`, `leaderId`, `instructorId`, historical `TaskAssignee`/`TaskHistory`/`TaskReview` actors).
  2. Compute separated Current Active (`removedAt IS NULL`) vs Historical Removed (`removedAt IS NOT NULL`) counts (`DEC-049`), explicit `Sole-Assigned` vs `Co-Assigned` sub-counts (`DEC-047`), planned `estimateHours` + `estimateCoveragePercent` (`DEC-048`), departed `"LEFT_PROJECT"` status + `includeRemoved` toggle (`DEC-050`), and verifiable `TaskHistory` / `TaskReview` action counters.
  3. Apply effective authority isolation (`DEC-052`): `ADMIN`, assigned `INSTRUCTOR`, or `LEADER` receive `PROJECT_FULL`; `MEMBER` receives `SELF_ONLY` (strictly own row + Project Totals reconciliation header).
- **Dependencies:** Package 0, Package 1.
- **Acceptance Criteria:** Multi-assignee rows never imply vertical summation equals Project Totals; former members remain inspectable; `MEMBER` cannot enumerate peer metrics; zero rankings or CSV export endpoints exist.
- **Required Tests:** Edge-case unit tests (`sprint6-member-contribution.test.ts`: 2-assignee sole/co split, reassigned task, departed member with `DONE` task, `MEMBER` `SELF_ONLY` isolation) + real-DB integration tests (`sprint6-db.test.ts`).

### Package 6 — Operational Active-First Dashboard Backend & UI (`DEC-051`, `DEC-052`, `DEC-053`)
- **Objective:** Upgrade `/dashboard` and expose `GET /api/v1/dashboard` with operational Project Switcher, KPI cards, separated Work vs Timeline progress, Active Sprint summary, `MyAssignedTasksCard`, `DEC-052`-scoped Recent Activity, and Admin shortcuts — decoupled from Reports analytics.
- **Files / Modules Affected:** `src/modules/dashboard/dashboard.schema.ts` *(new)*, `src/modules/dashboard/dashboard.service.ts` *(new)*, `src/app/api/v1/dashboard/route.ts` *(new)*, `src/app/(dashboard)/dashboard/page.tsx` *(updated)*, `src/components/dashboard/*` *(new client widgets)*.
- **Implementation Tasks:**
  1. Implement `getDashboardSummaryService(actor, rawQuery)` enforcing `requireActiveUser` + conditional per-widget permissions (`project.read`, `task.read`, `sprint.read`, `activity.read`, `account.read`, `notification.delivery.read` — NO `dashboard.read`), defaulting to accessible `ACTIVE` Project, returning separated `workProgressPercent` and `timelineProgressPercent`, operational Active Sprint summaries (no Burndown chart embed), `recentActivity` (`<= 15`, `DEC-052` scoped), and `listMyAssignedTasksService`.
  2. Upgrade `/dashboard` Server Component to call `getDashboardSummaryService` directly and render Project Switcher + `?projectId=` URL sync without timeframe pickers.
- **Dependencies:** Packages 2, 3, 4.
- **Acceptance Criteria:** Dashboard renders accurate operational KPIs matching `/projects/[projectId]/tasks`, respects active-user + per-widget RBAC (`MEMBER` Recent Activity properly isolated), and keeps Reports analytics separated on `/reports`.
- **Required Tests:** Unit tests (`sprint6-dashboard.test.ts` + `/api/v1/dashboard` route auth/project-boundary tests).

### Package 7 — Pure SVG Reports, Analytics & Cursor Activity UI + Navigation (`DEC-053`, `DEC-054`, `DEC-056`, `DEC-057`)
- **Objective:** Build interactive view-only UI pages (`/reports`, `/projects/[projectId]/reports`, `/activity`), Pure React + SVG + Tailwind chart primitives, and AppShell / Project Detail links.
- **Files / Modules Affected:** `src/components/layout/app-shell.tsx` *(updated nav & footer)*, `src/app/(dashboard)/projects/[projectId]/page.tsx` *(add Reports/Activity links)*, `src/app/(dashboard)/reports/page.tsx` *(new)*, `src/app/(dashboard)/projects/[projectId]/reports/page.tsx` *(new)*, `src/app/(dashboard)/activity/page.tsx` *(new)*, `src/components/reports/*` *(new Pure SVG charts, Member Contribution view + non-additive/planned-effort banners, 6-metric Sprint table)*, `src/components/activity/activity-log-client.tsx` *(new)*.
- **Implementation Tasks:**
  1. Add `Báo cáo & Phân tích` (`/reports`) and `Lịch sử hoạt động` (`/activity`) to `NAV_ITEMS` gated by `PERMISSIONS.REPORT_READ` and `PERMISSIONS.ACTIVITY_READ`.
  2. Build responsive accessible **Pure React + SVG + Tailwind** chart components (`TrendLineChart`, `StackedBarChart`, `DistributionBarChart`, `DonutDistributionChart` — zero external chart libraries per `DEC-056`), displaying `365d` max / `(Gộp theo tuần)` >90d indicators (`DEC-057`), management-question subtitles, and empty/insufficient-data alerts.
  3. Build shared view-only `ProjectReportsClient` (with `"Project đã lưu trữ (Chỉ đọc)"` banner per `DEC-053`, zero export buttons per `DEC-054`, `"Hiển thị thành viên đã rời"` toggle per `DEC-050`, and `MEMBER` `"Phạm vi cá nhân"` banner per `DEC-052`) plus cursor-paginated `ActivityLogClient` (`"Làm mới"` + `"Xem thêm hoạt động cũ hơn"`).
- **Dependencies:** Packages 2, 4, 5, 6.
- **Acceptance Criteria:** All 3 routes render via SSR + clean URL/cursor state; SVG charts & tables degrade gracefully on empty/unestimated data; zero client secret/Prisma leakage; `npm run build` green.
- **Required Tests:** Component/route smoke tests + `npm run build` verification.

### Package 8 — End-to-End Verification, Regression Suite & Sprint 6 Completion Report
- **Objective:** Execute full quality gate (`prisma validate`, `typecheck`, `lint`, `npm test`, `npm run test:integration`, `npm run build`), verify PostgreSQL midnight/ISO-week parity & cursor invariants, and update repository specifications.
- **Files / Modules Affected:** `tests/unit/sprint6-*.test.ts`, `tests/integration/sprint6-db.test.ts`, `markdown/*` updates *(other than already-recorded `DECISION-LOG.md`)*, `report/SPRINT-6-IMPLEMENTATION-REPORT.md`.
- **Implementation Tasks:**
  1. Finalize unit & real-PostgreSQL integration suites covering all `TC-DASH`, `TC-REPORT`, `TC-ACT`, Vietnam midnight SQL-vs-TS parity, and cursor pagination stability.
  2. Run full regression across Sprints 1–6 (zero skipped/relaxed assertions, zero N+1 query regressions, partial indexes verified intact).
  3. Update specification docs & generate `report/SPRINT-6-IMPLEMENTATION-REPORT.md`.
- **Dependencies:** Packages 0–7.
- **Acceptance Criteria:** 100% pass across all CLI checks and real PostgreSQL integration assertions; documentation synchronized with as-built codebase.
- **Required Tests:** Complete test suite (`npm test`, `npm run test:integration`) + `npm run build`.

---

## 13. Testing Strategy

Aligned with `markdown/05-Quality-and-Delivery/Testing-Strategy.md`:

### 13.1. Automated Unit Tests (`tests/unit/`)
- **Dashboard & Project Analytics (`sprint6-dashboard.test.ts`, `sprint6-project-analytics.test.ts`):**
  - `0` task / `0` sprint edge cases (`workProgressPercent = 0`, `overdueRate = 0`, `estimateCoverage = 0`, no `NaN`).
  - Separated `workProgressPercent` (`DONE / Total`) vs `timelineProgressPercent` (`startDate -> endDate`), no `dashboard.read` requirement (`requireActiveUser` + widget permission gates).
  - Overdue exact boundary (`deadline == now` not overdue vs `deadline < now` overdue) & `DONE` tasks never counted as currently overdue.
  - `Asia/Ho_Chi_Minh` (`+07:00`) day & ISO Monday-week boundary math (`2026-11-15T16:59:59.999Z` = Sun `2026-11-15 23:59:59.999+07:00` vs `2026-11-15T17:00:00.000Z` = Mon `2026-11-16 00:00:00.000+07:00`).
  - Daily (`<= 90d`) vs ISO Weekly (`> 90d`) auto-bucketing and Zod rejection for `> 365` days or `to < from`; zero per-user arrays in `ProjectReportDTO`.
- **Member Contribution & Attribution (`sprint6-member-contribution.test.ts`):**
  - Multi-assignee non-additive `Sole-Assigned` vs `Co-Assigned` counters + Project Totals reconciliation header (`DEC-047`) and planned `estimateHours` coverage (`DEC-048`).
  - Reassigned task (`removedAt != null`) separated cleanly from active assignments (`removedAt == null`), plus verifiable `TaskHistory`/`TaskReview` counters (`DEC-049`).
  - Departed member (`ProjectMember.leftAt != null`) retaining `DONE` assignment, `"LEFT_PROJECT"` status, and `includeRemoved` toggle (`DEC-050`).
  - Strict authority isolation: `MEMBER` receives `SELF_ONLY` row only vs `LEADER`/`INSTRUCTOR`/`ADMIN` receiving `PROJECT_FULL` (`DEC-052`).
- **Sprint Commitment/Rollover & Burndown (`sprint6-sprint-analytics.test.ts`):**
  - All 6 separated metrics (`Baseline Commitment`, `Scope Added`, `Scope Removed`, `Completed Tasks`, `Rolled Over to Backlog`, `Rolled Over to Another Sprint`) verified against completion metadata (`source = "SPRINT_COMPLETION"`, `completedSprintId`) and `PLANNING` transitions without a snapshot table (`DEC-058`).
  - Final-day Burndown preserves pre-closure remaining hours accurately.
- **Activity Log & API Routes (`sprint6-activity.test.ts`, `sprint6-api-routes.test.ts`):**
  - Deterministic cursor encoding/decoding, `400 VALIDATION_ERROR` on invalid cursors, `(createdAt DESC, source DESC, id DESC)` tie-breaking, `MEMBER` `(actorId = self OR assignedTaskIds)` isolation, unreachable Project `403`/`404`, dynamic `report.read` / `activity.read` Permission Matrix revocation `403`.

### 13.2. Real PostgreSQL Integration Tests (`tests/integration/sprint6-db.test.ts`)
- Execute against live PostgreSQL 18 schema (`5` existing migrations + Sprint 6 migration):
  - Multi-project fixture (`ACTIVE`, `CREATED`, `ARCHIVED`) + multi-sprint (`ACTIVE`, `COMPLETED` with real `completeSprintService` rollover to Backlog and next Sprint, `CANCELLED`) + multi-assignee & reassigned tasks + departed member (`removeProjectMemberService` after `DONE` tasks) + `TaskReview` approvals/rejections.
  - **Vietnam Midnight & ISO Week SQL-vs-TypeScript Parity Test:** Insert tasks and history rows straddling UTC day rollover and HCM midnight (`2026-11-15T16:59:59.999Z` vs `2026-11-15T17:00:00.000Z` — Sunday vs Monday in `Asia/Ho_Chi_Minh`) and verify SQL `(("col" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')` `::date` / `date_trunc('week', ...)` aggregations produce **100% identical buckets and counts** to `src/lib/timezone.ts` TypeScript helpers, while confirming `Sprint.startDate`/`endDate` PostgreSQL `DATE` values remain unshifted.
  - **Keyset Cursor Stability & Backfill Test:** Verify `ActivityLog.projectId` guarded backfill handles both valid Projects and malformed/unbackfillable metadata safely; verify cursor paging over `ActivityLog` + `TaskHistory` ties at identical timestamps (`source DESC, id DESC`) and inserts a brand-new row mid-pagination without causing duplicates or skips on subsequent `cursor` pages.
  - Assert Sprint 2–4 partial unique indexes (`Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`) remain active alongside Sprint 6 indexes.

### 13.3. Traceability to `Testing-Strategy.md`
- Covers `TC-DASH-001`..`TC-DASH-008` (Active/Archived/Empty Dashboard, Overdue count, My Tasks, Recent Activity, Widget RBAC).
- Covers `TC-REPORT-001`..`TC-REPORT-004` (Project progress, Member contribution non-additive/self-scope rules, 6-metric Sprint comparison, Insufficient estimate data).
- Covers `TC-ACT-001`..`TC-ACT-006` (Project/Workspace activity filters, keyset cursor pagination, Task+Project log unification, `MEMBER`/`INSTRUCTOR`/`LEADER`/`ADMIN` authorization).

---

## 14. Acceptance Criteria

Sprint 6 is acceptable for release only when ALL criteria below hold simultaneously:
1. Operational Dashboard (`/dashboard`) displays live `Total`, `Completed`, `In Progress`, `Waiting Review`, `Overdue`, separated `Work Progress %` and `Timeline Progress %`, Active Sprint operational summary, `My Assigned Tasks`, and `DEC-052`-scoped `Recent Activity` using `requireActiveUser` + per-widget permission checks (`DEC-051`).
2. Project Reports (`/reports`, `/projects/[projectId]/reports`) render all 6 management-question Aggregate Analytics charts using **Pure React + SVG + Tailwind** (`DEC-056`) with `Asia/Ho_Chi_Minh` alignment, `365d` cap / `> 90d` weekly aggregation (`DEC-057`), explicit insufficient-data alerts, and zero per-user breakdowns (`DEC-052`).
3. Member Contribution Report transparently reports non-additive `Sole-Assigned` vs `Co-Assigned` counts + Project Totals banner (`DEC-047`), planned `estimateHours` with coverage disclaimers (`DEC-048`), current vs historical removed assignments & verifiable actions (`DEC-049`), departed member status + toggle (`DEC-050`), strict `MEMBER` `SELF_ONLY` isolation (`DEC-052`), and zero ranking scores or CSV exports (`DEC-054`).
4. Sprint Completion & Burndown reports accurately separate all 6 Sprint commitment & rollover metrics from history (`DEC-058`) and eliminate Sprint 4's final-day `0h`-drop artifact.
5. Unified Activity History (`/activity`) merges `ActivityLog` + `TaskHistory` via `ActivityLog.projectId` (`DEC-055`) using deterministic keyset cursor pagination `(createdAt DESC, source DESC, id DESC)`, deep links, and strict `DEC-052` authorization (`MEMBER` isolated to own/assigned-task events).
6. `ARCHIVED` projects remain fully inspectable in read-only mode across Dashboard switcher, Reports, and Activity without leaking mutation controls (`DEC-053`).
7. Every endpoint enforces RBAC, Project-scoped access, and Zod v4 validation on the server (`401`/`403`/`404`/`400`), with no client-bundle secrets or Prisma client leakage.
8. Zero N+1 query loops (`< 8` SQL queries per report request).

---

## 15. Risks and Dependencies

| Risk / Dependency | Severity | Impact | Concrete Mitigation |
|---|---|---|---|
| **Historical Sprint Reconstruction Clock Skew & Mutable Estimates (`TU-601`, `TU-602`)** | Medium | Pre-enrichment Sprint 4–5 baseline moves adjacent to `activatedAt` or edited `estimateHours` cannot achieve immutable snapshot accuracy without a snapshot table. | Disclose `reconstructionConfidence` + limitations honestly per `DEC-058`; add zero-table forward JSON metadata (`baselineTaskIds`, `sprintStatus`) in Package 3 for deterministic precision going forward. |
| **Prisma Migration Partial-Index Deletion** | High | `prisma migrate dev` drops `Project_single_active_idx`, `ProjectMember_active_project_user_idx`, `TaskAssignee_active_task_user_idx`, `Task_projectId_backlog_deadline_idx`. | Always run `--create-only`, inspect SQL, strip generated `DROP INDEX` lines, keep `@db.VarChar(100)` on `ActivityLog.entityType`, and verify partial indexes in `sprint6-db.test.ts`. |
| **PostgreSQL `TIMESTAMP(3)` vs `DATE` Timezone Shift Bug** | High | Using single `col AT TIME ZONE 'Asia/Ho_Chi_Minh'` on `TIMESTAMP(3)` (`TIMESTAMP WITHOUT TIME ZONE`) shifts timestamps by `-07:00` instead of `+07:00`, while shifting `Sprint.startDate`/`endDate` (`DATE`) corrupts calendar bounds. | Enforce double conversion `(("col" AT TIME ZONE 'UTC') AT TIME ZONE 'Asia/Ho_Chi_Minh')` in raw SQL, use UTC `Date` bounds in indexed `WHERE` clauses, keep `DATE` unshifted via `formatSprintDateYmd`, and verify with midnight PostgreSQL parity tests. |
| **Unit Mock Drift on `activityLog.create` Update** | Low–Medium | Updating `19` project-scoped `activityLog.create` calls in `6` services to include `projectId` may break strict `toHaveBeenCalledWith(...)` unit mocks from Sprints 2–5. | Update affected Sprint 2–5 unit test expectations cleanly inside Package 1 and run full `npm test` regression before Package 2. |
| **Uncommitted Sprint 5 Working Tree & Empty Domain Seed (`TU-605`)** | Medium | Workspace holds uncommitted Sprint 5 edits, and `prisma/seed.ts` seeds no projects/tasks for manual chart QA. | Commit/verify Sprint 5 clean baseline before Package 1; rely on `sprint6-db.test.ts` multi-sprint PostgreSQL fixtures for full automated coverage. |
| **Ethical / Interpretation Misuse of Member Metrics** | Medium | Naive readers might still sum member rows or equate `Done Count` / `estimateHours` with individual effort. | Enforce `BR-S6-004`/`005` banners (`DEC-047`, `DEC-048`), exclude scores/leaderboards, and surface `Sole`/`Co-Assigned` & coverage disclaimers. |

---

## 16. Documentation Updates

- **Completed in Planning Revision:** `markdown/DECISION-LOG.md` updated with confirmed Sprint 6 decisions **`DEC-047` – `DEC-058`**.
- **During Sprint 6 Execution (Package 8), synchronize:**
  1. `markdown/02-Requirements/Business-Rules-and-Workflows.md` — Close `TBD-014`, `TBD-029`, `TBD-030` (reporting scope) and add Sprint 6 attribution/reporting rules.
  2. `markdown/02-Requirements/Software-Requirements-Specification.md` — Close `OI-013` and align `FR-DASH` / `FR-ACT` specs.
  3. `markdown/02-Requirements/Use-Case-Specification.md` — Close `TBD-UC-017`, `TBD-UC-018`.
  4. `markdown/03-Architecture-and-Design/API-Specification.md`, `Database-Design.md`, `UI-UX-Design.md` — Document `/api/v1/dashboard`, `/api/v1/reports/*`, `/api/v1/activity` keyset cursor contract, `ActivityLog.projectId` + cursor/reporting indexes, and Pure SVG UI architecture (noting `Recharts` intentionally omitted per `DEC-056`).
  5. `markdown/05-Quality-and-Delivery/Testing-Strategy.md` — Update `TEST-008`, `TEST-009`, and Sprint 6 automated test coverage inventory.
  6. `report/SPRINT-6-IMPLEMENTATION-REPORT.md` — Final implementation, migration, and verification evidence report.

---

## 17. Definition of Done

Sprint 6 is **Done** only when ALL items below are verified and evidenced:
- [x] **1.** All 12 Open Questions (`OQ-601`–`OQ-612`) confirmed by PO and logged in `markdown/DECISION-LOG.md` as `DEC-047`–`DEC-058`.
- [ ] **2.** Minimal `ActivityLog.projectId` + guarded SQL backfill + cursor/reporting index migration applied via reviewed Prisma migration with Sprint 2–4 partial indexes preserved, `19` project-scoped `activityLog.create` call sites updated, and `npx prisma validate` passing (`DEC-055`).
- [ ] **3.** `src/lib/timezone.ts` shared across Burndown, Deadline Reminder, Analytics, and Activity queries with verified PostgreSQL `TIMESTAMP(3)` double `AT TIME ZONE` / `DATE` midnight parity (`DEC-057`).
- [ ] **4.** Unified `/activity` + `GET /api/v1/activity` implemented merging `ActivityLog` and `TaskHistory` under deterministic keyset cursor pagination `(createdAt DESC, source DESC, id DESC)` and strict `DEC-052` role/assignment filtering.
- [ ] **5.** All 6 Sprint commitment & rollover metrics reconstructed cleanly without a snapshot table (`DEC-058`), plus Sprint Burndown completion-day rollover fix preserving Sprint 4 contracts.
- [ ] **6.** `GET /api/v1/reports/projects/[projectId]` and all 6 management-question Aggregate Analytics views implemented via non-N+1 PostgreSQL queries (`365d` max window, weekly auto >90d, zero per-user leaks).
- [ ] **7.** `GET /api/v1/reports/projects/[projectId]/members` implemented strictly obeying non-additive `Sole`/`Co-Assigned` split (`DEC-047`), planned-effort coverage (`DEC-048`), current/historical separation (`DEC-049`), departed members + toggle (`DEC-050`), `MEMBER` `SELF_ONLY` isolation (`DEC-052`), and view-only zero-export compliance (`DEC-054`).
- [ ] **8.** `/dashboard` and `GET /api/v1/dashboard` upgraded with operational Project Switcher, KPIs, separated `Work Progress` & `Timeline Progress`, Active Sprint summary (no Reports/Burndown duplication per `DEC-051`), `MyAssignedTasksCard`, and `DEC-052`-scoped `Recent Activity` using `requireActiveUser` + per-widget permissions.
- [ ] **9.** `/reports`, `/projects/[projectId]/reports`, `/activity`, and AppShell navigation implemented strictly with **Pure React + SVG + Tailwind** charts (`DEC-056`), read-only `ARCHIVED` banners (`DEC-053`), accessible insufficient-data states, and zero client secret leakage.
- [ ] **10.** `npm run typecheck`, `npm run lint`, `npm test` (unit + API route tests), `npm run test:integration` (real PostgreSQL incl. midnight parity & concurrent cursor stability), and `npm run build` all pass with zero failures and zero skipped assertions.
- [ ] **11.** All specification docs listed in Section 16 updated and `report/SPRINT-6-IMPLEMENTATION-REPORT.md` generated.

---

## 18. Phase 1 Technical Refinements & Boundary Specifications (`P0-01` – `P1-03`, Consistency Rules)

This section locks exact engineering contracts resolved during Phase 1 technical review without altering any confirmed decision (`DEC-047` – `DEC-058`).

### 18.1. `P0-01` — Historical Estimate Snapshot & Reconstruction Rules (`DEC-058`)

Direct inspection of `src/modules/tasks/task.service.ts` confirms `Leader`/`Admin` may edit `Task.estimateHours` via `updateTaskService` (`src/modules/tasks/task.service.ts:368-372`) even after Sprint activation or completion on non-archived Projects, and every edit appends a `TaskHistory(INFO_UPDATED)` record containing `{ oldValue: { estimateHours }, newValue: { estimateHours } }`, while `createTaskService` logs initial `{ newValue: { estimateHours } }` on `TaskHistory(CREATED)`.

1. **Deterministic Chronological Rollback (Zero Snapshot Table Required):**
   - To reconstruct `task.estimateHours` at any target instant `T` (e.g., `Sprint.activatedAt`, end-of-day `hcmEndOfDay(d)`, `task.completedAt`, or `Sprint.completedAt`), start from `cursorEstimate = task.estimateHours` and roll backward in strict `(createdAt DESC, id DESC)` order over all `TaskHistory(INFO_UPDATED)` rows touching `estimateHours` strictly after `T` (`event.createdAt > T`), restoring `cursorEstimate = event.oldValue.estimateHours`.
   - When forward JSON metadata exists (`ActivityLog(SPRINT_ACTIVATED).metadata.baselineTasks` or `TaskHistory(SPRINT_*).metadata.estimateHoursSnapshot`), prefer the explicit event snapshot and cross-validate against rollback.
2. **Sprint Metric Evaluation Instants & Unestimated Handling:**
   - `Baseline Commitment`: evaluated at `Sprint.activatedAt` (or explicit `SPRINT_ACTIVATED` metadata snapshot).
   - `Scope Added` / `Scope Removed` (including mid-sprint `SPRINT_MOVED`): evaluated at `TaskHistory.createdAt` of the transition event.
   - `Completed Tasks`: evaluated at `min(task.completedAt, closureAtOrNow)`.
   - `Rolled Over to Backlog` / `Rolled Over to Another Sprint`: evaluated at `closureAt` (`completedAt` / `cancelledAt`).
   - Tasks with `estimateHours === null` at the target instant contribute `0h` AND increment unestimated counts (`estimateCoveragePercent`); current post-instant estimates are **never** back-propagated into prior instants.
   - If continuity in `INFO_UPDATED` history is broken (e.g., direct manual SQL edit bypassing services), flag `estimateSnapshotStatus = "INCOMPLETE_HISTORY"` honestly instead of claiming exactness.
   - Expose explicit `estimateSnapshotMode`, `reconstructionConfidence`, `estimateCoveragePercent`, `hasPostSprintEstimateEdits`, `estimateDeltaHours`, and `limitations[]` on Sprint comparison and Burndown DTOs.

### 18.2. `P0-02` & `P1-03` — Current vs Historical Assignment, Left Members & Episode Counts

- **Current Assignment Rule (`P0-02`):** Verified `member.service.ts` (`taskAssignmentGuard`) permits departing members (`ProjectMember.leftAt IS NOT NULL`) to retain `TaskAssignee.removedAt IS NULL` on already-`DONE` Tasks. Therefore, a contributor `u` holds a **Current Assignment** on Task `t` iff **both**:
  1. `TaskAssignee` has `removedAt IS NULL`, **AND**
  2. `u` is currently an active Project participant (`membershipStatus === "ACTIVE"`, i.e., `u === project.leaderId || u === project.instructorId || active ProjectMember with leftAt IS NULL`).
  - If `membershipStatus !== "ACTIVE"` (`"LEFT_PROJECT"` or `"HISTORICAL_ONLY"`), any remaining `removedAt IS NULL` rows on `DONE` tasks move strictly into **Historical Assignments** (`retainedOnDepartureDoneCount`), with `currentAssigned.* = 0`.
- **Historical Distinct Task Count vs Episode Count (`P1-03`):** Because assign/unassign cycles create multiple `TaskAssignee` rows for the same `(taskId, userId)`:
  - `historicalAssignedTaskCount` counts **`COUNT(DISTINCT taskId)`** across tasks where `u` participated previously and is NOT currently actively assigned.
  - `historicalUnassignedTaskCount` counts **`COUNT(DISTINCT taskId)`** across tasks with at least one `removedAt IS NOT NULL` row (never double-counting repeated cycles on the same task).
  - `assignmentEpisodeCount` (`COUNT(*)`) is surfaced separately as assignment episode telemetry and **never** summed into task counts.

### 18.3. `P1-01` — Activity History Cursor Validation & Pagination Semantics

- Cursor format (`?cursor=`): Base64url-encoded JSON `{ createdAt: ISO8601, source: "WORKSPACE" | "TASK", id: UUID }`, schema-validated via Zod (`400 VALIDATION_ERROR` on invalid format). This is an **opaque schema-validated keyset cursor** (not claimed tamper-proof); server queries ALWAYS enforce `PERMISSIONS.ACTIVITY_READ`, accessible Project scope, Admin-only system logs (`projectId IS NULL`), and `MEMBER` `(actorId = self OR assignedTaskIds)` rules independently of cursor contents.
- Dual-arm index-pushed keyset seek fetches `limit + 1` per arm ordered `(createdAt DESC, source DESC, id DESC)`:
  - When `cursor.source === "WORKSPACE"`: Arm A (`ActivityLog`) seeks `(createdAt < c.createdAt OR (createdAt = c.createdAt AND id < c.id))`; Arm B (`TaskHistory`) seeks `createdAt <= c.createdAt`.
  - When `cursor.source === "TASK"`: Arm A seeks `createdAt < c.createdAt`; Arm B seeks `(createdAt < c.createdAt OR (createdAt = c.createdAt AND id < c.id))`.
- `nextCursor` is ALWAYS encoded from **`items[limit - 1]`** (last returned item), NEVER from the `limit + 1` probe item.
- Filter updates on UI reset `cursor` to `null`; concurrent inserts after page 1 do not corrupt `cursor`-paged older pages, and **"Làm mới"** resets to latest head.

### 18.4. `P1-02` — Project Timeline Progress & Date Parity (`Project.startDate/endDate`)

- Verified `src/components/projects/project-form.tsx` submits `"YYYY-MM-DD"` dates via `z.coerce.date()`, stored as `TIMESTAMP(3)` UTC midnight (`YYYY-MM-DDT00:00:00.000Z`), and formats back with `.toISOString().slice(0, 10)`.
- `toBusinessCalendarYmd(date)` treats exact UTC midnight (`HH:mm:ss.sss === 00:00:00.000Z`) as that `YYYY-MM-DD` calendar date and uses `Asia/Ho_Chi_Minh` (`UTC+07:00`) for all other instants (`now` is always evaluated in `Asia/Ho_Chi_Minh`).
- `computeProjectTimelineProgress(startDate, endDate, now)`:
  - Missing either date or invalid range -> `timelineProgressPercent: null` (rendered `"N/A"`).
  - `todayYmd < startYmd` -> `0%`.
  - `todayYmd > endYmd` -> `100%` (capped).
  - `startYmd === endYmd` (single-day project, zero-division guard) -> `100%` when `todayYmd >= startYmd`.
  - Otherwise `Math.min(100, Math.max(0, Math.round((elapsedDays / totalSpanDays) * 100)))`.
  - Displayed strictly alongside and separate from `workProgressPercent` (`DONE / Total`, `DEC-051`).

### 18.5. `§6` — Date Range & Current-vs-Historical Scope Rules

- **Current Operational State (Unaffected by Date Range `from`–`to`):** Dashboard KPIs, Task Status & Priority Distributions, Overdue Aging of currently unfinished tasks, Estimated Effort aggregate distributions, and Member Contribution **`currentAssigned.*`** (`To Do`, `In Progress`, `Review`, `Done`, `Overdue`, `Sole`/`Co-Assigned`, `Planned Estimate Hours`) always reflect live Project truth regardless of selected Analytics window (`7d`/`30d`/`90d`/`all`/`custom`).
- **Date-Range Filtered Analytics & Actions (`[fromUtc, toUtc]` in `Asia/Ho_Chi_Minh`):** `completionSeries`, `overdueSlipSeries`, Activity History (`from`/`to`), and Member Contribution **`activities.*`** (`TaskHistory` & `TaskReview` counters) are strictly filtered to `[fromUtc, toUtc]`.
- **Attribution vs Request-Time Authorization:** Historical attribution (`TaskAssignee`, `TaskHistory`, `TaskReview`, former `ProjectMember` rows) preserves past contributor credit (`DEC-050`) independently of request-time API authorization (`assertProjectReadAccess` + `MEMBER` `SELF_ONLY`).

