# SPRINT 7 IMPLEMENTATION PLAN — FINALIZATION, TESTING & DEPLOYMENT (REVISED)

**Project:** Akatsuki Yui — Internal Team & Project Management System  
**Sprint:** Sprint 7 (Final MVP Sprint) — Security-First, Performance-Optimized Finalization, System Testing, Deployment & Handover  
**Phase:** Final Review Corrections Applied (`DEC-059` – `DEC-069` Logged as `Approved` in `markdown/DECISION-LOG.md`) — Planning Complete — Awaiting Implementation Authorization  
**Current Branch Observed:** `feat/sprint6-reporting-analytics-dashboard` (head `7d52781`, plus 3 unstaged working-tree files for Sprint 4 backlog pagination bugfix — preserved untouched during planning)  
**Architecture:** Modular Monolith (`Next.js 16.4.6` App Router, `React 19`, `TypeScript 5.9`, `PostgreSQL 18`, `Prisma 6.19.3`, `Auth.js v5`, `Zod v4`, `Tailwind CSS v4`, `shadcn/ui`, `Resend SDK`, `Vitest 5.1.0`)  
**Author:** Senior Software Architect / Technical Lead  
**Last Updated:** 2026-11-15

---

## 1. Sprint Overview

Sprint 7 is the **finalization, hardening, verification, and release Sprint** for **Akatsuki Yui**. Across Sprints 1–6, the application implemented the full MVP scope (Authentication & Account Approval, Dynamic RBAC & Permission Matrix, Project Lifecycle & Templates, Multi-Assignee Tasks with DAG Dependencies & Review Workflow, Sprint Planning/Backlog/Kanban/Burndown, Google Drive Document Library, In-app & Resend Email Notifications with Cron Recovery, Operational Dashboard, Member Contribution Reports, Project/Sprint Analytics, and Unified Activity History).

Following Product Owner technical review and Final Review Corrections, Sprint 7 prioritizes:
1. **Highest MVP-appropriate Security & Privacy:** Additive `User.tokenVersion` session revocation (`DEC-063`), dedicated `project.template.manage` RBAC permission (`DEC-064`), PostgreSQL-backed atomic **Sliding Window Log** rate limiting (`RateLimitEvent`) with scope+identifier HMAC keying and fail-closed `503` protection (`DEC-065`), Last-Admin & Task `FOR SHARE` concurrency locks, HTTP security headers / CSP, strict redirect/URL sanitization, and strict data minimization.
2. **Absolute Test-Data, Least-Privilege & Free-Tier Safety:** Mandatory `TEST_DATABASE_URL` isolation with zero fallback to `.env` `DATABASE_URL` (`DEC-066`), non-destructive idempotent `prisma/seed.ts` preserving Admin permission revocations (`DEC-067`), least-privilege Vercel Runtime DB access (pooled `DATABASE_URL` only; `DIRECT_URL` kept strictly in Operator/Migration runner), centralized API/batch/query resource caps, and Free-Tier quota protections (`DEC-059`–`DEC-062`).
3. **Measurable Lab & Remote Performance:** RSC-first rendering, N+1/over-fetching elimination, keyset pagination, Neon Singapore + Vercel `sin1` co-location, Prisma 6.19.3 PgBouncer verification, and transparent Lab Performance benchmarking (Lighthouse/Playwright `LCP`/`CLS`/Interaction Latency + Neon Cold-Start vs Warm-Request latency) measured cleanly without misrepresenting Lab runs as Field Core Web Vitals.
4. **End-to-End Business Confidence:** Automated Vitest + PostgreSQL integration + Playwright E2E coverage spanning Workflows **A–H** with an explicit Event-to-Report Verification Matrix, fixing all verified Sprint 6 & Dashboard/UX defects (`BUG-701`–`BUG-704`), and completing safe non-destructive Production Smoke Verification + Documentation Synchronization (`DEC-068`–`DEC-069`).

> **Planning Mode Boundary:** During this planning revision, only `report/SPRINT-7-IMPLEMENTATION-PLAN.md` and `markdown/DECISION-LOG.md` were updated. Zero application source code, Prisma schema/migrations, `.env`, `.env.example`, `.gitignore`, or Git branches/commits (including the 3 uncommitted Sprint 4 fix files) were modified.

---

## 2. Current System Status

Independent inspection of `src/`, `prisma/`, `tests/`, `package.json`, `vercel.json`, `next.config.ts`, `.gitignore`, and Sprint 1–6 reports confirms:

### 2.1. Sprint 1–6 Completeness & Verification Baseline

| Metric / Artifact | `SPRINT-6-IMPLEMENTATION-REPORT.md` Note | Verified Repository Reality (2026-11-15) | Action Required in Sprint 7 |
|---|---|---|---|
| **Git Branch & Working Tree** | Reported on `feat/sprint5-*` with Sprint 6 uncommitted | On `feat/sprint6-reporting-analytics-dashboard` (`7d52781` committed) + **3 unstaged Sprint 4 fix files** (`sprints/[sprintId]/page.tsx`, `sprint-planning.service.ts`, `sprint4-services.test.ts`) | Keep untouched during planning; PO review -> commit -> `dev` -> `feat/sprint7-*` in Package 1 |
| **Database Migrations** | 6 migrations applied | **6 migrations** in `prisma/migrations/*`; `npx prisma migrate status` up to date; `package.json#prisma` Prisma 7 deprecation warning noted | Additive Sprint 7 migration needed in Package 2 (`User.tokenVersion`, `RateLimitEvent`, one-time `project.template.manage` `ADMIN` grant) |
| **Permission Catalog** | Reported 27/29 permissions (`README.md:24` misstates `29`) | **27 permissions** currently in `src/modules/authorization/constants.ts:10-38` | Add `project.template.manage` (**28 permissions** total) and fix `README.md:24` |
| **Test Suite (`npm test`)** | 29 files / 165 tests passed | **29 files (23 unit + 6 PostgreSQL integration) / 168 tests passed, 0 skipped** | Isolate `TEST_DATABASE_URL` immediately (`DEC-066`), clean `sprint1-db.test.ts:60` hardcoded email, add Playwright E2E (`tests/e2e/`) |
| **Build (`npm run build`)** | 30 static pages / 102 routes | **30 static pages / 102 route entries**, `tsc --noEmit` & `eslint .` PASS (`middleware.ts` deprecated -> `proxy.ts` warning) | Evaluate `middleware.ts` -> `proxy.ts`, add `/api/health`, `postinstall`, `trustHost: true` |
| **Format Check** | Pre-existing CRLF warnings | Fails on **83 older Sprint 1–4 files** | **Do not bulk-reformat** (`DEC-068`); enforce Prettier only on touched Sprint 7 files |
| **E2E Browser Tests** | Planned in `Testing-Strategy.md` | **0 files** (`tests/e2e/` and `@playwright/test` absent) | Add Playwright E2E covering Workflows A–H, Security & Lab Performance / UI |

### 2.2. Verification of Sprint 6 Specifics

1. **Historical Estimate Reconstruction (`P0-01`):** Implemented in `src/modules/sprints/estimate-reconstruction.ts`, `sprint-analytics.service.ts`, and `sprint-report.service.ts`. Gaps: `canUseActivationFallback` (`sprint-analytics.service.ts:245-273, 310-314`) only triggers for `dayIndex === 0` (`Day 0` snapshot pass vs `Day 1+` fallback mismatch), `resolveTaskEstimateAt` (`estimate-reconstruction.ts:196-236`) skips cross-checking `CREATED.newValue.estimateHours`, and tests miss `CREATED` after `targetInstant`, partial `INFO_UPDATED` diffs, `CANCELLED` sprint burndown, and pre-activation `DONE` tasks.
2. **Current vs Historical Assignment (`P0-02`, `P1-03`):** Implemented cleanly in `src/modules/reports/member-contribution.service.ts:265-380`. Note minor DTO drift from `report/SPRINT-6-IMPLEMENTATION-PLAN.md:518-536` (`estimateEffortByAssignmentState`, `completedHours`, `failedEmailDeliveriesCount` omitted).
3. **Activity Cursor Pagination (`P1-01`):** Implemented in `src/modules/activity/activity.repository.ts:252-609`. Gaps: `ACTIVITY_ENTITY_TYPES` (`activity.schema.ts:11-19`) omits `"ProjectMember"`; `findActorOptionsForFilter` omits peer actors for `MEMBER` on assigned tasks; `activity-log-client.tsx:229-319` omits UI controls for `search`, `entityType`, and `action`; `search`/`entityType`/`getActivityFilterOptionsService` lack unit coverage.
4. **Project Timeline & Switcher:** Confirmed bugs: `/reports` stale state (`reports/page.tsx:82`), single-active-sprint `findFirst` assumption (`DEC-006` violation in `dashboard.service.ts` & `project-analytics.repository.ts`), and `formatPgDateYmd` vs `toProjectCalendarYmd` formatter mismatch.
5. **`ActivityLog.projectId` Backfill & `MEMBER` `SELF_ONLY` / `ARCHIVED` Read-Only:** Verified working cleanly across services and PostgreSQL migration `20261115114856`.

### 2.3. Verified Defects, Security Risks & Infrastructure Hazards to Fix in Sprint 7

| ID | Severity | Area | Verified Evidence & Required Fix |
|---|---|---|---|
| **BUG-701** | **High** | Dashboard Links | **3 broken `404` links** in `src/components/dashboard/operational-dashboard-client.tsx`: `L193` `/board` -> `/kanban`, `L526` `/admin/accounts` -> `/admin/users`, `L534` `/admin/rbac` -> `/admin/roles`. |
| **BUG-702** | **High** | Reports UI | `src/app/(dashboard)/reports/page.tsx:82` passes no `key` to `ProjectReportsClient` -> Project Switcher renders stale state (`L123-144`). |
| **BUG-703** | **Medium** | Stability & UX | Zero `error.tsx`, `global-error.tsx`, `not-found.tsx`, `loading.tsx` in `src/app/`; `/activity` lacks `search`/`entityType`/`action` UI filters; Sprint 5 `/documents`, `/notifications`, `/admin/notifications/deliveries` truncate silently at 100 items without pagination or Toast notifications. |
| **BUG-704** | **Medium** | Logic Parity | `dashboard.service.ts` & `project-analytics.repository.ts` assume single Active Sprint (`DEC-006`); inconsistent `Project.startDate/endDate` formatters; `ACTIVITY_ENTITY_TYPES` omits `"ProjectMember"`; Sprint 6 Day-0/1+ & `CANCELLED` burndown edges. |
| **SEC-701** | **High** | Rate Limiting | **Zero rate limiting** on Login, Register, Admin Retry, Password Change, or notification-emitting mutations -> implement PostgreSQL-backed atomic **Sliding Window Log** (`RateLimitEvent`, `DEC-065`) with fail-closed `503`. |
| **SEC-702** | **Medium** | Authorization | `template.service.ts:35-37`, `admin/templates/page.tsx:12-15`, `app-shell.tsx:78` allow any `LEADER` (`project.create`) to mutate/delete global templates -> restrict to independent `project.template.manage` (`DEC-064`). |
| **SEC-703** | **Medium** | Session Security | Password change (`user.service.ts:326-363`) leaves 7-day JWTs valid -> implement `User.tokenVersion` check (`DEC-063`) across Password Change & Suspend/Reactivate. |
| **SEC-704** | **Medium** | Concurrency & Bounds | Last-Admin protection (`user.service.ts:130-138, 227-238`) lacks `pg_advisory_xact_lock`; Task mutations omit `Project ... FOR SHARE` lock; `completeSprintSchema.taskDispositions` lacks `.max()`; `parseJsonBody` (`src/lib/request.ts:18-24`) lacks body byte limit. |
| **SEC-705** | **Medium** | HTTP & Hygiene | `next.config.ts` lacks `CSP`, `HSTS`, `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, `Permissions-Policy`; `PROTECTED_ROUTE_PREFIXES` (`auth.config.ts:12`) omits 5 protected sections; `getSafeCallbackUrl` (`login-form.tsx:24-29`) misses `/\` & control chars; `logger.ts` misses `email` PII masking; email `targetUrl.startsWith("http")` (`notification-email.templates.ts:53`) needs strict URL check. |
| **TEST-701** | **High** | Test Data Safety | `tests/setup-env.ts:1` loads `.env` (`DATABASE_URL`) directly with zero guard; `sprint4-db`, `sprint5-db`, `sprint6-db`, `sprint2-db` mutate live `ACTIVE` Project & `RolePermission` rows; `sprint1-db.test.ts:60` falls back to hardcoded `"pnk1590@gmail.com"` -> enforce `DEC-066` strict `TEST_DATABASE_URL` isolation. |
| **DEP-701** | **Medium** | Production Build & Seed | Missing `/api/health`; missing `postinstall: "prisma generate"`; `auth.config.ts` lacks `trustHost: true`; `route.ts` exports `verifyCronAuthorizationHeader`; `prisma.ts` disables singleton cache in production; `getServerEnv()` unused; `seed.ts:90-103` re-activates `SUSPENDED` Admin & overwrites `fullName`; `rolePermission.upsert` / naive `count === 0` or unconditional permission seeding risks restoring Admin-revoked permissions. |

---

## 3. Sprint 7 Objectives

1. **System-wide Integration & E2E Testing (Objective 1):** Validate Workflows **A–H** end-to-end across UI, Server Actions, REST APIs, Services, and PostgreSQL, verifying event-specific downstream propagation from A–G into matching Dashboard, Member Contribution, Project/Sprint Analytics, and Activity History metrics (H).
2. **Security, Authorization & Resource Limit Enforcement (Objective 2):** Deliver `DEC-063`, `DEC-064`, `DEC-065`, `SEC-701`–`SEC-705`, centralized API/query/batch resource bounds, strict Free-Tier quota safeguards, and full IDOR/injection/redirect/header security verification.
3. **Performance Verification & Stability/UX Finalization (Objective 3):** Fix `BUG-701`–`BUG-704`, enforce RSC/query/pool optimization without cross-user data leaks, add error/404/loading boundaries, and record transparent Lab Performance benchmarks (Lighthouse/Playwright `LCP`, `CLS`, Interaction Latency against target thresholds `LCP <= 2.5s`, `INP <= 200ms`, `CLS <= 0.1`) plus Cold Start vs Warm latency without equating Lab runs to Field Core Web Vitals.
4. **Free-Tier Production Deployment & Operational Readiness (Objective 4):** Deploy safely with **least-privilege DB separation** on Neon Free (Vercel Runtime receives pooled `DATABASE_URL` only; `DIRECT_URL` stays strictly in Operator / Migration runner env) and Vercel Hobby (`sin1`, conditional on account eligibility/privacy checks) + Resend Free (`DEC-059`–`DEC-062`, `DEC-067`), run `prisma migrate deploy` prior to deploy, bootstrap 1 Admin safely once, and pass strictly non-destructive Production Smoke Verification + Lab/WAN measurements.
5. **Final Documentation, Backup & Release Closure (Objective 5):** Synchronize all specs, guides (`12`-step install/deploy + User/Admin + Troubleshooting), `SPRINT-7-IMPLEMENTATION-REPORT.md`, independent off-disk documentation backup (`DEC-068`), and clean `dev -> main` Git release.

---

## 4. Scope

### 4.1. In Scope

- Mandatory `TEST_DATABASE_URL` isolation guard (`DEC-066`) and removal of hardcoded email fixtures (`sprint1-db.test.ts:60`).
- Remediating `BUG-701`–`BUG-704`, `SEC-701`–`SEC-705`, and `DEP-701`, including **1 additive Sprint 7 migration**:
  - `User.tokenVersion Int @default(0)` (`DEC-063`).
  - `RateLimitEvent` table + `(keyHash, createdAt)` and `(expiresAt)` indexes (`DEC-065` Sliding Window Log).
  - One-time default assignment of 28th permission `project.template.manage` to `ADMIN` (`DEC-064`, `DEC-067`).
- Fixing/hardening API & request resource bounds (`parseJsonBody` byte cap, `completeSprintSchema.taskDispositions.max()`, batch/cursor bounds).
- Fixing `prisma/seed.ts` strict permission preservation (`DEC-067`) so repeat runs never overwrite existing Admin profile/status/password and never re-grant Admin-revoked `RolePermission`s (no `count === 0` fallback, no unconditional additive loop).
- Frontend/Backend performance audit, `GET /api/health` readiness check, Playwright E2E + Cross-Module Integration suite + Lab Performance & Neon Cold/Warm latency benchmarking.
- Neon Free + Vercel Hobby (`sin1`, `DATABASE_URL` only) + Resend Free deployment, Operator-run pre-deploy `prisma migrate deploy` over `DIRECT_URL`, safe Production Smoke Verification, doc sync, and independent doc backup.

### 4.2. Out of Scope (Strict Scope Control)

- **New functional modules:** Internal Chat, Real-time Collaboration / WebSockets, GitHub Integration, Actual Time Tracking (`DEC-048`), Story Points, Non-FS Task Dependencies, Task Delete/Reopen workflows, CSV/PDF/Excel Export (`DEC-054`), `NotificationPreference` opt-out UI (`DEC-041`), User Deletion/Retention Cleanup Cron (`DEC-043`).
- **Infra/Architecture drift:** Microservices, NestJS/Express, Redis/Upstash SaaS, Docker/K8s, External Schedulers (`DEC-062`), Paid APM (`DEC-069`), Installing `recharts` (`DEC-056`), or collecting extra personal data beyond `email` & `fullName` (`DEC-061`).
- **Cosmetic churn:** UI redesigns, heavy animations, changing `.gitignore`, or bulk-formatting the 83 pre-existing CRLF/style files (`DEC-068`).

---

## 5. Out of Scope Summary Matrix

| Excluded Item | Reference / Rationale |
|---|---|
| Internal Chat, GitHub, Real-time Collab, Mobile App | Post-MVP (`Project-Scope-and-Roadmap.md`) |
| Actual Time, Non-FS Dependencies, Task Delete/Reopen, CSV/PDF/Excel Exports | Deferred (`DEC-048`, `DEC-054`, `DECISION-LOG.md` -> *Deferred Post-MVP Topics*) |
| Redis / External Scheduler / Paid APM | Zero-cost Modular Monolith (`DEC-062`, `DEC-065`, `DEC-069`) |
| Extra Personal Data (Phone, DOB, Home Address, Shared/Fake Emails) | Strict PII Minimization & Email Ownership (`DEC-061`) |
| In-memory Primary Rate Limiter / Fixed Window Counter Aliased as Sliding Window | Rejected in favor of atomic PostgreSQL **Sliding Window Log** (`RateLimitEvent`, `DEC-065`) |
| `.env` Fallbacks in Integration Tests / Bulk Format of 83 Legacy Files | Forbidden by `DEC-066` and `DEC-068` |

---

## 6. Architecture, Performance, Security & Resource Limit Rules

### 6.1. Architecture & Technical Constraints Preserved

- **Modular Monolith:** Business logic stays inside `src/modules/<domain>/*.service.ts`; RSC pages invoke services directly without self-HTTP calls; Route Handlers & Server Actions authenticate via `requireActiveUser()` -> `loadTrustedAuthContext(userId)` (`policy.service.ts`), which checks BOTH `user.status === ACTIVE` and `user.tokenVersion === jwt.tokenVersion` (`DEC-063`) and reads live RBAC `RolePermission` rows from Postgres.
- **Prisma + Neon Compatibility (`prisma/schema.prisma:5-9`):** Runtime queries use pooled `DATABASE_URL`; DDL/Migrations (`prisma migrate deploy`) use unpooled `DIRECT_URL`. **Prisma 6.19.3 + Neon PgBouncer rule:** Neon uses PgBouncer (`>= 1.21.0`) with protocol-level prepared statement support; Prisma 6 documentation advises **not** appending `?pgbouncer=true` blindly unless `42P05` (*prepared statement already exists*) is actually observed during smoke/integration tests against Neon, and **never** arbitrarily inflating `connection_limit`.

### 6.2. Personal Data & Authentication Privacy Rules (`DEC-061`, `DEC-063`)

- **Minimal Personal Data:** System collects **only `email` and `fullName`** required for identity and team coordination. Never add phone number, birth date, address, or unneeded profile fields.
- **Email Ownership & Credential Separation:** Team members use real email accounts they control individually (no shared/dummy identities); Akatsuki Yui passwords must be distinct from personal email passwords; system never asks for or stores email-account passwords.
- **Zero Cleartext Credential Leaks:** All passwords hashed with `bcryptjs` (`BCRYPT_SALT_ROUNDS = 12`); passwords and `email` PII never logged in cleartext (`logger.ts` masks email addresses as e.g. `a***@domain.com`), never placed in `ActivityLog`, `AuditLog`, or `Notification` messages.
- **Session Revocation (`DEC-063`):** `User.tokenVersion Int @default(0)` increments inside the same transaction whenever `changeMyPasswordService` succeeds OR Admin `SUSPEND`s an account. Reactivated accounts (`ACTIVATE`) do **not** reset or restore old JWTs — users must re-authenticate cleanly.

### 6.3. ProjectTemplate Independent Permission (`DEC-064`)

- Add `PERMISSIONS.PROJECT_TEMPLATE_MANAGE = "project.template.manage"` (28th permission in `PERMISSION_CATALOG`).
- Assigned by default to **`ADMIN` only** in `ROLE_DEFINITIONS`; configurable dynamically in `/admin/roles` Permission Matrix. (Non-core or admin-governed? Admin retains `ROLE_MANAGE` control; default `ADMIN` only, never auto-granted to `LEADER`/`MEMBER`/`INSTRUCTOR`.)
- `LEADER` (`project.create`) retains `listProjectTemplatesService` (`project.read`) read/selection rights when creating a Project, and receives **`403 FORBIDDEN`** on Create/Update/Toggle-Active/Delete Template endpoints & UI unless explicitly granted `project.template.manage` via Matrix.
- Required updates across **7 touchpoints**: Permission Constants (`constants.ts`), Seed (`prisma/seed.ts`), Permission Matrix (`role.service.ts` / tests), `Authorization-Design.md`, `template.service.ts` & `admin/templates/page.tsx`, UI Navigation (`app-shell.tsx`), and Unit/API/Integration tests.

### 6.4. PostgreSQL-Backed Sliding Window Rate Limiting Architecture (`DEC-065`)

- **Why PostgreSQL-Backed Atomic Sliding Window Log (No Redis, No Fixed-Window Counter Aliasing):** Vercel Serverless invokes isolated ephemeral instances where in-memory maps reset across cold starts/instances. Rather than using a Fixed Window Counter (which allows up to `2x` threshold bursts across window boundaries), Sprint 7 implements an exact **PostgreSQL Sliding Window Log** (`RateLimitEvent` table) serialized per key via transaction-scoped advisory locks (`pg_advisory_xact_lock`, compatible with Neon PgBouncer transaction pooling) at `$0` extra infrastructure cost.
- **Data Model (`RateLimitEvent`):**
  - `id String @id @default(uuid()) @db.Uuid`
  - `keyHash String @db.VarChar(64)` — HMAC-SHA256 hex digest using key from `RATE_LIMIT_SECRET` (or HKDF domain-separated subkey derived from `AUTH_SECRET`). **HMAC input MUST strictly combine both `scope` and normalized identifier** (e.g., `${scope}:${normalizedIdentifier}`) so identical IPs/emails never share keys across different limit scopes.
  - `scope String @db.VarChar(50)`
  - `createdAt DateTime @default(now())`
  - `expiresAt DateTime`
  - Indexes: `@@index([keyHash, createdAt])` for trailing-window counts/oldest timestamp lookup; `@@index([expiresAt])` for bounded expiry pruning.
- **Trusted Identifier Extraction:** Read client IP strictly from platform-trusted Vercel headers (`x-vercel-forwarded-for` / `x-real-ip` / trusted last hop), **never trusting client-spoofed `X-Forwarded-For` leftmost entries**. Normalize identifier (`trim().toLowerCase()` for email/IP) before combining with `scope` and HMAC hashing so raw IPs and emails are never persisted in `RateLimitEvent`.
- **Atomic Sliding Window Semantics & Exact `Retry-After`:**
  - Execute inside `prisma.$transaction`:
    1. Acquire transaction lock: `SELECT pg_advisory_xact_lock(hashtextextended($keyHash, 0))` (automatically released on commit/rollback).
    2. Inspect active trailing window `[NOW() - windowInterval, NOW()]`: `SELECT COUNT(*)::int AS "count", MIN("createdAt") AS "oldestAt" FROM "RateLimitEvent" WHERE "keyHash" = $keyHash AND "createdAt" > NOW() - ($windowMs * INTERVAL '1 millisecond')`.
    3. If `count >= limit`: reject **without inserting excess rows**, returning HTTP **`429 Too Many Requests`** + `Retry-After = MAX(1, CEIL((oldestAt + windowMs - now) / 1000))` + generic non-enumerating error text.
    4. Otherwise insert 1 `RateLimitEvent` row (`createdAt = NOW()`, `expiresAt = NOW() + windowInterval`) when recording a request or failed attempt.
- **Explicit Login Bucket Separation & Single-Check Request Guard:**
  - **IP Request Bucket (`scope = "auth:login:ip"`):** Checked and incremented for **every** incoming login attempt regardless of credentials validity.
  - **`(IP + Email)` Login Failure Bucket (`scope = "auth:login:fail"`):** Checked read-only *before* credential verification (`assertSlidingWindowBelowLimit`). **Only incremented (`recordSlidingWindowEvent`) when authentication fails** (wrong password, non-existent/inactive account — maintaining dummy-hash constant timing and generic failure messages). **A successful login MUST NEVER increment the failed-attempt bucket.**
  - **Per-Request Duplicate Check Guard:** Maintain a per-request guard (`WeakSet<Request>` / `AsyncLocalStorage` `checkedScopes: Set<string>`) across REST Route Handlers, Server Actions, and Auth.js `Credentials.authorize` so one HTTP request cannot double-check or double-increment the same `(request, scope)` when layers invoke shared auth helpers.
- **Fail-Closed DB Outage Behavior (`503`):** If the PostgreSQL rate-limit lookup/insert throws an error (DB unavailable/timeout) on security-sensitive endpoints (`/api/v1/auth/login`, `/api/v1/auth/register`, `loginAction`, `registerAction`, `Credentials.authorize`, password change, manual retry, sensitive email mutations), **fail closed** with safe HTTP **`503 Service Unavailable`** (sanitized message, zero raw SQL/connection details) — never failing open to permit unthrottled brute force.
- **Centralized Thresholds (`src/lib/rate-limit.ts` — NO tunable threshold env vars):**

| Protected Flow | Scope(s) & Keyed Input (`${scope}:${normalizedId}`) | Proposed Limit & Mode | Rationale & DoS Fairness |
|---|---|---|---|
| **Login** (`/api/v1/auth/login`, `loginAction`, Credentials `authorize`) | `auth:login:ip` (normalized IP)<br>`auth:login:fail` (`${ip}\|${email}`) | **20 req / 15m** (all requests);<br>**8 failed / 15m** (failures only) | Keying `auth:login:fail` on `(IP + email)` prevents an attacker from locking out a legitimate user logging in from another IP; successful sign-in never increments failure log; single check/increment per HTTP request. |
| **Register** (`/api/v1/auth/register`, `registerAction`) | `auth:register:ip`<br>`auth:register:email` | **10 req / 60m** (all requests);<br>**3 req / 60m** (all requests) | Accommodates shared campus NAT Wi-Fi while protecting `ACCOUNT_REGISTERED` Admin notifications & Resend `100/day` quota. |
| **Change Password** (`changeMyPasswordService`) | `auth:password:fail` (`userId`) | **5 failed / 15m** (wrong `currentPassword` only) | Prevents guessing `currentPassword` from a stolen session without penalizing valid password updates. |
| **Admin Manual Email Retry** (`.../retry` route & action) | `admin:email-retry:actor` (`adminUserId`) + `deliveryId` | **10 req / 10m** per Admin + `DEC-040` `retryCount < 3` | Prevents double-clicks/loops from exhausting Resend Free `100/day` quota. |
| **Email-Emitting Admin/Leader Mutations** (Approve/Reject, Add/Remove member, Transfer leader) | `mutation:email-actor` (`actorUserId`) | **30 req / 5m** per `actor.userId` | Supports realistic onboarding bursts while bounding automated loops and email quota exhaustion. |

- **Valid PostgreSQL Bounded Cleanup SQL (`LIMIT 200`):** PostgreSQL does **not** support `DELETE FROM ... LIMIT N`; cleanup executes via an ordered subquery/CTE bounded to `200` expired rows per short single-statement transaction (inside daily Vercel Cron `/api/internal/notifications/process`, plus optional non-blocking post-response amortized cleanup):
  ```sql
  WITH expired AS (
    SELECT "id"
    FROM "RateLimitEvent"
    WHERE "expiresAt" < NOW()
    ORDER BY "expiresAt" ASC
    LIMIT 200
  )
  DELETE FROM "RateLimitEvent"
  WHERE "id" IN (SELECT "id" FROM expired);
  ```
  - Guarantees short lockless single-statement batches (`<= 200` rows), never deletes events with `"expiresAt" >= NOW()`, never blocks active requests, and is explicitly verified by PostgreSQL Integration Tests.

### 6.5. API, Input & Cost-Protection Resource Limits Table

| Resource | Verified Current State / Sprint 7 Standard | Enforcement Location & Limit |
|---|---|---|
| **Pagination** | Tasks/Projects/Activity max `50`; Docs/Notifications/Deliveries/Templates/TaskHistory max `100`; Defaults `10` or `20` | Zod schemas (`paginationQuerySchema`, `activityQuerySchema`, `documentQuerySchema`, `notificationQuerySchema`, `taskListQuerySchema`) |
| **Search Strings** | `search` capped at `150`–`255` chars trimmed | Zod schemas across `user`, `project`, `task`, `sprint`, `template`, `document`, `notification`, `activity` |
| **Analytics Date Window** | Max **`365 days`**, auto weekly bucket `> 90 days` (`DEC-057`) | `src/modules/reports/report.schema.ts` |
| **Array Inputs** | `technologies` max `30`; `memberIds` max `50`; `sprintPlanningAssignSchema.taskIds` max `100`; `referenceLinks` max `MAX_REFERENCE_LINKS`; **`completeSprintSchema.taskDispositions` -> ADD max `250`** | `sprint.schema.ts:204` (`BUG/SEC-704` fix to match `MAX_KANBAN_CARDS = 250`) |
| **Request JSON Body Size** | Currently unbounded (`request.json()`) -> **ADD `64 KB` (`65536` bytes)** max JSON body check | `src/lib/request.ts` (`parseJsonBody`) returning `400`/`413` cleanly |
| **Batch Operations** | `processDueEmailDeliveriesBatch(50)`; Deadline reminders scoped to `ACTIVE` Projects in `[now-24h, now+24h]` | `notification-delivery.service.ts`, `notification-deadline.service.ts` |
| **Cursor Format** | Base64url JSON validated via Zod, max `1000` chars | `src/modules/activity/activity.schema.ts:69` |
| **DB Unbounded Queries** | Reports/KPIs use SQL aggregates/`groupBy`/bounded `take`; Tasks Kanban max `250` cards | Verified across `dashboard`, `reports`, `kanban` services |
| **Email & Cron Quota Safeguards** | `retryCount < 3` (`DEC-040`), `dedupKey` (`DEC-039`), Resend `idempotencyKey` (`DEC-045`), `SENT` skip check, `CRON_SECRET` Bearer `timingSafeEqual`, **zero client UI polling**, **no user-triggered Cron** | `notification-delivery.service.ts`, `notification-deadline.service.ts`, `cron-auth.ts` |
| **Quota Overflow Behavior** | Exceeding rate limit -> HTTP `429` + `Retry-After`; Resend quota/429/403 -> persisted cleanly as `FAILED` + error code/message in `NotificationDelivery` (never silently dropped, never rolls back domain write); Neon/Vercel quota exhaustion documented in runbook | `api-response.ts`, `notification-delivery.service.ts` |

### 6.6. Performance Architecture & Measurement Plan

#### A. Frontend & Backend Performance Engineering Rules
- **Frontend:** Keep pages Server Components by default; isolate `"use client"` strictly to interactive forms/dialogs/charts/tables; never refetch SSR props redundantly on mount; **zero `setInterval` background polling** (`Notifications` refreshes via manual button / navigation SSR); retain Pure React SVG charts (`DEC-056`, zero `recharts` bundle weight); lazy-load heavy dialogs/modals only if profiling shows bundle bloat.
- **Backend / Database:**
  - Verify zero N+1 loops and narrow `select` projections (never `SELECT *` on wide descriptions/metadata in list views).
  - Use `Promise.all` carefully only across independent read queries (never in parallel inside shared single-client Prisma transactions unless strictly sequential, per Prisma guidelines).
  - Fix `src/lib/prisma.ts:14` so `globalForPrisma.prisma = prisma` caches safely across module reloads in production serverless containers as well as dev.
  - **Strict Privacy-Cache Boundary:** Never store user-specific or `MEMBER`-scoped authorization payloads (`SELF_ONLY`, `/activity`, `/dashboard`, `/notifications`) in shared cross-user caches (`unstable_cache` without `userId+permissions` scope or CDN public `Cache-Control`). Keep authenticated routes `force-dynamic` with `Cache-Control: private, no-store`.

#### B. Lab Performance Benchmark vs Field Core Web Vitals Policy (Never Claim Met Before Measuring!)
Keep **`LCP <= 2.5s`**, **`INP <= 200ms`**, and **`CLS <= 0.1`** as MVP performance targets, **strictly distinguishing Lab Performance Benchmarks from Field Core Web Vitals (CrUX / Real-User Monitoring)**:
- `N >= 5` automated Playwright / Lighthouse / Chrome DevTools runs measure **Lab Performance only** — they are **never** cited as compliance proof for Field Core Web Vitals.
- Because `INP` is natively a Field metric, report **Lab Interaction Latency** (client state transitions, form submissions, Kanban column moves, `/activity` cursor paging) whenever real-user Field `INP` data is unavailable.
- Every benchmark entry MUST record: **Environment** (`next build && next start` local vs Vercel `sin1` + Neon), **Device & Viewport** (Desktop `1280x720`, Mobile `375x812`), **Network Conditions** (local loopback vs throttled / real Singapore WAN), **Dataset Size** (e.g., 150 tasks, 6 sprints, 10 members, 300 activity rows), **Sample Count** (`N >= 5` baseline; `N >= 20` on primary routes where reporting **P50 / P75 / P95** distributions), **Cold Start vs Warm Request** separation, and exact observed metrics:

| Measurement Category | Target Thresholds | How Measured & Reported (Packages 4 & 6) |
|---|---|---|
| **Lab Rendering & Interaction Proxies** (`/login`, `/dashboard`, `/projects/[id]/tasks`, `/projects/[id]/kanban`, `/reports`, `/activity`) | • Target **Lab LCP <= 2.5s**<br>• Target **Interaction Latency <= 200ms** *(INP lab proxy when Field INP unavailable)*<br>• Target **Lab CLS <= 0.1** | Lighthouse / Chrome DevTools Performance trace / Playwright Performance Observer against local `next build && next start` (Package 4) AND Vercel `sin1` + Neon URL (Package 6), logging **Environment, Device/Viewport, Network Conditions, Sample Count (`N`), P50/P75/P95 (when sampled), Warm vs Cold Start**. **Never claim Field CWV pass from Lab runs alone.** |
| **Page / API Load Breakdown** | Record P50 / P75 / P95 TTFB, SSR, & Hydration duration | 1. Initial Landing / Login Load<br>2. Operational Dashboard (`/dashboard`)<br>3. Project Reports (`/reports` + tab switches)<br>4. Task List (`/tasks` page/filter)<br>5. Activity History Keyset Cursor (`page 1 -> page 5`) |
| **Database & Cold Start Latency** | Record SQL duration & Wake-up RTT | Measure Prisma query timings (debug timing wrapper on test/staging) + measure first request after **>5 min idle** on Neon Free (`scale-to-zero` cold wake) vs subsequent warm requests on Vercel `sin1` <-> Neon Singapore. |

---

## 7. Implementation Packages (Updated 7-Package Structure)

Each package touches cohesive, non-overlapping responsibilities and files to avoid rework.

### Package 1: Git Checkpoint, Mandatory Test-DB Isolation & Baseline Hygiene

1. **Objective:** Isolate all integration tests strictly on a dedicated `TEST_DATABASE_URL` (`DEC-066`) and prepare the clean Sprint 7 workspace checkpoint once PO approves Git commit of pending Sprint 4 work.
2. **Scope:**
   - **Preserve 3 uncommitted Sprint 4 fix files untouched during planning** (`sprints/[sprintId]/page.tsx`, `sprint-planning.service.ts`, `sprint4-services.test.ts`); upon PO approval in Package 1 execution, commit them cleanly, sync `dev`, and create branch `feat/sprint7-finalization-deployment`.
   - Enforce `TEST_DATABASE_URL` isolation in `tests/setup-env.ts` (**zero fallback to `.env` `DATABASE_URL`, even on `localhost`**; hard abort if unset or matching `DATABASE_URL` / `DIRECT_URL`; zero URL printing to logs).
   - Remove hardcoded `"pnk1590@gmail.com"` fallback in `tests/integration/sprint1-db.test.ts:60` (use deterministic test-scoped admin setup/query inside test DB).
   - Split scripts cleanly in `package.json`: `test:unit`, `test:integration`, `test:e2e`.
3. **Prerequisites:** PO creates local `akatsuki_yui_test` DB and grants Git checkpoint approval for pending 3 files.
4. **Tasks:**
   - Review `git diff`, commit 3 Sprint 4 fix files, merge to `dev`, create `feat/sprint7-finalization-deployment`.
   - Implement `validateTestDatabaseIsolation()` in `tests/setup-env.ts` invoked for integration tests (`VITEST` / integration suite setup) checking `process.env.TEST_DATABASE_URL`, rejecting empty/missing value, rejecting identical host+db/string with `DATABASE_URL` or `DIRECT_URL`, mapping Prisma's `DATABASE_URL` inside integration worker runtime exclusively to `TEST_DATABASE_URL` in memory (without touching `.env`!), and stripping URLs from error/test logs.
   - Clean up `tests/integration/sprint1-db.test.ts` admin lookup without hardcoded personal email.
5. **Expected Files:** `tests/setup-env.ts`, `tests/integration/sprint1-db.test.ts`, `package.json`.
6. **Dependencies:** None.
7. **Acceptance Criteria:**
   - `npm run test:integration` fails fast with clear redacted error when `TEST_DATABASE_URL` is unset or equals `DATABASE_URL`/`DIRECT_URL` (even if `localhost`).
   - All existing `29` files / `168` tests pass cleanly against `akatsuki_yui_test`.
8. **Test Cases:** `tests/unit/test-db-isolation.test.ts` covering unset `TEST_DATABASE_URL`, matching `DATABASE_URL`, matching `DIRECT_URL`, localhost-fallback rejection, and valid isolated `TEST_DATABASE_URL`.
9. **Risks:** Developers forgetting to migrate/seed `akatsuki_yui_test` before running integration tests -> document exact 2-line setup command cleanly in error message & docs without printing credentials.
10. **Definition of Done:** Clean Sprint 7 branch, P0 `TEST_DATABASE_URL` isolation verified, 168+ tests passing on `akatsuki_yui_test`.

---

### Package 2: Security, Session Revocation, Rate Limiting & Permission Remediation

1. **Objective:** Implement `DEC-063` (`User.tokenVersion`), `DEC-064` (`project.template.manage`), `DEC-065` (PostgreSQL Sliding Window Log rate limiting), concurrency locks, HTTP security headers, body/array resource caps, and PII/redirect hardening (`SEC-701`–`SEC-705`).
2. **Scope:** Prisma additive migration (`User.tokenVersion`, `RateLimitEvent`, one-time `project.template.manage` `ADMIN` default grant), authorization/auth/rate-limit/task-lock/header modules and tests.
3. **Prerequisites:** Package 1 completed.
4. **Tasks:**
   - **Schema & Additive Migration:** Add `User.tokenVersion Int @default(0)` and `model RateLimitEvent` (`id` UUID PK, `keyHash` `VarChar(64)`, `scope` `VarChar(50)`, `createdAt`, `expiresAt`, indexes `[keyHash, createdAt]` and `[expiresAt]`) in `prisma/schema.prisma`, generate reviewed SQL migration preserving all Sprint 2–6 partial indexes and triggers (`--create-only`, verify SQL, include one-time `project.template.manage` Permission + default `ADMIN` grant inside the migration / durable bootstrap marker so `seed.ts` never re-grants revoked permissions later, apply to `akatsuki_yui_test` and dev DB).
   - **Session Revocation (`DEC-063`):** Emit `tokenVersion` in JWT (`src/lib/auth.config.ts`, `src/lib/auth.ts`), compare `user.tokenVersion === token.tokenVersion` inside `loadTrustedAuthContext` (`src/modules/authorization/policy.service.ts`), increment `tokenVersion` inside `changeMyPasswordService` and `updateAccountStatusService` (`SUSPEND` branch, and verify `ACTIVATE` does **not** make stale JWTs work).
   - **Independent `project.template.manage` (`DEC-064`):** Add permission to `src/modules/authorization/constants.ts`, configure new-role default for `ADMIN` in `prisma/seed.ts` (for fresh DB creation only; existing upgraded DBs get one-time migration grant), update `template.service.ts:35-37`, `src/app/(dashboard)/admin/templates/page.tsx:12-15`, and `src/components/layout/app-shell.tsx:78`; keep Project template reading (`PROJECT_READ`) working for Leaders creating Projects; add unit/API/integration tests.
   - **PostgreSQL Sliding Window Rate Limiting (`DEC-065`):** Build `src/lib/rate-limit.ts` implementing atomic PostgreSQL **Sliding Window Log** (`RateLimitEvent` + `pg_advisory_xact_lock(hashtextextended(keyHash, 0))` inside `$transaction`), HMAC-SHA256 over `${scope}:${normalizedIdentifier}` keyed by `RATE_LIMIT_SECRET` or HKDF from `AUTH_SECRET`, trusted IP parsing, separate `auth:login:ip` (all requests) vs `auth:login:fail` `(IP + normalized email)` (read-only assert before verify, increment strictly on failure; **successful login never increments failure log**), per-request duplicate-check guard across REST/Action/Credentials `authorize`, **fail-closed `503`** on DB rate-limit error on sensitive endpoints, and valid PostgreSQL CTE cleanup (`LIMIT 200` inside Cron + optional non-blocking sweep). Enforce on `/api/v1/auth/login`, `/api/v1/auth/register`, `loginAction`, `registerAction`, Credentials `authorize`, `changeMyPasswordService`, `retryNotificationDeliveryService`, Account Status change, Member add/remove, Leader transfer. Ensure `429 Too Many Requests` + exact `Retry-After` + zero Account Enumeration.
   - **Locks & Resource Limits (`SEC-704`):** Add `pg_advisory_xact_lock` to Last-Admin mutations (`user.service.ts`); add `SELECT id FROM "Project" WHERE id = $1::uuid FOR SHARE` inside Task mutation transactions (`task.access.ts` + task services); cap `parseJsonBody` (`64 KB`) in `src/lib/request.ts`; cap `completeSprintSchema.taskDispositions` (`.max(250)`); validate `ProjectTemplate.configuration` JSON size.
   - **HTTP Headers, Middleware/Proxy & Hygiene (`SEC-705`):** Configure tested `CSP` (Next.js/Tailwind/Radix/SVG compatible without blanket `unsafe-eval`/`unsafe-inline` workarounds), `HSTS`, `X-Frame-Options: DENY`, `X-Content-Type-Options: nosniff`, `Referrer-Policy`, `Permissions-Policy` in `next.config.ts`; expand `PROTECTED_ROUTE_PREFIXES` (`auth.config.ts:12`); evaluate `src/middleware.ts` -> `src/proxy.ts` for Next 16 cleanliness; tighten `getSafeCallbackUrl` against `/\` and control chars; mask `email` PII in `logger.ts`; parse `targetUrl` strictly with `new URL(..., baseUrl)` allowing `http:`/`https:` only; extract `verifyCronAuthorizationHeader` from `route.ts` into `src/modules/notifications/cron-auth.ts`.
5. **Expected Files:**
   - `prisma/schema.prisma`, `prisma/migrations/<ts>_sprint7_security_and_rate_limit/migration.sql`, `prisma/seed.ts` (permission constant reference)
   - `src/modules/authorization/constants.ts`, `src/modules/authorization/policy.service.ts`, `src/modules/authorization/require-auth.ts`
   - `src/lib/auth.config.ts`, `src/lib/auth.ts`, `src/lib/rate-limit.ts`, `src/lib/request.ts`, `src/lib/logger.ts`, `next.config.ts`, `src/middleware.ts` (or `src/proxy.ts`)
   - `src/modules/auth/*`, `src/app/api/v1/auth/login/route.ts`, `src/app/api/v1/auth/register/route.ts`, `src/components/auth/login-form.tsx`
   - `src/modules/project-templates/template.service.ts`, `src/app/(dashboard)/admin/templates/page.tsx`, `src/components/layout/app-shell.tsx`
   - `src/modules/users/user.service.ts`, `src/modules/tasks/task.access.ts`, `src/modules/sprints/sprint.schema.ts`
   - `src/modules/notifications/cron-auth.ts`, `src/modules/notifications/notification-delivery.service.ts`, `src/modules/notifications/notification-email.templates.ts`, `src/app/api/internal/notifications/process/route.ts`
6. **Dependencies:** Package 1.
7. **Acceptance Criteria:**
   - Old JWT fails immediately after password change or suspend (even after re-activation).
   - Leader receives `403` attempting template mutations; Admin retains full control; dynamic RBAC grants/revokes `project.template.manage` live.
   - Repeated login/register/retry bursts hit `429` with `Retry-After` from `RateLimitEvent` Sliding Window Log without locking legitimate user email from other IPs, without counting successful logins as failures, without double-counting within one HTTP request, and failing closed (`503`) if rate-limit DB lookup fails.
   - CSP + security headers active cleanly on `next build && next start` with zero console CSP violations.
8. **Test Cases:** `tests/unit/sprint7-security.test.ts` (sliding-window boundary burst, window slide/expiry reset, successful vs failed login tracking, duplicate-check request guard, DB error fail-closed `503`, scope+identifier HMAC keying, `getSafeCallbackUrl`, PII email masking, `parseJsonBody` cap, `completeSprintSchema` cap, strict URL), PostgreSQL integration tests in `tests/integration/sprint7-rate-limit-and-locks.test.ts` (true concurrent burst `pg_advisory_xact_lock`, CTE `LIMIT 200` expired cleanup preserving valid events, Last-Admin & Task `FOR SHARE` races, `tokenVersion`), plus updates in `sprint2-services.test.ts` / `sprint2-api-routes.test.ts` / `user-service.test.ts` / `sprint5-notifications.test.ts`.
9. **Risks:** CSP strictness breaking Next.js inline hydration scripts -> test CSP in headless Chromium against production `next build && next start` in Package 2/4 and tune script-src/hash/nonce cleanly without `unsafe-eval`.
10. **Definition of Done:** All security controls & additive migration tested and passing without regressions.

---

### Package 3: Bug Fixes, Performance Polish, Stability & UX Finalization

1. **Objective:** Fix `BUG-701`–`BUG-704`, Sprint 6 edge cases, and App Router stability boundaries (`error.tsx`, `not-found.tsx`, `loading.tsx`) while enforcing frontend/backend performance discipline without redesigning UI.
2. **Scope:** Dashboard dead links, `/reports` Project Switcher `key` fix, `DEC-006` multi-active sprint parity, date formatter unification, `/activity` missing filter UI & `"ProjectMember"` schema, Sprint 6 estimate reconstruction edge fixes, App Router boundaries, Sprint 5 Toast + pagination parity, responsive polish, and query projection audit.
3. **Prerequisites:** Package 2 completed.
4. **Tasks:**
   - Fix **3 broken 404 links** (`BUG-701`) in `src/components/dashboard/operational-dashboard-client.tsx:193, 526, 534`.
   - Fix **`/reports` Project Switcher stale state** (`BUG-702`) in `src/app/(dashboard)/reports/page.tsx:82` (`key={bundle.analytics.projectId}`) & verify `ProjectReportsClient` state resets cleanly.
   - Fix **Multi-Active Sprints (`DEC-006`) & Date Parity (`BUG-704`):** Upgrade `dashboard.service.ts` / `dashboard.repository.ts` & `project-analytics.repository.ts` to expose `activeSprints[]` cleanly (retaining clean layout); unify `Project.startDate/endDate` formatting via `toBusinessCalendarYmd`; add `"ProjectMember"` to `ACTIVITY_ENTITY_TYPES` (`activity.schema.ts`), fix `findActorOptionsForFilter` (`activity.repository.ts`) for `MEMBER`, and add UI controls for `search`, `entityType`, and `action` on `/activity` (`activity-log-client.tsx`).
   - Fix **Sprint 6 Reconstruction Edge Cases:** Fix Day 0 vs Day 1+ `activationSnapshotByTask` fallback behavior (`sprint-analytics.service.ts:245-273, 310-314`), cross-check `CREATED` initial estimate consistency (`estimate-reconstruction.ts`), and inspect N+1 / overly wide `select` projections across Sprint 1–6 read endpoints.
   - Add **`error.tsx`, `global-error.tsx`, `not-found.tsx`, `loading.tsx`** boundaries (`src/app/` & `src/app/(dashboard)/`) matching existing Tailwind/shadcn styling, never rendering raw stacks/DB errors.
   - Add **Toast feedback** (`sonner`) and **pagination UI (`?page=`)** to Sprint 5 views (`/documents`, `/projects/[id]/documents`, `/notifications`, `/admin/notifications/deliveries`), removing silent 100-row truncation without adding continuous polling.
   - Verify mobile (`375px`), tablet (`768px`), desktop (`1280px`) layouts, confirmation dialogs, disabled submit states, and Vietnamese error/empty states across modules.
5. **Expected Files:**
   - `src/components/dashboard/operational-dashboard-client.tsx`, `src/modules/dashboard/*`
   - `src/app/(dashboard)/reports/page.tsx`, `src/components/reports/project-reports-client.tsx`, `src/modules/reports/*`
   - `src/modules/activity/*`, `src/components/activity/activity-log-client.tsx`
   - `src/modules/sprints/estimate-reconstruction.ts`, `src/modules/sprints/sprint-analytics.service.ts`
   - `src/app/global-error.tsx`, `src/app/not-found.tsx`, `src/app/(dashboard)/error.tsx`, `src/app/(dashboard)/not-found.tsx`, `src/app/(dashboard)/loading.tsx`
   - `src/components/features/documents/document-library-client.tsx`, `src/components/features/notifications/*`, corresponding RSC pages
6. **Dependencies:** Package 2.
7. **Acceptance Criteria:**
   - Zero `404` links anywhere in AppShell, Dashboard, Reports, or Activity.
   - Switching projects on `/reports` updates every metric & SVG chart immediately.
   - Projects with 2+ concurrent `ACTIVE` Sprints render accurately on Dashboard & Reports.
   - Invalid UUIDs show branded `not-found.tsx`; simulated server error shows branded `error.tsx` without leaks.
   - Zero N+1 query regressions and responsive layout clean across 375px/768px/1280px.
8. **Test Cases:** Expand `sprint6-dashboard.test.ts`, `sprint6-sprint-analytics.test.ts`, `sprint6-activity.test.ts` (including `CREATED` after `targetInstant`, partial diffs, `CANCELLED` burndown, `"ProjectMember"` filter, `search`, `getActivityFilterOptionsService`).
9. **Risks:** `OperationalDashboardDTO` multi-sprint shape change touches dashboard API test expectations -> update `sprint6-dashboard.test.ts`, `sprint6-api-routes.test.ts`, and `API-Specification.md` cleanly together.
10. **Definition of Done:** All `BUG-701`–`BUG-704` closed, boundary UIs & UX consistency complete, unit tests passing.

---

### Package 4: Comprehensive Testing (Unit, Integration, Playwright E2E, Security & Lab Performance Benchmark)

1. **Objective:** Execute thorough automated testing across Unit, PostgreSQL Integration (`TEST_DATABASE_URL`), Playwright Browser E2E (Workflows A–H with Event-to-Report Verification Matrix), Security/IDOR, Responsive UX, and transparent Lab Performance + DB Latency benchmarking.
2. **Scope:** Install `@playwright/test` (`devDependencies`), build `tests/integration/sprint7-cross-module.test.ts` and `tests/integration/sprint7-seed-safety.test.ts`, implement `tests/e2e/*.spec.ts`, execute Security & IDOR tests, and capture Lab Performance baselines (`N >= 5`).
3. **Prerequisites:** Packages 1–3 complete; `akatsuki_yui_test` migrated & seeded cleanly.
4. **Tasks:**
   - Add **Seed Idempotency & Strict Permission Preservation Integration Tests** (`tests/integration/sprint7-seed-safety.test.ts` — proving repeated seed never changes existing Admin `fullName`/`passwordHash` or reactivates `SUSPENDED` Admin, AND enforcing the exact 6-step permission preservation check: (1) Admin revokes permission [including testing a role with 0 remaining permissions], (2) run `seed.ts` a second time, (3) assert permission stays revoked, (4) Admin revokes `project.template.manage`, (5) run `seed.ts` again, (6) assert `project.template.manage` is never re-granted!).
   - Add **Cross-Module Integration Suite** (`tests/integration/sprint7-cross-module.test.ts`) verifying end-to-end DB truth across Workflows A–H strictly per Section 8 **Event-to-Report Verification Matrix** (never assuming unrelated metrics or `AuditLog` in `/activity`), plus concurrent Last-Admin, Task Archive `FOR SHARE`, and Sliding Window Rate Limit concurrency/cleanup races.
   - Configure `playwright.config.ts` targeting `next build && next start` on isolated `TEST_DATABASE_URL` and implement:
     - `tests/e2e/01-auth-rbac-and-session.spec.ts` (Workflows A & B + `tokenVersion` invalidation after password change & suspend/reactivate).
     - `tests/e2e/02-project-task-sprint.spec.ts` (Workflows C, D, E + multi-active sprints + DAG dependency + complete sprint rollover).
     - `tests/e2e/03-docs-notifications-reports.spec.ts` (Workflows F, G, H + multi-run same-day Cron `/api/internal/notifications/process` idempotency check strictly against `TEST_DATABASE_URL` + Dashboard/Reports switcher + `MEMBER` `SELF_ONLY` & `ARCHIVED` read-only).
     - `tests/e2e/04-security-idor-and-ux.spec.ts` (IDOR direct HTTP checks, Sliding Window `429` burst + successful-login non-increment check on test server, CSP compliance, invalid `callbackUrl`, `404`/`error`/`access-denied`, viewports `375px`/`768px`/`1280px`).
   - **Lab Performance Benchmark (Local Production Build):** Seed realistic sample data in `akatsuki_yui_test` (e.g., 150 Tasks, 5 Sprints, 10 Users, 300 Activity records), measure `N >= 5` runs (`N >= 20` on critical routes where P75/P95 is reported) via Lighthouse / Playwright Performance Observer recording **Environment, Viewport/Device, Network Conditions, Sample Count, P50/P75/P95, Cold Start vs Warm, Lab LCP, Lab CLS, and Interaction Latency** (flagged strictly as **Lab Performance**, never Field CWV) on Initial Load, Dashboard, Reports, Task List, and Activity Cursor Pagination.
5. **Expected Files:** `playwright.config.ts`, `tests/integration/sprint7-seed-safety.test.ts`, `tests/integration/sprint7-cross-module.test.ts`, `tests/e2e/01..04*.spec.ts`, `package.json`.
6. **Dependencies:** Packages 1–3.
7. **Acceptance Criteria:**
   - `100%` of `test:unit`, `test:integration`, and `test:e2e` pass (`0` skipped, `0` relaxed assertions).
   - `0 Critical` / `0 High` unresolved bugs or security flaws.
   - Explicit `TC-*` matrix mapped to `Testing-Strategy.md`.
   - Lab Performance benchmark log completed honestly with full environment/network/sample metadata and no Field CWV overclaiming.
8. **Test Cases:** Sections 8 & 9 matrices + 6-step Seed Permission Preservation + Lab Performance benchmarks.
9. **Risks:** Running Playwright `next build && next start` accidentally using `.env` instead of `TEST_DATABASE_URL` -> force explicit test server env overrides (`DATABASE_URL = TEST_DATABASE_URL`, `DIRECT_URL = TEST_DATABASE_URL`) exclusively inside `playwright.config.ts` / test runner after verifying `TEST_DATABASE_URL` isolation guard!
10. **Definition of Done:** Full automated test pyramid green, strict seed preservation proved, local Lab performance benchmarked cleanly.

---

### Package 5: Production Configuration, Safe Seed & Deployment Preparation

1. **Objective:** Harden build, runtime DB pooling, `/api/health`, strictly non-destructive `prisma/seed.ts`, and `.env.example` (executed during Package 5 implementation, never during planning) for zero-cost Production deployment on **Neon Free + Vercel Hobby (`sin1`) + Resend Free** (`DEC-059`–`DEC-062`, `DEC-067`).
2. **Scope:** Healthcheck endpoint, Prisma production singleton & PgBouncer prep, `postinstall` + `prisma` dependency placement, permission-preserving `seed.ts`, `authConfig` `trustHost: true`, `env.ts` runtime check, `.env.example` (blank values reflecting least-privilege runtime vs operator separation), and `pg_dump` backup runbook.
3. **Prerequisites:** Package 4 green; PO confirms Vercel Hobby ToS/age eligibility & privacy/AI opt-out conditions (`OQ-702` precondition).
4. **Tasks:**
   - **Health Endpoint:** Implement `GET /api/health` (and `/api/v1/health` re-export) running `SELECT 1` with `Cache-Control: no-store`, returning `200 { status: "ok", db: "up" }` or sanitized `503` (zero internal DB errors or secrets).
   - **Prisma & Build Prep (`DEP-701`):** Add `"postinstall": "prisma generate"` in `package.json`; evaluate `prisma` in `dependencies` vs build availability (since `prisma migrate deploy` runs separately from Operator/Migration runner before deploy per `DEC-067`, keep build clean and fast with `prisma generate` + `next build`); enable `globalForPrisma.prisma = prisma` in production (`src/lib/prisma.ts`); verify `authConfig` sets `trustHost: true`; invoke runtime env validation safely inside server entrypoints without blocking `next build` static export (do **not** require `DIRECT_URL` inside Vercel Runtime server startup).
   - **Vercel Singapore Region Prep:** Add `"regions": ["sin1"]` (or verify Dashboard Function Region setting `sin1` — single region only per Hobby cap) alongside existing `crons` (`0 1 * * *`) in `vercel.json`.
   - **Safe Idempotent `prisma/seed.ts` (`DEC-067` — Zero Re-Granting of Revoked Permissions):**
     - Split clearly inside `prisma/seed.ts` into:
       1. `seedPermissionCatalog()`: upsert `Permission` definitions (`code`, `name`, `description`) idempotently without adding/deleting/modifying any `RolePermission` rows.
       2. `bootstrapDefaultRolePermissionsForNewRoles()`: **ONLY** assign default `RolePermission` rows when creating a **brand-new `Role`** record (or gated by an explicit persistent bootstrap marker row stored in DB — **NEVER checking `count === 0`** and **NEVER looping unconditionally to re-add `project.template.manage`**; `project.template.manage` is granted to existing `ADMIN` roles **strictly once** via the Package 2 SQL migration or persistent marker). Re-running `seed.ts` NEVER restores permissions intentionally revoked by Admin (even if a Role was stripped to 0 permissions).
       3. `bootstrapInitialAdmin()`: read `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` / `SEED_ADMIN_NAME`; if User email already exists, **skip updating `fullName`, `passwordHash`, or `status`** (`update: {}`, never reactivating a suspended admin!).
   - **Environment Prep (Package 5 Implementation Only):** Update `.env.example` cleanly with **all values completely empty** (`VAR=`, zero dummy strings), documenting clearly that pooled `DATABASE_URL` powers runtime while `DIRECT_URL` / `SEED_ADMIN_*` belong strictly to Operator / Migration runs (`§11`), and double-check zero client bundle secrets (`NEXT_PUBLIC_*`).
   - **Backup & Recovery Runbook:** Document pre-migration Neon manual snapshot + `pg_dump --format=custom` CLI workflow + branch restore drill instructions.
5. **Expected Files:** `src/app/api/health/route.ts`, `src/app/api/v1/health/route.ts`, `package.json`, `vercel.json`, `src/lib/prisma.ts`, `src/lib/auth.config.ts`, `src/lib/env.ts`, `prisma/seed.ts`, `.env.example`.
6. **Dependencies:** Package 4; PO confirmation of Vercel ToS/privacy readiness.
7. **Acceptance Criteria:**
   - `/api/health` tested (`200` DB up, `503` masked DB down).
   - `seed.ts` 6-step Permission Preservation & Admin safety integration suite passes 100%.
   - `.env.example` contains strictly empty values (`VAR=`); `next build` succeeds cleanly with `NODE_ENV=production` without requiring `DIRECT_URL` at runtime.
8. **Test Cases:** `tests/unit/sprint7-health-env.test.ts` (`/api/health`, `env.ts`), re-run `sprint7-seed-safety.test.ts` on final `seed.ts`.
9. **Risks:** Running `prisma generate` vs cached Vercel `node_modules`: mitigated cleanly by `"postinstall": "prisma generate"`.
10. **Definition of Done:** Package 5 build, healthcheck, strict seed preservation, and `.env.example` verified locally.

---

### Package 6: Production Provisioning, Migration, Deployment & Safe Smoke Verification

1. **Objective:** Provision Neon PostgreSQL 18 (Singapore) and Vercel Hobby (`sin1`), safely apply Production migrations (`prisma migrate deploy`) from Operator environment and one-time Admin seed, deploy Vercel Runtime with **least-privilege pooled `DATABASE_URL` only**, verify Resend & Cron safely, and run strictly non-destructive Production Smoke Verification + Lab/WAN Measurements (`DEC-059`–`DEC-062`, `DEC-067`).
2. **Scope:** PO/operator Neon & Vercel environment injection (never sharing `.env` secrets with Agent), manual migration deployment over `DIRECT_URL` from Operator CLI, one-time Admin seed, Vercel deployment (`DATABASE_URL` only — **no `DIRECT_URL`, no `SEED_ADMIN_*`**), PgBouncer verification, non-destructive Production Smoke Verification, and Production Cold/Warm Lab/WAN Measurements.
3. **Prerequisites:** Package 5 complete; PO supplies/configures Neon (`DATABASE_URL` in Vercel Runtime + local `.env`; `DIRECT_URL` **exclusively** in Operator environment / future dedicated Migration runner), Resend API Key / custom domain or Demo confirmation (`OQ-704`), and confirms Vercel account ToS & Privacy/AI opt-out settings (`OQ-702`).
4. **Tasks:**
   - **Neon & Least-Privilege Provisioning (`DEC-067`):** PO provisions Neon PostgreSQL 18 in Asia-Pacific (Singapore `ap-southeast-1`), sets pooled `DATABASE_URL` for Vercel Production Runtime, and retains `DIRECT_URL` **strictly in the Operator workstation / Migration Runner environment** (never pushed into Vercel Runtime Environment; if automated CI migrations are added later, scope `DIRECT_URL` strictly to the isolated Migration Job).
   - **Pre-Deploy Migration & One-Time Seed (`DEC-067`):**
     - Take initial Neon snapshot / baseline check.
     - From Operator CLI targeting `DIRECT_URL`, run `npx prisma migrate deploy`; verify `_prisma_migrations`, partial unique indexes (`Project_single_active_idx`, etc.), `RateLimitEvent` (+ indexes), `User.tokenVersion`, one-time `project.template.manage` `ADMIN` default grant, and triggers (`trg_task_sprint_same_project`, `trg_document_sprint_same_project`).
     - From Operator CLI, run `npx prisma db seed` **once** with temporary `SEED_ADMIN_EMAIL` / `SEED_ADMIN_PASSWORD` / `SEED_ADMIN_NAME`; immediately verify Admin login and unset `SEED_ADMIN_*` afterwards (**never store `SEED_ADMIN_*` in Vercel Runtime**).
   - **Vercel Deployment:** Configure **only** pooled `DATABASE_URL`, `AUTH_SECRET`, `AUTH_URL`, `NEXT_PUBLIC_APP_URL`, `AUTH_TRUST_HOST=true`, `CRON_SECRET`, `RESEND_API_KEY`, `EMAIL_FROM` (plus optional `RATE_LIMIT_SECRET`) in Vercel Project Settings (`Production`) — **explicitly excluding `DIRECT_URL` and `SEED_ADMIN_*`**. Verify Function Region `sin1` & AI/Privacy toggles, and deploy.
   - **PgBouncer Compatibility Verification:** Test safe read/session flows and non-destructive `$transaction` behavior against Neon pooled `DATABASE_URL` to confirm zero `42P05` prepared statement errors (only add `?pgbouncer=true` if observed in real logs!).
   - **Strictly Non-Destructive Production Smoke Checklist & Lab/WAN Telemetry:**
     1. Verify `GET https://<prod-url>/api/health` -> `200` + HTTP security headers (`CSP`, `HSTS`, `X-Frame-Options`, etc.) + unauthenticated protected-route checks (`401`/`403`/redirect without mutations).
     2. Verify safe Admin session/role views in read-only mode (zero destructive operations, zero mass/junk data creation, zero bulk emails or unintended notifications; **Rate Limit `429` burst testing stays strictly in Preview / `TEST_DATABASE_URL`, NOT Production**).
     3. Inspect pending `NotificationDelivery` rows **before** running Production Cron; invoke manual `GET /api/internal/notifications/process` with `Authorization: Bearer <CRON_SECRET>` **ONLY after Operator inspects pending deliveries and explicitly approves the run** (verify invalid token returns `401`; **same-day multi-run Cron dedup tests run strictly on `TEST_DATABASE_URL`, NOT Production**).
     4. Confirm Resend configuration matches active `OQ-704` mode transparently without sending unintended notifications.
     5. Capture **Production Lab/WAN Cold Start (after >5 min Neon idle) vs Warm Request telemetry (`N >= 5`)** recording Environment, Viewport/Device, Network Conditions, Sample Count, P50/P75/P95, Interaction Latency (reported strictly as **Lab/WAN telemetry, not Field CWV**) across `/login`, `/dashboard`, `/projects`, `/reports`, `/activity`; verify Vercel Runtime Logs show `0` unhandled `500` errors.
5. **Expected Files:** None in app source (smoke verification record, deployed Production URL, and Lab/WAN Cold/Warm telemetry captured for Package 7 reports).
6. **Dependencies:** Package 5.
7. **Acceptance Criteria:**
   - Live HTTPS Production URL passes all non-destructive Smoke Verification items with zero `500` errors and zero secret/PII leaks.
   - Vercel Production Runtime contains pooled `DATABASE_URL` only (zero `DIRECT_URL`, zero `SEED_ADMIN_*`).
   - Migrations, partial indexes, triggers, Admin login, Resend readiness, Operator-approved Cron check, and `RateLimitEvent` table verified cleanly.
   - Actual Production Lab/WAN telemetry recorded transparently (Cold vs Warm, Viewport/Network/Sample Count).
8. **Test Cases:** 5-group Non-Destructive Production Smoke Matrix + Production Lab/WAN Telemetry Log.
9. **Risks:**
   - `42P05` error over Neon `-pooler` -> tested explicitly in step 4; if triggered, append `?pgbouncer=true` per Prisma 6 docs and re-verify.
   - Unintended Production emails or premature Cron trigger -> prevented by pre-Cron `NotificationDelivery` inspection + mandatory Operator approval gate.
10. **Definition of Done:** Production deployment live with least-privilege DB env, healthy, non-destructively smoke-verified, and benchmarked cleanly.

---

### Package 7: Documentation Synchronization, Backup, Final Regression & Handover Release

1. **Objective:** Synchronize all repository documentation to actual shipped MVP state, archive independent documentation backup (`DEC-068`), run final clean regression, write `report/SPRINT-7-IMPLEMENTATION-REPORT.md`, and complete `dev -> main` MVP release.
2. **Scope:** Docs sync across `README.md` & `markdown/*`, 12-step Deployment/Installation + User/Admin + Troubleshooting Guides, final test/security/performance/completion reports, off-disk backup verification, and final Git merge/tag.
3. **Prerequisites:** Packages 1–6 completed.
4. **Tasks:**
   - Update `README.md` (fix `29` -> `28` permissions count, add live deployment notes, split `test:unit`/`test:integration`/`test:e2e`, reference Deployment & Troubleshooting guide cleanly without secrets).
   - Sync `markdown/04-Technical-Specifications/Development-Guidelines.md` (§6 env vars list matching `.env.example` & least-privilege `DIRECT_URL` separation, §7/§11 Vercel Hobby `sin1` + Neon Free + Resend Free procedures covering all **12 onboarding/deployment steps**, §12 `dev`/`feat/*` Git branches, §14 Neon PITR + `pg_dump` backup procedure, §16 close `DEV-003, 006..012`, remove `Recharts`).
   - Create concise User Guide & Admin Guide (`markdown/05-Quality-and-Delivery/User-and-Admin-Guide.md`) covering workflows A–H, Resend Demo vs Verified Domain caveats, and known MVP boundaries.
   - Sync remaining specs:
     - Remove `Recharts` & `[CHƯA XÁC ĐỊNH]` placeholders in `Project-Overview.md`, `PROJECT-IMPLEMENTATION-ROADMAP.md`, `Software-Architecture-Document.md`.
     - Update `Authorization-Design.md` (add `project.template.manage` 28-permission matrix & `tokenVersion`).
     - Update `Database-Design.md` (`TaskHistory`, `estimateHours`, `DocumentCategory`, Sprint 6–7 indexes, `User.tokenVersion`, `RateLimitEvent` Sliding Window Log).
     - Update `API-Specification.md` (fix `KEEP_IN_SPRINT` & `/notifications/.../read`, add `/api/health`, `/api/internal/notifications/process`, rate-limit `429`/`503` fail-closed semantics, body/array limits, multi-active-sprint Dashboard DTO).
     - Update `UI-UX-Design.md` (align Dashboard §6.2 to `DEC-051`, document `error.tsx`/`not-found.tsx`/`loading.tsx`, close resolved `UI-001..012`).
     - Update `Testing-Strategy.md` (document Vitest unit/integration (`TEST_DATABASE_URL`) + Playwright E2E, add Sprint 4–7 `TC-*` IDs & Event-to-Report Matrix, distinguish Lab Performance vs Field CWV, close stale `TEST-*` open items).
     - Update `Business-Rules-and-Workflows.md`, `Software-Requirements-Specification.md`, `Use-Case-Specification.md` (close resolved items and clearly tag post-MVP items).
     - Update `markdown/DOCUMENT-INVENTORY.md`.
   - **Independent Documentation Backup (`DEC-068`):** Keep `.gitignore` unchanged; package `markdown/`, `report/`, and `README.md` into an independent archive stored **off the development workstation drive** (e.g., private cloud drive / secondary storage, verified zero secrets included), and test opening & extracting the backup archive!
   - Write **`report/SPRINT-7-IMPLEMENTATION-REPORT.md`** containing: Final Regression Results, Security Verification Report, Transparent Lab & WAN Performance Benchmark Report (explicitly recording Environment, Device/Viewport, Network Conditions, Sample Count, P50/P75/P95, Cold Start vs Warm, Interaction Latency, and NOT claiming Field CWV pass from Lab runs alone), Non-Destructive Smoke Evidence, Known Limitations, and MVP Completion Sign-Off.
   - Execute final full check (`npm run typecheck`, `npm run lint`, `npm run prisma:validate`, `npm run test:unit`, `npm run test:integration`, `npm run test:e2e`, `npm run build`), merge `feat/sprint7-finalization-deployment` -> `dev` -> `main`, and tag `v1.0.0-mvp`.
5. **Expected Files:** `README.md`, `markdown/DOCUMENT-INVENTORY.md`, `markdown/*` spec & guide files, `report/SPRINT-7-IMPLEMENTATION-REPORT.md`.
6. **Dependencies:** Packages 1–6.
7. **Acceptance Criteria:**
   - Zero contradictions between code, `DECISION-LOG.md`, `README.md`, and `markdown/*`.
   - Off-disk archive backup verified readable/extractable and contains zero secrets.
   - Final checks pass `100%` after last edit; `main` cleanly reflects final `v1.0.0-mvp` release.
8. **Test Cases:** Fresh onboarding run check against `README.md` + archive extraction test + final full regression run.
9. **Risks:** Leaving gitignored docs unbacked-up or leaking `.env` into backup zip -> exclude `.env*` explicitly before archiving and inspect archive manifest!
10. **Definition of Done:** Documentation synchronized, backup verified, final reports complete, `main` tagged and handed over.

---

## 8. E2E Testing Strategy (Cross-Module Workflows A–H)

Automated tests split strictly into:
1. **`tests/unit/`** (mocked/fast service, Zod limit, security helper tests),
2. **`tests/integration/`** (PostgreSQL 18 via mandatory `TEST_DATABASE_URL` = `akatsuki_yui_test`),
3. **`tests/e2e/`** (Playwright headless Chromium against `next build && next start` pointed cleanly at `TEST_DATABASE_URL`).

| Workflow | End-to-End Business Flow Verified | Cross-Module Downstream Verification & Security Boundaries |
|---|---|---|
| **A. Account Lifecycle** | Register (`/register`) -> `PENDING` blocked at Login -> Admin approves (`APPROVE`) -> Active user logs in -> Second user rejected (`REJECT`) blocked -> Active user changes Password (`tokenVersion++`, old cookie revoked!) -> Admin suspends active user (`SUSPEND`, `tokenVersion++`, immediate session kill) -> Admin reactivates (`ACTIVATE`, old cookie still invalid; requires fresh login) -> Dynamic RBAC update. | `ActivityLog` (`projectId: null`) entries checked inside Unified Activity History `/activity` (`SOURCE=WORKSPACE`, visible to `ADMIN`, hidden from `MEMBER`); `AuditLog` rows verified **separately** in `AuditLog` audit storage (never assumed inside `/activity`, and Unified Activity History scope is NOT expanded to ingest `AuditLog`); `ACCOUNT_REGISTERED/APPROVED/REJECTED` create notifications/deliveries. |
| **B. Authorization** | Test all 4 roles (`ADMIN`, `LEADER`, `INSTRUCTOR`, `MEMBER`): Admin permission matrix live updates + `CORE_ADMIN_PERMISSION_LOCKED` (`409`) + Last-Admin protection (`409` incl. concurrency); Instructor read-only on assigned projects (`403` mutations & unassigned projects); Leader manages project/members but **cannot** mutate workspace Templates (`403` per `DEC-064`); direct REST `/api/v1/*` IDOR probes fail closed (`403`). | Enforced server-side regardless of UI button visibility; dynamic grant/revoke reflects on next request via `loadTrustedAuthContext`. |
| **C. Project Lifecycle** | Create Project (with/without Template/Instructor) -> Add `ACTIVE` Members -> Transfer Project Leader -> Activate Project (`ACTIVE`) -> Attempt second concurrent `ACTIVE` Project (`409`) -> Archive (`ARCHIVED`, all mutations in Tasks/Sprints/Members/Docs blocked `409`) -> Non-Admin restore blocked (`403`) -> Admin Restore (`CREATED` / `ACTIVE` obeying Single Active rule). | Departed members (`leftAt != null`) remain included with badge in Member Contribution (`DEC-050`); Archived projects remain readable across Dashboard switcher, Reports, Documents & Activity (`DEC-053`); `ProjectMember` events propagate to `ActivityLog`. |
| **D. Task Management** | Create Backlog Tasks (with/without assignees, `estimateHours`, `deadline`, `referenceLinks`) -> Edit Task -> Multi-Assignee + Unassign -> Add Task Dependency DAG (`A -> B`, reject cycle `409`, block completing dependent before predecessor) -> Member updates allowed fields/status (`TODO -> IN_PROGRESS -> REVIEW`, forbidden field edit returns `403`) -> Reviewer Rejects (mandatory reason) -> Resubmit -> Approve (`DONE`). | **`TaskAssignee` current (`removedAt == null`) vs historical (`removedAt != null`)** stays separated; `TaskHistory` checked cleanly in **Task Activity Stream** and `/activity` `TASK` stream; `TaskReview` & `TaskHistory` feed verifiable Member Contribution action counters (`DEC-049`/`P0-02`); review/assign notifications fire cleanly. |
| **E. Sprint Management** | Create `PLANNED` Sprint -> Open Sprint Detail (backlog candidate loader works within `pageSize <= 50`) -> Assign Tasks from Backlog -> Activate Sprint (`ACTIVE`) -> Create & Activate second concurrent `ACTIVE` Sprint (`DEC-006`) -> Move Task via Kanban & between Sprints -> Complete Sprint rolling unfinished tasks to Backlog / Target Sprint -> Inspect Burndown & Sprint 6-metric Analytics. | Editing `estimateHours` after Sprint completion does **not** alter reconstructed Sprint Baseline/Completion burndown analytics (`DEC-058`/`P0-01`); Dashboard & Project Analytics show multiple active Sprints cleanly (`DEC-006`). |
| **F. Document Library** | Add valid `https://drive.google.com/...` & `https://docs.google.com/...` linked to same-project Sprint -> Reject `http:`, `javascript:`, lookalike hosts, cross-project `sprintId` -> Enforce Project permission + block non-member (`403`) -> Soft delete (`deletedAt`) -> Block mutations when Project `ARCHIVED` (`409`). | Active list hides soft-deleted docs; Doc create/delete events populate `ActivityLog.projectId` and surface in `/activity` & Project summary card (not in Task KPIs). |
| **G. Notifications** | Trigger Task Assign, Review Approve/Reject, Project Member/Leader changes, Account Approved/Rejected, and 24h Deadline Reminder batch -> Check In-App bell/unread count/Mark Read/Mark Unread/Mark All Read -> Simulate Resend failure (`onboarding@resend.dev` 403 or unconfigured key) -> Inspect `NotificationDelivery` history (`retryCount`, error message) -> Admin Manual Retry (blocked after `retryCount >= 3` & rate-limited `429`) -> Run Cron `/api/internal/notifications/process` twice same day strictly on `TEST_DATABASE_URL` verifying `dedupKey` zero duplicates. | Failed Resend dispatch **never** rolls back originating Task/Project transaction; non-owner notification read update returns `403`. |
| **H. Dashboard & Reports Verification** | Open `/dashboard` (KPIs, Project Switcher Active-first, Work vs Timeline Progress, Active Sprints, My Tasks, Recent Activity, Admin summary) -> Navigate to `/reports` -> Switch Active & Archived projects (no stale data!) -> Verify Member Contribution (`Sole/Co-Assigned` non-additive totals, Current vs Historical distinct counts, Departed toggle, Coverage disclaimers, **`MEMBER` sees `SELF_ONLY` row**) -> Verify Project Analytics 6 SVG charts (`7d/30d/90d/all/custom <= 365d`, weekly `>90d`) -> Verify Sprint Analytics -> Page `/activity` via keyset cursor & filters (`search`, `entityType: "ProjectMember"`, `action`, `source`). | Verified strictly against the **Event-to-Report Verification Matrix** below: each event from Workflows A–G is checked only in matching metrics while preserving non-additive counts (`DEC-047`), Current vs Historical assignment separation (`DEC-049`), Sprint Estimate Reconstruction (`P0-01`), and `AuditLog` separation. |

### 8.1. Cross-Module Event-to-Report Verification Matrix

Downstream verification checks **only** the specific widgets/streams whose metric definitions include each Business Event (never forcing an event into unrelated views, never summing incompatible metrics, and never mixing `AuditLog` into `/activity`):

| Origin Event (Workflows A–G) | Operational `/dashboard` | Member Contribution (`/reports`) | Project Analytics (`/reports`) | Sprint Analytics & Burndown | `/activity` & Task Stream | Separate Storage / Scope Guard |
|---|---|---|---|---|---|---|
| **Account Approve / Reject / Suspend / PW Change (A, B)** | Admin Account Summary counts (`ADMIN` only) | Excluded | Excluded | Excluded | `ActivityLog` (`SOURCE=WORKSPACE`, `ADMIN` only) | `AuditLog` verified separately in Audit table (NOT `/activity`) |
| **Project / Member Add / Depart / Leader Transfer / Archive (C)** | Project Switcher status badge, Active/Archived state | Included via Membership status badge (`DEC-050` departed toggle) | Included in Membership / Team context only | Excluded | `ActivityLog` (`entityType: "ProjectMember"` / `"Project"`) | Archived read-only enforced (`DEC-053`) |
| **Task Create / Edit / Status `DONE` / Review / Reassign (D)** | Work Progress (completed/total tasks), My Tasks, Urgent Summary | **Non-additive (`DEC-047`)**: `Sole` + `Co-Assigned`; **Current vs Historical (`DEC-049`/`P0-02`)** distinct counts + `TaskReview` / `TaskHistory` action counts | Throughput, Status/Priority/Overdue charts within selected window | Included if linked to Sprint (within `DEC-058` rules) | `TaskHistory` in **Task Activity Stream** + `/activity` `TASK` stream | Does NOT sum Member rows to Project total; Review actions do NOT measure work hours |
| **Sprint Plan / Activate / Complete / Rollover + Post-Completion `estimateHours` Edit (E)** | Timeline Progress (`startDate`/`endDate`), Multi-Active Sprints (`DEC-006`) | Reflects current vs historical task state without double-counting rolled tasks | Sprint velocity / throughput timelines | **`P0-01` Estimate Reconstruction**: Baseline & historical Burndown remain immutable after completion | `ActivityLog` (`entityType: "Sprint"`) + `TaskHistory` move events | Never conflates Timeline Progress with Task Work Progress (`DEC-051`) |
| **Document Create / Soft Delete (F)** | Excluded from Task/Sprint KPIs (Doc card summary if shown) | Excluded | Excluded from Task charts | Excluded | `ActivityLog` (`entityType: "Document"`, `PROJECT` stream) | Soft-deleted docs excluded from active lists (`DEC-035`) |
| **Notifications / Email Deliveries / Cron (G)** | Notification bell & Admin delivery alerts | Excluded | Excluded | Excluded | Excluded from `/activity` Task/Workspace streams | Verified in `/notifications`, `/admin/notifications/deliveries`, and `AuditLog`/`NotificationDelivery` |

---

## 9. Security Testing Strategy

Executed in Package 2 + Package 4 (`tests/unit/sprint7-security.test.ts`, `tests/integration/sprint7-rate-limit-and-locks.test.ts`, `tests/integration/sprint7-cross-module.test.ts`, `tests/e2e/04-security-idor-and-ux.spec.ts`):

1. **Auth & Session Revocation (`DEC-063`):** Verify old JWT cookie fails cleanly (`401`/`403`/redirect `/login`) immediately after password change, immediate block on `SUSPEND`, and old JWT from before suspension stays invalid after `ACTIVATE`. Verify `PENDING` / `REJECTED` blocked at login; cookies have `HttpOnly`, `SameSite=Lax`, and `Secure` over HTTPS.
2. **PostgreSQL Sliding Window Rate Limiting & Anti-DoS (`DEC-065`):** Hit login/register/manual-retry above configured windows on isolated `TEST_DATABASE_URL` / Preview environment (**never Production**): verify exact **Sliding Window boundary bursts** across window edges, verify **window slide/expiry counter reset**, verify `auth:login:ip` counts all requests while `auth:login:fail` `(IP + email)` increments **only on failed auth** and **successful login does NOT increment failed attempts**, verify **per-request duplicate-check guard** prevents double counting across Route/Action/Credentials layers, verify DB rate-limit error on sensitive endpoints **fails closed with safe `503`**, verify concurrent requests serialize cleanly via `pg_advisory_xact_lock`, verify CTE `LIMIT 200` cleanup removes expired rows while preserving active events, verify brute-force on `(IP_A + victim@email)` does **not** lock `victim@email` from `IP_B`, verify spoofed `X-Forwarded-For` cannot bypass trusted platform IP key, and verify zero email enumeration.
3. **RBAC, Template Isolation (`DEC-064`) & IDOR:** Probe every `/api/v1/*` & Server Action with unauthorized roles, cross-project UUIDs, `LEADER` calling Template mutations (`403`), `MEMBER` requesting peer Member Contribution (`SELF_ONLY` single-row invariant), `MEMBER` hitting peer/system Activity logs, cross-project dependencies/moves/documents, non-owner notification marks (`403`), Last-Admin concurrent race, and concurrent Task update vs `ARCHIVE` (`FOR SHARE`).
4. **HTTP Security, Validation, Injection, XSS & Leaks:** Inspect production response headers (`CSP`, `HSTS` on HTTPS, `X-Frame-Options`, `X-Content-Type-Options`, `Referrer-Policy`, absence of `X-Powered-By`); test `parseJsonBody` > `64 KB` rejection; test SQLi payloads in search/cursor; test `<script>` payloads and `javascript:`/`data:` links across Tasks/Docs/Notifications; test `callbackUrl=//evil.com` & `/\evil.com`; confirm zero secrets/DB URLs/cleartext passwords/full emails in error responses, logs, and client JS bundles.

---

## 10. Deployment Architecture (`DEC-059` – `DEC-062`)

### 10.1. Verified Provider Stack & Official Free-Tier Constraints

| Layer | Approved Selection | Official Limits & Verified Behavior (2026-11) | Operational Caveats & Conditions |
|---|---|---|---|
| **App Hosting & Scheduled Cron** | **Vercel Hobby** (`$0/mo`, region **`sin1`** Singapore) | • **Functions:** max **300s** duration, **1M invocations/mo**, **4 CPU-hrs / 360 GB-hrs**.<br>• **Transfer:** **100 GB** Fast Data + **10 GB** Origin/mo.<br>• **Builds:** 45m max, 100 deploys/day, 1 concurrent.<br>• **Cron:** max **1 run/day** per job (jitter within hour; `GET` + `Authorization: Bearer CRON_SECRET`).<br>• **Region:** Single region `sin1` supported on Hobby. | **Mandatory Conditions (`DEC-059`):** Strictly non-commercial portfolio/demo; account manager must satisfy Vercel Terms of Service & age eligibility (eligible adult manages account if primary dev is underage — never falsify info); disable/opt out AI Model Training / review privacy preferences **before** loading any live team data. |
| **PostgreSQL 18 Database** | **Neon Free Plan** (`$0/mo`, Asia-Pacific Singapore) | • **Storage:** **1 GB / project** (writes blocked if exceeded).<br>• **Compute:** **100 CU-hrs/mo**, autoscale up to 2 CU.<br>• **Auto-suspend:** **Scale to zero after 5 min inactivity** (cannot disable on Free; cold wake ~300–800ms).<br>• **Connections:** **10,000** PgBouncer pooled (`-pooler`) / **112** direct (~105 app).<br>• **Recovery:** **6h PITR** + **1 manual snapshot**, **10 branches**. | Co-locates cleanly with Vercel `sin1`. Verify Prisma 6.19.3 compatibility on `-pooler` in Package 6 before adding `?pgbouncer=true`. Supplement 6h PITR with manual snapshots + CLI `pg_dump` backups. |
| **Transactional Email** | **Resend Free Tier** (`$0/mo`, `DEC-045`) | • **3,000 emails/mo**, **100 emails/day** (UTC midnight reset), **10 req/s** API cap, **3 verified domains**.<br>• **`onboarding@resend.dev` cap:** Sends **only to the Resend account owner email** (`403` for all others). | If verified custom domain available (`OQ-704` input) -> full team delivery; otherwise explicitly operate in **Demo / Owner-only Mode** (`DEC-061`). |

### 10.2. Production Topology

```mermaid
flowchart LR
    Browsers["Users (HTTPS)"] -->|"sin1 Edge/Serverless"| Vercel["Vercel Hobby (Next.js 16 + Auth.js JWT + PG Sliding-Window Limiter)"]
    Cron["Vercel Cron (0 1 * * * UTC / 08:00 UTC+7)"] -->|"GET + Bearer CRON_SECRET"| Vercel
    Vercel -->|"Pooled SSL (DATABASE_URL ONLY)"| NeonPool["Neon PgBouncer (-pooler)"]
    NeonPool --> Neon["Neon PostgreSQL 18 (1 GB Free, 5m idle suspend)"]
    AdminCLI["Operator CLI / Migration Runner"] -->|"Direct SSL (DIRECT_URL ONLY)"| Neon
    Vercel -->|"Resend SDK + idempotencyKey"| Resend["Resend API (3,000/mo, 100/day)"]
```

---

## 11. Environment Variable Inventory (All Values Empty — No Secrets Stored)

Verified against `src/lib/env.ts`, codebase `process.env.*` usages, and `.env.example`:
- **Least-Privilege Provisioning (`DEC-067`):** Product Owner configures pooled `DATABASE_URL` in local `.env` and Vercel Production Runtime Settings, while **`DIRECT_URL` stays strictly inside Operator workstation / Migration Runner environment (NEVER placed in Vercel Production Runtime)**. If automated CI/CD migrations are introduced post-MVP, grant `DIRECT_URL` strictly to that isolated CI Migration Job only. Agent **must never** inspect, request, print, or store actual values from `.env`.
- Every variable in `.env.example` (updated strictly during Package 5 implementation, never during planning) must hold an **empty value** (`KEY=`) with **zero dummy strings** (`your-secret`, `change-me`, fake URLs/emails).
- No threshold-tuning env vars (like `RATE_LIMIT_MAX_*`) are added (`DEC-065` keeps limits centralized in `src/lib/rate-limit.ts`).

| Variable Name | Source / Code Usage | Dev (`.env`) | Test (CI / Local Test) | Prod (Vercel Runtime Env) | Policy & Purpose |
|---|---|---|---|---|---|
| `DATABASE_URL=` | `prisma/schema.prisma:7` | *(PO local)* | *(Runtime test guard sets from `TEST_DATABASE_URL`)* | *(PO Neon `-pooler` ONLY)* | Pooled PostgreSQL runtime URL (sole DB credential in Vercel Runtime) |
| `DIRECT_URL=` | `prisma/schema.prisma:8` | *(PO local)* | *(Same as `TEST_DATABASE_URL`)* | **NOT SET IN VERCEL RUNTIME** *(Operator / Migration job only)* | Direct PostgreSQL URL strictly for pre-deploy `prisma migrate deploy`, CLI backup `pg_dump`, and one-time seed |
| `TEST_DATABASE_URL=` | **New (`DEC-066`)** `tests/setup-env.ts` | *(Empty / local `akatsuki_yui_test`)* | **Required (`akatsuki_yui_test`)** | **NEVER SET IN PROD** | Mandatory isolated test DB; zero fallback to `DATABASE_URL` |
| `NODE_ENV=` | `src/lib/env.ts:5`, `prisma.ts`, `notification-delivery.service.ts` | `development` | `test` | *(Vercel auto: `production`)* | Environment mode |
| `NEXT_PUBLIC_APP_URL=` | `notification-email.templates.ts:46` | *(Local URL)* | *(Test server URL)* | *(Actual Vercel HTTPS URL)* | Public base URL for email CTA links |
| `AUTH_URL=` | `src/lib/env.ts:9`, `notification-email.templates.ts:47`, Auth.js | *(Local URL)* | *(Test server URL)* | *(Actual Vercel HTTPS URL)* | Canonical Auth.js origin URL |
| `AUTH_TRUST_HOST=` | Auth.js v5 proxy trust (`DEC-060`) | *(Empty/true)* | *(Empty/true)* | `true` | Trusts Vercel forwarded host headers (paired with `trustHost: true`) |
| `AUTH_SECRET=` | `src/lib/env.ts:8`, Auth.js JWT | *(PO random >=32B)* | *(Test random)* | *(Unique Prod random >=32B)* | Signs JWT cookies; never share Dev & Prod secrets |
| `RATE_LIMIT_SECRET=` | **Optional (`DEC-065`)** `src/lib/rate-limit.ts` | *(Optional)* | *(Optional)* | *(Optional)* | Optional independent HMAC key for rate-limit hashes (derives HKDF subkey from `AUTH_SECRET` if left blank) |
| `RESEND_API_KEY=` | `src/lib/env.ts:10`, `email.ts:37,62` | *(Optional)* | *(Blank / test key)* | *(PO Resend key)* | Resend SDK authentication key (server-only) |
| `EMAIL_FROM=` | `src/lib/env.ts:11`, `email.ts:63` | *(Sender)* | *(Sender)* | *(Verified domain or `onboarding@resend.dev`)* | Sender header matching `DEC-061` mode |
| `CRON_SECRET=` | `src/lib/env.ts:12`, `cron-auth.ts` | *(PO random)* | *(Test random)* | *(Unique Prod random >=32B)* | Vercel Cron `Authorization: Bearer` validation (`timingSafeEqual`) |
| `SEED_ADMIN_EMAIL=` | `prisma/seed.ts:72` | *(One-time dev seed)* | *(Test fixture only)* | **NEVER KEEP IN VERCEL RUNTIME** | One-time Admin bootstrap email run from Operator CLI only |
| `SEED_ADMIN_PASSWORD=` | `prisma/seed.ts:73` | *(One-time dev seed)* | *(Test fixture only)* | **NEVER KEEP IN VERCEL RUNTIME** | One-time Admin password matching `DEC-013`; never keep in logs/env long-term |
| `SEED_ADMIN_NAME=` | `prisma/seed.ts:74` | *(One-time dev seed)* | *(Test fixture only)* | **NEVER KEEP IN VERCEL RUNTIME** | Initial Admin display name run from Operator CLI only |

---

## 12. Migration, Seed & Cron Safety (`DEC-062`, `DEC-066`, `DEC-067`)

### 12.1. Migration Deployment & Backup Safety
1. **Strict `prisma migrate deploy`:** Always run `npx prisma migrate deploy` manually from the Operator workstation (or isolated CI Migration Job) using `DIRECT_URL` **before** flipping Production traffic (`DEC-067`). Never run `prisma migrate dev` or destructive resets in Production, and never expose `DIRECT_URL` inside Vercel Runtime Environment.
2. **Pre-Migration Backup:** Neon Free offers 6h PITR + 1 manual snapshot. Always refresh the manual Neon snapshot and execute an encrypted/off-host `pg_dump "$DIRECT_URL" --format=custom` backup prior to Production DDL changes, testing restore on a temporary Neon branch during Package 5/6.

### 12.2. Non-Destructive Idempotent `prisma/seed.ts` — Strict Permission Preservation (`DEC-067`)
Refactor `prisma/seed.ts` into 4 cleanly separated, non-destructive steps proven by `tests/integration/sprint7-seed-safety.test.ts`:
1. **Permission Definition Seeding:** `permission.upsert` idempotently ensures `Permission` catalog definitions (`28` codes, names, descriptions) exist without ever modifying customized `RolePermission` rows.
2. **Strict Creation-Only Role Defaults (NO `count === 0`, NO Unconditional Additive Re-Grant):**
   - **Prohibited pattern:** Never inspect `RolePermission` count (`count === 0`) to decide whether to populate defaults (an Admin intentionally stripping all permissions from a Role would have their revocation overwritten on the next seed!), and never run an unconditional loop adding `project.template.manage` on every seed execution!
   - **Approved mechanism:** Assign default `RolePermission` rows **exclusively when creating a brand-new `Role` (`!existingRole`)** or gated by an explicit persistent database Bootstrap Marker / Version record; deliver the initial `project.template.manage` grant to existing `ADMIN` roles **strictly once** inside the Sprint 7 additive SQL migration (or durable applied-marker record). Repeated `prisma db seed` runs **must never** re-grant any `RolePermission` customized/revoked by an Admin in `/admin/roles`.
3. **One-Time Initial Admin Bootstrap:** If `SEED_ADMIN_EMAIL` & `SEED_ADMIN_PASSWORD` are provided in Operator CLI environment, validate `DEC-013` complexity; if user does not yet exist, create `ACTIVE` Admin + assign `ADMIN` role. **If that User already exists (`update: {}`), NEVER modify `fullName`, NEVER modify `passwordHash`, and NEVER re-activate a `SUSPENDED` account.**
4. **Zero Demo/Mock Data Injection:** Seed creates Roles, Permissions, and optionally the single initial Admin only.

**Mandatory 6-Step Permission Preservation Integration Test (`tests/integration/sprint7-seed-safety.test.ts`):**
1. Admin revokes a permission from a Role via RBAC management (including verifying the edge case where a Role is reduced to `0` permissions).
2. Run `prisma/seed.ts` a second time.
3. Verify the revoked permission **remains revoked** (NOT re-added).
4. Admin revokes `project.template.manage` from `ADMIN`.
5. Run `prisma/seed.ts` again.
6. Verify `project.template.manage` **is NOT automatically re-granted**.

### 12.3. Cron & Email Delivery Reality (`DEC-062`)
- **Initial Send:** Fired asynchronously inside Next.js `after()` right after business DB commit (claimed atomically via `FOR UPDATE SKIP LOCKED`), using Resend `idempotencyKey = notification-delivery:${delivery.id}`.
- **Failed Delivery & Non-Rollback:** Resend outage/rate-limit/`403` never rolls back the Task/Project/Account DB transaction; delivery status & error code/message persist cleanly in `NotificationDelivery` (`SENT` rows are strictly skipped on any retry).
- **Daily Cron Recovery SLA:** Vercel Hobby executes `/api/internal/notifications/process` once daily (`0 1 * * *` = 08:00 `Asia/Ho_Chi_Minh`) + runs PostgreSQL CTE bounded cleanup (`LIMIT 200`) on expired `RateLimitEvent` rows (`expiresAt < NOW()`) + creates daily `TASK_DEADLINE_REMINDER` batch (`dedupKey` idempotent). Because Cron runs once daily, automatic backoff retries (`retryCount = 1..3`) run on the next daily Cron cycle rather than exact `+1m/+5m/+15m` wall-clock timing; urgent failures can be retried via rate-limited Admin Manual Retry (`retryCount < 3`).

---

## 13. Documentation Plan & Off-Disk Backup (`DEC-068`)

1. **Synchronize Core Docs (Package 7):** `README.md` (`28` permissions, Vercel+Neon+Resend overview, split test commands), `markdown/DOCUMENT-INVENTORY.md`, `markdown/03-Architecture-and-Design/Authorization-Design.md` (`project.template.manage` & `tokenVersion`), `Database-Design.md` (`TaskHistory`, `estimateHours`, `DocumentCategory`, `User.tokenVersion`, `RateLimitEvent`), `API-Specification.md` (`/api/health`, `/api/internal/notifications/process`, `429`/`503` rate limit, body/array caps, multi-active-sprint DTO, fix `KEEP_IN_SPRINT` & `/read`), `UI-UX-Design.md` (Dashboard `DEC-051`, Error/404/Loading boundaries, `/activity` filters), `Testing-Strategy.md` (`TEST_DATABASE_URL`, Playwright E2E, `TC-*` & Event-to-Report Matrix, Lab Performance vs Field CWV distinction), and clear stale `Recharts` / `[CHƯA XÁC ĐỊNH]` markers across `Project-Overview.md`, `ROADMAP`, `SRS`, `Business-Rules`, `Use-Cases`, `Software-Architecture-Document.md`.
2. **Guides & Reports:** Expand `Development-Guidelines.md` (or linked `Deployment-Guide.md`) with the 12-step local-to-production deployment & troubleshooting runbook; create `markdown/05-Quality-and-Delivery/User-and-Admin-Guide.md`; write `report/SPRINT-7-IMPLEMENTATION-REPORT.md` (Event-to-Report Matrix, E2E Summary, Security Audit Results, Local + Production Lab/WAN Performance & Cold/Warm Benchmarks, Smoke Verification, MVP Sign-off).
3. **Mandatory Backup Retention (`DEC-068`):** Keep `.gitignore` unchanged; after Package 7 doc freeze, package `markdown/`, `report/`, and `README.md` (strictly excluding `.env*`) to an **independent off-workstation backup location** and verify archive integrity/extraction before closing Sprint 7.

---

## 14. Git Workflow

- **Current Verified Baseline:** `feat/sprint6-reporting-analytics-dashboard` (`7d52781`) + 3 uncommitted Sprint 4 fix files (`sprints/[sprintId]/page.tsx`, `sprint-planning.service.ts`, `sprint4-services.test.ts`). **Preserved completely untouched during planning revision.**
- **Execution Sequence (Only when PO authorizes implementation):**
  1. Package 1: Review & commit 3 Sprint 4 fix files -> merge `feat/sprint6-reporting-analytics-dashboard` -> `dev` -> create `feat/sprint7-finalization-deployment`.
  2. Packages 2–5: Package-scoped Conventional Commits on `feat/sprint7-finalization-deployment`; inspect `git status` before every commit so zero `.env*` secrets or local artifacts slip in.
  3. Package 7: Merge `feat/sprint7-finalization-deployment` -> `dev`, run final full verification, merge `dev` -> `main`, and tag `v1.0.0-mvp`.

---

## 15. Risks & Mitigations

| Risk | Severity | Mitigation |
|---|---|---|
| **Vercel Hobby ToS / Age / Privacy Precondition Failure (`OQ-702`)** | **High** | Verify eligibility & opt out of AI Model Training **before** hosting real team data; have eligible adult own Vercel account if needed or halt real-data deploy per `DEC-059`. |
| **Integration Tests Running Against Wrong DB** | **Critical** | Hard `TEST_DATABASE_URL` isolation (`DEC-066`) with zero `.env` fallback implemented first in Package 1. |
| **Resend `onboarding@resend.dev` `403` on Team Emails** | **High** | Disclose Demo/Owner-only mode cleanly (`DEC-061`) unless verified custom domain DNS is configured before Package 6. |
| **Neon Cold Start Latency Affecting LCP Target** | **Medium** | Co-locate Vercel `sin1` + Neon Singapore; stream RSC shells with `loading.tsx`; separate Cold Start vs Warm reporting transparently (`§6.6`). |
| **Prisma 6.19.3 + Neon `-pooler` Prepared Statement (`42P05`)** | **Medium** | Test `$transaction` + DDL explicitly during Package 6 smoke test; add `?pgbouncer=true` **only if verified necessary**; migrations always run over `DIRECT_URL`. |
| **Strict CSP Breaking Radix / Tailwind / Next Runtime** | **Medium** | Validate CSP under Playwright on production `next build && next start` (Package 2/4) without resorting to `unsafe-eval`. |
| **Loss of Gitignored `markdown/` & `report/` Docs** | **High** | Enforce mandatory off-disk archive & extract verification (`DEC-068`). |

---

## 16. Open Questions & Preconditions Status

### 16.1. Approved & Closed Technical Resolutions (`OQ-701` – `OQ-712` -> `DEC-059` – `DEC-069`)

| OQ | Approved Resolution | Mapped Decision | Status |
|---|---|---|---|
| **OQ-701** | Neon Free PostgreSQL 18 (`DATABASE_URL` pooled runtime + `DIRECT_URL` migrations) | `DEC-059` | **Closed (`Approved`)** |
| **OQ-702** | Vercel Hobby (non-commercial portfolio/demo, conditional on ToS/age & privacy checks) | `DEC-059` | **Resolved Policy (`Pending Account Precondition`)** |
| **OQ-703** | Additive `User.tokenVersion` revoking old JWTs on password change & suspend | `DEC-063` | **Closed (`Approved`)** |
| **OQ-704** | Resend Free (`verified domain` if owned, else explicit Demo / Owner-only Mode) | `DEC-061` | **Resolved Policy (`Pending Domain Input`)** |
| **OQ-705** | Default `*.vercel.app`, `AUTH_TRUST_HOST=true` (`trustHost: true`), Region `sin1` | `DEC-060` | **Resolved Policy (`Pending Live URL`)** |
| **OQ-706** | PostgreSQL-backed atomic **Sliding Window Log** rate limiting (`RateLimitEvent`) | `DEC-065` | **Closed (`Approved`)** |
| **OQ-707** | Operator/Migration-only `prisma migrate deploy` (`DIRECT_URL` excluded from Vercel Runtime) & strict permission-preserving seed | `DEC-067` | **Closed (`Approved`)** |
| **OQ-708** | Keep `.gitignore` unchanged; mandatory independent backup of `markdown/` & `report/` | `DEC-068` | **Closed (`Approved`)** |
| **OQ-709** | Daily Vercel Cron (`0 1 * * *`) + Admin Manual Retry (no external scheduler) | `DEC-062` | **Closed (`Approved`)** |
| **OQ-710** | Markdown authoritative; DOCX optional | `DEC-068` | **Closed (`Approved`)** |
| **OQ-711** | No bulk Prettier reformatting across 83 legacy files | `DEC-068` | **Closed (`Approved`)** |
| **OQ-712** | Structured JSON server logs (with PII redaction) + Vercel Runtime Logs; no paid APM | `DEC-069` | **Closed (`Approved`)** |

### 16.2. Pending Operational Inputs Required Before Live Deployment (Package 6 Blockers)

1. **`PEND-701` (Vercel ToS, Eligibility & Privacy Verification — `OQ-702`):** PO must confirm Vercel account owner meets platform Terms of Service / age requirements and has reviewed Data Preferences / AI Model Training opt-out prior to deploying live team data.
2. **`PEND-702` (Resend Sender Domain Decision — `OQ-704`):** PO must provide verified domain DNS confirmation for `EMAIL_FROM`, **or** confirm Package 6 deploys in explicit Demo / Owner-only Mode (`onboarding@resend.dev`).
3. **`PEND-703` (Environment Secrets Provisioning by PO):** PO configures local `TEST_DATABASE_URL` (`akatsuki_yui_test`) before Package 1 execution; prior to Package 6, PO configures **only pooled `DATABASE_URL`** (alongside `AUTH_SECRET`, `RESEND_API_KEY`, `CRON_SECRET`) inside Vercel Production Runtime, keeping `DIRECT_URL` and temporary one-time `SEED_ADMIN_*` **strictly on the Operator CLI / dedicated Migration runner** without exposing values to Agent.
4. **`PEND-704` (Assigned Production URL — `OQ-705`):** Actual `https://<project>.vercel.app` URL recorded into `AUTH_URL`, `NEXT_PUBLIC_APP_URL`, and `SPRINT-7-IMPLEMENTATION-REPORT.md` once Vercel project is created in Package 6.

---

## 17. Decision Log Updates (Recorded & Approved in `markdown/DECISION-LOG.md`)

Confirmed last ID in `markdown/DECISION-LOG.md` prior to Sprint 7 was **`DEC-058 *(OQ-612)***`. All 11 Sprint 7 technical decisions are logged sequentially as **`Approved`** with zero unresolved policy conflicts:

| ID | Topic | Status | Linked OQ / Audit Item |
|---|---|---|---|
| **DEC-059** | Neon Free PostgreSQL 18 + Vercel Hobby (Conditional ToS/Privacy) | **Approved** | `OQ-701`, `OQ-702` |
| **DEC-060** | Vercel Region `sin1`, `*.vercel.app` Default & `AUTH_TRUST_HOST=true` | **Approved** | `OQ-705` |
| **DEC-061** | Resend Free Verified-Domain vs Demo Mode & Member PII Minimization | **Approved** | `OQ-704` |
| **DEC-062** | Daily Vercel Cron + Admin Manual Retry SLA & Non-Rollback | **Approved** | `OQ-709` |
| **DEC-063** | Session Revocation via Additive `User.tokenVersion` | **Approved** | `OQ-703`, `SEC-703` |
| **DEC-064** | Independent `project.template.manage` RBAC Permission | **Approved** | `SEC-702` |
| **DEC-065** | PostgreSQL-Backed Atomic Sliding Window Log Rate Limiting (`RateLimitEvent`) | **Approved** | `OQ-706`, `SEC-701` |
| **DEC-066** | Mandatory `TEST_DATABASE_URL` Isolation (Zero `.env` Fallback) | **Approved** | `TEST-701` (P0) |
| **DEC-067** | Least-Privilege Migration (`DIRECT_URL` Operator-Only) & Strict Permission-Preserving `seed.ts` | **Approved** | `OQ-707` |
| **DEC-068** | `.gitignore` Preserved, Markdown Source & Off-Disk Doc Backup | **Approved** | `OQ-708`, `OQ-710`, `OQ-711` |
| **DEC-069** | Structured JSON Logging (PII Masked) & Free-Tier Runtime Monitoring | **Approved** | `OQ-712` |

---

## 18. Acceptance Criteria (Sprint 7 Exit Gate)

Sprint 7 closes only when **all** gates pass simultaneously:
1. **Workflows & Event-to-Report Matrix:** Unit, PostgreSQL Integration (exclusively on `TEST_DATABASE_URL`), and Playwright E2E pass `100%` across Workflows **A–H**, verifying every event exclusively against its matching Dashboard/Report metrics (`DEC-047`, `DEC-049`/`P0-02`, `DEC-058`/`P0-01`) with `AuditLog` checked separately from `/activity`.
2. **Defects & Security Closed:** **0 Critical** and **0 High** open issues; `BUG-701`–`BUG-704` & `SEC-701`–`SEC-705` verified fixed (`tokenVersion` revocation, `project.template.manage`, `RateLimitEvent` Sliding Window `429` + fail-closed `503` + `seed.ts` 6-step permission preservation, HTTP security headers/CSP, locks, safe redirects, zero secret/PII leaks).
3. **CI & Quality Gates:** `tsc --noEmit`, `eslint .`, `npx prisma validate`, `npm run test:unit`, `npm run test:integration`, `npm run test:e2e`, and `npm run build` pass after the final edit (`0` skipped).
4. **Lab Performance Measured Honestly:** Both Local Production Build and Live Vercel `sin1` + Neon measurements recorded with Environment, Device/Viewport, Network Conditions, Sample Count, P50/P75/P95, Cold Start vs Warm, and Lab LCP/CLS/Interaction Latency — without falsely claiming Field Core Web Vitals compliance from Lab data alone.
5. **Live Production Verified Safely:** `prisma migrate deploy` applied cleanly over Operator `DIRECT_URL` (pooled `DATABASE_URL` only in Vercel Runtime; zero `DIRECT_URL`, zero `SEED_ADMIN_*`), `/api/health` returning `200`, Resend & Operator-approved Cron verified safely without bulk emails or destructive actions (`429` burst & same-day multi-run Cron tests isolated to Preview/`TEST_DATABASE_URL`), zero `500` errors, and Vercel Terms/Privacy preconditions satisfied (`PEND-701`).
6. **Documentation & Backup Complete:** Specs/Guides/Report synchronized, off-disk backup of `markdown/` & `report/` verified extractable, and `dev -> main` tagged `v1.0.0-mvp`.

---

## 19. Definition of Done

- [x] Planning complete (`Final Review Corrections` integrated): `DEC-059`–`DEC-069` logged as `Approved` in `markdown/DECISION-LOG.md` and synchronized in `SPRINT-7-IMPLEMENTATION-PLAN.md`.
- [ ] Operational preconditions (`PEND-701`–`PEND-704`: Vercel ToS/privacy sign-off, Resend domain vs demo mode, PO provisioning `TEST_DATABASE_URL`, pooled `DATABASE_URL` in Vercel Runtime & `DIRECT_URL` in Operator env) ready prior to execution.
- [ ] Package 1 done: Pending Sprint 4 fix committed on PO approval, `feat/sprint7-finalization-deployment` created from `dev`, strict `TEST_DATABASE_URL` isolation verified (`0` fallback).
- [ ] Package 2 done: `tokenVersion`, `RateLimitEvent` Sliding Window Log (+ `503` fail-closed & CTE cleanup), `project.template.manage` (+ one-time migration default grant), locks, bounds, CSP/headers & PII redaction tested and passing.
- [ ] Package 3 done: `BUG-701`–`BUG-704`, boundaries (`error.tsx`/`not-found.tsx`/`loading.tsx`), Toast/Pagination/Activity parity verified.
- [ ] Package 4 done: Unit + Integration (incl. 6-step Seed Permission Preservation, Event-to-Report Matrix, `429`/CTE tests) + Playwright E2E (A–H) + Security + Local Lab Performance Measurements passed (`0` skipped).
- [ ] Package 5 done: `/api/health`, `seed.ts` strict permission preservation proven by integration tests, `postinstall`, `trustHost`, `.env.example` (blank values), and `pg_dump` runbook ready.
- [ ] Package 6 done: `prisma migrate deploy` via Operator `DIRECT_URL`, one-time Admin seed, Vercel `sin1` deploy (`DATABASE_URL` only), PgBouncer check, strictly non-destructive Smoke Verification, Operator-approved Cron/Resend checks & Production Lab/WAN Cold/Warm benchmarks passed.
- [ ] Package 7 done: Docs synced, off-disk backup archive tested, `SPRINT-7-IMPLEMENTATION-REPORT.md` finalized, `dev` merged to `main` & tagged `v1.0.0-mvp`.

---

## 20. Estimated Effort

*Disclaimer: Projected working-day estimates below reflect a 1-engineer / AI-assisted implementation pace and are **not** hard timeline commitments. Package 2 (`RateLimitEvent` Sliding Window + `tokenVersion` + CSP validation) and Package 4 (Playwright E2E + Lab Performance benchmarking) carry the highest test-iteration variance.*

| Package | Focus | Projected Effort |
|---|---|---|
| **Package 1** | Git Checkpoint, Strict `TEST_DATABASE_URL` Guard & Script Split | **0.5 day** |
| **Package 2** | `tokenVersion`, `project.template.manage`, PG Sliding Window, Locks & Headers/CSP | **1.5 – 2.0 days** |
| **Package 3** | `BUG-701`–`BUG-704` Fixes, App Boundaries, Multi-Sprint & Query Polish | **1.0 – 1.5 days** |
| **Package 4** | Playwright Setup, Workflows A–H E2E, Seed Preservation & Lab Benchmarks | **1.5 – 2.0 days** |
| **Package 5** | `/api/health`, Safe `seed.ts`, `prisma` Production Prep, `.env.example` & Runbook | **0.5 – 1.0 day** |
| **Package 6** | Neon/Vercel `sin1` Least-Privilege Deploy, `migrate deploy`, Safe Smoke & Lab/WAN Telemetry | **0.5 – 1.0 day** |
| **Package 7** | Doc Sync (12-Step Guide, User/Admin Guides), Backup Drill & `main` Release | **1.0 day** |
| **Total** | **Sprint 7 Revised Projected Total** | **6.5 – 9.0 working days** |
