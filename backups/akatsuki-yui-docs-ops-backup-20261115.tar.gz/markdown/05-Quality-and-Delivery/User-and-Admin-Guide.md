# User and Administrator Operational Guide — Akatsuki Yui

**Version:** 1.0 (Sprint 7 Finalization)  
**Target Roles:** `ADMIN`, `LEADER`, `INSTRUCTOR`, `MEMBER`

---

## 1. Hướng dẫn dành cho Thành viên (`MEMBER`) & Giảng viên (`INSTRUCTOR`)

### 1.1. Đăng ký & Trạng thái Tài khoản (`DEC-013`, `DEC-014`)
1. Truy cập `/register`, nhập **Họ và tên**, **Email**, và mật khẩu mạnh (tối thiểu 8 ký tự, gồm chữ hoa, chữ thường, chữ số và ký tự đặc biệt).
2. Tài khoản mới mặc định ở trạng thái **`PENDING`** — bạn cần chờ Quản trị viên phê duyệt trước khi đăng nhập tại `/login`.
3. Nếu đăng nhập sai quá ngưỡng bảo mật (`5` lần trong `15` phút theo `IP + Email`), hệ thống tạm giới hạn `429 RATE_LIMIT_EXCEEDED` và tự mở lại sau `Retry-After`.

### 1.2. Hồ sơ cá nhân & Bảo mật Phiên (`DEC-018`, `DEC-063`)
- Tại `/profile`, bạn có thể sửa **Họ và tên** và **Đổi mật khẩu** (bắt buộc nhập mật khẩu hiện tại).
- **Thu hồi phiên tự động:** Ngay sau khi bạn đổi mật khẩu (hoặc khi Admin tạm khóa / thay đổi Role), mọi phiên đăng nhập cũ ở thiết bị/trình duyệt khác sẽ bị vô hiệu hóa ngay lập tức ở request tiếp theo.

### 1.3. Quy trình Công việc hàng ngày (`DEC-015`, `DEC-032`)
- **Dashboard (`/dashboard`):** Chọn Project trong danh sách truy cập để xem tiến độ **Work Progress (`DONE / Total`)** và **Timeline Progress**, cùng danh sách Task của bạn.
- **Task & Review (`/projects/[projectId]/tasks` · `/kanban`):**
  - Chỉ **Assignee** của Task mới có thể chuyển `TODO -> IN_PROGRESS -> REVIEW`, cập nhật ghi chú tiến độ và liên kết tham chiếu (`https://`).
  - Các trường cấu trúc (`Title`, `Description`, `Priority`, `Deadline`, `Estimate`, `Assignees`, `Dependencies`, `Sprint`) chỉ do `LEADER` / `ADMIN` chỉnh sửa.
  - Task chỉ chuyển được sang `DONE` sau khi mọi predecessor trong DAG đã `DONE` và Leader/Admin phê duyệt Review kèm lý do.
- **Tài liệu & Thông báo (`/documents`, `/notifications`):**
  - Nút chuông **Thông báo** hiển thị số chưa đọc từ server (không tự polling nền nhằm tối ưu Free Tier); nhấn vào biểu tượng chuông hoặc nút **Làm mới** để nạp thông báo mới nhất.
  - Giảng viên (`INSTRUCTOR`) có quyền đọc toàn bộ tiến độ, Sprint, Tài liệu, Báo cáo (`PROJECT_FULL`) và Lịch sử hoạt động của các Project được phân công (bao gồm Project `ARCHIVED` ở chế độ chỉ đọc).

---

## 2. Hướng dẫn dành cho Quản lý Nhóm (`LEADER`)

1. **Quản lý Project (`/projects`):**
   - Tạo Project mới (trạng thái `CREATED`), gán Template/Giảng viên hướng dẫn (tùy chọn), thêm thành viên từ danh sách user `ACTIVE`.
   - Workspace chỉ cho phép **01 Project `ACTIVE` tại một thời điểm** (`BR-PROJ-004`). Khi cần kết thúc học kỳ/giai đoạn, lưu trữ (**Archive**) Project cũ trước khi kích hoạt Project mới.
   - Khi gỡ thành viên khỏi Project, phải reassign toàn bộ Task đang giao cho thành viên đó trước (`DEC-009`).
2. **Planning Backlog, Sprint & Kanban (`DEC-026`–`DEC-031`):**
   - Tạo Task trong Product Backlog (`/projects/[projectId]/backlog`), đặt `estimateHours` và thiết lập DAG Dependencies (hệ thống chặn tự động nếu phát hiện chu trình).
   - Có thể kích hoạt đồng thời nhiều Sprint `ACTIVE` trong một Project (`DEC-006`).
   - Khi hoàn thành Sprint (**Complete Sprint**), mọi Task chưa `DONE` bắt buộc chọn **Chuyển về Backlog** hoặc **Chuyển sang Sprint khác (`PLANNED | ACTIVE`)**.
3. **Báo cáo & Truy vết (`/reports`, `/activity`):**
   - Xem báo cáo đóng góp thành viên (phi cộng dồn **Sole vs Co-Assigned**, bao gồm cựu thành viên `leftAt`), 6 biểu đồ phân tích SVG và Sprint Commitment / Rollover.

---

## 3. Hướng dẫn Vận hành dành cho Quản trị viên (`ADMIN`)

### 3.1. Quản lý Tài khoản & Ma trận Phân quyền (`/admin/users`, `/admin/roles`, `/admin/templates`)
- Phê duyệt (`APPROVE`) hoặc Từ chối (`REJECT`) tài khoản mới; Tạm khóa (`SUSPEND`) hoặc Kích hoạt lại (`ACTIVATE`). Khi `SUSPEND`, hệ thống tăng `tokenVersion` để ngắt mọi phiên đang hoạt động của user đó ngay lập tức.
- Bảo vệ **Last Admin Protection**: Không thể hạ Role hay Tạm khóa Admin hoạt động cuối cùng.
- Tại `/admin/roles`: điều chỉnh trực tiếp 28 quyền trên 4 Role (áp dụng ngay cho request kế tiếp). Các **Core Admin Permissions** (`account.*`, `role.manage`, `project.restore`, `notification.delivery.*`) luôn bị khóa bảo vệ trên Role `ADMIN`.
- Project Template (`/admin/templates`) yêu cầu quyền riêng `project.template.manage` (`DEC-064`).

### 3.2. Giám sát Email SMTP & Xử lý `UNKNOWN` (`/admin/notifications/deliveries`, `DEC-070`)
- Hệ thống gửi email qua **Nodemailer SMTP** (tối đa 5 email tức thì/request + tối đa 10 email mỗi lần Cron `0 1 * * *`), bảo vệ ngưỡng gửi bằng rolling quota (`SMTP_DAILY_SEND_LIMIT = 50`, `SMTP_PER_MINUTE_LIMIT = 10`).
- Các trạng thái Email Delivery:
  - `PENDING`: Đang chờ gửi hoặc chờ chu kỳ Cron kế tiếp (khi vượt quota ngày/phút hoặc đang backoff).
  - `SENT`: SMTP đã nhận và trả `250 OK` kèm `Message-ID`.
  - `FAILED`: Gặp lỗi tạm thời/vĩnh viễn (`+1m`, `+5m`, `+15m`). Nếu `retryCount < 3`, Admin có thể bấm **"Thử gửi lại"**.
  - **`UNKNOWN` (Cần kiểm tra thủ công):** Kết nối SMTP bị đứt/timeout *sau* bước truyền dữ liệu (`DATA`), không rõ server đã phát email hay chưa. Hệ thống **khóa auto-retry** để tránh gửi trùng; Admin kiểm tra mailbox/SMTP log trước khi bấm **"Xác nhận gửi lại"**.

### 3.3. Vận hành Migration & Backup (`DEC-067`)
- Luôn dùng **`DIRECT_URL`** (Operator CLI) để chạy `pg_dump --format=custom`, `npx prisma migrate deploy`, và `npx prisma db seed`.
- Trên Vercel Production Env (`sin1`), chỉ nạp pooled `DATABASE_URL` (`-pooler`) cùng `AUTH_*`, `CRON_SECRET`, `SMTP_*`; không nạp `DIRECT_URL` hay `SEED_ADMIN_*`.
- Kiểm tra tình trạng DB bất cứ lúc nào bằng endpoint `GET /api/health`.
